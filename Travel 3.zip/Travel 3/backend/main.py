"""Main FastAPI application entrypoint for the unified Travel-AI platform."""

from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.core.config import settings
from backend.api import (
    itinerary_router,
    routing_router,
    nlp_router,
    profile_router,
    food_router,
    cultural_router,
    blendin_router,
    translation_router,
)

app = FastAPI(
    title=settings.APP_NAME,
    description=(
        "Unified Travel-AI platform: Connecting Natural Language Understanding, "
        "Traveler Personas, Dining Recommendations, Geodesic Corridor Filtering, "
        "OSRM Road Routing, Strict 20m Buffer Optimization, Cultural Etiquette, "
        "BlendIn Authenticity Scoring, and Multilingual Translation."
    ),
    version=settings.APP_VERSION,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register All Domain Routers
app.include_router(itinerary_router)
app.include_router(routing_router)
app.include_router(nlp_router)
app.include_router(profile_router)
app.include_router(food_router)
app.include_router(cultural_router)
app.include_router(blendin_router)
app.include_router(translation_router)

# Static Frontend Assets
frontend_dir = Path(__file__).resolve().parent.parent / "frontend"
if frontend_dir.exists():
    app.mount("/static", StaticFiles(directory=str(frontend_dir)), name="static")


@app.get("/health", tags=["system"])
def health_check():
    """Comprehensive system health status and registered API endpoints."""
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "endpoints": [
            "POST /api/v1/nlp/parse",
            "POST /api/v1/profile/synthesize",
            "POST /api/v1/food/recommend",
            "POST /api/v1/food/meal-window",
            "GET  /api/v1/itinerary/bookings",
            "POST /api/v1/itinerary/nearby-destinations",
            "POST /api/v1/itinerary/discover-corridor",
            "POST /api/v1/itinerary/corridor-pois",
            "POST /api/v1/itinerary/generate-schedule",
            "GET  /api/v1/itinerary/presets",
            "POST /api/v1/routing/route",
            "POST /api/v1/routing/multi-route",
            "POST /api/v1/cultural/guide",
            "POST /api/v1/blendin/score",
            "POST /api/v1/blendin/balance",
            "POST /api/v1/translation/phrase",
            "POST /api/v1/translation/food-bridge",
        ],
    }


@app.get("/", include_in_schema=False)
def serve_root():
    """Serve frontend index.html if available, otherwise return API metadata."""
    index_file = frontend_dir / "index.html"
    if index_file.exists():
        return FileResponse(str(index_file))
    return {
        "message": settings.APP_NAME,
        "docs": "/docs",
        "health": "/health",
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.main:app", host="0.0.0.0", port=8000, reload=True)
