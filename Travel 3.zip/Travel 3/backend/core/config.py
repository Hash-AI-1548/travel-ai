"""Centralized application configuration and runtime settings."""

import os
from typing import List
from pydantic import BaseModel


class Settings(BaseModel):
    """Core settings for Travel-AI platform."""
    APP_NAME: str = "Travel-AI Unified Platform"
    APP_VERSION: str = "1.0.0"
    API_PREFIX: str = "/api/v1"
    DEBUG: bool = os.getenv("DEBUG", "False").lower() in ("true", "1", "yes")
    
    # Routing Engine
    OSRM_ROUTER_URL: str = os.getenv("OSRM_ROUTER_URL", "http://router.project-osrm.org")
    ROUTING_TIMEOUT_SECONDS: float = float(os.getenv("ROUTING_TIMEOUT_SECONDS", "5.0"))
    
    # CORS Origins
    CORS_ORIGINS: List[str] = [
        "http://localhost:8000",
        "http://127.0.0.1:8000",
        "http://localhost:3000",
        "http://localhost:5173",
        "*",
    ]
    
    # Default Corridor & Optimizer Constraints
    DEFAULT_DETOUR_THRESHOLD_KM: float = 3.5
    POST_ARRIVAL_BUFFER_MINUTES: int = 20
    PRE_CHECKIN_BUFFER_MINUTES: int = 20
    DEFAULT_POI_DWELL_MINUTES: int = 45
    DEFAULT_MEAL_DWELL_MINUTES: int = 55


settings = Settings()
