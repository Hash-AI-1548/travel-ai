"""Core configuration package."""

from backend.core.config import Settings, settings

__all__ = ["Settings", "settings"]
