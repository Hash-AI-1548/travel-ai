"""FastAPI routes for travel phrase translation and food cultural bridge."""

from fastapi import APIRouter, HTTPException, status
from backend.schemas.translation import (
    TranslationRequest,
    TranslationResponse,
    FoodBridgeRequest,
    FoodBridgeResponse,
)
from backend.modules.translation.translation_service import (
    get_phrases_for_language,
    get_food_cultural_bridge,
)

router = APIRouter(prefix="/api/v1/translation", tags=["translation"])


@router.post(
    "/phrase",
    response_model=TranslationResponse,
    status_code=status.HTTP_200_OK,
    summary="Get essential multilingual phrases for dining, greetings, and transit",
)
def get_travel_phrases(request: TranslationRequest) -> TranslationResponse:
    """Returns curated phrases categorized with phonetics and usage tips."""
    try:
        return get_phrases_for_language(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Translation error: {str(e)}")


@router.post(
    "/food-bridge",
    response_model=FoodBridgeResponse,
    status_code=status.HTTP_200_OK,
    summary="Get culinary cultural bridge explaining foreign dish ingredients, allergens, and etiquette",
)
def get_culinary_bridge(request: FoodBridgeRequest) -> FoodBridgeResponse:
    """Translates foreign culinary terminology with allergen warnings and dining tips."""
    try:
        return get_food_cultural_bridge(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Food bridge error: {str(e)}")
