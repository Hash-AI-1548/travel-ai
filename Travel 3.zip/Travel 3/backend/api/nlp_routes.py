"""FastAPI routes for NLP travel intent parsing."""

from fastapi import APIRouter, HTTPException, status
from backend.schemas.nlp import NLPParseRequest, NLPParseResponse
from backend.modules.nlp.nlp_parser import parse_trip_query

router = APIRouter(prefix="/api/v1/nlp", tags=["nlp"])


@router.post(
    "/parse",
    response_model=NLPParseResponse,
    status_code=status.HTTP_200_OK,
    summary="Extract structured travel parameters from freeform query",
)
def parse_nlp_intent(request: NLPParseRequest) -> NLPParseResponse:
    """Parses freeform prompt into destination, party size, pace, interests, and timing."""
    try:
        return parse_trip_query(request.query)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"NLP parsing error: {str(e)}")
