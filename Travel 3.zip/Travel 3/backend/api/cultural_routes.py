"""FastAPI routes for cultural etiquette and attire guidance."""

from fastapi import APIRouter, HTTPException, status
from backend.schemas.cultural import CulturalGuideRequest, CulturalGuideResponse
from backend.modules.cultural.cultural_service import get_cultural_guide

router = APIRouter(prefix="/api/v1/cultural", tags=["cultural"])


@router.post(
    "/guide",
    response_model=CulturalGuideResponse,
    status_code=status.HTTP_200_OK,
    summary="Get destination etiquette, tipping norms, and attire guidelines",
)
def get_culture_guide(request: CulturalGuideRequest) -> CulturalGuideResponse:
    """Returns local etiquette, cathedral/temple dress codes, and dining customs."""
    try:
        return get_cultural_guide(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Cultural guide error: {str(e)}")
