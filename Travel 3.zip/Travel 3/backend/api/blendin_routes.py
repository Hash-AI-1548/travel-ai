"""FastAPI routes for BlendIn authenticity scoring and balancing."""

from fastapi import APIRouter, HTTPException, status
from backend.schemas.blendin import (
    BlendInScoreRequest,
    BlendInScoreResponse,
    BlendInItineraryRequest,
    BlendInItineraryResponse,
)
from backend.modules.blendin.blendin_service import (
    calculate_blendin_score,
    balance_itinerary_blendin,
)

router = APIRouter(prefix="/api/v1/blendin", tags=["blendin"])


@router.post(
    "/score",
    response_model=BlendInScoreResponse,
    status_code=status.HTTP_200_OK,
    summary="Compute authenticity vs familiarity metrics for a POI or stop",
)
def compute_blendin_score(request: BlendInScoreRequest) -> BlendInScoreResponse:
    """Calculates local authenticity score, familiarity score, and patronage."""
    try:
        return calculate_blendin_score(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"BlendIn scoring error: {str(e)}")


@router.post(
    "/balance",
    response_model=BlendInItineraryResponse,
    status_code=status.HTTP_200_OK,
    summary="Balance an itinerary against a target BlendIn preference slider",
)
def balance_itinerary(request: BlendInItineraryRequest) -> BlendInItineraryResponse:
    """Re-ranks or weights itinerary stops to match desired authenticity balance."""
    try:
        return balance_itinerary_blendin(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"BlendIn balance error: {str(e)}")
