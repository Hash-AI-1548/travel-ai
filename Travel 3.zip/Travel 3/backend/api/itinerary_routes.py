"""FastAPI API routes for POI Corridor Filtering, Ranking, and Dynamic Buffer Itinerary Planning."""

from typing import Any, Dict, List
from fastapi import APIRouter, HTTPException, status
from backend.modules.itinerary.poi_service import (
    filter_pois_along_corridor,
    generate_candidate_pois_for_corridor,
    generate_nearby_destinations,
    get_hotel_bookings,
)
from backend.modules.itinerary.poi_ranker import rank_corridor_pois
from backend.modules.itinerary.itinerary_optimizer import generate_optimized_itinerary
from backend.schemas.poi import (
    BookingsResponse,
    CandidatePOI,
    Coordinate,
    CorridorPOIRequest,
    CorridorPOIResponse,
    DestinationOption,
    DiscoverCorridorRequest,
    DiscoverCorridorResponse,
    HotelBooking,
    NearbyDestinationsRequest,
    NearbyDestinationsResponse,
    RankedPOI,
    TravelerPreferences,
)
from backend.schemas.itinerary import (
    ItineraryGenerationRequest,
    ItineraryResponse,
)

router = APIRouter(prefix="/api/v1/itinerary", tags=["itinerary"])


@router.get(
    "/bookings",
    response_model=BookingsResponse,
    status_code=status.HTTP_200_OK,
    summary="Retrieve confirmed hotel reservations for booking-aware destination selection",
)
def get_user_bookings() -> BookingsResponse:
    """Return active confirmed hotel bookings with check-in/out dates and coordinates."""
    raw_bookings = get_hotel_bookings()
    bookings = [HotelBooking(**b) for b in raw_bookings]
    return BookingsResponse(bookings=bookings)


@router.post(
    "/nearby-destinations",
    response_model=NearbyDestinationsResponse,
    status_code=status.HTTP_200_OK,
    summary="Find candidate hotel and destination checkpoints near user coordinates",
)
def get_nearby_destinations(request: NearbyDestinationsRequest) -> NearbyDestinationsResponse:
    """Find candidate hotels and destination checkpoints relative to the user's real location."""
    try:
        raw_destinations = generate_nearby_destinations(request.source, request.radius_km)
        destinations = [DestinationOption(**d) for d in raw_destinations]
        return NearbyDestinationsResponse(destinations=destinations, source=request.source)
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Nearby destination error: {str(e)}")


@router.post(
    "/discover-corridor",
    response_model=DiscoverCorridorResponse,
    status_code=status.HTTP_200_OK,
    summary="Discover candidate POIs along any arbitrary S -> D transit corridor",
)
def discover_corridor_pois(request: DiscoverCorridorRequest) -> DiscoverCorridorResponse:
    """Dynamically generate candidate POIs along any arbitrary real coordinate corridor S -> D."""
    try:
        candidate_pois = generate_candidate_pois_for_corridor(request.source, request.destination)
        return DiscoverCorridorResponse(
            source=request.source,
            destination=request.destination,
            candidate_pois=candidate_pois,
        )
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Corridor discovery error: {str(e)}")



@router.post(
    "/corridor-pois",
    response_model=CorridorPOIResponse,
    status_code=status.HTTP_200_OK,
    summary="Filter and rank candidate POIs along a finite transit corridor",
)
def get_corridor_pois(request: CorridorPOIRequest) -> CorridorPOIResponse:
    """
    Filter candidate POIs against the finite S -> D corridor using geodesic distance.
    Deterministically scores each candidate against traveler preferences and assigns
    traffic-light classification (GREEN >= 0.65, YELLOW 0.35-0.65, RED < 0.35).
    """
    try:
        # 1. Geodesic Corridor Filtering
        evaluated_pois = filter_pois_along_corridor(
            source=request.source,
            destination=request.destination,
            candidate_pois=request.candidate_pois,
            detour_threshold_km=request.detour_threshold_km,
        )

        # 2. Preference Ranking & Traffic-Light Classification
        ranked_pois = rank_corridor_pois(
            evaluated_pois=evaluated_pois,
            preferences=request.preferences,
            detour_threshold_km=request.detour_threshold_km,
            current_time=request.current_time,
        )

        filtered_count = sum(1 for p in ranked_pois if p.is_inside_corridor)

        return CorridorPOIResponse(
            corridor_pois=ranked_pois,
            total_candidates=len(request.candidate_pois),
            filtered_count=filtered_count,
            detour_threshold_km=request.detour_threshold_km,
            source=request.source,
            destination=request.destination,
        )
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Corridor calculation error: {str(e)}")


@router.post(
    "/generate-schedule",
    response_model=ItineraryResponse,
    status_code=status.HTTP_200_OK,
    summary="Generate optimized chronological itinerary enforcing 20m arrival and pre-checkin buffers",
)
def generate_schedule(request: ItineraryGenerationRequest) -> ItineraryResponse:
    """
    Builds a chronological timeline enforcing:
    - Rule 1: Mandatory 20-minute post-arrival buffer at transit hub.
    - Rule 2: Mandatory >=20-minute pre-checkin buffer before hotel check-in.
    - Explicitly reports feasibility, transit legs, dwell times, and buffer guarantees.
    """
    try:
        response = generate_optimized_itinerary(request)
        return response
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Itinerary optimization error: {str(e)}")



@router.get(
    "/presets",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get curated travel corridor presets with candidate POIs and realistic transit scenarios",
)
def get_corridor_presets() -> Dict[str, Any]:
    """Curated presets for instant exploration across iconic travel corridors."""
    return {
        "presets": [
            {
                "id": "paris_hub_marais",
                "name": "Paris: Charles de Gaulle (CDG) to Le Marais Boutique Hotel",
                "city": "Paris, France",
                "source": {"lat": 49.0097, "lon": 2.5479, "name": "Paris CDG Airport (Terminal 2)"},
                "destination": {"lat": 48.8575, "lon": 2.3622, "name": "Hotel Le Marais Prestige"},
                "transit_arrival_time": "13:30",
                "check_in_time": "18:00",
                "detour_threshold_km": 3.5,
                "transit_mode": "driving",
                "preferences": {
                    "preferred_tags": ["art", "history", "architecture", "cafe"],
                    "pace": "moderate",
                    "max_detour_km": 3.5,
                },
                "candidate_pois": [
                    {
                        "id": "louvre",
                        "name": "Louvre Museum & Cour Napoléon",
                        "lat": 48.8606,
                        "lon": 2.3376,
                        "category": "Museum",
                        "tags": ["art", "museum", "history", "culture", "monument"],
                        "rating": 4.9,
                        "estimated_dwell_minutes": 60,
                        "address": "Rue de Rivoli, 75001 Paris",
                        "image_url": "https://images.unsplash.com/photo-1565099824688-e93eb20fe622?w=600&auto=format&fit=crop&q=80",
                        "description": "World famous art museum featuring the Mona Lisa and glass pyramid.",
                    },
                    {
                        "id": "rest_bistro_marais",
                        "name": "Bistrot des Vosges (Classic French Dining)",
                        "lat": 48.8558,
                        "lon": 2.3667,
                        "category": "Restaurant",
                        "tags": ["food", "restaurant", "bistro", "french", "wine", "lunch", "dinner"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 55,
                        "address": "31 Boulevard Beaumarchais, 75004 Paris",
                        "description": "Celebrated Parisian bistro serving traditional duck confit and seasonal specialties.",
                        "cuisine": "French Traditional",
                        "service_hours": {
                            "lunch": ["12:00", "14:30"],
                            "dinner": ["19:00", "22:30"],
                        },
                        "meal_types": ["lunch", "dinner"],
                        "price_tier": "$$$",
                    },
                    {
                        "id": "notre_dame",
                        "name": "Cathédrale Notre-Dame de Paris",
                        "lat": 48.8530,
                        "lon": 2.3499,
                        "category": "Historical Monument",
                        "tags": ["history", "architecture", "gothic", "monument"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 45,
                        "address": "6 Parvis Notre-Dame, 75004 Paris",
                        "image_url": "https://images.unsplash.com/photo-1549144511-f099e773c147?w=600&auto=format&fit=crop&q=80",
                        "description": "Masterpiece of French Gothic architecture on the Île de la Cité.",
                    },
                    {
                        "id": "pompidou",
                        "name": "Centre Pompidou Modern Art",
                        "lat": 48.8606,
                        "lon": 2.3522,
                        "category": "Art Gallery",
                        "tags": ["art", "modern", "architecture", "exhibition"],
                        "rating": 4.6,
                        "estimated_dwell_minutes": 45,
                        "address": "Place Georges-Pompidou, 75004 Paris",
                        "image_url": "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&auto=format&fit=crop&q=80",
                        "description": "High-tech architectural icon housing the National Museum of Modern Art.",
                    },
                    {
                        "id": "sainte_chapelle",
                        "name": "Sainte-Chapelle Royal Chapel",
                        "lat": 48.8554,
                        "lon": 2.3450,
                        "category": "Historical Monument",
                        "tags": ["history", "architecture", "stained-glass", "culture"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 40,
                        "address": "10 Boulevard du Palais, 75001 Paris",
                        "image_url": "https://images.unsplash.com/photo-1583037189850-1921ae7c6c22?w=600&auto=format&fit=crop&q=80",
                        "description": "Gothic gem renowned for its 13th-century radiant stained-glass windows.",
                    },
                    {
                        "id": "cafe_flore",
                        "name": "Café de Flore Historic Bistro",
                        "lat": 48.8542,
                        "lon": 2.3325,
                        "category": "Cafe & Dining",
                        "tags": ["cafe", "food", "historic", "coffee", "bistro", "breakfast", "lunch"],
                        "rating": 4.5,
                        "estimated_dwell_minutes": 35,
                        "address": "172 Boulevard Saint-Germain, 75006 Paris",
                        "image_url": "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?w=600&auto=format&fit=crop&q=80",
                        "description": "Legendary Saint-Germain café popular with existentialist writers and artists.",
                        "cuisine": "French Cafe",
                        "service_hours": {
                            "breakfast": ["07:30", "11:30"],
                            "lunch": ["11:30", "16:00"],
                        },
                        "meal_types": ["breakfast", "lunch"],
                    },
                    {
                        "id": "sacre_coeur",
                        "name": "Basilique du Sacré-Cœur (Montmartre)",
                        "lat": 48.8867,
                        "lon": 2.3431,
                        "category": "Landmark",
                        "tags": ["scenic", "viewpoint", "architecture", "church"],
                        "rating": 4.7,
                        "estimated_dwell_minutes": 50,
                        "address": "35 Rue du Chevalier de la Barre, 75018 Paris",
                        "image_url": "https://images.unsplash.com/photo-1509439581779-6298f75bf6e5?w=600&auto=format&fit=crop&q=80",
                        "description": "Romano-Byzantine basilica perched atop Montmartre overlooking the city.",
                    },
                    {
                        "id": "versailles",
                        "name": "Palace of Versailles (Deep Outlier)",
                        "lat": 48.8049,
                        "lon": 2.1204,
                        "category": "Palace",
                        "tags": ["history", "palace", "gardens", "royalty"],
                        "rating": 4.9,
                        "estimated_dwell_minutes": 120,
                        "address": "Place d'Armes, 78000 Versailles",
                        "image_url": "https://images.unsplash.com/photo-1547471080-7cc2caa01a7e?w=600&auto=format&fit=crop&q=80",
                        "description": "Opulent royal residence located well outside the direct transit corridor.",
                    },
                ],
            },
            {
                "id": "tokyo_haneda_shibuya",
                "name": "Tokyo: Haneda Airport (HND) to Shibuya Excel Hotel",
                "city": "Tokyo, Japan",
                "source": {"lat": 35.5494, "lon": 139.7798, "name": "Haneda Airport International Terminal"},
                "destination": {"lat": 35.6591, "lon": 139.7006, "name": "Shibuya Excel Hotel Tokyu"},
                "transit_arrival_time": "14:00",
                "check_in_time": "18:30",
                "detour_threshold_km": 3.5,
                "transit_mode": "transit",
                "preferences": {
                    "preferred_tags": ["food", "scenic", "modern", "gardens"],
                    "pace": "moderate",
                    "max_detour_km": 3.5,
                },
                "candidate_pois": [
                    {
                        "id": "tokyo_tower",
                        "name": "Tokyo Tower Observatory",
                        "lat": 35.6586,
                        "lon": 139.7454,
                        "category": "Landmark",
                        "tags": ["scenic", "viewpoint", "modern", "landmark"],
                        "rating": 4.6,
                        "estimated_dwell_minutes": 45,
                        "address": "4-2-8 Shibakoen, Minato City, Tokyo",
                        "description": "Communications and observation tower offering panoramic views of Tokyo skyline.",
                    },
                    {
                        "id": "rest_tokyo_ramen",
                        "name": "Ichiran Ramen Shibuya & Dining",
                        "lat": 35.6618,
                        "lon": 139.7003,
                        "category": "Restaurant",
                        "tags": ["food", "restaurant", "ramen", "japanese", "lunch", "dinner"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 45,
                        "address": "1-22-7 Jinnan, Shibuya City, Tokyo",
                        "description": "Famous tonkotsu ramen dining experience with custom flavor profiling.",
                        "cuisine": "Japanese Ramen",
                        "service_hours": {
                            "lunch": ["11:00", "15:00"],
                            "dinner": ["17:00", "23:00"],
                        },
                        "meal_types": ["lunch", "dinner"],
                        "price_tier": "$$",
                    },
                    {
                        "id": "roppongi_hills",
                        "name": "Roppongi Hills & Mori Art Museum",
                        "lat": 35.6605,
                        "lon": 139.7292,
                        "category": "Art & Observation",
                        "tags": ["art", "modern", "scenic", "shopping"],
                        "rating": 4.5,
                        "estimated_dwell_minutes": 50,
                        "address": "6-10-1 Roppongi, Minato City, Tokyo",
                        "description": "Integrated cultural hub with contemporary art museum and rooftop sky deck.",
                    },
                    {
                        "id": "meiji_shrine",
                        "name": "Meiji Jingu Shinto Shrine",
                        "lat": 35.6764,
                        "lon": 139.6993,
                        "category": "Shrine & Forest",
                        "tags": ["history", "gardens", "culture", "nature"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 45,
                        "address": "1-1 Yoyogikamizonocho, Shibuya City, Tokyo",
                        "description": "Serene forest shrine dedicated to Emperor Meiji in the heart of Shibuya.",
                    },
                    {
                        "id": "tsukiji_outer",
                        "name": "Tsukiji Outer Food Market",
                        "lat": 35.6655,
                        "lon": 139.7707,
                        "category": "Culinary & Market",
                        "tags": ["food", "market", "culinary", "seafood", "street-food", "lunch"],
                        "rating": 4.7,
                        "estimated_dwell_minutes": 40,
                        "address": "4-16-2 Tsukiji, Chuo City, Tokyo",
                        "description": "Historic seafood and street food stalls with fresh sushi and sashimi.",
                        "cuisine": "Japanese Seafood",
                        "service_hours": {
                            "lunch": ["09:00", "14:30"],
                        },
                        "meal_types": ["lunch"],
                    },
                ],
            },
            {
                "id": "nyc_jfk_manhattan",
                "name": "New York: JFK Airport to Central Park South Hotel",
                "city": "New York, USA",
                "source": {"lat": 40.6413, "lon": -73.7781, "name": "JFK Airport (Terminal 4)"},
                "destination": {"lat": 40.7663, "lon": -73.9774, "name": "The Plaza Hotel Central Park"},
                "transit_arrival_time": "12:45",
                "check_in_time": "17:00",
                "detour_threshold_km": 4.0,
                "transit_mode": "driving",
                "preferences": {
                    "preferred_tags": ["architecture", "park", "food", "viewpoint"],
                    "pace": "moderate",
                    "max_detour_km": 4.0,
                },
                "candidate_pois": [
                    {
                        "id": "dumbo_waterfront",
                        "name": "DUMBO & Brooklyn Bridge Park",
                        "lat": 40.7033,
                        "lon": -73.9897,
                        "category": "Scenic Waterfront",
                        "tags": ["scenic", "viewpoint", "park", "architecture"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 45,
                        "address": "1 Water St, Brooklyn, NY 11201",
                        "description": "Iconic Manhattan skyline views and cobblestone historic streets.",
                    },
                    {
                        "id": "rest_river_cafe",
                        "name": "The River Café & Grill",
                        "lat": 40.7037,
                        "lon": -73.9936,
                        "category": "Restaurant",
                        "tags": ["food", "restaurant", "american", "scenic", "lunch", "dinner"],
                        "rating": 4.8,
                        "estimated_dwell_minutes": 60,
                        "address": "1 Water St, Brooklyn, NY 11201",
                        "description": "Michelin-starred American cuisine with dramatic panoramic views of Manhattan skyline.",
                        "cuisine": "American Contemporary",
                        "service_hours": {
                            "lunch": ["12:00", "14:30"],
                            "dinner": ["17:30", "22:00"],
                        },
                        "meal_types": ["lunch", "dinner"],
                        "price_tier": "$$$$",
                    },
                    {
                        "id": "grand_central",
                        "name": "Grand Central Terminal",
                        "lat": 40.7527,
                        "lon": -73.9772,
                        "category": "Landmark",
                        "tags": ["architecture", "history", "food", "landmark"],
                        "rating": 4.7,
                        "estimated_dwell_minutes": 35,
                        "address": "89 E 42nd St, New York, NY 10017",
                        "description": "Beaux-Arts transit palace with celestial ceiling and gourmet food hall.",
                    },
                    {
                        "id": "high_line",
                        "name": "The High Line Elevated Park",
                        "lat": 40.7480,
                        "lon": -74.0048,
                        "category": "Park & Promenade",
                        "tags": ["park", "scenic", "art", "walk"],
                        "rating": 4.7,
                        "estimated_dwell_minutes": 45,
                        "address": "Meatpacking to Hudson Yards, New York",
                        "description": "Elevated freight rail line transformed into a lush public park above Manhattan.",
                    },
                ],
            },
        ]
    }
