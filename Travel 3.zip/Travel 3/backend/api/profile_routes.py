"""FastAPI routes for traveler profile synthesis."""

from fastapi import APIRouter, HTTPException, status
from backend.schemas.profile import TravelerProfileInput, ProfileSynthesizeResponse
from backend.modules.profile.profile_service import synthesize_traveler_profile

router = APIRouter(prefix="/api/v1/profile", tags=["profile"])


@router.post(
    "/synthesize",
    response_model=ProfileSynthesizeResponse,
    status_code=status.HTTP_200_OK,
    summary="Synthesize traveler persona, pacing and interest weights",
)
def synthesize_profile(request: TravelerProfileInput) -> ProfileSynthesizeResponse:
    """Builds a structured traveler profile with calculated affinities and pacing."""
    try:
        return synthesize_traveler_profile(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Profile error: {str(e)}")
