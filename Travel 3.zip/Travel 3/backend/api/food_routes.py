"""FastAPI routes for restaurant recommendation and meal timing."""

from fastapi import APIRouter, HTTPException, status
from backend.schemas.food import (
    FoodRecommendationRequest,
    FoodRecommendationResponse,
    MealTimeMatchRequest,
    MealTimeMatchResponse,
)
from backend.modules.food.food_service import recommend_restaurants
from backend.modules.food.meal_time import validate_service_hours

router = APIRouter(prefix="/api/v1/food", tags=["food"])


@router.post(
    "/recommend",
    response_model=FoodRecommendationResponse,
    status_code=status.HTTP_200_OK,
    summary="Recommend candidate restaurants filtered by cuisine, dietary, and meal windows",
)
def get_food_recommendations(request: FoodRecommendationRequest) -> FoodRecommendationResponse:
    """Discovers restaurants around coordinates matched to meal windows and cuisines."""
    try:
        return recommend_restaurants(request)
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Food recommendation error: {str(e)}")


@router.post(
    "/meal-window",
    response_model=MealTimeMatchResponse,
    status_code=status.HTTP_200_OK,
    summary="Validate service hour availability for a planned arrival time",
)
def check_meal_timing(request: MealTimeMatchRequest) -> MealTimeMatchResponse:
    """Checks whether restaurant service hours accommodate target arrival time."""
    try:
        is_open, meal_type, msg = validate_service_hours(request.service_hours, request.target_time)
        return MealTimeMatchResponse(
            is_open=is_open,
            matched_meal_type=meal_type,
            message=msg,
        )
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Meal timing validation error: {str(e)}")
