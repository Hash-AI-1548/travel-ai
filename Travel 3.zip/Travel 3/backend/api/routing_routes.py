"""FastAPI API routes for Road Routing and Multi-Segment Itinerary Navigation."""

from typing import List
from fastapi import APIRouter, HTTPException, status
from backend.modules.routing.routing_service import get_road_route, get_multi_segment_route
from backend.schemas.routing import (
    MultiSegmentRouteRequest,
    MultiSegmentRouteResponse,
    RouteRequest,
    RouteResponse,
)

router = APIRouter(prefix="/api/v1/routing", tags=["routing"])


@router.post(
    "/route",
    response_model=RouteResponse,
    status_code=status.HTTP_200_OK,
    summary="Calculate road distance, duration, and GeoJSON geometry for a single travel leg",
)
def calculate_road_route(request: RouteRequest) -> RouteResponse:
    """
    Route a single origin-destination leg along the actual road network.
    Returns exact road distance (km/meters), duration (minutes/seconds), and GeoJSON LineString geometry.
    """
    try:
        route = get_road_route(request.origin, request.destination, request.mode)
        return route
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Routing error: {str(e)}")


@router.post(
    "/multi-route",
    response_model=MultiSegmentRouteResponse,
    status_code=status.HTTP_200_OK,
    summary="Independently road-route all consecutive segments in an itinerary waypoint chain",
)
def calculate_multi_segment_route(request: MultiSegmentRouteRequest) -> MultiSegmentRouteResponse:
    """
    Route all consecutive itinerary legs:
    Point 0 -> Point 1, Point 1 -> Point 2, ..., Point N-1 -> Point N.
    Returns structured list of road-routed segments with independent GeoJSON LineStrings.
    """
    try:
        segments = get_multi_segment_route(request.points, request.mode)
        total_dist = round(sum(s.distance_km for s in segments), 2)
        total_dur = sum(s.duration_minutes for s in segments)
        return MultiSegmentRouteResponse(
            segments=segments,
            total_distance_km=total_dist,
            total_duration_minutes=total_dur,
        )
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(ve))
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=f"Multi-routing error: {str(e)}")
