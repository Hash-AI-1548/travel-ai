"""API route registration package for Travel-AI platform."""

from backend.api.itinerary_routes import router as itinerary_router
from backend.api.routing_routes import router as routing_router
from backend.api.nlp_routes import router as nlp_router
from backend.api.profile_routes import router as profile_router
from backend.api.food_routes import router as food_router
from backend.api.cultural_routes import router as cultural_router
from backend.api.blendin_routes import router as blendin_router
from backend.api.translation_routes import router as translation_router

__all__ = [
    "itinerary_router",
    "routing_router",
    "nlp_router",
    "profile_router",
    "food_router",
    "cultural_router",
    "blendin_router",
    "translation_router",
]
