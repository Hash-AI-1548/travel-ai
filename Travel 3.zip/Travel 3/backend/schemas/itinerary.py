"""Pydantic schemas for Itinerary Optimization, Timelines, Events, and Buffer Statuses."""

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from backend.schemas.poi import Coordinate, TrafficLightClassification


class TimelineEventType(str, Enum):
    """Types of timeline events in the chronological itinerary."""
    TRANSIT_ARRIVAL = "TRANSIT_ARRIVAL"
    BUFFER = "BUFFER"
    TRANSIT = "TRANSIT"
    POI_VISIT = "POI_VISIT"
    MEAL_STOP = "MEAL_STOP"
    HOTEL_CHECKIN_ARRIVAL = "HOTEL_CHECKIN_ARRIVAL"


class ItineraryStop(BaseModel):
    """An individual stop (POI or Restaurant) to include in the itinerary schedule."""
    poi_id: str = Field(..., description="Unique POI identifier")
    name: str = Field(..., description="POI or Restaurant name")
    lat: float = Field(..., ge=-90.0, le=90.0, description="Latitude")
    lon: float = Field(..., ge=-180.0, le=180.0, description="Longitude")
    dwell_minutes: int = Field(default=45, ge=5, le=360, description="Time spent at the POI/Restaurant in minutes")
    category: Optional[str] = Field(default="General", description="POI category (e.g. Museum, Restaurant, Park)")
    tags: List[str] = Field(default_factory=list, description="POI interest tags")
    preference_score: Optional[float] = Field(default=None, ge=0.0, le=1.0, description="Preference match score")
    traffic_light: Optional[TrafficLightClassification] = Field(default=None, description="Traffic-light classification")
    cuisine: Optional[str] = Field(None, description="Cuisine type if restaurant")
    service_hours: Optional[dict] = Field(None, description="Opening / service hours")
    meal_type: Optional[str] = Field(None, description="Target meal window (breakfast, lunch, dinner)")
    is_restaurant: Optional[bool] = Field(default=False, description="True if this stop is a restaurant or meal stop")


class TimelineEvent(BaseModel):
    """A discrete chronological event within the itinerary timeline."""
    event_type: TimelineEventType = Field(..., description="Type of event")
    title: str = Field(..., description="Short descriptive title of the event")
    start_time: str = Field(..., description="Start time formatted as HH:MM")
    end_time: str = Field(..., description="End time formatted as HH:MM")
    duration_minutes: int = Field(..., ge=0, description="Duration of this event in minutes")
    location: Optional[Coordinate] = Field(None, description="Primary location coordinate")
    origin_location: Optional[Coordinate] = Field(None, description="Origin coordinate for transit events")
    destination_location: Optional[Coordinate] = Field(None, description="Destination coordinate for transit events")
    transit_mode: Optional[str] = Field(None, description="Transit mode (driving, transit, walking)")
    distance_km: Optional[float] = Field(None, description="Actual road distance in km if transit leg")
    route_geometry: Optional[Dict[str, Any]] = Field(None, description="GeoJSON LineString route geometry")
    road_routed: Optional[bool] = Field(None, description="True if real road-routing engine was used")
    dwell_minutes: Optional[int] = Field(None, description="Dwell duration if POI/Meal visit")
    category: Optional[str] = Field(None, description="POI category if applicable")
    cuisine: Optional[str] = Field(None, description="Cuisine type if restaurant")
    meal_type: Optional[str] = Field(None, description="Meal type if restaurant event")
    traffic_light: Optional[TrafficLightClassification] = Field(None, description="Traffic light classification if POI")
    preference_score: Optional[float] = Field(None, description="Score if POI")
    description: Optional[str] = Field(None, description="Human-readable description or context")
    status_badge: Optional[str] = Field(None, description="Dedicated UI badge label (e.g. '+20m Post-Arrival Buffer')")
    is_buffer_satisfied: Optional[bool] = Field(None, description="True if buffer constraint is satisfied")
    is_meal_open: Optional[bool] = Field(None, description="True if restaurant is verified open during meal stop")
    details: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Additional metadata")


class BufferStatus(BaseModel):
    """Explicit status tracking for mandatory travel buffers."""
    post_arrival_buffer_minutes: int = Field(..., description="Actual post-arrival buffer duration in minutes")
    post_arrival_buffer_satisfied: bool = Field(..., description="Whether the mandatory 20m post-arrival buffer was enforced")
    pre_checkin_buffer_minutes: int = Field(..., description="Available window before hotel check-in time in minutes")
    pre_checkin_buffer_satisfied: bool = Field(..., description="Whether hotel arrival is at least 20m before check-in")
    required_post_arrival_minutes: int = Field(default=20, description="Mandatory post-arrival threshold (20m)")
    required_pre_checkin_minutes: int = Field(default=20, description="Mandatory pre-checkin threshold (20m)")


class ItineraryGenerationRequest(BaseModel):
    """Request payload for generating an optimized chronological itinerary."""
    transit_arrival_time: str = Field(..., description="Transit arrival time (HH:MM or ISO timestamp)")
    check_in_time: str = Field(..., description="Hotel check-in time (HH:MM or ISO timestamp)")
    source: Coordinate = Field(..., description="Source transit hub coordinate")
    destination: Coordinate = Field(..., description="Destination hotel coordinate")
    stops: List[ItineraryStop] = Field(default_factory=list, description="Ordered or candidate stops to include")
    transit_mode: str = Field(default="driving", description="Transit mode: 'driving', 'transit', or 'walking'")
    travel_date: Optional[str] = Field(None, description="Date of travel (YYYY-MM-DD) for cross-midnight scheduling")
    custom_transit_durations: Optional[List[int]] = Field(None, description="Optional override transit minutes between consecutive stops")
    booking_id: Optional[str] = Field(None, description="Optional confirmed booking ID tied to destination hotel")


class ItineraryResponse(BaseModel):
    """Complete optimized itinerary response with timeline, buffer guarantees, and feasibility."""
    is_feasible: bool = Field(..., description="Whether the itinerary satisfies all time and buffer constraints")
    timeline: List[TimelineEvent] = Field(..., description="Chronological list of timeline events")
    buffer_status: BufferStatus = Field(..., description="Explicit buffer guarantee evaluation")
    total_duration_minutes: int = Field(..., description="Total timeline duration from transit arrival to hotel check-in")
    total_transit_minutes: int = Field(..., description="Sum of all transit travel durations in minutes")
    total_dwell_minutes: int = Field(..., description="Sum of all POI/Meal dwell durations in minutes")
    warnings: List[str] = Field(default_factory=list, description="Actionable warning messages if infeasible or tight")
    source: Coordinate = Field(..., description="Source transit hub")
    destination: Coordinate = Field(..., description="Destination hotel")
    summary: Optional[str] = Field(None, description="Summary of the scheduled trip")
