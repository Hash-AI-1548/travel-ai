"""Schemas for real-time travel translations and culinary food bridge."""

from typing import List, Optional
from pydantic import BaseModel, Field


class TravelPhrase(BaseModel):
    """Essential travel phrase representation."""
    category: str  # Greetings, Dining, Navigation, Emergency, Hotel
    source_phrase: str
    target_phrase: str
    pronunciation: str
    context_tip: Optional[str] = None


class TranslationRequest(BaseModel):
    """Request to translate text or retrieve categorized phrases."""
    text: Optional[str] = None
    category: Optional[str] = None
    target_language: str = "fr"  # fr, ja, es, it, de, hi


class TranslationResponse(BaseModel):
    """Response containing phrase translations."""
    phrases: List[TravelPhrase]
    source_language: str = "en"
    target_language: str


class FoodCulturalBridge(BaseModel):
    """Culinary breakdown and cultural bridge for unfamiliar menu items."""
    dish_name: str
    local_name: str
    pronunciation: str
    origin_region: str
    description: str
    key_ingredients: List[str]
    dietary_warnings: List[str] = Field(default_factory=list)  # e.g., "Contains Gluten", "Shellfish", "Pork"
    how_to_eat_etiquette: Optional[str] = None


class FoodBridgeRequest(BaseModel):
    """Request for food cultural bridge explanation."""
    dish_or_item: str
    target_language: str = "fr"


class FoodBridgeResponse(BaseModel):
    """Response with culinary breakdown."""
    bridge: FoodCulturalBridge
