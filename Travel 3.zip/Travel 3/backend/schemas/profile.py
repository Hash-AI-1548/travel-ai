"""Schemas for traveler personas and profile management."""

from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class PacingType(str, Enum):
    RELAXED = "relaxed"
    MODERATE = "moderate"
    FAST = "fast"


class TravelerProfileInput(BaseModel):
    """Input parameters for synthesizing traveler profile."""
    traveler_count: int = Field(default=1, ge=1)
    traveler_ages: List[int] = Field(default_factory=lambda: [30])
    pace: PacingType = PacingType.MODERATE
    interests: List[str] = Field(default_factory=lambda: ["art", "history", "food"])
    cuisines: List[str] = Field(default_factory=list)
    dietary: List[str] = Field(default_factory=list)
    budget: str = "$$"
    blendin_level: float = Field(default=0.5, ge=0.0, le=1.0)
    accessibility: bool = False


class TravelerProfile(BaseModel):
    """Synthesized traveler profile with calculated affinities."""
    persona_id: str
    persona_label: str
    pace: PacingType
    max_stops_per_day: int
    target_dwell_minutes: int
    interest_weights: Dict[str, float]
    dietary_flags: List[str]
    budget_tier: str
    blendin_weight: float
    accessibility_enforced: bool


class ProfileSynthesizeResponse(BaseModel):
    """Response model containing synthesized profile."""
    profile: TravelerProfile
    summary: str
