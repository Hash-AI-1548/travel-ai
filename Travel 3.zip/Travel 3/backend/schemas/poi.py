"""Pydantic schemas for Points of Interest (POI), Coordinates, and Corridor filtering."""

from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field, field_validator


class Coordinate(BaseModel):
    """Geographic coordinate representation with strict latitude/longitude validation."""
    lat: float = Field(..., ge=-90.0, le=90.0, description="Latitude in decimal degrees (-90 to 90)")
    lon: float = Field(..., ge=-180.0, le=180.0, description="Longitude in decimal degrees (-180 to 180)")
    name: Optional[str] = Field(None, description="Human-readable name or label of the location")

    @field_validator("lat")
    @classmethod
    def validate_latitude(cls, v: float) -> float:
        if v < -90.0 or v > 90.0:
            raise ValueError("Latitude must be between -90.0 and 90.0 degrees.")
        return v

    @field_validator("lon")
    @classmethod
    def validate_longitude(cls, v: float) -> float:
        if v < -180.0 or v > 180.0:
            raise ValueError("Longitude must be between -180.0 and 180.0 degrees.")
        return v


class TrafficLightClassification(str, Enum):
    """Traffic-light classification based on traveler preference match."""
    GREEN = "GREEN"      # Top Preference Match (score >= 0.65)
    YELLOW = "YELLOW"    # Scenic / Secondary Stop (0.35 <= score < 0.65)
    RED = "RED"          # Low Priority / Constraint Mismatch (score < 0.35)


class TravelerPreferences(BaseModel):
    """Traveler preferences and interest tags for deterministic POI ranking."""
    preferred_tags: List[str] = Field(default_factory=list, description="List of preferred interest tags (e.g. 'history', 'art', 'cafe')")
    pace: str = Field(default="moderate", description="Travel pace: 'relaxed', 'moderate', or 'fast'")
    max_detour_km: Optional[float] = Field(default=3.5, gt=0.0, description="Maximum detour distance from corridor in km")


class CandidatePOI(BaseModel):
    """Candidate Point of Interest or Restaurant with geographic location and metadata."""
    id: str = Field(..., description="Unique POI identifier")
    name: str = Field(..., description="POI or Restaurant name")
    lat: float = Field(..., ge=-90.0, le=90.0, description="Latitude in decimal degrees")
    lon: float = Field(..., ge=-180.0, le=180.0, description="Longitude in decimal degrees")
    category: str = Field(default="General", description="POI category (e.g. Museum, Park, Cafe, Restaurant, Landmark)")
    tags: List[str] = Field(default_factory=list, description="Categorical tags describing the POI")
    rating: float = Field(default=4.0, ge=0.0, le=5.0, description="Review rating from 0.0 to 5.0")
    estimated_dwell_minutes: int = Field(default=45, ge=5, le=360, description="Estimated time spent at the POI in minutes")
    address: Optional[str] = Field(None, description="Physical address")
    image_url: Optional[str] = Field(None, description="Preview image URL")
    description: Optional[str] = Field(None, description="Short summary of the POI")
    cuisine: Optional[str] = Field(None, description="Cuisine type if restaurant (e.g. French, Japanese, Italian, Local)")
    service_hours: Optional[dict] = Field(None, description="Service hours dictionary (e.g. {'lunch': ['12:00', '14:30'], 'dinner': ['18:30', '22:00']})")
    meal_types: List[str] = Field(default_factory=list, description="Available meal windows: 'breakfast', 'lunch', 'dinner'")
    price_tier: Optional[str] = Field(None, description="Price tier ($, $$, $$$, $$$$)")


class RankedPOI(BaseModel):
    """A POI or Restaurant evaluated against a transit corridor and ranked by traveler preferences."""
    id: str
    name: str
    lat: float
    lon: float
    category: str
    tags: List[str]
    rating: float
    estimated_dwell_minutes: int
    address: Optional[str] = None
    image_url: Optional[str] = None
    description: Optional[str] = None
    cuisine: Optional[str] = None
    service_hours: Optional[dict] = None
    meal_types: List[str] = Field(default_factory=list)
    price_tier: Optional[str] = None
    is_open_for_meal: Optional[bool] = Field(None, description="True if open during requested/scheduled meal time")
    meal_window_match: Optional[str] = Field(None, description="Eligible meal window e.g. 'LUNCH', 'DINNER', 'ALL_DAY'")
    distance_to_corridor_km: float = Field(..., description="Minimum geodesic distance from POI to finite corridor S->D in km")
    is_inside_corridor: bool = Field(..., description="Whether distance is within configured detour threshold")
    preference_score: float = Field(..., ge=0.0, le=1.0, description="Normalized preference match score [0.0, 1.0]")
    traffic_light: TrafficLightClassification = Field(..., description="Traffic-light status: GREEN, YELLOW, or RED")
    match_explanation: str = Field(..., description="Deterministic explanation of the preference score and classification")
    matched_tags: List[str] = Field(default_factory=list, description="List of tags that matched traveler preferences")


class HotelBooking(BaseModel):
    """Confirmed hotel booking record used for booking-aware destination setting and check-in constraints."""
    booking_id: str = Field(..., description="Unique reservation/booking identifier")
    hotel_name: str = Field(..., description="Name of the booked hotel")
    lat: float = Field(..., ge=-90.0, le=90.0, description="Hotel latitude")
    lon: float = Field(..., ge=-180.0, le=180.0, description="Hotel longitude")
    check_in_date: str = Field(default="2026-08-23", description="Check-in date (YYYY-MM-DD)")
    check_in_time: str = Field(default="18:00", description="Guaranteed check-in time (HH:MM)")
    check_out_date: Optional[str] = Field(default="2026-08-25", description="Check-out date")
    check_out_time: Optional[str] = Field(default="11:00", description="Check-out time")
    status: str = Field(default="CONFIRMED", description="Booking status (CONFIRMED, PENDING, CANCELLED)")
    room_type: Optional[str] = Field(default="Deluxe Suite", description="Room category")
    address: Optional[str] = Field(None, description="Hotel physical address")
    rating: float = Field(default=4.8, ge=0.0, le=5.0, description="Hotel rating")


class BookingsResponse(BaseModel):
    """Response payload containing active/confirmed hotel bookings for the user."""
    bookings: List[HotelBooking] = Field(..., description="List of available hotel bookings")


class DestinationOption(BaseModel):
    """A candidate hotel or destination checkpoint for the traveler."""
    id: str = Field(..., description="Unique destination identifier")
    name: str = Field(..., description="Hotel or destination name")
    lat: float = Field(..., ge=-90.0, le=90.0, description="Latitude")
    lon: float = Field(..., ge=-180.0, le=180.0, description="Longitude")
    category: str = Field(default="Hotel", description="Category (Hotel, Resort, Transit Hub, Checkpoint)")
    address: Optional[str] = Field(None, description="Street address or location summary")
    rating: float = Field(default=4.5, ge=0.0, le=5.0, description="Rating")
    distance_from_source_km: Optional[float] = Field(None, description="Distance from user's current location in km")
    booking_id: Optional[str] = Field(None, description="Linked booking identifier if booked")
    check_in_time: Optional[str] = Field(None, description="Associated check-in time if known")


class NearbyDestinationsRequest(BaseModel):
    """Request payload for finding candidate hotels and destinations near the user."""
    source: Coordinate = Field(..., description="User's real location coordinate")
    radius_km: float = Field(default=15.0, gt=0.0, description="Search radius in km")


class NearbyDestinationsResponse(BaseModel):
    """Response payload with nearby candidate hotels and destinations."""
    destinations: List[DestinationOption] = Field(..., description="List of candidate destinations/hotels")
    source: Coordinate = Field(..., description="User's real location coordinate")


class DiscoverCorridorRequest(BaseModel):
    """Request payload to discover candidate POIs and destinations for any arbitrary S -> D corridor."""
    source: Coordinate = Field(..., description="Source/origin coordinate S")
    destination: Coordinate = Field(..., description="Destination coordinate D")
    preferences: Optional[TravelerPreferences] = Field(default=None, description="Traveler preferences")
    detour_threshold_km: float = Field(default=3.5, gt=0.0, description="Corridor threshold in km")


class DiscoverCorridorResponse(BaseModel):
    """Response payload containing generated candidate POIs for dynamic corridor."""
    source: Coordinate
    destination: Coordinate
    candidate_pois: List[CandidatePOI] = Field(..., description="Discovered/generated candidate POIs along corridor")


class CorridorPOIRequest(BaseModel):
    """Request payload for filtering and ranking candidate POIs along a corridor."""
    source: Coordinate = Field(..., description="Source/transit hub coordinate")
    destination: Coordinate = Field(..., description="Destination/hotel coordinate")
    candidate_pois: List[CandidatePOI] = Field(..., description="List of candidate POIs to filter and rank")
    preferences: Optional[TravelerPreferences] = Field(default=None, description="Optional traveler preferences")
    detour_threshold_km: float = Field(default=3.5, gt=0.0, description="Maximum detour distance from corridor in km (default: 3.5)")
    current_time: Optional[str] = Field(None, description="Optional current time or trip arrival time for meal window evaluation")


class CorridorPOIResponse(BaseModel):
    """Response payload containing corridor-filtered and ranked POIs."""
    corridor_pois: List[RankedPOI] = Field(..., description="Ranked POIs within or evaluated against the corridor")
    total_candidates: int = Field(..., description="Total candidate POIs evaluated")
    filtered_count: int = Field(..., description="Number of POIs inside the corridor threshold")
    detour_threshold_km: float = Field(..., description="Detour threshold applied in km")
    source: Coordinate
    destination: Coordinate


