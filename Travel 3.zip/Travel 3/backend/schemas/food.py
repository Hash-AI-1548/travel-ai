"""Schemas for food and restaurant discovery, dining preferences, and meal timing."""

from enum import Enum
from typing import Dict, List, Optional
from pydantic import BaseModel, Field
from backend.schemas.poi import CandidatePOI, Coordinate


class MealType(str, Enum):
    BREAKFAST = "breakfast"
    LUNCH = "lunch"
    DINNER = "dinner"


class MealWindow(BaseModel):
    """Meal timing availability window."""
    meal_type: MealType
    start_time: str
    end_time: str
    target_dwell_minutes: int = 55


class FoodRecommendationRequest(BaseModel):
    """Request to discover candidate dining stops."""
    location: Coordinate
    meal_type: Optional[MealType] = None
    preferred_cuisines: List[str] = Field(default_factory=list)
    dietary_restrictions: List[str] = Field(default_factory=list)
    price_tier: Optional[str] = None
    radius_km: float = 5.0
    target_time: Optional[str] = None


class FoodRecommendationResponse(BaseModel):
    """Response containing recommended restaurants."""
    restaurants: List[CandidatePOI]
    total_found: int
    meal_type_applied: Optional[str] = None


class MealTimeMatchRequest(BaseModel):
    """Request to validate if a restaurant is open at target time."""
    service_hours: Optional[Dict[str, List[str]]] = None
    target_time: str


class MealTimeMatchResponse(BaseModel):
    """Response validation for meal timing."""
    is_open: Optional[bool]
    matched_meal_type: Optional[str]
    message: str
