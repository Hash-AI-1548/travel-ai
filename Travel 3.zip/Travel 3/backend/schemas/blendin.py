"""Schemas for BlendIn authenticity scoring and itinerary balancing."""

from typing import List, Optional
from pydantic import BaseModel, Field
from backend.schemas.poi import RankedPOI


class BlendInMetrics(BaseModel):
    """Authenticity vs Familiarity metrics for a stop."""
    poi_id: str
    poi_name: str
    authenticity_score: float = Field(..., ge=0.0, le=1.0, description="1.0 = highly authentic local secret")
    familiarity_score: float = Field(..., ge=0.0, le=1.0, description="1.0 = world-famous iconic tourist attraction")
    local_patronage_pct: int = Field(default=50, ge=0, le=100)
    blendin_category: str  # "Hidden Gem", "Local Favorite", "Iconic Landmark", "Balanced"


class BlendInScoreRequest(BaseModel):
    """Request to score POI authenticity."""
    poi_id: str
    name: str
    category: str
    tags: List[str] = Field(default_factory=list)
    rating: float = 4.5


class BlendInScoreResponse(BaseModel):
    """Response containing calculated BlendIn metrics."""
    metrics: BlendInMetrics


class BlendInItineraryRequest(BaseModel):
    """Request to balance an itinerary against a target blendin slider."""
    stops: List[RankedPOI]
    target_blendin: float = Field(default=0.5, ge=0.0, le=1.0, description="0.0 = tourist icons, 1.0 = local secrets")


class BlendInItineraryResponse(BaseModel):
    """Response containing re-weighted or curated stops."""
    balanced_stops: List[RankedPOI]
    overall_authenticity: float
    overall_familiarity: float
    blendin_summary: str
