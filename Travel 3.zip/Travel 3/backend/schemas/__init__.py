"""Centralized schemas package for Travel-AI platform."""

from backend.schemas.poi import (
    Coordinate,
    CandidatePOI,
    RankedPOI,
    TrafficLightClassification,
    TravelerPreferences,
    CorridorPOIRequest,
    CorridorPOIResponse,
    DestinationOption,
    NearbyDestinationsRequest,
    NearbyDestinationsResponse,
    DiscoverCorridorRequest,
    DiscoverCorridorResponse,
    HotelBooking,
    BookingsResponse,
)

from backend.schemas.itinerary import (
    TimelineEventType,
    ItineraryStop,
    BufferStatus,
    TimelineEvent,
    ItineraryGenerationRequest,
    ItineraryResponse,
)

from backend.schemas.routing import (
    GeoJSONGeometry,
    RouteRequest,
    RouteResponse,
    MultiSegmentRouteRequest,
    MultiSegmentRouteResponse,
)

from backend.schemas.nlp import (
    NLPParseRequest,
    ParsedTripIntent,
    NLPParseResponse,
)

from backend.schemas.profile import (
    PacingType,
    TravelerProfileInput,
    TravelerProfile,
    ProfileSynthesizeResponse,
)

from backend.schemas.food import (
    MealType,
    MealWindow,
    FoodRecommendationRequest,
    FoodRecommendationResponse,
    MealTimeMatchRequest,
    MealTimeMatchResponse,
)

from backend.schemas.cultural import (
    AttireGuidance,
    CulturalNorm,
    CulturalGuide,
    CulturalGuideRequest,
    CulturalGuideResponse,
)

from backend.schemas.blendin import (
    BlendInMetrics,
    BlendInScoreRequest,
    BlendInScoreResponse,
    BlendInItineraryRequest,
    BlendInItineraryResponse,
)

from backend.schemas.translation import (
    TravelPhrase,
    TranslationRequest,
    TranslationResponse,
    FoodCulturalBridge,
    FoodBridgeRequest,
    FoodBridgeResponse,
)

__all__ = [
    # POI
    "Coordinate",
    "CandidatePOI",
    "RankedPOI",
    "TrafficLightClassification",
    "TravelerPreferences",
    "CorridorPOIRequest",
    "CorridorPOIResponse",
    "DestinationOption",
    "NearbyDestinationsRequest",
    "NearbyDestinationsResponse",
    "DiscoverCorridorRequest",
    "DiscoverCorridorResponse",
    "HotelBooking",
    "BookingsResponse",
    # Itinerary
    "TimelineEventType",
    "ItineraryStop",
    "BufferStatus",
    "TimelineEvent",
    "ItineraryGenerationRequest",
    "ItineraryResponse",
    # Routing
    "GeoJSONGeometry",
    "RouteRequest",
    "RouteResponse",
    "MultiSegmentRouteRequest",
    "MultiSegmentRouteResponse",
    # NLP
    "NLPParseRequest",
    "ParsedTripIntent",
    "NLPParseResponse",
    # Profile
    "PacingType",
    "TravelerProfileInput",
    "TravelerProfile",
    "ProfileSynthesizeResponse",
    # Food
    "MealType",
    "MealWindow",
    "FoodRecommendationRequest",
    "FoodRecommendationResponse",
    "MealTimeMatchRequest",
    "MealTimeMatchResponse",
    # Cultural
    "AttireGuidance",
    "CulturalNorm",
    "CulturalGuide",
    "CulturalGuideRequest",
    "CulturalGuideResponse",
    # BlendIn
    "BlendInMetrics",
    "BlendInScoreRequest",
    "BlendInScoreResponse",
    "BlendInItineraryRequest",
    "BlendInItineraryResponse",
    # Translation
    "TravelPhrase",
    "TranslationRequest",
    "TranslationResponse",
    "FoodCulturalBridge",
    "FoodBridgeRequest",
    "FoodBridgeResponse",
]
