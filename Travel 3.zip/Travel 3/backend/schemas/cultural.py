"""Schemas for cultural etiquette, customs, occasion matching, and attire guidance."""

from typing import List, Optional
from pydantic import BaseModel, Field


class AttireGuidance(BaseModel):
    """Specific attire guidance for places/occasions."""
    occasion: str
    recommended_outfit: str
    prohibited_items: List[str] = Field(default_factory=list)
    weather_note: Optional[str] = None
    cultural_context: str


class CulturalNorm(BaseModel):
    """Local etiquette or customary behavior."""
    category: str  # Dining, Greetings, Religious, Tipping
    rule: str
    importance: str  # Mandatory, Recommended, Good Practice


class CulturalGuide(BaseModel):
    """City or country cultural guide."""
    destination_name: str
    season: str
    general_etiquette: List[CulturalNorm]
    attire_guidelines: List[AttireGuidance]
    tipping_customs: str
    dining_etiquette: List[str]


class CulturalGuideRequest(BaseModel):
    """Request for cultural etiquette & attire guidance."""
    destination: str
    season: str = "summer"
    planned_occasions: List[str] = Field(default_factory=list)


class CulturalGuideResponse(BaseModel):
    """Response containing cultural guide."""
    guide: CulturalGuide
