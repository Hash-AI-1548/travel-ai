"""Pydantic schemas for Road Routing, GeoJSON geometries, and Navigation."""

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field
from backend.schemas.poi import Coordinate


class GeoJSONGeometry(BaseModel):
    """Standard GeoJSON LineString geometry for road network routes."""
    type: str = Field(default="LineString", description="GeoJSON geometry type")
    coordinates: List[List[float]] = Field(
        ...,
        description="Array of [longitude, latitude] coordinates along the actual road network",
    )


class RouteRequest(BaseModel):
    """Request payload for routing a single origin-destination leg."""
    origin: Coordinate = Field(..., description="Starting coordinate")
    destination: Coordinate = Field(..., description="Ending coordinate")
    mode: str = Field(default="driving", description="Travel mode: 'driving' or 'walking'")


class RouteResponse(BaseModel):
    """Structured road routing response with exact road metrics and GeoJSON geometry."""
    distance_meters: float = Field(..., description="Total road distance in meters")
    distance_km: float = Field(..., description="Total road distance in kilometers")
    duration_seconds: float = Field(..., description="Total travel duration in seconds")
    duration_minutes: int = Field(..., description="Travel duration rounded to whole minutes")
    mode: str = Field(..., description="Routing mode used (driving, walking)")
    geometry: GeoJSONGeometry = Field(..., description="GeoJSON LineString following actual roads")
    is_fallback: bool = Field(default=False, description="True if synthesized road fallback was used")
    route_summary: Optional[str] = Field(None, description="Human-readable road summary")


class MultiSegmentRouteRequest(BaseModel):
    """Request payload for routing a sequential series of itinerary waypoints."""
    points: List[Coordinate] = Field(..., min_length=2, description="Ordered list of coordinates to route consecutively")
    mode: str = Field(default="driving", description="Travel mode")


class MultiSegmentRouteResponse(BaseModel):
    """Multi-segment road routing response containing each routed leg independently."""
    segments: List[RouteResponse] = Field(..., description="List of individual road-routed segments")
    total_distance_km: float = Field(..., description="Sum of all road distances in km")
    total_duration_minutes: int = Field(..., description="Sum of all road travel durations in minutes")
