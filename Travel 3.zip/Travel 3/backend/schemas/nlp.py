"""Schemas for Natural Language Processing (NLP) trip intent parsing."""

from typing import List, Optional
from pydantic import BaseModel, Field


class NLPParseRequest(BaseModel):
    """Freeform user travel query."""
    query: str = Field(..., min_length=2, description="Natural language trip description or prompt")


class ParsedTripIntent(BaseModel):
    """Structured parameters extracted from freeform query."""
    destination_name: Optional[str] = None
    party_size: int = 1
    duration_days: int = 1
    pace: str = "moderate"
    budget_tier: str = "$$"
    preferred_tags: List[str] = Field(default_factory=list)
    preferred_cuisines: List[str] = Field(default_factory=list)
    dietary_restrictions: List[str] = Field(default_factory=list)
    accessibility_needed: bool = False
    transit_arrival_time: str = "13:30"
    check_in_time: str = "18:00"
    blendin_preference: float = 0.5  # 0.0 = Tourist classics, 1.0 = Pure local


class NLPParseResponse(BaseModel):
    """API response for NLP parse operation."""
    success: bool = True
    raw_query: str
    parsed_intent: ParsedTripIntent
    extracted_entities: List[str] = Field(default_factory=list)
