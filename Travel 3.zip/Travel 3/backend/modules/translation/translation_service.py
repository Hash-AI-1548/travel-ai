"""Real-time travel translation service and food cultural bridge."""

from typing import Dict, List
from backend.schemas.translation import (
    FoodCulturalBridge,
    FoodBridgeRequest,
    FoodBridgeResponse,
    TravelPhrase,
    TranslationRequest,
    TranslationResponse,
)


PHRASE_DICTIONARY: Dict[str, Dict[str, List[dict]]] = {
    "fr": {
        "Greetings": [
            {"src": "Hello / Good morning", "tgt": "Bonjour", "pron": "bohn-zhoor", "tip": "Use upon entering any shop or greeting anyone."},
            {"src": "Good evening", "tgt": "Bonsoir", "pron": "bohn-swahr", "tip": "Use after 17:00."},
            {"src": "Thank you very much", "tgt": "Merci beaucoup", "pron": "mair-see boh-koo", "tip": "Polite expression of gratitude."},
            {"src": "Please", "tgt": "S'il vous plaît", "pron": "seel voo pleh", "tip": "Add to any request."},
        ],
        "Dining": [
            {"src": "The bill, please", "tgt": "L'addition, s'il vous plaît", "pron": "lah-dee-syohn seel voo pleh", "tip": "Servers will not bring the bill until requested."},
            {"src": "A carafe of tap water, please", "tgt": "Une carafe d'eau, s'il vous plaît", "pron": "oon kah-rahf doh seel voo pleh", "tip": "Complimentary chilled tap water."},
            {"src": "Do you have vegetarian options?", "tgt": "Avez-vous des options végétariennes ?", "pron": "ah-vay voo day zop-syohn vay-zhay-tah-ryen", "tip": "Clarifies dietary options."},
        ],
        "Navigation & Transit": [
            {"src": "Where is the train station?", "tgt": "Où est la gare ?", "pron": "oo eh lah gahr", "tip": "Used for regional and main transit hubs."},
            {"src": "How do I get to the museum?", "tgt": "Comment aller au musée ?", "pron": "koh-mahn ah-lay oh mew-zay", "tip": "Asking locals for directions."},
        ],
        "Emergency": [
            {"src": "I need help", "tgt": "J'ai besoin d'aide", "pron": "zhay buh-zwan dehd", "tip": "General emergency request."},
            {"src": "Where is the nearest pharmacy?", "tgt": "Où est la pharmacie la plus proche ?", "pron": "oo eh lah fahr-mah-see lah plew prosh", "tip": "Green neon cross indicates pharmacy."},
        ],
    },
    "ja": {
        "Greetings": [
            {"src": "Hello", "tgt": "こんにちは (Konnichiwa)", "pron": "kohn-nee-chee-wah", "tip": "Standard daytime greeting."},
            {"src": "Thank you very much", "tgt": "ありがとうございます (Arigatou gozaimasu)", "pron": "ah-ree-gah-toh goh-zeye-mahs", "tip": "Polite gratitude with slight bow."},
            {"src": "Excuse me / Sorry", "tgt": "すみません (Sumimasen)", "pron": "soo-mee-mah-sen", "tip": "Call waitstaff or navigate crowds."},
        ],
        "Dining": [
            {"src": "The check, please", "tgt": "お会計をお願いします (O-kaikei o onegaishimasu)", "pron": "oh-kye-kay oh oh-nay-gaye-shee-mahs", "tip": "Cross fingers in X or ask at counter."},
            {"src": "Water, please", "tgt": "お水をお願いします (O-mizu o onegaishimasu)", "pron": "oh-mee-zoo oh oh-nay-gaye-shee-mahs", "tip": "Complimentary water or tea."},
            {"src": "It was delicious (Thank you)", "tgt": "ごちそうさまでした (Gochisousama deshita)", "pron": "goh-chee-soh-sah-mah desh-tah", "tip": "Say when leaving the restaurant."},
        ],
        "Navigation & Transit": [
            {"src": "Where is the station?", "tgt": "駅はどこですか？ (Eki wa doko desu ka?)", "pron": "eh-kee wah doh-koh dess kah", "tip": "Locating train or subway station."},
        ],
        "Emergency": [
            {"src": "Please help me", "tgt": "助けてください (Tasukete kudasai)", "pron": "tahs-keh-teh koo-dah-seye", "tip": "Urgent emergency assistance."},
        ],
    },
}

FOOD_BRIDGE_DATABASE: Dict[str, dict] = {
    "confit de canard": {
        "local_name": "Confit de Canard",
        "pron": "kohn-fee duh kah-nahr",
        "region": "Southwest France (Gascony)",
        "desc": "Duck leg slow-cooked in its own fat until tender, then pan-crisped with pomme sarladaise potatoes.",
        "ingredients": ["Duck Leg", "Duck Fat", "Garlic", "Thyme", "Sea Salt"],
        "dietary_warnings": ["Poultry", "High Sodium"],
        "etiquette": "Eat with fork and knife; savor the crisp golden skin.",
    },
    "bouillabaisse": {
        "local_name": "Bouillabaisse Provençale",
        "pron": "boo-yah-bess proh-vahn-sahl",
        "region": "Marseille / Provence",
        "desc": "Traditional Provençal fish stew with saffron broth, served with rouille garlic mayonnaise and toasted croutons.",
        "ingredients": ["Rockfish", "Saffron", "Fennel", "Garlic", "Olive Oil", "Croutons"],
        "dietary_warnings": ["Contains Shellfish", "Fish", "Gluten (Croutons)"],
        "etiquette": "Spread spicy rouille on croutons, float them in the broth, and enjoy fish pieces separately.",
    },
    "tonkotsu ramen": {
        "local_name": "豚骨ラーメン (Tonkotsu Ramen)",
        "pron": "tohn-koht-soo rah-men",
        "region": "Fukuoka (Kyushu, Japan)",
        "desc": "Rich, creamy pork bone broth simmered for 14+ hours with springy noodles, chashu pork, and ajitsuke tamago egg.",
        "ingredients": ["Pork Bones", "Wheat Noodles", "Chashu Pork Belly", "Scallions", "Marinated Egg"],
        "dietary_warnings": ["Contains Pork", "Gluten (Wheat Noodles)", "Soy", "Egg"],
        "etiquette": "Slurp noodles promptly while steaming hot; do not leave noodles sitting in broth too long.",
    },
}


def get_phrases_for_language(req: TranslationRequest) -> TranslationResponse:
    """Retrieves curated essential phrases for traveler by category and target language."""
    lang = req.target_language.lower()
    if lang not in PHRASE_DICTIONARY:
        lang = "fr"

    lang_dict = PHRASE_DICTIONARY[lang]
    phrases: List[TravelPhrase] = []

    for cat_name, items in lang_dict.items():
        if req.category and req.category.lower() not in cat_name.lower():
            continue
        for item in items:
            phrases.append(
                TravelPhrase(
                    category=cat_name,
                    source_phrase=item["src"],
                    target_phrase=item["tgt"],
                    pronunciation=item["pron"],
                    context_tip=item["tip"],
                )
            )

    return TranslationResponse(
        phrases=phrases,
        source_language="en",
        target_language=lang,
    )


def get_food_cultural_bridge(req: FoodBridgeRequest) -> FoodBridgeResponse:
    """Provides deep culinary context, pronunciation, ingredients and allergen warnings for menu items."""
    query = req.dish_or_item.lower().strip()
    match = None
    for key, data in FOOD_BRIDGE_DATABASE.items():
        if key in query or query in key:
            match = data
            break

    if not match:
        match = {
            "local_name": req.dish_or_item.title(),
            "pron": "Pronunciation available upon request",
            "region": "Regional Specialty",
            "desc": f"Curated traditional dish ({req.dish_or_item}) prepared with local seasonal produce.",
            "ingredients": ["Local seasonal ingredients", "Regional herbs & spices"],
            "dietary_warnings": ["Verify specific dietary ingredients with server"],
            "etiquette": "Inquire with waitstaff regarding customary pairing.",
        }

    bridge = FoodCulturalBridge(
        dish_name=req.dish_or_item.title(),
        local_name=match["local_name"],
        pronunciation=match["pron"],
        origin_region=match["region"],
        description=match["desc"],
        key_ingredients=match["ingredients"],
        dietary_warnings=match["dietary_warnings"],
        how_to_eat_etiquette=match["etiquette"],
    )

    return FoodBridgeResponse(bridge=bridge)
