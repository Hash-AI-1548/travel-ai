"""Translation & Culinary Bridge package."""

from backend.modules.translation.translation_service import (
    get_phrases_for_language,
    get_food_cultural_bridge,
)

__all__ = [
    "get_phrases_for_language",
    "get_food_cultural_bridge",
]
