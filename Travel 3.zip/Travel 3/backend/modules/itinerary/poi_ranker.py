"""POI Traffic-Light Ranker: Deterministic, explainable scoring against traveler preferences."""

from typing import List, Optional, Tuple
from backend.schemas.poi import (
    CandidatePOI,
    RankedPOI,
    TrafficLightClassification,
    TravelerPreferences,
)


def check_meal_availability(
    service_hours: Optional[dict],
    time_str: Optional[str] = None,
) -> Tuple[Optional[bool], Optional[str]]:
    """
    Check if restaurant is open for a meal given service hours and an optional time string (HH:MM).
    Returns (is_open_for_meal, meal_window_label).
    If service hours are not provided, returns (None, None) (Availability Unknown).
    """
    if not service_hours:
        return (None, None)

    if not time_str:
        windows = [k.upper() for k in service_hours.keys()]
        return (True, "/".join(windows) if windows else "AVAILABLE")

    try:
        parts = time_str.split(":")
        h = int(parts[0])
        m = int(parts[1])
        t_minutes = h * 60 + m
    except Exception:
        return (None, None)

    for meal_key, hours_range in service_hours.items():
        if isinstance(hours_range, (list, tuple)) and len(hours_range) >= 2:
            open_str, close_str = hours_range[0], hours_range[1]
            try:
                o_h, o_m = [int(x) for x in open_str.split(":")]
                c_h, c_m = [int(x) for x in close_str.split(":")]
                o_min = o_h * 60 + o_m
                c_min = c_h * 60 + c_m
                if o_min <= t_minutes <= c_min:
                    return (True, f"OPEN FOR {meal_key.upper()}")
            except Exception:
                continue

    return (False, "CLOSED AT CURRENT TIME")


def score_and_rank_poi(
    poi: CandidatePOI,
    distance_to_corridor_km: float,
    is_inside_corridor: bool,
    preferences: Optional[TravelerPreferences] = None,
    detour_threshold_km: float = 3.5,
    current_time: Optional[str] = None,
) -> RankedPOI:
    """
    Deterministically score a candidate POI or Restaurant against traveler preferences and corridor proximity.
    
    Score S in [0.0, 1.0]:
    - GREEN:  S >= 0.65  (Top Preference Match)
    - YELLOW: 0.35 <= S < 0.65 (Scenic / Secondary Stop)
    - RED:    S < 0.35   (Low Priority / Constraint Mismatch)
    """
    threshold = max(0.1, detour_threshold_km)
    
    # 1. Proximity Score in [0.0, 1.0]
    proximity_ratio = min(1.0, max(0.0, distance_to_corridor_km / threshold))
    s_prox = 1.0 - proximity_ratio

    # 2. Rating Score in [0.0, 1.0]
    rating_val = max(0.0, min(5.0, poi.rating if poi.rating is not None else 3.5))
    s_rating = rating_val / 5.0

    # 3. Preference / Tag & Cuisine Match Component
    matched_tags: List[str] = []
    preferred_tags = [t.strip().lower() for t in (preferences.preferred_tags if preferences else []) if t.strip()]
    
    poi_tags_normalized = [t.strip().lower() for t in poi.tags]
    if poi.category:
        poi_tags_normalized.append(poi.category.strip().lower())
    if poi.cuisine:
        poi_tags_normalized.append(poi.cuisine.strip().lower())
    for meal in poi.meal_types:
        poi_tags_normalized.append(meal.strip().lower())

    if preferred_tags:
        for pref in preferred_tags:
            for p_tag in poi_tags_normalized:
                if pref in p_tag or p_tag in pref:
                    if pref not in matched_tags:
                        matched_tags.append(pref)
        
        # Tag match score: ratio of matched user preferences
        denominator = max(1, min(len(preferred_tags), 3))
        s_tag = min(1.0, len(matched_tags) / denominator)

        # Weighted combination: 40% Tag match, 35% Rating, 25% Proximity
        raw_score = (0.40 * s_tag) + (0.35 * s_rating) + (0.25 * s_prox)
    else:
        # Safe fallback when preferences are missing: 60% Rating, 40% Proximity
        s_tag = 0.0
        raw_score = (0.60 * s_rating) + (0.40 * s_prox)

    # Strictly clamp to [0.0, 1.0] and round
    score = round(min(1.0, max(0.0, raw_score)), 3)

    # Meal availability check
    is_open_meal, meal_label = check_meal_availability(poi.service_hours, current_time)

    # Traffic-light classification
    if score >= 0.65:
        traffic_light = TrafficLightClassification.GREEN
        quality_label = "Top Preference Match"
    elif score >= 0.35:
        traffic_light = TrafficLightClassification.YELLOW
        quality_label = "Scenic / Secondary Stop"
    else:
        traffic_light = TrafficLightClassification.RED
        quality_label = "Low Priority / Constraint Mismatch"

    # Deterministic explanation
    cuisine_str = f" Cuisine: {poi.cuisine}." if poi.cuisine else ""
    meal_str = f" [{meal_label}]" if meal_label else ""
    if matched_tags:
        tags_str = ", ".join(f"'{t}'" for t in matched_tags)
        match_explanation = f"{quality_label} (Score: {score:.2f}). Matched tags: {tags_str}.{cuisine_str}{meal_str} Detour: {distance_to_corridor_km:.2f} km."
    elif preferred_tags:
        match_explanation = f"{quality_label} (Score: {score:.2f}). No direct tag matches with preferences.{cuisine_str}{meal_str} Rating: {rating_val:.1f}/5. Detour: {distance_to_corridor_km:.2f} km."
    else:
        match_explanation = f"{quality_label} (Score: {score:.2f}). Baseline general interest match.{cuisine_str}{meal_str} Rating: {rating_val:.1f}/5. Detour: {distance_to_corridor_km:.2f} km."

    return RankedPOI(
        id=poi.id,
        name=poi.name,
        lat=poi.lat,
        lon=poi.lon,
        category=poi.category,
        tags=poi.tags,
        rating=poi.rating,
        estimated_dwell_minutes=poi.estimated_dwell_minutes,
        address=poi.address,
        image_url=poi.image_url,
        description=poi.description,
        cuisine=poi.cuisine,
        service_hours=poi.service_hours,
        meal_types=poi.meal_types,
        price_tier=poi.price_tier,
        is_open_for_meal=is_open_meal,
        meal_window_match=meal_label,
        distance_to_corridor_km=distance_to_corridor_km,
        is_inside_corridor=is_inside_corridor,
        preference_score=score,
        traffic_light=traffic_light,
        match_explanation=match_explanation,
        matched_tags=matched_tags,
    )


def rank_corridor_pois(
    evaluated_pois: List[Tuple[CandidatePOI, float, bool]],
    preferences: Optional[TravelerPreferences] = None,
    detour_threshold_km: float = 3.5,
    current_time: Optional[str] = None,
) -> List[RankedPOI]:
    """Rank a list of evaluated corridor POIs, returning sorted list by score descending."""
    ranked = [
        score_and_rank_poi(
            poi=poi,
            distance_to_corridor_km=dist,
            is_inside_corridor=inside,
            preferences=preferences,
            detour_threshold_km=detour_threshold_km,
            current_time=current_time,
        )
        for poi, dist, inside in evaluated_pois
    ]
    # Sort by inside_corridor first, then preference_score desc, then distance_to_corridor asc
    ranked.sort(key=lambda p: (p.is_inside_corridor, p.preference_score, -p.distance_to_corridor_km), reverse=True)
    return ranked
