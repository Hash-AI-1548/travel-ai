"""POI Corridor Service: Geodesic and cross-track distance calculations for finite corridors."""

import math
from typing import List, Optional, Tuple
from backend.schemas.poi import CandidatePOI, Coordinate

EARTH_RADIUS_KM = 6371.0088


def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Calculate the great-circle distance between two points on the Earth in kilometers."""
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2.0) ** 2
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(max(0.0, 1.0 - a)))
    return EARTH_RADIUS_KM * c


def _to_cartesian(lat: float, lon: float) -> Tuple[float, float, float]:
    """Convert spherical latitude/longitude in degrees to 3D Cartesian coordinates on unit sphere."""
    phi = math.radians(lat)
    lam = math.radians(lon)
    x = math.cos(phi) * math.cos(lam)
    y = math.cos(phi) * math.sin(lam)
    z = math.sin(phi)
    return (x, y, z)


def _cross_product(v1: Tuple[float, float, float], v2: Tuple[float, float, float]) -> Tuple[float, float, float]:
    """Calculate the 3D cross product v1 x v2."""
    return (
        v1[1] * v2[2] - v1[2] * v2[1],
        v1[2] * v2[0] - v1[0] * v2[2],
        v1[0] * v2[1] - v1[1] * v2[0],
    )


def _dot_product(v1: Tuple[float, float, float], v2: Tuple[float, float, float]) -> float:
    """Calculate the 3D dot product v1 . v2."""
    return v1[0] * v2[0] + v1[1] * v2[1] + v1[2] * v2[2]


def _magnitude(v: Tuple[float, float, float]) -> float:
    """Calculate the Euclidean magnitude of a 3D vector."""
    return math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2)


def distance_point_to_finite_segment(
    p_lat: float, p_lon: float,
    s_lat: float, s_lon: float,
    d_lat: float, d_lon: float
) -> float:
    """
    Calculate the minimum geographic distance (in km) from a point P
    to a FINITE great-circle line segment S -> D.

    If P's projection on the great-circle arc lies outside the finite [S, D] segment,
    the distance is measured against the nearest endpoint (S or D).
    """
    # Quick check if S and D are identical
    dist_s_d = haversine_distance(s_lat, s_lon, d_lat, d_lon)
    dist_p_s = haversine_distance(p_lat, p_lon, s_lat, s_lon)
    dist_p_d = haversine_distance(p_lat, p_lon, d_lat, d_lon)

    if dist_s_d < 1e-6:
        return dist_p_s

    # Unit vectors
    v_s = _to_cartesian(s_lat, s_lon)
    v_d = _to_cartesian(d_lat, d_lon)
    v_p = _to_cartesian(p_lat, p_lon)

    # Normal vector to the plane of the great circle passing through S and D
    normal = _cross_product(v_s, v_d)
    norm_len = _magnitude(normal)

    if norm_len < 1e-12:
        # S and D are antipodal; return distance to nearest endpoint
        return min(dist_p_s, dist_p_d)

    n_unit = (normal[0] / norm_len, normal[1] / norm_len, normal[2] / norm_len)

    # Project P onto the plane containing the great circle arc S -> D
    dot_p_n = _dot_product(v_p, n_unit)
    v_proj = (
        v_p[0] - dot_p_n * n_unit[0],
        v_p[1] - dot_p_n * n_unit[1],
        v_p[2] - dot_p_n * n_unit[2],
    )
    v_proj_len = _magnitude(v_proj)

    if v_proj_len < 1e-12:
        return min(dist_p_s, dist_p_d)

    v_proj_unit = (v_proj[0] / v_proj_len, v_proj[1] / v_proj_len, v_proj[2] / v_proj_len)

    # Check if projection lies between S and D along the minor arc
    # S x V_proj must be in same direction as normal, and V_proj x D must also be in same direction
    c1 = _dot_product(_cross_product(v_s, v_proj_unit), n_unit)
    c2 = _dot_product(_cross_product(v_proj_unit, v_d), n_unit)

    if c1 >= -1e-10 and c2 >= -1e-10:
        # Projection lies ON the finite segment [S, D]
        # Cross-track angular distance
        angular_dist = math.asin(min(1.0, max(-1.0, abs(dot_p_n))))
        return EARTH_RADIUS_KM * angular_dist
    else:
        # Projection falls beyond endpoints; clamp to nearest endpoint
        return min(dist_p_s, dist_p_d)


def filter_pois_along_corridor(
    source: Coordinate,
    destination: Coordinate,
    candidate_pois: List[CandidatePOI],
    detour_threshold_km: float = 3.5,
) -> List[Tuple[CandidatePOI, float, bool]]:
    """
    Filter candidate POIs along the finite S -> D corridor.
    
    Returns a list of tuples: (candidate_poi, distance_to_corridor_km, is_inside_corridor)
    """
    results: List[Tuple[CandidatePOI, float, bool]] = []

    for poi in candidate_pois:
        dist_km = distance_point_to_finite_segment(
            p_lat=poi.lat,
            p_lon=poi.lon,
            s_lat=source.lat,
            s_lon=source.lon,
            d_lat=destination.lat,
            d_lon=destination.lon,
        )
        is_inside = dist_km <= detour_threshold_km
        results.append((poi, round(dist_km, 3), is_inside))

    return results


def calculate_offset_coordinate(
    lat: float, lon: float, distance_km: float, bearing_deg: float
) -> Tuple[float, float]:
    """Calculate target latitude/longitude given origin, distance in km, and bearing in degrees."""
    delta = distance_km / EARTH_RADIUS_KM
    theta = math.radians(bearing_deg)
    phi1 = math.radians(lat)
    lambda1 = math.radians(lon)

    phi2 = math.asin(
        math.sin(phi1) * math.cos(delta)
        + math.cos(phi1) * math.sin(delta) * math.cos(theta)
    )
    lambda2 = lambda1 + math.atan2(
        math.sin(theta) * math.sin(delta) * math.cos(phi1),
        math.cos(delta) - math.sin(phi1) * math.sin(phi2),
    )

    # Convert back to degrees and normalize
    lat_deg = math.degrees(phi2)
    lon_deg = (math.degrees(lambda2) + 540.0) % 360.0 - 180.0
    return round(lat_deg, 6), round(lon_deg, 6)


def generate_nearby_destinations(
    source: Coordinate, radius_km: float = 15.0
) -> List[dict]:
    """
    Generate candidate hotel and destination checkpoints around the user's real coordinate S.
    Provides varied bearings and realistic transit distances.
    """
    candidates = [
        {"name": "Grand Central Luxury Hotel & Suites", "category": "Luxury Hotel", "dist_ratio": 0.45, "bearing": 35.0, "rating": 4.8, "desc": "Premium boutique hotel in the central district."},
        {"name": "The Riverside Heritage Hotel", "category": "Heritage Hotel", "dist_ratio": 0.65, "bearing": 110.0, "rating": 4.7, "desc": "Charming boutique hotel with waterfront views and garden lounge."},
        {"name": "Metropolitan Business & Transit Hub Hotel", "category": "Business Hotel", "dist_ratio": 0.35, "bearing": 215.0, "rating": 4.5, "desc": "Conveniently located contemporary hotel with express terminal access."},
        {"name": "Skyline Panorama Resort & Spa", "category": "Resort & Spa", "dist_ratio": 0.85, "bearing": 300.0, "rating": 4.9, "desc": "Scenic hilltop retreat with panoramic views of the region."},
        {"name": "Historic Old Town Boutique Inn", "category": "Boutique Inn", "dist_ratio": 0.55, "bearing": 175.0, "rating": 4.6, "desc": "Historic building converted into an elegant boutique accommodation."},
    ]

    destinations = []
    for idx, c in enumerate(candidates, start=1):
        dist = max(2.0, min(radius_km, radius_km * c["dist_ratio"]))
        lat, lon = calculate_offset_coordinate(source.lat, source.lon, dist, c["bearing"])
        real_dist = round(haversine_distance(source.lat, source.lon, lat, lon), 2)
        destinations.append({
            "id": f"dest_{idx}",
            "name": c["name"],
            "lat": lat,
            "lon": lon,
            "category": c["category"],
            "address": f"{c['name']}, {real_dist} km from current location",
            "rating": c["rating"],
            "distance_from_source_km": real_dist,
        })

    return destinations


def get_hotel_bookings() -> List[dict]:
    """
    Retrieve confirmed hotel bookings for booking-aware destination selection.
    """
    return [
        {
            "booking_id": "BK-88219",
            "hotel_name": "Hotel Le Marais Prestige",
            "lat": 48.8575,
            "lon": 2.3622,
            "check_in_date": "2026-08-23",
            "check_in_time": "18:00",
            "check_out_date": "2026-08-25",
            "check_out_time": "11:00",
            "status": "CONFIRMED",
            "room_type": "Executive King Suite",
            "address": "14 Rue des Rosiers, 75004 Paris, France",
            "rating": 4.8,
        },
        {
            "booking_id": "BK-77402",
            "hotel_name": "Shibuya Excel Hotel Tokyu",
            "lat": 35.6591,
            "lon": 139.7006,
            "check_in_date": "2026-08-23",
            "check_in_time": "18:30",
            "check_out_date": "2026-08-26",
            "check_out_time": "10:00",
            "status": "CONFIRMED",
            "room_type": "Premier View Room",
            "address": "1-12-2 Dogenzaka, Shibuya City, Tokyo, Japan",
            "rating": 4.7,
        },
        {
            "booking_id": "BK-99154",
            "hotel_name": "The Plaza Hotel Central Park",
            "lat": 40.7663,
            "lon": -73.9774,
            "check_in_date": "2026-08-23",
            "check_in_time": "17:00",
            "check_out_date": "2026-08-26",
            "check_out_time": "12:00",
            "status": "CONFIRMED",
            "room_type": "Fifth Avenue Suite",
            "address": "768 5th Ave, New York, NY 10019, USA",
            "rating": 4.9,
        },
        {
            "booking_id": "BK-55310",
            "hotel_name": "Taj Coromandel Luxury Suites",
            "lat": 13.0604,
            "lon": 80.2496,
            "check_in_date": "2026-08-23",
            "check_in_time": "17:00",
            "check_out_date": "2026-08-25",
            "check_out_time": "12:00",
            "status": "CONFIRMED",
            "room_type": "Grand Heritage Suite",
            "address": "37, Mahatma Gandhi Rd, Nungambakkam, Chennai, India",
            "rating": 4.9,
        },
    ]


def generate_candidate_pois_for_corridor(
    source: Coordinate, destination: Coordinate
) -> List[CandidatePOI]:
    """
    Deterministically generate realistic candidate POIs & Restaurants along the finite S -> D corridor.
    Positions POIs at varied milestones along the path with controlled lateral offsets.
    Includes first-class restaurants with cuisines, service hours, and meal windows.
    """
    total_dist_km = haversine_distance(source.lat, source.lon, destination.lat, destination.lon)
    total_dist_km = max(0.5, total_dist_km)

    # Bearing from S to D
    y = math.sin(math.radians(destination.lon - source.lon)) * math.cos(math.radians(destination.lat))
    x = math.cos(math.radians(source.lat)) * math.sin(math.radians(destination.lat)) - math.sin(math.radians(source.lat)) * math.cos(math.radians(destination.lat)) * math.cos(math.radians(destination.lon - source.lon))
    base_bearing = (math.degrees(math.atan2(y, x)) + 360.0) % 360.0

    poi_templates = [
        {
            "id": "poi_art_museum",
            "name": "Contemporary Arts & Heritage Museum",
            "category": "Museum",
            "tags": ["art", "history", "museum", "culture", "exhibition"],
            "rating": 4.9,
            "dwell": 60,
            "frac": 0.25,
            "lateral_km": 0.4,
            "lateral_bearing_offset": 90.0,
            "desc": "Renowned regional art museum showcasing modern exhibitions and historic archives.",
            "cuisine": None,
            "service_hours": None,
            "meal_types": [],
            "price_tier": None,
        },
        {
            "id": "poi_historic_square",
            "name": "Historic City Plaza & Monument",
            "category": "Landmark",
            "tags": ["history", "architecture", "monument", "culture"],
            "rating": 4.8,
            "dwell": 40,
            "frac": 0.45,
            "lateral_km": 0.7,
            "lateral_bearing_offset": -90.0,
            "desc": "Iconic central square with historic architecture, fountains, and vibrant pedestrian walkways.",
            "cuisine": None,
            "service_hours": None,
            "meal_types": [],
            "price_tier": None,
        },
        {
            "id": "rest_culinary_bistro",
            "name": "L'Epicure Modern Bistro & Grill",
            "category": "Restaurant",
            "tags": ["food", "restaurant", "bistro", "french", "culinary", "lunch", "dinner"],
            "rating": 4.8,
            "dwell": 55,
            "frac": 0.50,
            "lateral_km": 0.5,
            "lateral_bearing_offset": 90.0,
            "desc": "Award-winning restaurant featuring farm-to-table lunch & dinner tasting menus.",
            "cuisine": "French Contemporary",
            "service_hours": {
                "lunch": ["12:00", "14:30"],
                "dinner": ["18:30", "22:00"],
            },
            "meal_types": ["lunch", "dinner"],
            "price_tier": "$$$",
        },
        {
            "id": "poi_botanical_gardens",
            "name": "Royal Botanical Gardens & Conservatory",
            "category": "Park",
            "tags": ["park", "gardens", "nature", "scenic", "walking"],
            "rating": 4.7,
            "dwell": 50,
            "frac": 0.60,
            "lateral_km": 1.2,
            "lateral_bearing_offset": 90.0,
            "desc": "Lush landscaped gardens featuring rare flora, walking trails, and glasshouse pavilions.",
            "cuisine": None,
            "service_hours": None,
            "meal_types": [],
            "price_tier": None,
        },
        {
            "id": "rest_trattoria_delight",
            "name": "Trattoria Bella Vista (Artisan Pasta)",
            "category": "Restaurant",
            "tags": ["food", "restaurant", "italian", "pasta", "wine", "lunch", "dinner"],
            "rating": 4.7,
            "dwell": 50,
            "frac": 0.68,
            "lateral_km": 0.6,
            "lateral_bearing_offset": -90.0,
            "desc": "Authentic regional trattoria celebrated for handmade pasta and wood-fired specialities.",
            "cuisine": "Italian",
            "service_hours": {
                "lunch": ["11:30", "15:00"],
                "dinner": ["18:00", "22:30"],
            },
            "meal_types": ["lunch", "dinner"],
            "price_tier": "$$",
        },
        {
            "id": "poi_artisanal_bistro",
            "name": "Artisanal Coffee Roasters & Cafe",
            "category": "Cafe & Dining",
            "tags": ["cafe", "food", "coffee", "bistro", "breakfast", "pastries"],
            "rating": 4.6,
            "dwell": 35,
            "frac": 0.75,
            "lateral_km": 0.3,
            "lateral_bearing_offset": -90.0,
            "desc": "Popular local culinary stop serving specialty coffee, fresh pastries, and regional brunch.",
            "cuisine": "Cafe / Bakery",
            "service_hours": {
                "breakfast": ["07:30", "11:30"],
                "lunch": ["11:30", "16:00"],
            },
            "meal_types": ["breakfast", "lunch"],
            "price_tier": "$$",
        },
        {
            "id": "poi_scenic_skydeck",
            "name": "Panoramic City Observation Skydeck",
            "category": "Scenic Viewpoint",
            "tags": ["scenic", "viewpoint", "modern", "landmark"],
            "rating": 4.8,
            "dwell": 45,
            "frac": 0.85,
            "lateral_km": 0.8,
            "lateral_bearing_offset": 90.0,
            "desc": "High observation point offering 360-degree views of the skyline and surrounding landscape.",
            "cuisine": None,
            "service_hours": None,
            "meal_types": [],
            "price_tier": None,
        },
        {
            "id": "poi_craft_market",
            "name": "Central Artisans Market & Food Hall",
            "category": "Market & Shopping",
            "tags": ["shopping", "food", "market", "culture"],
            "rating": 4.5,
            "dwell": 45,
            "frac": 0.35,
            "lateral_km": 1.8,
            "lateral_bearing_offset": -90.0,
            "desc": "Vibrant indoor bazaar with local handcrafted goods, street eats, and gourmet treats.",
            "cuisine": "Street Food & Local",
            "service_hours": {
                "lunch": ["10:00", "18:00"],
            },
            "meal_types": ["lunch"],
            "price_tier": "$",
        },
        {
            "id": "poi_deep_outlier",
            "name": "Outer Regional Nature Reserve (Detour Outlier)",
            "category": "Nature Reserve",
            "tags": ["nature", "scenic", "gardens", "park"],
            "rating": 4.7,
            "dwell": 90,
            "frac": 0.50,
            "lateral_km": 8.5,  # Deliberately outside default 3.5 km threshold
            "lateral_bearing_offset": 90.0,
            "desc": "Expansive nature reserve situated far outside the direct transit corridor.",
            "cuisine": None,
            "service_hours": None,
            "meal_types": [],
            "price_tier": None,
        },
    ]

    candidate_pois = []
    for t in poi_templates:
        # Step 1: Find midpoint along corridor line at fraction t['frac']
        step_dist = total_dist_km * t["frac"]
        mid_lat, mid_lon = calculate_offset_coordinate(source.lat, source.lon, step_dist, base_bearing)

        # Step 2: Offset laterally perpendicular to corridor
        offset_bearing = (base_bearing + t["lateral_bearing_offset"]) % 360.0
        poi_lat, poi_lon = calculate_offset_coordinate(mid_lat, mid_lon, t["lateral_km"], offset_bearing)

        candidate_pois.append(
            CandidatePOI(
                id=t["id"],
                name=t["name"],
                lat=poi_lat,
                lon=poi_lon,
                category=t["category"],
                tags=t["tags"],
                rating=t["rating"],
                estimated_dwell_minutes=t["dwell"],
                address=f"Corridor Stop near {source.name or 'Origin'} - {destination.name or 'Destination'}",
                description=t["desc"],
                cuisine=t.get("cuisine"),
                service_hours=t.get("service_hours"),
                meal_types=t.get("meal_types", []),
                price_tier=t.get("price_tier"),
            )
        )

    return candidate_pois


