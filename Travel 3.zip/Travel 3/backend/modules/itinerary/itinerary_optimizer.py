"""Strict Itinerary Buffer Optimizer: Chronological scheduling with mandatory 20m arrival and pre-checkin buffers."""

from datetime import date, datetime, time, timedelta
import math
from typing import List, Optional, Tuple
from backend.modules.itinerary.poi_service import haversine_distance
from backend.schemas.itinerary import (
    BufferStatus,
    ItineraryGenerationRequest,
    ItineraryResponse,
    ItineraryStop,
    TimelineEvent,
    TimelineEventType,
)
from backend.schemas.poi import Coordinate

from backend.modules.routing.routing_service import get_road_route

# Mandatory buffer constants (in minutes)
MANDATORY_POST_ARRIVAL_BUFFER_MINUTES = 20
MANDATORY_PRE_CHECKIN_BUFFER_MINUTES = 20


def parse_time_or_datetime(
    time_str: str, base_date: Optional[date] = None
) -> datetime:
    """
    Parse a time string (HH:MM or HH:MM:SS) or ISO datetime into a concrete datetime object.
    Ensures calculations are performed using real datetime arithmetic.
    """
    time_str = time_str.strip()
    target_date = base_date or date(2026, 8, 22)

    # Try full ISO datetime first
    try:
        return datetime.fromisoformat(time_str)
    except (ValueError, TypeError):
        pass

    # Try HH:MM:SS or HH:MM
    parts = time_str.split(":")
    if len(parts) >= 2:
        hour = int(parts[0])
        minute = int(parts[1])
        second = int(parts[2]) if len(parts) > 2 else 0
        return datetime.combine(target_date, time(hour, minute, second))

    raise ValueError(f"Invalid time format: '{time_str}'. Expected HH:MM or ISO timestamp.")


def estimate_transit_minutes(
    origin: Coordinate,
    dest: Coordinate,
    transit_mode: str = "driving",
) -> int:
    """
    Estimate transit duration in minutes between two coordinates using road routing engine.
    """
    route = get_road_route(origin, dest, transit_mode)
    return route.duration_minutes


def generate_optimized_itinerary(
    request: ItineraryGenerationRequest,
) -> ItineraryResponse:
    """
    Build an optimized chronological itinerary enforcing:
    1. Mandatory 20-minute post-arrival buffer at transit hub (first movement starts >= arrival + 20m).
    2. Mandatory 20-minute pre-checkin buffer at destination hotel (hotel arrival <= check_in - 20m).
    3. Chronological timeline using actual road-network routing duration & distance for EVERY leg.
    4. Real datetime arithmetic handling midnight/cross-day transitions.
    """
    # Parse base travel date
    base_date = None
    if request.travel_date:
        try:
            base_date = date.fromisoformat(request.travel_date)
        except ValueError:
            base_date = date(2026, 8, 22)
    else:
        base_date = date(2026, 8, 22)

    # Parse arrival and check-in datetimes
    dt_arrival = parse_time_or_datetime(request.transit_arrival_time, base_date)
    dt_checkin = parse_time_or_datetime(request.check_in_time, base_date)

    # Handle cross-midnight scheduling if check-in time is logically later but string is <= arrival
    if dt_checkin <= dt_arrival:
        # Check-in is on the next calendar day
        dt_checkin = dt_checkin + timedelta(days=1)

    timeline: List[TimelineEvent] = []
    warnings: List[str] = []
    total_transit_minutes = 0
    total_dwell_minutes = 0

    # 1. Event: Transit Hub Arrival
    timeline.append(
        TimelineEvent(
            event_type=TimelineEventType.TRANSIT_ARRIVAL,
            title=f"Transit Arrival at {request.source.name or 'Transit Hub'}",
            start_time=dt_arrival.strftime("%H:%M"),
            end_time=dt_arrival.strftime("%H:%M"),
            duration_minutes=0,
            location=request.source,
            description=f"Deboarding and arrival at {request.source.name or 'Transit Hub'}",
            details={"type": "arrival_milestone"},
        )
    )

    # 2. Event: RULE 1 - Mandatory 20-Minute Post-Arrival Buffer
    dt_buffer_end = dt_arrival + timedelta(minutes=MANDATORY_POST_ARRIVAL_BUFFER_MINUTES)
    timeline.append(
        TimelineEvent(
            event_type=TimelineEventType.BUFFER,
            title="+20m Post-Arrival Buffer",
            start_time=dt_arrival.strftime("%H:%M"),
            end_time=dt_buffer_end.strftime("%H:%M"),
            duration_minutes=MANDATORY_POST_ARRIVAL_BUFFER_MINUTES,
            location=request.source,
            description="Deboarding, baggage claim, terminal exit, and transit readiness",
            status_badge="+20m Post-Arrival Buffer",
            is_buffer_satisfied=True,
            details={"required_buffer_minutes": MANDATORY_POST_ARRIVAL_BUFFER_MINUTES},
        )
    )

    # Current state tracking
    current_time = dt_buffer_end
    current_coord = request.source
    custom_transit_idx = 0

    # 3. Intermediate POI Stops and Road-Routed Transit Legs
    for i, stop in enumerate(request.stops, start=1):
        stop_coord = Coordinate(lat=stop.lat, lon=stop.lon, name=stop.name)

        # Route actual road network leg from current location to this POI stop
        road_route = get_road_route(current_coord, stop_coord, request.transit_mode)

        if request.custom_transit_durations and custom_transit_idx < len(request.custom_transit_durations):
            transit_duration = request.custom_transit_durations[custom_transit_idx]
            custom_transit_idx += 1
        else:
            transit_duration = road_route.duration_minutes

        dt_transit_start = current_time
        dt_transit_end = dt_transit_start + timedelta(minutes=transit_duration)
        total_transit_minutes += transit_duration

        timeline.append(
            TimelineEvent(
                event_type=TimelineEventType.TRANSIT,
                title=f"Transit to {stop.name}",
                start_time=dt_transit_start.strftime("%H:%M"),
                end_time=dt_transit_end.strftime("%H:%M"),
                duration_minutes=transit_duration,
                origin_location=current_coord,
                destination_location=stop_coord,
                transit_mode=request.transit_mode,
                distance_km=road_route.distance_km,
                route_geometry=road_route.geometry.model_dump(),
                road_routed=not road_route.is_fallback,
                description=f"{request.transit_mode.capitalize()} via road network ({road_route.distance_km:.1f} km · {transit_duration} min)",
                details={
                    "leg_index": i,
                    "transit_minutes": transit_duration,
                    "distance_km": road_route.distance_km,
                    "distance_meters": road_route.distance_meters,
                    "is_road_fallback": road_route.is_fallback,
                },
            )
        )

        # POI or Restaurant Stop
        is_restaurant_stop = (
            stop.is_restaurant
            or (stop.category and stop.category.strip().lower() in ["restaurant", "cafe & dining", "cafe", "bistro", "dining"])
            or bool(stop.cuisine)
        )

        dwell_duration = max(5, stop.dwell_minutes)
        dt_stop_start = dt_transit_end
        dt_stop_end = dt_stop_start + timedelta(minutes=dwell_duration)
        total_dwell_minutes += dwell_duration

        is_open_meal = None
        meal_label = None

        if is_restaurant_stop and stop.service_hours:
            from backend.modules.itinerary.poi_ranker import check_meal_availability
            is_open_meal, meal_label = check_meal_availability(stop.service_hours, dt_stop_start.strftime("%H:%M"))
            if is_open_meal is False:
                warnings.append(
                    f"Restaurant Timing Warning: '{stop.name}' may be CLOSED at your planned arrival time of {dt_stop_start.strftime('%H:%M')}."
                )

        if is_restaurant_stop:
            event_type = TimelineEventType.MEAL_STOP
            desc_prefix = f"Dining at {stop.name}"
            if stop.cuisine:
                desc_prefix += f" ({stop.cuisine})"
            if meal_label:
                desc_prefix += f" · {meal_label}"
            desc = f"{desc_prefix} (Dwell: {dwell_duration} min)"
        else:
            event_type = TimelineEventType.POI_VISIT
            desc = f"Visit and explore {stop.name} (Dwell: {dwell_duration} min)"

        timeline.append(
            TimelineEvent(
                event_type=event_type,
                title=stop.name,
                start_time=dt_stop_start.strftime("%H:%M"),
                end_time=dt_stop_end.strftime("%H:%M"),
                duration_minutes=dwell_duration,
                location=stop_coord,
                dwell_minutes=dwell_duration,
                category=stop.category,
                cuisine=stop.cuisine,
                meal_type=stop.meal_type or ("Lunch" if 11 <= dt_stop_start.hour <= 15 else "Dinner" if dt_stop_start.hour >= 18 else "Meal"),
                traffic_light=stop.traffic_light,
                preference_score=stop.preference_score,
                description=desc,
                is_meal_open=is_open_meal,
                status_badge=f"🍽️ {meal_label}" if meal_label else None,
                details={
                    "poi_id": stop.poi_id,
                    "tags": stop.tags,
                    "preference_score": stop.preference_score,
                    "traffic_light": stop.traffic_light.value if stop.traffic_light else None,
                    "cuisine": stop.cuisine,
                    "is_restaurant": is_restaurant_stop,
                    "is_meal_open": is_open_meal,
                },
            )
        )

        current_time = dt_stop_end
        current_coord = stop_coord

    # 4. Final Transit Leg: From last location to Hotel / Destination
    final_road_route = get_road_route(current_coord, request.destination, request.transit_mode)

    if request.custom_transit_durations and custom_transit_idx < len(request.custom_transit_durations):
        hotel_transit_duration = request.custom_transit_durations[custom_transit_idx]
    else:
        hotel_transit_duration = final_road_route.duration_minutes

    dt_hotel_transit_start = current_time
    dt_hotel_arrival = dt_hotel_transit_start + timedelta(minutes=hotel_transit_duration)
    total_transit_minutes += hotel_transit_duration

    timeline.append(
        TimelineEvent(
            event_type=TimelineEventType.TRANSIT,
            title=f"Transit to {request.destination.name or 'Hotel'}",
            start_time=dt_hotel_transit_start.strftime("%H:%M"),
            end_time=dt_hotel_arrival.strftime("%H:%M"),
            duration_minutes=hotel_transit_duration,
            origin_location=current_coord,
            destination_location=request.destination,
            transit_mode=request.transit_mode,
            distance_km=final_road_route.distance_km,
            route_geometry=final_road_route.geometry.model_dump(),
            road_routed=not final_road_route.is_fallback,
            description=f"{request.transit_mode.capitalize()} via road network to {request.destination.name or 'Hotel'} ({final_road_route.distance_km:.1f} km · {hotel_transit_duration} min)",
            details={
                "leg_index": len(request.stops) + 1,
                "transit_minutes": hotel_transit_duration,
                "distance_km": final_road_route.distance_km,
                "distance_meters": final_road_route.distance_meters,
                "is_road_fallback": final_road_route.is_fallback,
            },
        )
    )


    # 5. Event: RULE 2 - Hotel Arrival & Pre-Checkin Window
    # Calculate available buffer before hotel check-in
    pre_checkin_delta = dt_checkin - dt_hotel_arrival
    pre_checkin_minutes = int(pre_checkin_delta.total_seconds() / 60)
    pre_checkin_satisfied = pre_checkin_minutes >= MANDATORY_PRE_CHECKIN_BUFFER_MINUTES

    timeline.append(
        TimelineEvent(
            event_type=TimelineEventType.HOTEL_CHECKIN_ARRIVAL,
            title=f"Arrival at {request.destination.name or 'Destination Hotel'}",
            start_time=dt_hotel_arrival.strftime("%H:%M"),
            end_time=dt_checkin.strftime("%H:%M"),
            duration_minutes=max(0, pre_checkin_minutes),
            location=request.destination,
            description=f"Arrive at {request.destination.name or 'Hotel'} at {dt_hotel_arrival.strftime('%H:%M')}. Scheduled check-in at {dt_checkin.strftime('%H:%M')}.",
            status_badge=">= 20m Pre-Checkin Guaranteed Arrival" if pre_checkin_satisfied else "Pre-Checkin Buffer Violated",
            is_buffer_satisfied=pre_checkin_satisfied,
            details={
                "hotel_arrival_time": dt_hotel_arrival.strftime("%H:%M"),
                "check_in_time": dt_checkin.strftime("%H:%M"),
                "available_buffer_minutes": pre_checkin_minutes,
                "required_buffer_minutes": MANDATORY_PRE_CHECKIN_BUFFER_MINUTES,
                "booking_id": request.booking_id,
            },
        )
    )

    # Buffer Status Evaluation
    post_arrival_buffer_minutes = MANDATORY_POST_ARRIVAL_BUFFER_MINUTES
    post_arrival_satisfied = True

    is_feasible = post_arrival_satisfied and pre_checkin_satisfied

    if not pre_checkin_satisfied:
        if pre_checkin_minutes < 0:
            deficit = abs(pre_checkin_minutes) + MANDATORY_PRE_CHECKIN_BUFFER_MINUTES
            warnings.append(
                f"Infeasible Schedule: Estimated hotel arrival at {dt_hotel_arrival.strftime('%H:%M')} is "
                f"{abs(pre_checkin_minutes)}m AFTER check-in ({dt_checkin.strftime('%H:%M')}). "
                f"Requires reducing trip activities by at least {deficit} minutes to satisfy the 20-minute buffer."
            )
        else:
            deficit = MANDATORY_PRE_CHECKIN_BUFFER_MINUTES - pre_checkin_minutes
            warnings.append(
                f"Infeasible Schedule: Hotel arrival at {dt_hotel_arrival.strftime('%H:%M')} leaves only "
                f"{pre_checkin_minutes}m before check-in ({dt_checkin.strftime('%H:%M')}). "
                f"Violates the mandatory 20-minute pre-checkin buffer by {deficit} minutes."
            )

    total_trip_minutes = int((dt_checkin - dt_arrival).total_seconds() / 60)

    buffer_status = BufferStatus(
        post_arrival_buffer_minutes=post_arrival_buffer_minutes,
        post_arrival_buffer_satisfied=post_arrival_satisfied,
        pre_checkin_buffer_minutes=pre_checkin_minutes,
        pre_checkin_buffer_satisfied=pre_checkin_satisfied,
        required_post_arrival_minutes=MANDATORY_POST_ARRIVAL_BUFFER_MINUTES,
        required_pre_checkin_minutes=MANDATORY_PRE_CHECKIN_BUFFER_MINUTES,
    )

    num_restaurants = sum(1 for e in timeline if e.event_type == TimelineEventType.MEAL_STOP)
    num_pois = sum(1 for e in timeline if e.event_type == TimelineEventType.POI_VISIT)

    summary_parts = []
    if num_pois > 0:
        summary_parts.append(f"{num_pois} POI stop(s)")
    if num_restaurants > 0:
        summary_parts.append(f"{num_restaurants} Meal stop(s)")
    if not summary_parts:
        summary_parts.append("Direct transit")

    summary_text = (
        f"Trip from {request.source.name or 'Hub'} to {request.destination.name or 'Hotel'}: "
        f"{', '.join(summary_parts)}, {total_transit_minutes}m transit, {total_dwell_minutes}m dwell. "
        f"{'Schedule is FEASIBLE with all buffers satisfied.' if is_feasible else 'Schedule is INFEASIBLE: buffer constraints violated.'}"
    )

    return ItineraryResponse(
        is_feasible=is_feasible,
        timeline=timeline,
        buffer_status=buffer_status,
        total_duration_minutes=total_trip_minutes,
        total_transit_minutes=total_transit_minutes,
        total_dwell_minutes=total_dwell_minutes,
        warnings=warnings,
        source=request.source,
        destination=request.destination,
        summary=summary_text,
    )
