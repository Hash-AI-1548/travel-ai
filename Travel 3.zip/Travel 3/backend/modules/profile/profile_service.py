"""Traveler profile builder and persona synthesis module."""

from typing import Dict, List
from backend.schemas.profile import (
    PacingType,
    TravelerProfileInput,
    TravelerProfile,
    ProfileSynthesizeResponse,
)


def synthesize_traveler_profile(data: TravelerProfileInput) -> ProfileSynthesizeResponse:
    """
    Builds a traveler profile with calculated pacing constraints,
    interest weights, dwell tolerances, and dietary sensitivities.
    """
    # 1. Pacing & Dwell calculations
    if data.pace == PacingType.RELAXED:
        max_stops = 2
        target_dwell = 60
        pace_label = "Leisurely Explorer"
    elif data.pace == PacingType.FAST:
        max_stops = 5
        target_dwell = 35
        pace_label = "High-Energy Sprint"
    else:
        max_stops = 3
        target_dwell = 45
        pace_label = "Balanced Voyager"

    # Persona determination
    persona_id = "general_traveler"
    if "art" in data.interests and "history" in data.interests:
        persona_id = "culture_heritage_buff"
        persona_label = f"Cultural Connoisseur ({pace_label})"
    elif "food" in data.interests or len(data.cuisines) > 0:
        persona_id = "culinary_epicure"
        persona_label = f"Gourmet & Dining Explorer ({pace_label})"
    elif "scenic" in data.interests or "gardens" in data.interests:
        persona_id = "scenic_nature_enthusiast"
        persona_label = f"Scenic Horizon Seeker ({pace_label})"
    else:
        persona_label = f"Custom Traveler ({pace_label})"

    # 2. Interest Weights Computation
    interest_weights: Dict[str, float] = {}
    base_weight = 1.0 / max(1, len(data.interests))
    for interest in data.interests:
        interest_weights[interest.lower()] = round(base_weight, 3)

    for cuisine in data.cuisines:
        interest_weights[cuisine.lower()] = 0.85

    profile = TravelerProfile(
        persona_id=persona_id,
        persona_label=persona_label,
        pace=data.pace,
        max_stops_per_day=max_stops,
        target_dwell_minutes=target_dwell,
        interest_weights=interest_weights,
        dietary_flags=data.dietary,
        budget_tier=data.budget,
        blendin_weight=data.blendin_level,
        accessibility_enforced=data.accessibility,
    )

    summary = (
        f"Profile: {persona_label}. Optimized for up to {max_stops} stops/day with ~{target_dwell}m dwell time. "
        f"BlendIn authenticity preference: {int(data.blendin_level * 100)}%."
    )

    return ProfileSynthesizeResponse(profile=profile, summary=summary)
