"""Cultural etiquette, attire recommendations, and local customs service."""

from typing import Dict, List
from backend.schemas.cultural import (
    AttireGuidance,
    CulturalGuide,
    CulturalNorm,
    CulturalGuideRequest,
    CulturalGuideResponse,
)


CITY_CULTURAL_KNOWLEDGE: Dict[str, dict] = {
    "paris": {
        "name": "Paris, France",
        "tipping": "Service is included (service compris). Rounding up or leaving 5-10% in bistros/cafes is appreciated for great service.",
        "general_etiquette": [
            CulturalNorm(category="Greetings", rule="Always say 'Bonjour Madame/Monsieur' upon entering any shop, café, or elevator.", importance="Mandatory"),
            CulturalNorm(category="Dining", rule="Keep bread on the table beside your plate, not on the plate. Never ask for butter with bread at dinner.", importance="Recommended"),
            CulturalNorm(category="Volume", rule="Keep conversational voice low on public transit (métro) and in restaurants.", importance="Good Practice"),
        ],
        "attire_guidelines": [
            AttireGuidance(
                occasion="Historical Monuments & Cathedrals (e.g. Notre-Dame, Sainte-Chapelle)",
                recommended_outfit="Modest attire covering shoulders and knees. Smart comfortable walking shoes for cobblestones.",
                prohibited_items=["Beachwear", "Revealing sleeveless tops", "Loud sports jerseys"],
                weather_note="Light breathable fabrics in summer; stylish trench coat or wool layers in spring/autumn.",
                cultural_context="Active religious and historic sanctuaries require respectful decorum.",
            ),
            AttireGuidance(
                occasion="Bistros & Evening Fine Dining",
                recommended_outfit="Smart casual to elegant. Well-fitted trousers, blazer, chic dress or dark denim with leather shoes.",
                prohibited_items=["Sweatpants", "Flip-flops", "Gym tank tops"],
                weather_note="Evenings can cool down rapidly along the Seine.",
                cultural_context="Parisian dining culture values understated elegance (élégance sobre).",
            ),
        ],
        "dining_etiquette": [
            "Wait for all guests to be served and say 'Bon appétit' before eating.",
            "Rest your hands on the table (wrists only), not in your lap.",
            "Ask for the bill with 'L'addition, s'il vous plaît' — servers will never rush you.",
        ],
    },
    "tokyo": {
        "name": "Tokyo, Japan",
        "tipping": "No tipping. Tipping can be considered confusing or disrespectful.",
        "general_etiquette": [
            CulturalNorm(category="Transit", rule="Keep mobile phones on silent ('manner mode') and avoid talking on trains.", importance="Mandatory"),
            CulturalNorm(category="Shoes", rule="Remove shoes when stepping onto tatami mats or entering homes/traditional ryokan.", importance="Mandatory"),
            CulturalNorm(category="Waste", rule="Carry a small bag for your trash as public bins are rare.", importance="Good Practice"),
        ],
        "attire_guidelines": [
            AttireGuidance(
                occasion="Shinto Shrines & Buddhist Temples (e.g. Meiji Jingu, Senso-ji)",
                recommended_outfit="Clean, modest clothing. Easy-to-slip-off footwear with clean socks.",
                prohibited_items=["Dirty/torn socks", "Overly revealing clothing"],
                cultural_context="Purify hands and mouth at the temizuya water pavilion before approaching.",
            ),
            AttireGuidance(
                occasion="Izakaya & Casual Dining in Shibuya/Shinjuku",
                recommended_outfit="Neat casual or streetwear. Layered clothing for indoor heating/cooling transitions.",
                prohibited_items=[],
                cultural_context="Order small dishes to share alongside draft beer or highballs.",
            ),
        ],
        "dining_etiquette": [
            "Say 'Itadakimasu' before dining and 'Gochisousama deshita' after concluding.",
            "Never stick chopsticks vertically into a bowl of rice (associated with funerals).",
            "Slurping noodles is accepted and signals appreciation of freshness.",
        ],
    },
    "default": {
        "name": "Global Travel Destination",
        "tipping": "Check local customs for standard service gratuity.",
        "general_etiquette": [
            CulturalNorm(category="General", rule="Respect local heritage, religious monuments, and environmental guidelines.", importance="Mandatory"),
            CulturalNorm(category="Greetings", rule="Learn simple local greetings (hello, please, thank you).", importance="Recommended"),
        ],
        "attire_guidelines": [
            AttireGuidance(
                occasion="Monuments & Heritage Sites",
                recommended_outfit="Comfortable, respectful clothing covering shoulders and knees.",
                prohibited_items=["Inappropriate graphic tees", "Beachwear"],
                cultural_context="Preserve site sanctity and decorum.",
            ),
        ],
        "dining_etiquette": [
            "Observe local table manners and dietary customs.",
        ],
    },
}


def get_cultural_guide(req: CulturalGuideRequest) -> CulturalGuideResponse:
    """Retrieves cultural etiquette, dining norms, and attire recommendations."""
    dest_lower = req.destination.lower()
    city_key = "default"
    for k in CITY_CULTURAL_KNOWLEDGE.keys():
        if k in dest_lower:
            city_key = k
            break

    data = CITY_CULTURAL_KNOWLEDGE[city_key]

    guide = CulturalGuide(
        destination_name=data["name"],
        season=req.season,
        general_etiquette=data["general_etiquette"],
        attire_guidelines=data["attire_guidelines"],
        tipping_customs=data["tipping"],
        dining_etiquette=data["dining_etiquette"],
    )

    return CulturalGuideResponse(guide=guide)
