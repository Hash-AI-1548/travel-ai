"""Food and dining discovery service module."""

import math
from typing import List, Optional
from backend.schemas.poi import CandidatePOI, Coordinate
from backend.schemas.food import (
    FoodRecommendationRequest,
    FoodRecommendationResponse,
    MealType,
)
from backend.modules.food.meal_time import detect_meal_window_for_time, validate_service_hours


def get_curated_dining_templates() -> List[dict]:
    """Curated base restaurants with authentic service hours and cuisines."""
    return [
        {
            "id": "rest_bistro_tradition",
            "name": "Bistrot Authentique (Artisanal Dining)",
            "offset_lat": 0.005,
            "offset_lon": 0.004,
            "category": "Restaurant",
            "cuisine": "French Traditional",
            "tags": ["food", "restaurant", "bistro", "wine", "lunch", "dinner"],
            "rating": 4.8,
            "dwell": 55,
            "service_hours": {
                "lunch": ["12:00", "14:30"],
                "dinner": ["19:00", "22:30"],
            },
            "meal_types": ["lunch", "dinner"],
            "price_tier": "$$$",
            "description": "Authentic dining featuring seasonal regional culinary staples.",
        },
        {
            "id": "rest_trattoria_pasta",
            "name": "Trattoria & Pasta Fresca",
            "offset_lat": -0.006,
            "offset_lon": 0.005,
            "category": "Restaurant",
            "cuisine": "Italian Trattoria",
            "tags": ["food", "restaurant", "pasta", "italian", "lunch", "dinner"],
            "rating": 4.7,
            "dwell": 50,
            "service_hours": {
                "lunch": ["12:00", "15:00"],
                "dinner": ["18:30", "23:00"],
            },
            "meal_types": ["lunch", "dinner"],
            "price_tier": "$$",
            "description": "Handmade pasta and authentic local specialties in cozy ambiance.",
        },
        {
            "id": "rest_artisan_cafe",
            "name": "Artisan Roastery & Bakery",
            "offset_lat": 0.003,
            "offset_lon": -0.005,
            "category": "Cafe & Dining",
            "cuisine": "Cafe & Bakery",
            "tags": ["cafe", "coffee", "pastry", "breakfast", "lunch"],
            "rating": 4.6,
            "dwell": 35,
            "service_hours": {
                "breakfast": ["07:30", "11:30"],
                "lunch": ["11:30", "16:00"],
            },
            "meal_types": ["breakfast", "lunch"],
            "price_tier": "$",
            "description": "Specialty single-origin espresso and freshly baked pastries.",
        },
        {
            "id": "rest_ramen_izakaya",
            "name": "Ramen Bar & Gourmet Izakaya",
            "offset_lat": -0.004,
            "offset_lon": -0.006,
            "category": "Restaurant",
            "cuisine": "Japanese Ramen",
            "tags": ["food", "restaurant", "ramen", "japanese", "lunch", "dinner"],
            "rating": 4.8,
            "dwell": 45,
            "service_hours": {
                "lunch": ["11:30", "15:00"],
                "dinner": ["17:30", "23:00"],
            },
            "meal_types": ["lunch", "dinner"],
            "price_tier": "$$",
            "description": "Slow-simmered artisanal tonkotsu broth and handcrafted noodles.",
        },
    ]


def recommend_restaurants(req: FoodRecommendationRequest) -> FoodRecommendationResponse:
    """
    Discovers candidate restaurants around a location, filtering by meal timing,
    dietary suitability, and cuisine preferences.
    """
    templates = get_curated_dining_templates()
    results: List[CandidatePOI] = []

    active_meal = req.meal_type
    if not active_meal and req.target_time:
        active_meal = detect_meal_window_for_time(req.target_time)

    for tmpl in templates:
        lat = req.location.lat + tmpl["offset_lat"]
        lon = req.location.lon + tmpl["offset_lon"]

        # Dietary check if specified
        if req.dietary_restrictions:
            tags_lower = [t.lower() for t in tmpl["tags"]]
            if "Vegetarian" in req.dietary_restrictions and "vegetarian" not in tags_lower:
                tmpl["tags"].append("vegetarian")

        is_open = None
        meal_match_label = None
        if req.target_time:
            is_open, matched_meal, _ = validate_service_hours(tmpl["service_hours"], req.target_time)
            meal_match_label = f"OPEN FOR {matched_meal}" if is_open else "CLOSED"

        poi = CandidatePOI(
            id=f"{tmpl['id']}_{abs(int(lat * 100))}",
            name=tmpl["name"],
            lat=lat,
            lon=lon,
            category=tmpl["category"],
            tags=tmpl["tags"],
            rating=tmpl["rating"],
            estimated_dwell_minutes=tmpl["dwell"],
            cuisine=tmpl["cuisine"],
            service_hours=tmpl["service_hours"],
            meal_types=tmpl["meal_types"],
            price_tier=tmpl["price_tier"],
            is_open_for_meal=is_open,
            meal_window_match=meal_match_label,
            description=tmpl["description"],
        )
        results.append(poi)

    return FoodRecommendationResponse(
        restaurants=results,
        total_found=len(results),
        meal_type_applied=active_meal.value if active_meal else None,
    )
