"""Meal timing validation and meal window discovery module."""

from typing import Dict, List, Optional, Tuple
from backend.schemas.food import MealType, MealWindow


MEAL_WINDOWS = {
    MealType.BREAKFAST: ("07:30", "11:00"),
    MealType.LUNCH: ("12:00", "14:30"),
    MealType.DINNER: ("18:30", "22:00"),
}


def detect_meal_window_for_time(time_str: str) -> Optional[MealType]:
    """Detects which standard meal window a time string falls into."""
    h, m = map(int, time_str.split(":"))
    mins = h * 60 + m

    if 7 * 60 + 30 <= mins <= 11 * 60:
        return MealType.BREAKFAST
    elif 11 * 60 + 30 <= mins <= 15 * 60:
        return MealType.LUNCH
    elif 18 * 60 <= mins <= 22 * 60 + 30:
        return MealType.DINNER
    return None


def validate_service_hours(service_hours: Optional[Dict[str, List[str]]], target_time: str) -> Tuple[Optional[bool], Optional[str], str]:
    """
    Validates whether a restaurant's explicit service hours accommodate the target arrival time.
    Returns: (is_open, matched_meal_type, explanatory_message)
    """
    if not service_hours:
        return None, None, "Service hours unknown — arrival eligibility unverified."

    th, tm = map(int, target_time.split(":"))
    t_mins = th * 60 + tm

    for meal_key, times in service_hours.items():
        if len(times) == 2:
            sh, sm = map(int, times[0].split(":"))
            eh, em = map(int, times[1].split(":"))
            s_mins = sh * 60 + sm
            e_mins = eh * 60 + em

            if s_mins <= t_mins <= e_mins:
                return True, meal_key.upper(), f"Open for {meal_key.capitalize()} ({times[0]} – {times[1]})."

    return False, None, f"Closed at {target_time}. Service periods: {service_hours}"
