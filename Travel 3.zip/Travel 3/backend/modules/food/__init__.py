"""Food & Dining discovery package."""

from backend.modules.food.meal_time import (
    detect_meal_window_for_time,
    validate_service_hours,
)
from backend.modules.food.food_service import recommend_restaurants

__all__ = [
    "detect_meal_window_for_time",
    "validate_service_hours",
    "recommend_restaurants",
]
