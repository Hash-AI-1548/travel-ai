"""Natural Language Processing module for extracting trip intent, entities, preferences and timing from freeform queries."""

import re
from typing import List, Tuple
from backend.schemas.nlp import ParsedTripIntent, NLPParseResponse


KNOWN_DESTINATIONS = {
    "paris": "Paris, France",
    "tokyo": "Tokyo, Japan",
    "new york": "New York, USA",
    "nyc": "New York, USA",
    "chennai": "Chennai, India",
    "rome": "Rome, Italy",
    "london": "London, UK",
}

KNOWN_TAGS = {
    "art": ["art", "museum", "gallery", "painting", "sculpture"],
    "history": ["history", "historic", "monument", "heritage", "ancient", "castle", "palace", "shrine", "temple"],
    "architecture": ["architecture", "gothic", "building", "cathedral", "tower", "bridge"],
    "cafe": ["cafe", "coffee", "bistro", "pastry", "bakery"],
    "scenic": ["scenic", "view", "viewpoint", "panorama", "skyline", "waterfront"],
    "gardens": ["garden", "gardens", "park", "nature", "botanical"],
    "modern": ["modern", "contemporary", "high-tech", "urban"],
    "shopping": ["shopping", "boutique", "market", "fashion"],
    "food": ["food", "dining", "cuisine", "gourmet", "restaurant", "culinary"],
}

KNOWN_CUISINES = {
    "french": ["french", "bistro", "patisserie"],
    "italian": ["italian", "pasta", "pizza", "osteria"],
    "japanese": ["japanese", "sushi", "ramen", "izakaya"],
    "indian": ["indian", "curry", "dosa", "biryani"],
    "american": ["american", "burger", "steakhouse", "grill"],
}


def parse_trip_query(query: str) -> NLPParseResponse:
    """
    Deterministically parses freeform natural language query into structured trip parameters.
    Extracts destination, party size, duration, pace, budget, tags, cuisines, dietary, and times.
    """
    lower = query.lower()
    entities: List[str] = []

    # 1. Destination Extraction
    dest_name = None
    for key, full_name in KNOWN_DESTINATIONS.items():
        if re.search(r'\b' + re.escape(key) + r'\b', lower):
            dest_name = full_name
            entities.append(f"Destination: {full_name}")
            break

    # 2. Party Size Extraction
    party_size = 1
    party_match = re.search(r'(\d+)\s*(?:people|person|persons|adults|travelers|travellers|of us)', lower)
    if party_match:
        party_size = int(party_match.group(1))
        entities.append(f"Party Size: {party_size}")
    elif "couple" in lower or re.search(r'\bfor 2\b|\bfor two\b', lower) or "with my friend" in lower or "with my partner" in lower:
        party_size = 2
        entities.append("Party Size: 2")
    elif "family" in lower:
        fam_match = re.search(r'family\s*(?:of\s*)?(\d+)', lower)
        party_size = int(fam_match.group(1)) if fam_match else 4
        entities.append(f"Party Size: {party_size}")

    # 3. Duration Days
    duration_days = 1
    dur_match = re.search(r'(\d+)[\s-]*(?:day|days|night|nights)', lower)
    if dur_match:
        duration_days = int(dur_match.group(1))
        entities.append(f"Duration: {duration_days} days")
    elif "weekend" in lower:
        duration_days = 2
        entities.append("Duration: 2 days")

    # 4. Pacing
    pace = "moderate"
    if any(w in lower for w in ["slow", "relaxed", "chill", "leisure", "laid back", "easy"]):
        pace = "relaxed"
        entities.append("Pace: Relaxed")
    elif any(w in lower for w in ["fast", "packed", "quick", "intensive", "cover all", "busy"]):
        pace = "fast"
        entities.append("Pace: Fast")

    # 5. Budget Tier
    budget_tier = "$$"
    if any(w in lower for w in ["luxury", "fine dining", "michelin", "five star", "$$$$", "high end"]):
        budget_tier = "$$$$"
        entities.append("Budget: Luxury ($$$$)")
    elif any(w in lower for w in ["upscale", "premium", "$$$"]):
        budget_tier = "$$$"
        entities.append("Budget: Premium ($$$)")
    elif any(w in lower for w in ["budget", "cheap", "backpack", "hostel", "inexpensive", "$"]):
        budget_tier = "$"
        entities.append("Budget: Budget ($)")

    # 6. Preferred Tags
    preferred_tags: List[str] = []
    for tag_key, keywords in KNOWN_TAGS.items():
        if any(re.search(r'\b' + re.escape(kw), lower) for kw in keywords):
            preferred_tags.append(tag_key)
    if preferred_tags:
        entities.append(f"Interests: {', '.join(preferred_tags)}")

    # 7. Preferred Cuisines
    preferred_cuisines: List[str] = []
    for cuisine_key, keywords in KNOWN_CUISINES.items():
        if any(re.search(r'\b' + re.escape(kw), lower) for kw in keywords):
            preferred_cuisines.append(cuisine_key.capitalize())
    if preferred_cuisines:
        entities.append(f"Cuisines: {', '.join(preferred_cuisines)}")

    # 8. Dietary Restrictions
    dietary: List[str] = []
    if "vegetarian" in lower or "veggie" in lower:
        dietary.append("Vegetarian")
    if "vegan" in lower:
        dietary.append("Vegan")
    if "halal" in lower:
        dietary.append("Halal")
    if "kosher" in lower:
        dietary.append("Kosher")
    if "gluten free" in lower or "gluten-free" in lower:
        dietary.append("Gluten-Free")
    if dietary:
        entities.append(f"Dietary: {', '.join(dietary)}")

    # 9. Accessibility
    accessibility_needed = False
    if any(w in lower for w in ["wheelchair", "accessible", "accessibility", "stroller", "mobility"]):
        accessibility_needed = True
        entities.append("Accessibility: Required")

    # 10. BlendIn Preference (Authenticity)
    blendin_preference = 0.5
    if any(w in lower for w in ["local", "hidden gem", "off the beaten path", "authentic", "non touristy", "blend in"]):
        blendin_preference = 0.85
        entities.append("BlendIn: High Authenticity (Local Secrets)")
    elif any(w in lower for w in ["classic", "iconic", "must see", "first time", "tourist highlights", "landmarks"]):
        blendin_preference = 0.2
        entities.append("BlendIn: Classic Highlights")

    # 11. Timing Defaults / Extraction
    arrival_time = "13:30"
    arr_match = re.search(r'arriv(?:e|ing|al)?\s*(?:at\s*)?(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)', lower)
    if arr_match:
        extracted_t = arr_match.group(1).strip()
        arrival_time = _normalize_time(extracted_t)
        entities.append(f"Arrival Time: {arrival_time}")

    checkin_time = "18:00"
    chk_match = re.search(r'check(?:ing|\s*in|ed)?\s*(?:in\s*)?(?:at\s*)?(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)', lower)
    if chk_match:
        extracted_t = chk_match.group(1).strip()
        checkin_time = _normalize_time(extracted_t)
        entities.append(f"Check-in Time: {checkin_time}")

    intent = ParsedTripIntent(
        destination_name=dest_name,
        party_size=party_size,
        duration_days=duration_days,
        pace=pace,
        budget_tier=budget_tier,
        preferred_tags=preferred_tags,
        preferred_cuisines=preferred_cuisines,
        dietary_restrictions=dietary,
        accessibility_needed=accessibility_needed,
        transit_arrival_time=arrival_time,
        check_in_time=checkin_time,
        blendin_preference=blendin_preference,
    )

    return NLPParseResponse(
        success=True,
        raw_query=query,
        parsed_intent=intent,
        extracted_entities=entities,
    )


def _normalize_time(time_str: str) -> str:
    """Normalizes time string into 24-hour HH:MM format."""
    time_str = time_str.strip().lower()
    is_pm = "pm" in time_str
    is_am = "am" in time_str
    clean = re.sub(r'[^\d:]', '', time_str)
    
    if ":" in clean:
        parts = clean.split(":")
        h, m = int(parts[0]), int(parts[1])
    else:
        h, m = int(clean), 0

    if is_pm and h < 12:
        h += 12
    elif is_am and h == 12:
        h = 0

    return f"{h:02d}:{m:02d}"
