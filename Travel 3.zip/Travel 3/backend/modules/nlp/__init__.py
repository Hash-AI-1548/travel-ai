"""NLP intent extraction package."""

from backend.modules.nlp.nlp_parser import parse_trip_query

__all__ = ["parse_trip_query"]
