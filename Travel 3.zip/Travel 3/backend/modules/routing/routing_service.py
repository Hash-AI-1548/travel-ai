"""Road Routing Service: OSRM (OpenStreetMap) road navigation with GeoJSON LineString geometry and caching."""

import logging
import math
from typing import Dict, List, Optional, Tuple
import httpx

from backend.modules.itinerary.poi_service import haversine_distance
from backend.schemas.poi import Coordinate
from backend.schemas.routing import GeoJSONGeometry, RouteResponse

logger = logging.getLogger(__name__)

# In-memory routing cache: (lat1, lon1, lat2, lon2, mode) -> RouteResponse
_ROUTING_CACHE: Dict[Tuple[float, float, float, float, str], RouteResponse] = {}

# OSRM Public Endpoint URL format
OSRM_BASE_URL = "http://router.project-osrm.org/route/v1"


def clear_routing_cache():
    """Clear in-memory routing cache."""
    _ROUTING_CACHE.clear()


def _get_cache_key(origin: Coordinate, destination: Coordinate, mode: str) -> Tuple[float, float, float, float, str]:
    """Generate normalized cache key rounded to 5 decimal places (~1.1 meter precision)."""
    return (
        round(origin.lat, 5),
        round(origin.lon, 5),
        round(destination.lat, 5),
        round(destination.lon, 5),
        mode.lower().strip(),
    )


def _synthesize_road_geometry_fallback(
    origin: Coordinate, destination: Coordinate, mode: str = "driving"
) -> RouteResponse:
    """
    Generate realistic road network routing fallback when external routing provider is unreachable.
    Uses urban road winding factor (1.28x haversine) and multi-vertex road curve geometry (GeoJSON LineString).
    """
    direct_dist_km = haversine_distance(origin.lat, origin.lon, destination.lat, destination.lon)

    if direct_dist_km < 0.02:
        return RouteResponse(
            distance_meters=round(direct_dist_km * 1000.0, 1),
            distance_km=round(direct_dist_km, 2),
            duration_seconds=0.0,
            duration_minutes=0,
            mode=mode,
            geometry=GeoJSONGeometry(
                type="LineString",
                coordinates=[[origin.lon, origin.lat], [destination.lon, destination.lat]],
            ),
            is_fallback=True,
            route_summary="Arrived at destination",
        )

    # Road network detour factor in urban grid (~1.28x direct distance)
    road_dist_km = direct_dist_km * 1.28
    road_dist_meters = road_dist_km * 1000.0

    # Speed profile
    if mode.lower() == "walking":
        speed_kmh = 4.8
        overhead_sec = 0.0
    else:  # driving / road transit
        speed_kmh = 32.0  # realistic urban driving speed
        overhead_sec = 45.0  # signal / intersection delay

    duration_sec = (road_dist_km / speed_kmh) * 3600.0 + overhead_sec
    duration_min = max(1, int(math.ceil(duration_sec / 60.0)))

    # Generate realistic multi-vertex road path (intermediate road turns)
    # GeoJSON standard: [longitude, latitude]
    num_subsegments = max(4, min(12, int(direct_dist_km * 3)))
    coords: List[List[float]] = []

    # Perpendicular vector for slight urban curvature
    dx = destination.lon - origin.lon
    dy = destination.lat - origin.lat
    perp_x = -dy * 0.08
    perp_y = dx * 0.08

    for i in range(num_subsegments + 1):
        t = i / float(num_subsegments)
        wave = math.sin(t * math.pi)
        lat = origin.lat + t * dy + wave * perp_y
        lon = origin.lon + t * dx + wave * perp_x
        coords.append([round(lon, 6), round(lat, 6)])

    return RouteResponse(
        distance_meters=round(road_dist_meters, 1),
        distance_km=round(road_dist_km, 2),
        duration_seconds=round(duration_sec, 1),
        duration_minutes=duration_min,
        mode=mode,
        geometry=GeoJSONGeometry(type="LineString", coordinates=coords),
        is_fallback=True,
        route_summary=f"Road route via local road network ({road_dist_km:.2f} km)",
    )


def get_road_route(
    origin: Coordinate,
    destination: Coordinate,
    mode: str = "driving",
    timeout_seconds: float = 4.0,
) -> RouteResponse:
    """
    Fetch exact road distance, duration, and GeoJSON LineString geometry between origin and destination.
    Uses OpenStreetMap / OSRM routing engine with in-memory caching and resilient fallback.
    """
    # 1. Check in-memory routing cache first
    cache_key = _get_cache_key(origin, destination, mode)
    if cache_key in _ROUTING_CACHE:
        return _ROUTING_CACHE[cache_key]

    # Map mode to OSRM profile
    mode_normalized = mode.lower().strip()
    profile = "driving"
    if mode_normalized == "walking":
        profile = "walking"
    elif mode_normalized == "transit":
        # OSRM public server handles road transit/driving profiles
        profile = "driving"

    # OSRM coordinate format is {longitude},{latitude}
    url = f"{OSRM_BASE_URL}/{profile}/{origin.lon:.6f},{origin.lat:.6f};{destination.lon:.6f},{destination.lat:.6f}?overview=full&geometries=geojson"

    headers = {
        "User-Agent": "CorridorPlanner/1.0 (Travel Platform Road Routing Service; contact@travelcorridor.local)"
    }

    try:
        with httpx.Client(timeout=timeout_seconds, follow_redirects=True) as client:
            resp = client.get(url, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("code") == "Ok" and len(data.get("routes", [])) > 0:
                    best_route = data["routes"][0]
                    dist_meters = float(best_route.get("distance", 0.0))
                    dist_km = round(dist_meters / 1000.0, 2)
                    dur_seconds = float(best_route.get("duration", 0.0))
                    dur_minutes = max(1, int(math.ceil(dur_seconds / 60.0))) if dist_meters > 50 else 0

                    geojson_geom = best_route.get("geometry", {})
                    coords = geojson_geom.get("coordinates", [])

                    if not coords:
                        coords = [[origin.lon, origin.lat], [destination.lon, destination.lat]]

                    legs = best_route.get("legs", [])
                    summary_parts = []
                    if legs and "summary" in legs[0] and legs[0]["summary"]:
                        summary_parts.append(f"via {legs[0]['summary']}")
                    summary_str = f"Road route {' '.join(summary_parts)} ({dist_km} km, {dur_minutes} min)".strip()

                    result = RouteResponse(
                        distance_meters=dist_meters,
                        distance_km=dist_km,
                        duration_seconds=dur_seconds,
                        duration_minutes=dur_minutes,
                        mode=mode_normalized,
                        geometry=GeoJSONGeometry(type="LineString", coordinates=coords),
                        is_fallback=False,
                        route_summary=summary_str,
                    )

                    _ROUTING_CACHE[cache_key] = result
                    return result
    except Exception as exc:
        logger.warning(f"OSRM routing request failed ({exc}); using synthesized road network fallback.")

    # Fallback to realistic road network geometry
    fallback_route = _synthesize_road_geometry_fallback(origin, destination, mode_normalized)
    _ROUTING_CACHE[cache_key] = fallback_route
    return fallback_route


def get_multi_segment_route(
    points: List[Coordinate],
    mode: str = "driving",
) -> List[RouteResponse]:
    """
    Route multiple consecutive itinerary points:
    points[0] -> points[1], points[1] -> points[2], ..., points[N-2] -> points[N-1].
    Every single segment is independently road-routed with its own distance, duration, and GeoJSON geometry.
    """
    if len(points) < 2:
        return []

    segments: List[RouteResponse] = []
    for i in range(len(points) - 1):
        origin = points[i]
        dest = points[i + 1]
        route_seg = get_road_route(origin, dest, mode)
        segments.append(route_seg)

    return segments
