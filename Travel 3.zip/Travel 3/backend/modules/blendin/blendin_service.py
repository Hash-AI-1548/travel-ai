"""BlendIn module: Authenticity vs Familiarity scoring and itinerary balancing."""

from typing import List
from backend.schemas.poi import RankedPOI
from backend.schemas.blendin import (
    BlendInMetrics,
    BlendInScoreRequest,
    BlendInScoreResponse,
    BlendInItineraryRequest,
    BlendInItineraryResponse,
)


TOURIST_ICONIC_KEYWORDS = ["louvre", "eiffel", "notre_dame", "tokyo_tower", "statue_of_liberty", "grand_central", "museum", "cathedral", "monument"]
LOCAL_SECRET_KEYWORDS = ["bistro", "izakaya", "market", "trattoria", "neighborhood", "bakery", "street-food", "roastery", "square"]


def calculate_blendin_score(req: BlendInScoreRequest) -> BlendInScoreResponse:
    """
    Computes authenticity score (local patronage / hidden gem nature)
    vs familiarity score (iconic landmark visibility).
    """
    lower_id = req.poi_id.lower()
    lower_name = req.name.lower()
    tags_lower = [t.lower() for t in req.tags]

    is_iconic = any(kw in lower_id or kw in lower_name or kw in tags_lower for kw in TOURIST_ICONIC_KEYWORDS)
    is_local = any(kw in lower_id or kw in lower_name or kw in tags_lower for kw in LOCAL_SECRET_KEYWORDS) or (req.category.lower() in ["restaurant", "cafe & dining"])

    if is_local and not is_iconic:
        authenticity = 0.88
        familiarity = 0.35
        patronage = 80
        cat = "Local Favorite"
    elif is_iconic and not is_local:
        authenticity = 0.45
        familiarity = 0.95
        patronage = 25
        cat = "Iconic Landmark"
    elif is_local and is_iconic:
        authenticity = 0.70
        familiarity = 0.75
        patronage = 50
        cat = "Balanced Gem"
    else:
        authenticity = 0.60
        familiarity = 0.50
        patronage = 60
        cat = "Balanced"

    metrics = BlendInMetrics(
        poi_id=req.poi_id,
        poi_name=req.name,
        authenticity_score=authenticity,
        familiarity_score=familiarity,
        local_patronage_pct=patronage,
        blendin_category=cat,
    )

    return BlendInScoreResponse(metrics=metrics)


def balance_itinerary_blendin(req: BlendInItineraryRequest) -> BlendInItineraryResponse:
    """
    Re-scores or ranks stops according to user's target BlendIn preference:
    target_blendin = 0.0 -> favors top familiarity (world-famous tourist spots)
    target_blendin = 1.0 -> favors top authenticity (authentic local immersion)
    """
    balanced: List[RankedPOI] = []
    total_auth = 0.0
    total_fam = 0.0

    target = req.target_blendin

    for stop in req.stops:
        score_req = BlendInScoreRequest(
            poi_id=stop.id,
            name=stop.name,
            category=stop.category,
            tags=stop.tags,
            rating=stop.rating,
        )
        metrics = calculate_blendin_score(score_req).metrics

        # Blend score: weight by target
        blend_score = (target * metrics.authenticity_score) + ((1.0 - target) * metrics.familiarity_score)
        
        # Combine with existing preference score
        combined_score = round(0.7 * stop.preference_score + 0.3 * blend_score, 3)

        updated_stop = stop.model_copy()
        updated_stop.preference_score = combined_score
        
        # Keep traffic light deterministic with new combined score
        if combined_stop_tier(combined_score):
            updated_stop.traffic_light = combined_stop_tier(combined_score)

        balanced.append(updated_stop)
        total_auth += metrics.authenticity_score
        total_fam += metrics.familiarity_score

    n = max(1, len(req.stops))
    avg_auth = round(total_auth / n, 2)
    avg_fam = round(total_fam / n, 2)

    summary = (
        f"Itinerary balanced for {int(target * 100)}% BlendIn Authenticity. "
        f"Average authenticity: {avg_auth}, Average familiarity: {avg_fam}."
    )

    return BlendInItineraryResponse(
        balanced_stops=balanced,
        overall_authenticity=avg_auth,
        overall_familiarity=avg_fam,
        blendin_summary=summary,
    )


def combined_stop_tier(score: float):
    from backend.schemas.poi import TrafficLightClassification
    if score >= 0.65:
        return TrafficLightClassification.GREEN
    elif score >= 0.35:
        return TrafficLightClassification.YELLOW
    return TrafficLightClassification.RED
