"""Automated unit and API tests for Cultural etiquette and attire guidance."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.cultural.cultural_service import get_cultural_guide
from backend.schemas.cultural import CulturalGuideRequest

client = TestClient(app)


def test_cultural_guide_paris():
    """Returns Paris etiquette, tipping, and monument dress code."""
    req = CulturalGuideRequest(destination="Paris, France", season="summer")
    res = get_cultural_guide(req)
    guide = res.guide

    assert "Paris" in guide.destination_name
    assert "service compris" in guide.tipping_customs.lower()
    assert len(guide.attire_guidelines) >= 2
    assert any("Notre-Dame" in a.occasion for a in guide.attire_guidelines)


def test_cultural_guide_tokyo():
    """Returns Tokyo etiquette, no tipping rule, and shrine attire."""
    req = CulturalGuideRequest(destination="Tokyo, Japan", season="autumn")
    res = get_cultural_guide(req)
    guide = res.guide

    assert "Tokyo" in guide.destination_name
    assert "no tipping" in guide.tipping_customs.lower()
    assert any("temples" in a.occasion.lower() or "shrine" in a.occasion.lower() for a in guide.attire_guidelines)


def test_cultural_api_endpoint():
    """POST /api/v1/cultural/guide returns valid cultural payload."""
    payload = {"destination": "Paris", "season": "summer"}
    response = client.post("/api/v1/cultural/guide", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert "guide" in data
    assert len(data["guide"]["general_etiquette"]) >= 2
