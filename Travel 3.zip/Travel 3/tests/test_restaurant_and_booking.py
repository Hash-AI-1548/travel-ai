"""Automated test suite for Restaurant discovery, meal timing, cuisine preference ranking, and Hotel booking integration."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.itinerary.poi_service import (
    filter_pois_along_corridor,
    generate_candidate_pois_for_corridor,
    get_hotel_bookings,
)
from backend.modules.itinerary.poi_ranker import (
    check_meal_availability,
    score_and_rank_poi,
    rank_corridor_pois,
)
from backend.modules.itinerary.itinerary_optimizer import generate_optimized_itinerary
from backend.modules.routing.routing_service import get_road_route
from backend.schemas.poi import (
    CandidatePOI,
    Coordinate,
    TrafficLightClassification,
    TravelerPreferences,
)
from backend.schemas.itinerary import (
    ItineraryGenerationRequest,
    ItineraryStop,
    TimelineEventType,
)

client = TestClient(app)


# ============================================================================
# 1. RESTAURANT CANDIDATE & CORRIDOR FILTERING
# ============================================================================

def test_restaurant_corridor_discovery():
    """Ensure dynamic corridor candidate POIs include first-class restaurant options with cuisines and service hours."""
    s = Coordinate(lat=48.8566, lon=2.3522, name="Paris Center")
    d = Coordinate(lat=48.8606, lon=2.3376, name="Louvre Destination")

    candidates = generate_candidate_pois_for_corridor(s, d)
    restaurants = [c for c in candidates if c.category.lower() in ["restaurant", "cafe & dining"]]

    assert len(restaurants) >= 2
    for r in restaurants:
        assert r.rating >= 4.0
        assert r.estimated_dwell_minutes >= 30
        assert r.cuisine is not None
        assert isinstance(r.service_hours, dict) or r.service_hours is None


def test_restaurant_corridor_filtering():
    """Restaurants within the configured detour threshold are marked as inside corridor."""
    s = Coordinate(lat=0.0, lon=0.0)
    d = Coordinate(lat=0.0, lon=1.0)

    # Restaurant 0.5 km north of corridor
    near_rest = CandidatePOI(
        id="r_near",
        name="Close Bistro",
        lat=0.004,
        lon=0.5,
        category="Restaurant",
        cuisine="French",
        service_hours={"lunch": ["12:00", "14:30"], "dinner": ["18:30", "22:00"]},
        rating=4.8,
        estimated_dwell_minutes=60,
    )

    # Restaurant 10 km north of corridor
    far_rest = CandidatePOI(
        id="r_far",
        name="Far Away Steakhouse",
        lat=0.1,
        lon=0.5,
        category="Restaurant",
        cuisine="Steakhouse",
        rating=4.5,
        estimated_dwell_minutes=60,
    )

    results = filter_pois_along_corridor(s, d, [near_rest, far_rest], detour_threshold_km=3.5)
    assert len(results) == 2
    assert results[0][2] is True   # near is inside
    assert results[1][2] is False  # far is outside


# ============================================================================
# 2. RESTAURANT TRAFFIC-LIGHT RANKING & CUISINE PREFERENCES
# ============================================================================

def test_restaurant_cuisine_matching_traffic_light():
    """When user expresses cuisine preferences, matching restaurants receive high scores (GREEN >= 0.65)."""
    rest_italian = CandidatePOI(
        id="r_italy",
        name="Osteria Deliziosa",
        lat=48.857,
        lon=2.355,
        category="Restaurant",
        cuisine="Italian",
        tags=["food", "italian", "pasta", "wine", "lunch", "dinner"],
        rating=4.9,
        estimated_dwell_minutes=50,
    )

    prefs = TravelerPreferences(preferred_tags=["italian", "pasta", "food"])
    ranked = score_and_rank_poi(rest_italian, distance_to_corridor_km=0.3, is_inside_corridor=True, preferences=prefs)

    assert ranked.preference_score >= 0.65
    assert ranked.traffic_light == TrafficLightClassification.GREEN
    assert "italian" in ranked.matched_tags
    assert ranked.cuisine == "Italian"


def test_restaurant_mismatched_cuisine_ranking():
    """Unmatched restaurant with low rating/far detour falls into YELLOW or RED category."""
    rest_other = CandidatePOI(
        id="r_other",
        name="Generic Diner",
        lat=48.85,
        lon=2.35,
        category="Restaurant",
        cuisine="Fast Food",
        tags=["fast-food", "quick-bite"],
        rating=2.5,
        estimated_dwell_minutes=30,
    )

    prefs = TravelerPreferences(preferred_tags=["fine-dining", "museum", "art"])
    ranked = score_and_rank_poi(rest_other, distance_to_corridor_km=3.2, is_inside_corridor=True, preferences=prefs)

    assert ranked.preference_score < 0.65
    assert ranked.traffic_light in [TrafficLightClassification.YELLOW, TrafficLightClassification.RED]


# ============================================================================
# 3. MEAL TIMING & SERVICE HOURS AVAILABILITY
# ============================================================================

def test_service_hours_availability_checker():
    """Verify split lunch/dinner service hours correctly report opening status."""
    service_hours = {
        "lunch": ["12:00", "14:30"],
        "dinner": ["18:30", "22:00"],
    }

    # 13:00 is during Lunch
    open_lunch, label_lunch = check_meal_availability(service_hours, "13:00")
    assert open_lunch is True
    assert "LUNCH" in label_lunch

    # 16:00 is between Lunch and Dinner (closed)
    open_afternoon, label_afternoon = check_meal_availability(service_hours, "16:00")
    assert open_afternoon is False
    assert "CLOSED" in label_afternoon

    # 19:30 is during Dinner
    open_dinner, label_dinner = check_meal_availability(service_hours, "19:30")
    assert open_dinner is True
    assert "DINNER" in label_dinner

    # When service hours are missing/null, report unknown (None)
    open_unknown, label_unknown = check_meal_availability(None, "13:00")
    assert open_unknown is None
    assert label_unknown is None


# ============================================================================
# 4. ITINERARY MEAL STOP INTEGRATION & ROAD ROUTING
# ============================================================================

def test_restaurant_itinerary_meal_stop_and_dwell():
    """Restaurant stop is inserted with MEAL_STOP event type, dwell time, and independent road routing."""
    s = Coordinate(lat=48.8566, lon=2.3522, name="Station")
    d = Coordinate(lat=48.8700, lon=2.3500, name="Hotel")

    rest_stop = ItineraryStop(
        poi_id="r_lunch",
        name="Bistro Parisien",
        lat=48.8600,
        lon=2.3510,
        category="Restaurant",
        cuisine="French Contemporary",
        service_hours={"lunch": ["12:00", "14:30"], "dinner": ["18:30", "22:00"]},
        dwell_minutes=55,
        is_restaurant=True,
    )

    req = ItineraryGenerationRequest(
        transit_arrival_time="12:00",
        check_in_time="16:00",
        source=s,
        destination=d,
        stops=[rest_stop],
        transit_mode="driving",
    )

    resp = generate_optimized_itinerary(req)
    assert resp.is_feasible is True

    # Check meal event
    meal_events = [e for e in resp.timeline if e.event_type == TimelineEventType.MEAL_STOP]
    assert len(meal_events) == 1
    meal_ev = meal_events[0]
    assert meal_ev.title == "Bistro Parisien"
    assert meal_ev.duration_minutes == 55
    assert meal_ev.cuisine == "French Contemporary"
    assert meal_ev.is_meal_open is True

    # Check that transit legs before and after restaurant are road-routed
    transit_legs = [e for e in resp.timeline if e.event_type == TimelineEventType.TRANSIT]
    assert len(transit_legs) == 2  # S -> Restaurant, Restaurant -> Hotel
    for leg in transit_legs:
        assert leg.distance_km is not None
        assert leg.duration_minutes > 0
        assert leg.route_geometry is not None


# ============================================================================
# 5. HOTEL BOOKING INTEGRATION & CHECK-IN CONSTRAINTS
# ============================================================================

def test_api_get_bookings_endpoint():
    """GET /api/v1/itinerary/bookings returns list of confirmed hotel reservations."""
    res = client.get("/api/v1/itinerary/bookings")
    assert res.status_code == 200
    data = res.json()
    assert "bookings" in data
    assert len(data["bookings"]) >= 3

    first_b = data["bookings"][0]
    assert first_b["booking_id"].startswith("BK-")
    assert first_b["status"] == "CONFIRMED"
    assert -90.0 <= first_b["lat"] <= 90.0
    assert -180.0 <= first_b["lon"] <= 180.0
    assert first_b["check_in_time"] is not None


def test_hotel_booking_as_destination_and_checkin_enforcement():
    """
    When booking exists, destination is set to booked hotel and check-in time is enforced:
    hotel_arrival <= check_in_time - 20 minutes.
    """
    bookings = get_hotel_bookings()
    booking = bookings[0]  # Hotel Le Marais Prestige, check_in_time: 18:00

    s = Coordinate(lat=49.0097, lon=2.5479, name="Paris CDG")
    hotel_d = Coordinate(lat=booking["lat"], lon=booking["lon"], name=booking["hotel_name"])

    req = ItineraryGenerationRequest(
        transit_arrival_time="14:00",
        check_in_time=booking["check_in_time"],
        source=s,
        destination=hotel_d,
        stops=[],
        booking_id=booking["booking_id"],
    )

    resp = generate_optimized_itinerary(req)
    assert resp.is_feasible is True
    assert resp.buffer_status.pre_checkin_buffer_satisfied is True
    assert resp.buffer_status.pre_checkin_buffer_minutes >= 20

    hotel_arrival_event = resp.timeline[-1]
    assert hotel_arrival_event.event_type == TimelineEventType.HOTEL_CHECKIN_ARRIVAL
    assert hotel_arrival_event.details.get("booking_id") == booking["booking_id"]


def test_infeasible_itinerary_due_to_long_meal_dwell():
    """Excessive dining dwell causing hotel arrival past check_in - 20m makes itinerary infeasible."""
    s = Coordinate(lat=48.86, lon=2.34, name="Origin")
    d = Coordinate(lat=48.88, lon=2.36, name="Hotel")

    # Available window: 14:00 to 15:30 (90 min). Post-arrival buffer: 20 min.
    # Long 3-course tasting menu restaurant dwell: 75 min + 30 min transits = 125 min total.
    long_dinner = ItineraryStop(
        poi_id="r_long",
        name="Grand Tasting Banquet",
        lat=48.87,
        lon=2.35,
        category="Restaurant",
        dwell_minutes=75,
        is_restaurant=True,
    )

    req = ItineraryGenerationRequest(
        transit_arrival_time="14:00",
        check_in_time="15:30",
        source=s,
        destination=d,
        stops=[long_dinner],
        custom_transit_durations=[15, 15],
    )

    resp = generate_optimized_itinerary(req)
    assert resp.is_feasible is False
    assert resp.buffer_status.pre_checkin_buffer_satisfied is False
    assert len(resp.warnings) >= 1
    assert "Infeasible Schedule" in resp.warnings[0]
