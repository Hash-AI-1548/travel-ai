"""End-to-end integration test validating the entire Travel-AI pipeline across all 8 modules."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)


def test_full_travel_ai_integrated_pipeline():
    """
    Simulates a complete real-world user workflow:
    1. User enters natural language prompt.
    2. NLP extracts destination, party size, pace, interests, arrival/checkin times.
    3. Profile synthesizes traveler persona and weights.
    4. Confirmed booking is retrieved for destination hotel.
    5. Candidate POIs & restaurants along corridor are discovered and filtered.
    6. POIs are ranked with deterministic traffic-light classification.
    7. Chronological itinerary is generated with road routing and buffer guarantees.
    8. Cultural guide, BlendIn authenticity, and translation bridge enrich the trip.
    """
    # 1. NLP Parse
    nlp_payload = {
        "query": "Plan a 1-day art and gourmet French dining trip for 2 in Paris arriving at 12:30 and checking in at 18:00 with local authenticity"
    }
    nlp_resp = client.post("/api/v1/nlp/parse", json=nlp_payload)
    assert nlp_resp.status_code == 200
    intent = nlp_resp.json()["parsed_intent"]
    assert intent["destination_name"] == "Paris, France"
    assert intent["party_size"] == 2
    assert "art" in intent["preferred_tags"]

    # 2. Profile Synthesize
    profile_payload = {
        "traveler_count": intent["party_size"],
        "pace": intent["pace"],
        "interests": intent["preferred_tags"],
        "cuisines": intent["preferred_cuisines"],
        "dietary": intent["dietary_restrictions"],
        "blendin_level": intent["blendin_preference"],
    }
    prof_resp = client.post("/api/v1/profile/synthesize", json=profile_payload)
    assert prof_resp.status_code == 200
    profile = prof_resp.json()["profile"]
    assert profile["target_dwell_minutes"] == 45

    # 3. Retrieve Bookings
    bookings_resp = client.get("/api/v1/itinerary/bookings")
    assert bookings_resp.status_code == 200
    paris_booking = next(b for b in bookings_resp.json()["bookings"] if "Paris" in b["hotel_name"] or "Marais" in b["hotel_name"])

    source = {"lat": 49.0097, "lon": 2.5479, "name": "Paris CDG Airport"}
    dest = {"lat": paris_booking["lat"], "lon": paris_booking["lon"], "name": paris_booking["hotel_name"]}

    # 4. Discover Corridor POIs
    disc_payload = {
        "source": source,
        "destination": dest,
        "preferences": {
            "preferred_tags": intent["preferred_tags"],
            "pace": intent["pace"],
            "max_detour_km": 3.5,
        },
        "detour_threshold_km": 3.5,
    }
    disc_resp = client.post("/api/v1/itinerary/discover-corridor", json=disc_payload)
    assert disc_resp.status_code == 200
    candidates = disc_resp.json()["candidate_pois"]
    assert len(candidates) >= 3

    # 5. Filter and Rank Corridor POIs (AUTHORITATIVE TRAFFIC-LIGHT)
    rank_payload = {
        "source": source,
        "destination": dest,
        "candidate_pois": candidates,
        "preferences": {
            "preferred_tags": intent["preferred_tags"] + ["french"],
            "pace": intent["pace"],
            "max_detour_km": 3.5,
        },
        "detour_threshold_km": 3.5,
        "current_time": intent["transit_arrival_time"],
    }
    rank_resp = client.post("/api/v1/itinerary/corridor-pois", json=rank_payload)
    assert rank_resp.status_code == 200
    corridor_pois = rank_resp.json()["corridor_pois"]
    inside_pois = [p for p in corridor_pois if p["is_inside_corridor"]]
    assert len(inside_pois) >= 2

    # Top green stop + top restaurant
    selected_stops = []
    for p in inside_pois[:2]:
        selected_stops.append({
            "poi_id": p["id"],
            "name": p["name"],
            "lat": p["lat"],
            "lon": p["lon"],
            "dwell_minutes": p["estimated_dwell_minutes"],
            "category": p["category"],
            "cuisine": p.get("cuisine"),
            "service_hours": p.get("service_hours"),
            "is_restaurant": p["category"] == "Restaurant" or bool(p.get("cuisine")),
        })

    # 6. Generate Chronological Itinerary with Road Routing & 20m Buffers
    sched_payload = {
        "transit_arrival_time": intent["transit_arrival_time"],
        "check_in_time": paris_booking["check_in_time"],
        "source": source,
        "destination": dest,
        "stops": selected_stops,
        "transit_mode": "driving",
        "booking_id": paris_booking["booking_id"],
    }
    sched_resp = client.post("/api/v1/itinerary/generate-schedule", json=sched_payload)
    assert sched_resp.status_code == 200
    schedule = sched_resp.json()

    assert schedule["is_feasible"] is True
    assert schedule["buffer_status"]["post_arrival_buffer_satisfied"] is True
    assert schedule["buffer_status"]["pre_checkin_buffer_satisfied"] is True
    assert schedule["buffer_status"]["pre_checkin_buffer_minutes"] >= 20

    # Ensure road routing geometry exists for transit legs
    transit_legs = [e for e in schedule["timeline"] if e["event_type"] == "TRANSIT"]
    assert len(transit_legs) >= 2
    for leg in transit_legs:
        assert leg["route_geometry"] is not None
        assert leg["duration_minutes"] > 0

    # 7. Cultural Guidance Enrichment
    cult_resp = client.post("/api/v1/cultural/guide", json={"destination": "Paris", "season": "summer"})
    assert cult_resp.status_code == 200
    guide = cult_resp.json()["guide"]
    assert "Paris" in guide["destination_name"]

    # 8. BlendIn Balancing
    blend_resp = client.post("/api/v1/blendin/balance", json={
        "stops": inside_pois[:2],
        "target_blendin": intent["blendin_preference"],
    })
    assert blend_resp.status_code == 200
    assert len(blend_resp.json()["balanced_stops"]) == len(inside_pois[:2])

    # 9. Translation Food Bridge
    trans_resp = client.post("/api/v1/translation/food-bridge", json={"dish_or_item": "confit de canard", "target_language": "fr"})
    assert trans_resp.status_code == 200
    assert trans_resp.json()["bridge"]["local_name"] == "Confit de Canard"
