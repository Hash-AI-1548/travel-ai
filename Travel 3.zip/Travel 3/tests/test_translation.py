"""Automated unit and API tests for Translation and Food Cultural Bridge."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.translation.translation_service import get_phrases_for_language, get_food_cultural_bridge
from backend.schemas.translation import TranslationRequest, FoodBridgeRequest

client = TestClient(app)


def test_get_phrases_french_and_japanese():
    """Returns categorized phrases for French and Japanese."""
    fr_res = get_phrases_for_language(TranslationRequest(target_language="fr"))
    assert len(fr_res.phrases) >= 5
    assert any("Bonjour" in p.target_phrase for p in fr_res.phrases)
    assert any("L'addition" in p.target_phrase for p in fr_res.phrases)

    ja_res = get_phrases_for_language(TranslationRequest(target_language="ja"))
    assert len(ja_res.phrases) >= 5
    assert any("Konnichiwa" in p.target_phrase for p in ja_res.phrases)


def test_food_cultural_bridge():
    """Explains dishes with regional origin and allergen declarations."""
    confit_req = FoodBridgeRequest(dish_or_item="confit de canard", target_language="fr")
    confit_res = get_food_cultural_bridge(confit_req)
    assert confit_res.bridge.local_name == "Confit de Canard"
    assert "Duck Leg" in confit_res.bridge.key_ingredients

    bouillabaisse_req = FoodBridgeRequest(dish_or_item="bouillabaisse", target_language="fr")
    bouillabaisse_res = get_food_cultural_bridge(bouillabaisse_req)
    assert "Shellfish" in " ".join(bouillabaisse_res.bridge.dietary_warnings)


def test_translation_api_endpoints():
    """POST /api/v1/translation/phrase and /food-bridge return 200."""
    phrase_payload = {"target_language": "fr", "category": "Dining"}
    p_resp = client.post("/api/v1/translation/phrase", json=phrase_payload)
    assert p_resp.status_code == 200
    assert len(p_resp.json()["phrases"]) > 0

    food_payload = {"dish_or_item": "tonkotsu ramen", "target_language": "ja"}
    f_resp = client.post("/api/v1/translation/food-bridge", json=food_payload)
    assert f_resp.status_code == 200
    assert "Pork" in f_resp.json()["bridge"]["key_ingredients"][0]
