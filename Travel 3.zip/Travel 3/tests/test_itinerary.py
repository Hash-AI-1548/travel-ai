"""Comprehensive automated tests for POI Corridor Filter, Traffic-Light Ranker, and Dynamic Buffer Optimizer."""

import pytest
from datetime import date
from fastapi.testclient import TestClient

from backend.main import app
from backend.modules.itinerary.poi_service import (
    haversine_distance,
    distance_point_to_finite_segment,
    filter_pois_along_corridor,
)
from backend.modules.itinerary.poi_ranker import (
    score_and_rank_poi,
    rank_corridor_pois,
)
from backend.modules.itinerary.itinerary_optimizer import (
    generate_optimized_itinerary,
    parse_time_or_datetime,
    MANDATORY_POST_ARRIVAL_BUFFER_MINUTES,
    MANDATORY_PRE_CHECKIN_BUFFER_MINUTES,
)
from backend.schemas.poi import (
    CandidatePOI,
    Coordinate,
    CorridorPOIRequest,
    TrafficLightClassification,
    TravelerPreferences,
)
from backend.schemas.itinerary import (
    ItineraryGenerationRequest,
    ItineraryStop,
    TimelineEventType,
)

client = TestClient(app)


# ============================================================================
# 1. HAVERSINE & GEODESIC DISTANCE TESTS
# ============================================================================

def test_haversine_distance_correctness():
    """Test Haversine distance matches known geographical distances within tight tolerance."""
    # Paris CDG (49.0097, 2.5479) to Eiffel Tower (48.8584, 2.2945) is ~25.01 km
    dist = haversine_distance(49.0097, 2.5479, 48.8584, 2.2945)
    assert 24.0 < dist < 26.0

    # Distance to identical point is 0.0 km
    zero_dist = haversine_distance(48.8566, 2.3522, 48.8566, 2.3522)
    assert zero_dist == pytest.approx(0.0, abs=1e-5)

    # London (51.5074, -0.1278) to Paris (48.8566, 2.3522) is ~343 km
    london_paris = haversine_distance(51.5074, -0.1278, 48.8566, 2.3522)
    assert 340.0 < london_paris < 346.0


def test_poi_directly_on_corridor_included():
    """A POI positioned exactly on the S -> D corridor should have distance ~0 and be included."""
    # S = (0.0, 0.0), D = (0.0, 1.0). POI = (0.0, 0.5) (directly on equator corridor)
    s = Coordinate(lat=0.0, lon=0.0)
    d = Coordinate(lat=0.0, lon=1.0)
    poi = CandidatePOI(id="mid", name="Midpoint Stop", lat=0.0, lon=0.5, category="Landmark", tags=["landmark"])

    results = filter_pois_along_corridor(s, d, [poi], detour_threshold_km=3.5)
    assert len(results) == 1
    poi_res, dist, is_inside = results[0]
    assert is_inside is True
    assert dist == pytest.approx(0.0, abs=1e-2)


def test_poi_outside_default_threshold_excluded():
    """A POI with perpendicular distance > 3.5 km must have is_inside_corridor = False."""
    # 1 degree latitude is ~111 km, so 0.1 degree is ~11.1 km north of the corridor
    s = Coordinate(lat=0.0, lon=0.0)
    d = Coordinate(lat=0.0, lon=1.0)
    far_poi = CandidatePOI(id="far", name="Far POI", lat=0.1, lon=0.5, category="Landmark", tags=["far"])

    results = filter_pois_along_corridor(s, d, [far_poi], detour_threshold_km=3.5)
    assert len(results) == 1
    _, dist, is_inside = results[0]
    assert dist > 3.5
    assert is_inside is False


def test_custom_detour_threshold():
    """A POI at ~5.5 km should be excluded at default 3.5 km but included when threshold=10.0 km."""
    # 0.05 degree latitude is ~5.55 km
    s = Coordinate(lat=0.0, lon=0.0)
    d = Coordinate(lat=0.0, lon=1.0)
    poi = CandidatePOI(id="custom", name="Custom Threshold POI", lat=0.05, lon=0.5, category="Park", tags=["park"])

    res_default = filter_pois_along_corridor(s, d, [poi], detour_threshold_km=3.5)
    assert res_default[0][2] is False  # Excluded at 3.5 km

    res_custom = filter_pois_along_corridor(s, d, [poi], detour_threshold_km=10.0)
    assert res_custom[0][2] is True   # Included at 10.0 km


def test_finite_corridor_endpoint_handling():
    """
    Finite corridor geometry:
    A POI located along the collinear line but beyond S or D must be measured against the nearest endpoint.
    """
    s_lat, s_lon = 0.0, 0.0
    d_lat, d_lon = 0.0, 1.0

    # POI 1: Located 0.5 degrees *before* S along the line: lat=0.0, lon=-0.5
    # The closest point on the segment [S, D] is S, so distance must be d(POI, S) = ~55.6 km
    dist_before_s = distance_point_to_finite_segment(0.0, -0.5, s_lat, s_lon, d_lat, d_lon)
    expected_dist_s = haversine_distance(0.0, -0.5, s_lat, s_lon)
    assert dist_before_s == pytest.approx(expected_dist_s, abs=0.1)

    # POI 2: Located 0.5 degrees *beyond* D along the line: lat=0.0, lon=1.5
    # The closest point on the segment [S, D] is D, so distance must be d(POI, D) = ~55.6 km
    dist_after_d = distance_point_to_finite_segment(0.0, 1.5, s_lat, s_lon, d_lat, d_lon)
    expected_dist_d = haversine_distance(0.0, 1.5, d_lat, d_lon)
    assert dist_after_d == pytest.approx(expected_dist_d, abs=0.1)


# ============================================================================
# 2. POI RANKER & TRAFFIC-LIGHT THRESHOLD TESTS
# ============================================================================

def test_traffic_light_green_threshold():
    """GREEN classification requires score >= 0.65."""
    poi = CandidatePOI(
        id="green_poi",
        name="Top Louvre Match",
        lat=48.8606,
        lon=2.3376,
        category="Museum",
        tags=["art", "history", "museum", "culture"],
        rating=5.0,
    )
    prefs = TravelerPreferences(preferred_tags=["art", "history", "museum"])
    ranked = score_and_rank_poi(poi, distance_to_corridor_km=0.2, is_inside_corridor=True, preferences=prefs)

    assert ranked.preference_score >= 0.65
    assert ranked.traffic_light == TrafficLightClassification.GREEN
    assert "art" in ranked.matched_tags
    assert "history" in ranked.matched_tags


def test_traffic_light_yellow_threshold():
    """YELLOW classification requires 0.35 <= score < 0.65."""
    poi = CandidatePOI(
        id="yellow_poi",
        name="Secondary Scenic Stop",
        lat=48.85,
        lon=2.35,
        category="Scenic View",
        tags=["view", "walking"],
        rating=3.8,
    )
    prefs = TravelerPreferences(preferred_tags=["food", "wine", "dining"])
    ranked = score_and_rank_poi(poi, distance_to_corridor_km=1.5, is_inside_corridor=True, preferences=prefs)

    assert 0.35 <= ranked.preference_score < 0.65
    assert ranked.traffic_light == TrafficLightClassification.YELLOW


def test_traffic_light_red_threshold():
    """RED classification requires score < 0.35."""
    poi = CandidatePOI(
        id="red_poi",
        name="Low Priority Stop",
        lat=48.80,
        lon=2.20,
        category="Industrial",
        tags=["industrial", "hardware"],
        rating=1.5,
    )
    prefs = TravelerPreferences(preferred_tags=["art", "history", "museum"])
    # Near edge of corridor threshold (e.g. 3.4 km)
    ranked = score_and_rank_poi(poi, distance_to_corridor_km=3.4, is_inside_corridor=True, preferences=prefs)

    assert ranked.preference_score < 0.35
    assert ranked.traffic_light == TrafficLightClassification.RED


def test_scores_always_bounded_between_zero_and_one():
    """Score must strictly remain within [0.0, 1.0] across extreme cases."""
    # Worst case: 0 rating, far detour, no match
    poi_worst = CandidatePOI(id="worst", name="Worst", lat=0, lon=0, rating=0.0, tags=["none"])
    prefs = TravelerPreferences(preferred_tags=["unique_tag"])
    ranked_worst = score_and_rank_poi(poi_worst, distance_to_corridor_km=100.0, is_inside_corridor=False, preferences=prefs)
    assert 0.0 <= ranked_worst.preference_score <= 1.0

    # Best case: 5 rating, 0 distance, 100% match
    poi_best = CandidatePOI(id="best", name="Best", lat=0, lon=0, rating=5.0, tags=["art", "museum"])
    prefs_best = TravelerPreferences(preferred_tags=["art", "museum"])
    ranked_best = score_and_rank_poi(poi_best, distance_to_corridor_km=0.0, is_inside_corridor=True, preferences=prefs_best)
    assert 0.0 <= ranked_best.preference_score <= 1.0


def test_missing_preferences_handled_safely():
    """When preferences are None or empty, scoring must be deterministic, non-random, and safe."""
    poi = CandidatePOI(id="safe_poi", name="Test Safe", lat=48.85, lon=2.35, rating=4.5, tags=["park"])
    ranked1 = score_and_rank_poi(poi, distance_to_corridor_km=0.5, is_inside_corridor=True, preferences=None)
    ranked2 = score_and_rank_poi(poi, distance_to_corridor_km=0.5, is_inside_corridor=True, preferences=TravelerPreferences())

    assert ranked1.preference_score == ranked2.preference_score
    assert 0.0 <= ranked1.preference_score <= 1.0
    assert ranked1.traffic_light in [TrafficLightClassification.GREEN, TrafficLightClassification.YELLOW]


# ============================================================================
# 3. DYNAMIC BUFFER ITINERARY OPTIMIZER TESTS
# ============================================================================

def test_post_arrival_buffer_enforced_and_first_movement_timing():
    """
    RULE 1: Mandatory 20-minute post-arrival buffer.
    The first movement after transit arrival MUST NOT start before: transit_arrival + 20 minutes.
    """
    source = Coordinate(lat=49.0097, lon=2.5479, name="CDG Airport")
    dest = Coordinate(lat=48.8575, lon=2.3622, name="Marais Hotel")
    stop = ItineraryStop(poi_id="p1", name="Louvre", lat=48.8606, lon=2.3376, dwell_minutes=30)

    req = ItineraryGenerationRequest(
        transit_arrival_time="14:00",
        check_in_time="18:00",
        source=source,
        destination=dest,
        stops=[stop],
    )
    resp = generate_optimized_itinerary(req)

    # 1. Timeline event 0 is transit arrival at 14:00
    assert resp.timeline[0].event_type == TimelineEventType.TRANSIT_ARRIVAL
    assert resp.timeline[0].start_time == "14:00"

    # 2. Timeline event 1 is the 20-minute post-arrival buffer from 14:00 to 14:20
    assert resp.timeline[1].event_type == TimelineEventType.BUFFER
    assert resp.timeline[1].start_time == "14:00"
    assert resp.timeline[1].end_time == "14:20"
    assert resp.timeline[1].duration_minutes == 20
    assert resp.buffer_status.post_arrival_buffer_satisfied is True
    assert resp.buffer_status.post_arrival_buffer_minutes == 20

    # 3. First movement (transit to Louvre) starts at or after 14:20
    assert resp.timeline[2].event_type == TimelineEventType.TRANSIT
    assert resp.timeline[2].start_time >= "14:20"


def test_hotel_arrival_guaranteed_before_checkin():
    """
    RULE 2: Hotel must be reached at least 20 minutes before hotel check-in.
    hotel_arrival <= check_in_time - 20 minutes.
    """
    source = Coordinate(lat=48.86, lon=2.34, name="Station")
    dest = Coordinate(lat=48.87, lon=2.35, name="Hotel")

    # Transit arrival 14:00, Check-in 18:00. No stops.
    req = ItineraryGenerationRequest(
        transit_arrival_time="14:00",
        check_in_time="18:00",
        source=source,
        destination=dest,
        stops=[],
        custom_transit_durations=[15],  # 15m transit to hotel
    )
    resp = generate_optimized_itinerary(req)

    # Arrival 14:00 + 20m buffer = 14:20. Transit 15m -> Hotel arrival at 14:35.
    # Check-in at 18:00 -> pre-checkin buffer is 18:00 - 14:35 = 205 minutes (>= 20 min).
    assert resp.is_feasible is True
    assert resp.buffer_status.pre_checkin_buffer_satisfied is True
    assert resp.buffer_status.pre_checkin_buffer_minutes == 205


def test_infeasible_itinerary_explicitly_reported():
    """If POI dwell & transit cause hotel arrival to violate the 20m buffer before check-in, report infeasible."""
    source = Coordinate(lat=48.86, lon=2.34, name="Station")
    dest = Coordinate(lat=48.87, lon=2.35, name="Hotel")

    # Transit arrival 14:00, Check-in 15:00 (Total available window: 60 minutes).
    # Post-arrival buffer: 20 min (ends 14:20).
    # Remaining window before check-in: 40 min.
    # If POI dwell is 35 min and transits take 20 min, total needed = 20 + 20 + 35 = 75 min (exceeds window).
    stop = ItineraryStop(poi_id="stop1", name="Heavy Stop", lat=48.865, lon=2.345, dwell_minutes=35)

    req = ItineraryGenerationRequest(
        transit_arrival_time="14:00",
        check_in_time="15:00",
        source=source,
        destination=dest,
        stops=[stop],
        custom_transit_durations=[10, 10],  # 10m to stop + 10m to hotel
    )
    resp = generate_optimized_itinerary(req)

    # Schedule:
    # 14:00 - 14:20 Buffer
    # 14:20 - 14:30 Transit to stop
    # 14:30 - 15:05 POI Dwell (35 min)
    # 15:05 - 15:15 Transit to hotel -> Hotel arrival 15:15 (which is 15 min AFTER 15:00 check-in!)
    assert resp.is_feasible is False
    assert resp.buffer_status.pre_checkin_buffer_satisfied is False
    assert resp.buffer_status.pre_checkin_buffer_minutes < 20
    assert len(resp.warnings) > 0
    assert "Infeasible Schedule" in resp.warnings[0] or "Critical Delay" in resp.warnings[0]


def test_zero_stops_direct_hub_to_hotel():
    """Test scenario where traveler goes directly from Transit Hub to Hotel with no stops."""
    source = Coordinate(lat=49.0097, lon=2.5479, name="CDG")
    dest = Coordinate(lat=48.8575, lon=2.3622, name="Hotel")

    req = ItineraryGenerationRequest(
        transit_arrival_time="10:00",
        check_in_time="14:00",
        source=source,
        destination=dest,
        stops=[],
    )
    resp = generate_optimized_itinerary(req)

    assert resp.is_feasible is True
    assert len(resp.timeline) == 4  # Arrival, Buffer, Transit to Hotel, Hotel Arrival Event
    assert resp.timeline[0].event_type == TimelineEventType.TRANSIT_ARRIVAL
    assert resp.timeline[1].event_type == TimelineEventType.BUFFER
    assert resp.timeline[2].event_type == TimelineEventType.TRANSIT
    assert resp.timeline[3].event_type == TimelineEventType.HOTEL_CHECKIN_ARRIVAL


def test_multiple_pois_chronologically_ordered_and_durations_respected():
    """Multiple POIs must be ordered sequentially with dwell and transit durations respected."""
    source = Coordinate(lat=48.86, lon=2.34, name="Hub")
    dest = Coordinate(lat=48.88, lon=2.36, name="Hotel")
    s1 = ItineraryStop(poi_id="s1", name="Stop 1", lat=48.862, lon=2.342, dwell_minutes=30)
    s2 = ItineraryStop(poi_id="s2", name="Stop 2", lat=48.865, lon=2.345, dwell_minutes=45)

    req = ItineraryGenerationRequest(
        transit_arrival_time="12:00",
        check_in_time="17:00",
        source=source,
        destination=dest,
        stops=[s1, s2],
        custom_transit_durations=[15, 20, 10],
    )
    resp = generate_optimized_itinerary(req)

    assert resp.is_feasible is True
    assert resp.total_dwell_minutes == 75  # 30 + 45
    assert resp.total_transit_minutes == 45  # 15 + 20 + 10

    poi_events = [e for e in resp.timeline if e.event_type == TimelineEventType.POI_VISIT]
    assert len(poi_events) == 2
    assert poi_events[0].title == "Stop 1"
    assert poi_events[0].start_time == "12:35"
    assert poi_events[0].end_time == "13:05"

    assert poi_events[1].title == "Stop 2"
    assert poi_events[1].start_time == "13:25"
    assert poi_events[1].end_time == "14:10"


def test_midnight_and_date_boundary_arithmetic():
    """Arrival late at night (23:30) with check-in at 02:00 next day must be handled smoothly."""
    source = Coordinate(lat=48.86, lon=2.34, name="Night Train Station")
    dest = Coordinate(lat=48.87, lon=2.35, name="Hotel")

    req = ItineraryGenerationRequest(
        transit_arrival_time="23:30",
        check_in_time="02:00",  # Crosses midnight
        source=source,
        destination=dest,
        stops=[],
        custom_transit_durations=[20],
    )
    resp = generate_optimized_itinerary(req)

    assert resp.is_feasible is True
    assert resp.buffer_status.pre_checkin_buffer_minutes == 110
    assert resp.buffer_status.pre_checkin_buffer_satisfied is True


# ============================================================================
# 4. API ROUTE INTEGRATION & VALIDATION TESTS
# ============================================================================

def test_api_corridor_pois_endpoint():
    """Test POST /api/v1/itinerary/corridor-pois returns filtered, ranked POIs with traffic lights."""
    payload = {
        "source": {"lat": 49.0097, "lon": 2.5479, "name": "CDG"},
        "destination": {"lat": 48.8575, "lon": 2.3622, "name": "Marais"},
        "detour_threshold_km": 3.5,
        "preferences": {
            "preferred_tags": ["art", "museum"],
            "pace": "moderate",
        },
        "candidate_pois": [
            {
                "id": "louvre",
                "name": "Louvre",
                "lat": 48.8606,
                "lon": 2.3376,
                "category": "Museum",
                "tags": ["art", "museum"],
                "rating": 4.9,
                "estimated_dwell_minutes": 60,
            },
            {
                "id": "far_away",
                "name": "Deep Outlier",
                "lat": 45.0,
                "lon": 5.0,
                "category": "Other",
                "tags": ["other"],
                "rating": 3.0,
            },
        ],
    }

    res = client.post("/api/v1/itinerary/corridor-pois", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["total_candidates"] == 2
    assert data["filtered_count"] >= 1

    louvre_poi = next(p for p in data["corridor_pois"] if p["id"] == "louvre")
    assert louvre_poi["is_inside_corridor"] is True
    assert louvre_poi["traffic_light"] in ["GREEN", "YELLOW", "RED"]
    assert 0.0 <= louvre_poi["preference_score"] <= 1.0


def test_api_generate_schedule_endpoint():
    """Test POST /api/v1/itinerary/generate-schedule returns complete timeline with buffers."""
    payload = {
        "transit_arrival_time": "13:30",
        "check_in_time": "17:30",
        "source": {"lat": 49.0097, "lon": 2.5479, "name": "CDG Airport"},
        "destination": {"lat": 48.8575, "lon": 2.3622, "name": "Marais Hotel"},
        "stops": [
            {
                "poi_id": "pompidou",
                "name": "Centre Pompidou",
                "lat": 48.8606,
                "lon": 2.3522,
                "dwell_minutes": 45,
                "category": "Museum",
                "tags": ["art", "modern"],
            }
        ],
        "transit_mode": "driving",
    }

    res = client.post("/api/v1/itinerary/generate-schedule", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "is_feasible" in data
    assert "buffer_status" in data
    assert data["buffer_status"]["post_arrival_buffer_satisfied"] is True
    assert len(data["timeline"]) >= 4


def test_api_presets_endpoint():
    """Test GET /api/v1/itinerary/presets returns list of presets."""
    res = client.get("/api/v1/itinerary/presets")
    assert res.status_code == 200
    data = res.json()
    assert "presets" in data
    assert len(data["presets"]) >= 3


def test_api_coordinate_validation():
    """Invalid coordinates (e.g. lat > 90 or lon > 180) must be rejected with 422 Unprocessable Entity."""
    payload = {
        "source": {"lat": 999.0, "lon": 2.5479, "name": "Invalid Lat"},
        "destination": {"lat": 48.8575, "lon": 2.3622, "name": "Marais"},
        "candidate_pois": [],
    }
    res = client.post("/api/v1/itinerary/corridor-pois", json=payload)
    assert res.status_code == 422


def test_corridor_filtering_empty_candidates():
    """Filtering an empty list of candidate POIs should return empty list gracefully."""
    s = Coordinate(lat=48.85, lon=2.35)
    d = Coordinate(lat=48.86, lon=2.36)
    results = filter_pois_along_corridor(s, d, [])
    assert results == []


def test_health_check_endpoint():
    """Health check endpoint returns healthy status."""
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "healthy"


def test_frontend_root_and_static_assets():
    """Ensure root serves index.html and static assets are accessible."""
    res_root = client.get("/")
    assert res_root.status_code == 200
    assert "CorridorPlanner" in res_root.text

    res_css = client.get("/static/css/app.css")
    assert res_css.status_code == 200
    assert "--color-green" in res_css.text

    res_js = client.get("/static/js/app.js")
    assert res_js.status_code == 200
    assert "generateSchedule" in res_js.text
    assert "requestBrowserGeolocation" in res_js.text
    assert "LOCATION_READY" in res_js.text


# ============================================================================
# 5. DYNAMIC REAL-WORLD S -> D LOCATION & DISCOVERY TESTS
# ============================================================================

def test_api_nearby_destinations_dynamic_coordinates():
    """Verify nearby hotel/destination discovery works for arbitrary real coordinates worldwide."""
    # Test for Chennai, India (12.8398, 80.1548)
    payload_chennai = {
        "source": {"lat": 12.8398, "lon": 80.1548, "name": "Chennai Real Location"},
        "radius_km": 15.0,
    }
    res = client.post("/api/v1/itinerary/nearby-destinations", json=payload_chennai)
    assert res.status_code == 200
    data = res.json()
    assert "destinations" in data
    assert len(data["destinations"]) >= 4
    for dest in data["destinations"]:
        assert -90.0 <= dest["lat"] <= 90.0
        assert -180.0 <= dest["lon"] <= 180.0
        assert dest["distance_from_source_km"] > 0

    # Test for Sydney, Australia (-33.8688, 151.2093)
    payload_sydney = {
        "source": {"lat": -33.8688, "lon": 151.2093, "name": "Sydney Real Location"},
        "radius_km": 10.0,
    }
    res_syd = client.post("/api/v1/itinerary/nearby-destinations", json=payload_sydney)
    assert res_syd.status_code == 200
    assert len(res_syd.json()["destinations"]) >= 4


def test_api_discover_corridor_pois_dynamic():
    """Verify dynamic POI discovery along an arbitrary real S -> D corridor."""
    # S = User location in London, D = Hotel in West London
    payload = {
        "source": {"lat": 51.5074, "lon": -0.1278, "name": "London Origin S"},
        "destination": {"lat": 51.5155, "lon": -0.1419, "name": "London Hotel D"},
        "detour_threshold_km": 3.5,
    }
    res = client.post("/api/v1/itinerary/discover-corridor", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert "candidate_pois" in data
    assert len(data["candidate_pois"]) >= 5
    for poi in data["candidate_pois"]:
        assert -90.0 <= poi["lat"] <= 90.0
        assert -180.0 <= poi["lon"] <= 180.0
        assert poi["estimated_dwell_minutes"] >= 5


def test_complete_dynamic_user_flow_chennai():
    """
    Simulate the complete end-to-end user flow with real coordinates:
    Real User Location S -> Find Nearby Hotels -> Select Hotel D -> Discover Corridor POIs -> Filter & Rank -> Schedule Itinerary.
    """
    # 1. User is located at real coordinates (e.g., Chennai)
    source_coord = {"lat": 12.8398, "lon": 80.1548, "name": "User Browser Location"}

    # 2. Fetch nearby destinations
    res_dest = client.post(
        "/api/v1/itinerary/nearby-destinations",
        json={"source": source_coord, "radius_km": 12.0},
    )
    assert res_dest.status_code == 200
    hotels = res_dest.json()["destinations"]
    assert len(hotels) > 0
    selected_hotel = hotels[0]
    dest_coord = {"lat": selected_hotel["lat"], "lon": selected_hotel["lon"], "name": selected_hotel["name"]}

    # 3. Discover corridor candidate POIs
    res_pois = client.post(
        "/api/v1/itinerary/discover-corridor",
        json={"source": source_coord, "destination": dest_coord, "detour_threshold_km": 3.5},
    )
    assert res_pois.status_code == 200
    candidate_pois = res_pois.json()["candidate_pois"]
    assert len(candidate_pois) >= 5

    # 4. Filter and rank candidate POIs along the corridor
    res_rank = client.post(
        "/api/v1/itinerary/corridor-pois",
        json={
            "source": source_coord,
            "destination": dest_coord,
            "candidate_pois": candidate_pois,
            "preferences": {"preferred_tags": ["art", "history"], "pace": "moderate"},
            "detour_threshold_km": 3.5,
        },
    )
    assert res_rank.status_code == 200
    corridor_data = res_rank.json()
    assert corridor_data["filtered_count"] > 0
    ranked_inside = [p for p in corridor_data["corridor_pois"] if p["is_inside_corridor"]]
    assert len(ranked_inside) > 0

    # 5. Generate schedule with top stop
    top_stop = ranked_inside[0]
    res_sched = client.post(
        "/api/v1/itinerary/generate-schedule",
        json={
            "transit_arrival_time": "14:00",
            "check_in_time": "18:00",
            "source": source_coord,
            "destination": dest_coord,
            "stops": [
                {
                    "poi_id": top_stop["id"],
                    "name": top_stop["name"],
                    "lat": top_stop["lat"],
                    "lon": top_stop["lon"],
                    "dwell_minutes": top_stop["estimated_dwell_minutes"],
                    "traffic_light": top_stop["traffic_light"],
                }
            ],
            "transit_mode": "driving",
        },
    )
    assert res_sched.status_code == 200
    sched_data = res_sched.json()
    assert sched_data["is_feasible"] is True
    assert sched_data["buffer_status"]["post_arrival_buffer_satisfied"] is True
    assert sched_data["buffer_status"]["pre_checkin_buffer_satisfied"] is True
    assert sched_data["source"]["lat"] == pytest.approx(12.8398, abs=1e-4)


def test_coordinate_validation_all_endpoints():
    """Verify all endpoints strictly validate coordinate bounds [-90, 90] and [-180, 180]."""
    # 1. Nearby destinations endpoint with invalid lat
    res1 = client.post(
        "/api/v1/itinerary/nearby-destinations",
        json={"source": {"lat": 95.0, "lon": 0.0}, "radius_km": 10.0},
    )
    assert res1.status_code == 422

    # 2. Discover corridor endpoint with invalid lon
    res2 = client.post(
        "/api/v1/itinerary/discover-corridor",
        json={
            "source": {"lat": 0.0, "lon": -195.0},
            "destination": {"lat": 0.0, "lon": 0.0},
        },
    )
    assert res2.status_code == 422

    # 3. Generate schedule with invalid destination lat
    res3 = client.post(
        "/api/v1/itinerary/generate-schedule",
        json={
            "transit_arrival_time": "12:00",
            "check_in_time": "16:00",
            "source": {"lat": 10.0, "lon": 10.0},
            "destination": {"lat": -100.0, "lon": 10.0},
            "stops": [],
        },
    )
    assert res3.status_code == 422


