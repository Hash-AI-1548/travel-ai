"""Automated tests for OSRM Road Routing, GeoJSON geometry, multi-segment navigation, and optimizer integration."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.routing.routing_service import (
    get_road_route,
    get_multi_segment_route,
    clear_routing_cache,
)
from backend.modules.itinerary.poi_service import haversine_distance, distance_point_to_finite_segment
from backend.modules.itinerary.itinerary_optimizer import generate_optimized_itinerary
from backend.schemas.poi import Coordinate, CandidatePOI
from backend.schemas.itinerary import (
    ItineraryGenerationRequest,
    ItineraryStop,
    TimelineEventType,
)
from backend.schemas.routing import RouteRequest, MultiSegmentRouteRequest

client = TestClient(app)


@pytest.fixture(autouse=True)
def reset_cache():
    clear_routing_cache()
    yield
    clear_routing_cache()


def test_routing_accepts_valid_coordinates_and_returns_geojson():
    """Test road routing returns road distance, duration, and GeoJSON LineString geometry."""
    origin = Coordinate(lat=12.8398, lon=80.1548, name="Melakottaiyur")
    dest = Coordinate(lat=13.0604, lon=80.2496, name="Taj Coromandel")

    route = get_road_route(origin, dest, mode="driving")

    assert route.distance_km > 0.0
    assert route.distance_meters > 0.0
    assert route.duration_minutes > 0
    assert route.geometry.type == "LineString"
    assert len(route.geometry.coordinates) >= 2

    # Verify GeoJSON coordinates format: [lon, lat]
    first_coord = route.geometry.coordinates[0]
    assert len(first_coord) == 2
    assert -180.0 <= first_coord[0] <= 180.0
    assert -90.0 <= first_coord[1] <= 90.0


def test_routing_invalid_coordinates_rejected():
    """Invalid latitude/longitude must be rejected with HTTP 422."""
    payload = {
        "origin": {"lat": 999.0, "lon": 80.1548, "name": "Invalid Origin"},
        "destination": {"lat": 13.0604, "lon": 80.2496, "name": "Taj"},
        "mode": "driving",
    }
    res = client.post("/api/v1/routing/route", json=payload)
    assert res.status_code == 422


def test_road_distance_greater_than_or_equal_to_straight_line():
    """
    Fundamental geographic rule:
    Actual road travel distance must be >= straight-line Haversine distance.
    """
    origin = Coordinate(lat=12.8398, lon=80.1548, name="Melakottaiyur")
    dest = Coordinate(lat=13.0604, lon=80.2496, name="Taj Coromandel")

    haversine_km = haversine_distance(origin.lat, origin.lon, dest.lat, dest.lon)
    route = get_road_route(origin, dest, mode="driving")

    # Road distance is strictly greater than or equal to straight-line distance
    assert route.distance_km >= round(haversine_km * 0.95, 2)
    assert route.duration_minutes >= 5


def test_corridor_detour_distinct_from_road_travel_distance():
    """
    CRITICAL DISTINCTION:
    Corridor detour distance to finite S -> D line is completely different from road travel distance.
    """
    s = Coordinate(lat=12.8398, lon=80.1548, name="Melakottaiyur")
    d = Coordinate(lat=13.0604, lon=80.2496, name="Taj Coromandel")
    poi = Coordinate(lat=13.0334, lon=80.2699, name="Kapaleeshwarar Temple")

    # 1. Geographic corridor detour (perpendicular distance to S -> D line)
    corridor_detour_km = distance_point_to_finite_segment(poi.lat, poi.lon, s.lat, s.lon, d.lat, d.lon)
    assert corridor_detour_km < 4.0  # Close to the transit corridor

    # 2. Road travel distance from S to POI
    road_route = get_road_route(s, poi, mode="driving")
    assert road_route.distance_km > 20.0  # Actual road drive is ~25-30 km

    # Ensure the two metrics are distinctly different
    assert road_route.distance_km != pytest.approx(corridor_detour_km, abs=5.0)


def test_itinerary_optimizer_uses_road_routing_for_every_segment():
    """
    Every transit leg in the optimized itinerary must contain:
    - road distance (distance_km)
    - road duration (duration_minutes)
    - GeoJSON route geometry (route_geometry)
    - road_routed flag
    """
    s = Coordinate(lat=12.8398, lon=80.1548, name="Melakottaiyur")
    d = Coordinate(lat=13.0604, lon=80.2496, name="Taj Coromandel")
    stop1 = ItineraryStop(poi_id="k1", name="Kapaleeshwarar Temple", lat=13.0334, lon=80.2699, dwell_minutes=45)
    stop2 = ItineraryStop(poi_id="g1", name="Guindy National Park", lat=13.0067, lon=80.2206, dwell_minutes=45)

    req = ItineraryGenerationRequest(
        transit_arrival_time="09:00",
        check_in_time="17:00",
        source=s,
        destination=d,
        stops=[stop1, stop2],
        transit_mode="driving",
    )

    resp = generate_optimized_itinerary(req)
    assert resp.is_feasible is True

    # Find all transit legs
    transit_events = [e for e in resp.timeline if e.event_type == TimelineEventType.TRANSIT]
    assert len(transit_events) == 3  # S -> stop1, stop1 -> stop2, stop2 -> D

    for idx, leg in enumerate(transit_events):
        assert leg.distance_km is not None
        assert leg.distance_km > 0.0
        assert leg.duration_minutes > 0
        assert leg.route_geometry is not None
        assert leg.route_geometry.get("type") == "LineString"
        assert len(leg.route_geometry.get("coordinates", [])) >= 2
        assert "via road network" in leg.description


def test_independent_multi_segment_routing():
    """Verify get_multi_segment_route routes each leg independently with its own geometry."""
    points = [
        Coordinate(lat=12.8398, lon=80.1548, name="Origin"),
        Coordinate(lat=13.0067, lon=80.2206, name="Stop 1"),
        Coordinate(lat=13.0334, lon=80.2699, name="Stop 2"),
        Coordinate(lat=13.0604, lon=80.2496, name="Hotel"),
    ]

    segments = get_multi_segment_route(points, mode="driving")
    assert len(segments) == 3

    for seg in segments:
        assert seg.distance_km > 0.0
        assert seg.duration_minutes > 0
        assert seg.geometry.type == "LineString"
        assert len(seg.geometry.coordinates) >= 2


def test_routing_cache_efficiency():
    """Verify subsequent requests for identical origin-destination hit the cache immediately."""
    origin = Coordinate(lat=48.8566, lon=2.3522, name="Paris Center")
    dest = Coordinate(lat=48.8606, lon=2.3376, name="Louvre")

    # First call
    route1 = get_road_route(origin, dest, mode="driving")

    # Second call (must be retrieved from cache)
    route2 = get_road_route(origin, dest, mode="driving")

    assert route1.distance_km == route2.distance_km
    assert route1.duration_minutes == route2.duration_minutes
    assert route1.geometry.coordinates == route2.geometry.coordinates


def test_api_routing_endpoint():
    """Test POST /api/v1/routing/route endpoint."""
    payload = {
        "origin": {"lat": 12.8398, "lon": 80.1548, "name": "Start"},
        "destination": {"lat": 13.0604, "lon": 80.2496, "name": "End"},
        "mode": "driving",
    }
    res = client.post("/api/v1/routing/route", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert data["distance_km"] > 0
    assert data["duration_minutes"] > 0
    assert data["geometry"]["type"] == "LineString"


def test_api_multi_routing_endpoint():
    """Test POST /api/v1/routing/multi-route endpoint."""
    payload = {
        "points": [
            {"lat": 12.8398, "lon": 80.1548, "name": "Start"},
            {"lat": 13.0067, "lon": 80.2206, "name": "Mid"},
            {"lat": 13.0604, "lon": 80.2496, "name": "End"},
        ],
        "mode": "driving",
    }
    res = client.post("/api/v1/routing/multi-route", json=payload)
    assert res.status_code == 200
    data = res.json()
    assert len(data["segments"]) == 2
    assert data["total_distance_km"] > 0
    assert data["total_duration_minutes"] > 0
