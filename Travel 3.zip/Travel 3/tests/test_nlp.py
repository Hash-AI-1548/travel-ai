"""Automated unit and API tests for NLP travel query parsing."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.nlp.nlp_parser import parse_trip_query

client = TestClient(app)


def test_parse_trip_query_paris_art_and_dining():
    """Extracts Paris, party of 2, art and dining interests, arrival and checkin times."""
    query = "Plan a 2-day art and French dining trip for 2 in Paris arriving at 12:30 and checking in at 17:30 with high local authenticity"
    res = parse_trip_query(query)

    assert res.success is True
    intent = res.parsed_intent
    assert intent.destination_name == "Paris, France"
    assert intent.party_size == 2
    assert intent.duration_days == 2
    assert "art" in intent.preferred_tags
    assert "French" in intent.preferred_cuisines
    assert intent.transit_arrival_time == "12:30"
    assert intent.check_in_time == "17:30"
    assert intent.blendin_preference > 0.7


def test_parse_trip_query_tokyo_relaxed_vegetarian():
    """Extracts Tokyo, relaxed pace, vegetarian dietary preference, and morning arrival."""
    query = "A relaxed slow trip to Tokyo for a vegetarian family of 4 arriving at 9:00am, looking for shrines and gardens"
    res = parse_trip_query(query)

    assert res.success is True
    intent = res.parsed_intent
    assert intent.destination_name == "Tokyo, Japan"
    assert intent.party_size == 4
    assert intent.pace == "relaxed"
    assert "Vegetarian" in intent.dietary_restrictions
    assert "gardens" in intent.preferred_tags
    assert intent.transit_arrival_time == "09:00"


def test_nlp_api_endpoint():
    """POST /api/v1/nlp/parse returns 200 with structured response."""
    payload = {"query": "A fast paced luxury trip to NYC for 1 person arriving at 2pm"}
    response = client.post("/api/v1/nlp/parse", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["success"] is True
    assert data["parsed_intent"]["destination_name"] == "New York, USA"
    assert data["parsed_intent"]["pace"] == "fast"
    assert data["parsed_intent"]["budget_tier"] == "$$$$"
    assert data["parsed_intent"]["transit_arrival_time"] == "14:00"
