"""Automated unit and API tests for food discovery and meal timing."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.food.meal_time import detect_meal_window_for_time, validate_service_hours
from backend.modules.food.food_service import recommend_restaurants
from backend.schemas.poi import Coordinate
from backend.schemas.food import FoodRecommendationRequest, MealType

client = TestClient(app)


def test_detect_meal_window_logic():
    """Validates breakfast, lunch, and dinner window detection."""
    assert detect_meal_window_for_time("08:30") == MealType.BREAKFAST
    assert detect_meal_window_for_time("13:00") == MealType.LUNCH
    assert detect_meal_window_for_time("19:45") == MealType.DINNER
    assert detect_meal_window_for_time("16:00") is None


def test_recommend_restaurants_service():
    """Recommends candidate dining spots around coordinates."""
    req = FoodRecommendationRequest(
        location=Coordinate(lat=48.8566, lon=2.3522, name="Paris Center"),
        target_time="13:00",
        dietary_restrictions=["Vegetarian"],
    )
    res = recommend_restaurants(req)
    assert res.total_found >= 3
    for r in res.restaurants:
        assert r.category in ["Restaurant", "Cafe & Dining"]
        assert r.rating >= 4.0


def test_food_api_endpoints():
    """Tests POST /api/v1/food/recommend and /meal-window."""
    rec_payload = {
        "location": {"lat": 48.8566, "lon": 2.3522, "name": "Paris"},
        "target_time": "12:30",
    }
    rec_resp = client.post("/api/v1/food/recommend", json=rec_payload)
    assert rec_resp.status_code == 200
    assert len(rec_resp.json()["restaurants"]) > 0

    meal_payload = {
        "service_hours": {"lunch": ["12:00", "14:30"], "dinner": ["19:00", "22:30"]},
        "target_time": "13:00",
    }
    meal_resp = client.post("/api/v1/food/meal-window", json=meal_payload)
    assert meal_resp.status_code == 200
    assert meal_resp.json()["is_open"] is True
    assert meal_resp.json()["matched_meal_type"] == "LUNCH"
