"""Automated tests for Frontend Geolocation mock handling, state transitions, and dynamic S -> D dispatch."""

import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)
ROOT_DIR = Path(__file__).parent.parent
FRONTEND_DIR = ROOT_DIR / "frontend"


def test_frontend_js_geolocation_contracts_and_states():
    """Verify frontend/js/app.js implements all 6 required location states and geolocation APIs."""
    js_file = FRONTEND_DIR / "js" / "app.js"
    assert js_file.exists()
    content = js_file.read_text(encoding="utf-8")

    # 1. Location States Enum
    assert "LOCATING" in content
    assert "LOCATION_READY" in content
    assert "LOCATION_PERMISSION_DENIED" in content
    assert "LOCATION_UNAVAILABLE" in content
    assert "LOCATION_TIMEOUT" in content
    assert "LOCATION_ERROR" in content

    # 2. Browser Geolocation API invocation
    assert "navigator.geolocation.getCurrentPosition" in content
    assert "enableHighAccuracy" in content
    assert "position.coords" in content
    assert "latitude" in content
    assert "longitude" in content
    assert "accuracy" in content


    # 3. Dynamic Source & Destination packaging
    assert "state.source" in content
    assert "state.destination" in content
    assert "/api/v1/itinerary/nearby-destinations" in content
    assert "/api/v1/itinerary/discover-corridor" in content

    # 4. Mock Geolocation injection hook for testing
    assert "window.mockGeolocation" in content


def test_frontend_html_location_ui_elements():
    """Verify frontend/index.html includes mode switcher, location status indicators, and center on me button."""
    html_file = FRONTEND_DIR / "index.html"
    assert html_file.exists()
    content = html_file.read_text(encoding="utf-8")

    # Mode switcher
    assert 'id="btn-mode-real"' in content
    assert 'id="btn-mode-demo"' in content

    # Location status and accuracy
    assert 'id="location-status-pill"' in content
    assert 'id="loc-accuracy-tag"' in content
    assert 'id="btn-center-on-me"' in content
    assert 'id="map-floating-center-btn"' in content

    # Location permission/error banner
    assert 'id="location-banner-card"' in content
    assert 'id="btn-request-location"' in content
    assert 'id="destination-select"' in content


def test_mock_geolocation_dispatch_simulation():
    """
    Simulate the frontend geolocation mock injection (Lat: 12.8398, Lon: 80.1548, Accuracy: 15)
    and verify the backend responses across the entire dynamic S -> D pipeline.
    """
    # 1. Mocked coordinates provided by browser Geolocation API
    mock_browser_position = {
        "coords": {
            "latitude": 12.8398,
            "longitude": 80.1548,
            "accuracy": 15.0,
        },
        "timestamp": 1724340000000,
    }

    lat = mock_browser_position["coords"]["latitude"]
    lon = mock_browser_position["coords"]["longitude"]
    source_payload = {"lat": lat, "lon": lon, "name": "Your Current Location"}

    # 2. Frontend Step: Fetch nearby candidate hotels for user location S
    res_hotels = client.post("/api/v1/itinerary/nearby-destinations", json={"source": source_payload, "radius_km": 15.0})
    assert res_hotels.status_code == 200
    hotel_list = res_hotels.json()["destinations"]
    assert len(hotel_list) > 0

    # 3. Frontend Step: User selects destination hotel D
    selected_hotel = hotel_list[0]
    dest_payload = {"lat": selected_hotel["lat"], "lon": selected_hotel["lon"], "name": selected_hotel["name"]}

    # 4. Frontend Step: Discover candidate POIs along S -> D
    res_pois = client.post(
        "/api/v1/itinerary/discover-corridor",
        json={"source": source_payload, "destination": dest_payload, "detour_threshold_km": 3.5},
    )
    assert res_pois.status_code == 200
    candidates = res_pois.json()["candidate_pois"]
    assert len(candidates) >= 5

    # 5. Frontend Step: Filter & Rank POIs along S -> D
    res_rank = client.post(
        "/api/v1/itinerary/corridor-pois",
        json={
            "source": source_payload,
            "destination": dest_payload,
            "candidate_pois": candidates,
            "detour_threshold_km": 3.5,
        },
    )
    assert res_rank.status_code == 200
    ranked_pois = res_rank.json()["corridor_pois"]
    assert len(ranked_pois) > 0

    # 6. Frontend Step: Schedule optimized itinerary
    stops = [
        {
            "poi_id": p["id"],
            "name": p["name"],
            "lat": p["lat"],
            "lon": p["lon"],
            "dwell_minutes": p["estimated_dwell_minutes"],
            "traffic_light": p["traffic_light"],
        }
        for p in ranked_pois if p["is_inside_corridor"]
    ][:2]

    res_schedule = client.post(
        "/api/v1/itinerary/generate-schedule",
        json={
            "transit_arrival_time": "13:30",
            "check_in_time": "18:00",
            "source": source_payload,
            "destination": dest_payload,
            "stops": stops,
            "transit_mode": "driving",
        },
    )
    assert res_schedule.status_code == 200
    schedule = res_schedule.json()
    assert schedule["source"]["lat"] == pytest.approx(12.8398, abs=1e-4)
    assert schedule["source"]["lon"] == pytest.approx(80.1548, abs=1e-4)
    assert schedule["buffer_status"]["post_arrival_buffer_satisfied"] is True
    assert schedule["buffer_status"]["pre_checkin_buffer_satisfied"] is True
