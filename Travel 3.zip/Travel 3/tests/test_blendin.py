"""Automated unit and API tests for BlendIn authenticity scoring and balancing."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.blendin.blendin_service import calculate_blendin_score, balance_itinerary_blendin
from backend.schemas.poi import RankedPOI, TrafficLightClassification
from backend.schemas.blendin import BlendInScoreRequest, BlendInItineraryRequest

client = TestClient(app)


def test_blendin_score_calculation():
    """Iconic landmarks have high familiarity; local bistros have high authenticity."""
    iconic_req = BlendInScoreRequest(poi_id="louvre", name="Louvre Museum", category="Museum", tags=["art", "museum"])
    iconic_res = calculate_blendin_score(iconic_req)
    assert iconic_res.metrics.familiarity_score >= 0.8
    assert iconic_res.metrics.blendin_category == "Iconic Landmark"

    local_req = BlendInScoreRequest(poi_id="bistro", name="Neighborhood Bakery & Bistro", category="Restaurant", tags=["food", "bistro"])
    local_res = calculate_blendin_score(local_req)
    assert local_res.metrics.authenticity_score >= 0.8
    assert local_res.metrics.blendin_category == "Local Favorite"


def test_blendin_api_endpoints():
    """POST /api/v1/blendin/score and /balance return 200."""
    score_payload = {
        "poi_id": "eiffel_tower",
        "name": "Eiffel Tower",
        "category": "Landmark",
        "tags": ["monument", "scenic"],
        "rating": 4.8,
    }
    score_resp = client.post("/api/v1/blendin/score", json=score_payload)
    assert score_resp.status_code == 200
    assert score_resp.json()["metrics"]["familiarity_score"] > 0.8

    stop = RankedPOI(
        id="louvre",
        name="Louvre Museum",
        lat=48.86,
        lon=2.33,
        category="Museum",
        tags=["art"],
        rating=4.9,
        estimated_dwell_minutes=60,
        distance_to_corridor_km=0.4,
        is_inside_corridor=True,
        preference_score=0.85,
        traffic_light=TrafficLightClassification.GREEN,
        match_explanation="High match for art and museum lovers.",
    )

    bal_payload = {
        "stops": [stop.model_dump()],
        "target_blendin": 0.8,
    }
    bal_resp = client.post("/api/v1/blendin/balance", json=bal_payload)
    assert bal_resp.status_code == 200
    assert len(bal_resp.json()["balanced_stops"]) == 1
