"""Automated unit and API tests for Traveler Profile synthesis."""

import pytest
from fastapi.testclient import TestClient
from backend.main import app
from backend.modules.profile.profile_service import synthesize_traveler_profile
from backend.schemas.profile import PacingType, TravelerProfileInput

client = TestClient(app)


def test_synthesize_traveler_profile_relaxed():
    """Relaxed pace caps stops at 2 and increases target dwell."""
    req = TravelerProfileInput(
        traveler_count=2,
        pace=PacingType.RELAXED,
        interests=["art", "history"],
        cuisines=["French"],
        blendin_level=0.8,
    )
    res = synthesize_traveler_profile(req)
    profile = res.profile

    assert profile.max_stops_per_day == 2
    assert profile.target_dwell_minutes == 60
    assert profile.blendin_weight == 0.8
    assert "french" in profile.interest_weights
    assert "art" in profile.interest_weights


def test_profile_api_endpoint():
    """POST /api/v1/profile/synthesize returns synthesized persona."""
    payload = {
        "traveler_count": 1,
        "traveler_ages": [28],
        "pace": "fast",
        "interests": ["shopping", "modern"],
        "cuisines": ["Japanese"],
        "dietary": ["Vegan"],
        "budget": "$$$",
        "blendin_level": 0.5,
        "accessibility": False,
    }
    response = client.post("/api/v1/profile/synthesize", json=payload)
    assert response.status_code == 200
    data = response.json()
    profile = data["profile"]
    assert profile["pace"] == "fast"
    assert profile["max_stops_per_day"] == 5
    assert profile["dietary_flags"] == ["Vegan"]
    assert profile["budget_tier"] == "$$$"
