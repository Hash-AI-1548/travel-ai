# Travel-AI — Unified Corridor & Dynamic Buffer Travel Platform

A production-grade, constraint-aware travel platform connecting natural language understanding, traveler personas, first-class dining recommendations, geodesic corridor filtering, OSRM road routing, strict buffer optimization (+20m post-arrival & ≥20m pre-check-in), cultural etiquette, BlendIn authenticity indexing, and travel translation into a unified web application.

---

## 🌟 Key Architecture & Pipeline

```text
INPUT (NLP / Geolocation / Bookings)
  ↓
UNDERSTAND (NLP Intent & Traveler Profile Synthesis)
  ↓
RECOMMEND (POIs, Cuisines & First-Class Dining)
  ↓
FILTER (Geodesic S->D Corridor & Service Hours)
  ↓
OPTIMIZE (OSRM Road Routing, +20m Buffers & Feasibility)
  ↓
ADAPT & ENRICH (Cultural Attire, BlendIn Index & Translation Bridge)
```

---

## 🚀 Quick Start

### 1. Requirements
- Python 3.9+
- Modern Web Browser (Chrome, Firefox, Safari, Edge)

### 2. Installation
```bash
pip install -r backend/requirements.txt
```

### 3. Run Application
```bash
python3 -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload
```
Open [http://localhost:8000](http://localhost:8000) in your browser.

### 4. Run Automated Test Suite
```bash
python3 -m pytest -v
```

---

## 📡 API Endpoints Summary

- `POST /api/v1/nlp/parse`: Parse freeform travel queries into structured parameters.
- `POST /api/v1/profile/synthesize`: Synthesize traveler profile, pacing, and dietary constraints.
- `POST /api/v1/food/recommend`: Discover and filter restaurants by cuisine and service hours.
- `POST /api/v1/itinerary/corridor-pois`: Geodesic corridor filtering & traffic-light ranking.
- `POST /api/v1/itinerary/generate-schedule`: Chronological timeline enforcing 20m post-arrival and pre-check-in guarantees.
- `GET  /api/v1/itinerary/bookings`: Retrieve confirmed hotel reservations.
- `POST /api/v1/routing/route`: OSRM road distance, duration, and GeoJSON navigation geometry.
- `POST /api/v1/cultural/guide`: Local customs, etiquette, and weather-aware attire guidance.
- `POST /api/v1/blendin/score`: Authenticity vs tourist familiarity scoring and itinerary balancing.
- `POST /api/v1/translation/phrase`: Essential multilingual phrases & food cultural bridge.
