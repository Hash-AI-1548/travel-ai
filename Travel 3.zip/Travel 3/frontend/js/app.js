/**
 * Travel Platform: POI Corridor & Dynamic Buffer Itinerary Planner
 * Production Frontend Application Logic with Real Browser Geolocation,
 * First-Class Restaurant Support & Hotel Booking Integration
 */

// Location State Enum
const LocationState = {
  LOCATING: 'LOCATING',
  LOCATION_READY: 'LOCATION_READY',
  LOCATION_PERMISSION_DENIED: 'LOCATION_PERMISSION_DENIED',
  LOCATION_UNAVAILABLE: 'LOCATION_UNAVAILABLE',
  LOCATION_TIMEOUT: 'LOCATION_TIMEOUT',
  LOCATION_ERROR: 'LOCATION_ERROR',
};

// Application State
const state = {
  // Mode: 'real' (DEFAULT) or 'demo'
  appMode: 'real',
  
  // Geolocation
  locationState: LocationState.LOCATING,
  locationData: null, // { latitude, longitude, accuracy, timestamp }
  
  // Dynamic S (Source) and D (Destination)
  source: null,       // Coordinate { lat, lon, name }
  destination: null,  // Coordinate { lat, lon, name }
  
  // Destination options & Confirmed Bookings in Real Mode
  nearbyDestinations: [],
  selectedDestinationId: null,
  bookings: [],
  activeBookingId: null,
  
  // Presets in Demo Mode
  presets: {},
  currentPresetId: 'paris_hub_marais',
  currentPreset: null,
  
  // Corridor & Preferences
  detourThresholdKm: 3.5,
  preferredTags: ['art', 'history', 'architecture', 'cafe', 'french'],
  transitMode: 'driving',
  arrivalTime: '13:30',
  checkinTime: '18:00',
  
  // POI & Stop Data
  candidatePois: [],
  corridorPois: [],
  selectedStops: [],
  
  // API Responses
  currentSchedule: null,
  activeDrawerPoi: null,
  
  // Map References
  map: null,
  userMarker: null,
  accuracyCircle: null,
  markersLayer: null,
  corridorLayer: null,
  routeLayer: null,
};

// API Base URL
const API_BASE = window.location.origin;

// ==========================================================================
// Initialization
// ==========================================================================
document.addEventListener('DOMContentLoaded', async () => {
  initMap();
  bindEventListeners();
  
  // 1. Preload demo presets & confirmed bookings
  await Promise.all([loadPresets(), loadBookings()]);

  // 2. PRIMARY OBJECTIVE: Initialize in REAL CURRENT LOCATION Mode (Default)
  switchMode('real');
});

// ==========================================================================
// Map Initialization
// ==========================================================================
function initMap() {
  state.map = L.map('map', {
    zoomControl: false,
  }).setView([20.0, 0.0], 2);

  L.control.zoom({ position: 'bottomright' }).addTo(state.map);

  // CartoDB Voyager tiles for clean aesthetic
  L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
    attribution: '&copy; <a href="https://carto.com/">CARTO</a>, &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    subdomains: 'abcd',
    maxZoom: 19,
  }).addTo(state.map);

  state.markersLayer = L.layerGroup().addTo(state.map);
  state.corridorLayer = L.layerGroup().addTo(state.map);
  state.routeLayer = L.layerGroup().addTo(state.map);
}

// ==========================================================================
// Event Listeners
// ==========================================================================
function bindEventListeners() {
  // Mode Switcher: Real Location vs Demo Presets
  document.getElementById('btn-mode-real')?.addEventListener('click', () => {
    switchMode('real');
  });

  document.getElementById('btn-mode-demo')?.addEventListener('click', () => {
    switchMode('demo');
  });

  // Geolocation Request / Retry Buttons
  document.getElementById('btn-request-location')?.addEventListener('click', () => {
    requestBrowserGeolocation();
  });

  document.getElementById('btn-switch-to-demo')?.addEventListener('click', () => {
    switchMode('demo');
  });

  // Center on Me Buttons (Header & Map overlay)
  document.getElementById('btn-center-on-me')?.addEventListener('click', () => {
    centerMapOnUser();
  });

  document.getElementById('map-floating-center-btn')?.addEventListener('click', () => {
    centerMapOnUser();
  });

  // Destination Selector in Real Mode
  const destSelect = document.getElementById('destination-select');
  if (destSelect) {
    destSelect.addEventListener('change', (e) => {
      onDestinationSelected(e.target.value);
    });
  }

  // Booking Selector in Real Mode
  const bookingSelect = document.getElementById('booking-select');
  if (bookingSelect) {
    bookingSelect.addEventListener('change', (e) => {
      onBookingSelected(e.target.value);
    });
  }

  // Demo Preset Selector
  const presetSelect = document.getElementById('preset-select');
  if (presetSelect) {
    presetSelect.addEventListener('change', (e) => {
      switchPreset(e.target.value);
    });
  }

  // Recalculate Button
  document.getElementById('btn-recalculate')?.addEventListener('click', () => {
    refreshAll();
  });

  // Time Inputs
  document.getElementById('input-arrival-time')?.addEventListener('change', (e) => {
    state.arrivalTime = e.target.value;
    generateSchedule();
  });

  document.getElementById('input-checkin-time')?.addEventListener('change', (e) => {
    state.checkinTime = e.target.value;
    generateSchedule();
  });

  // Transit Mode Buttons
  document.querySelectorAll('.mode-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.mode-btn').forEach((b) => b.classList.remove('active'));
      const target = e.currentTarget;
      target.classList.add('active');
      state.transitMode = target.dataset.mode || 'driving';
      generateSchedule();
    });
  });

  // Detour Threshold Slider
  const slider = document.getElementById('slider-threshold');
  const sliderVal = document.getElementById('slider-threshold-val');
  const thresholdLabel = document.getElementById('current-threshold-label');
  if (slider) {
    slider.addEventListener('input', (e) => {
      state.detourThresholdKm = parseFloat(e.target.value);
      if (sliderVal) sliderVal.textContent = `${state.detourThresholdKm.toFixed(1)} km`;
      if (thresholdLabel) thresholdLabel.textContent = `${state.detourThresholdKm.toFixed(1)} km threshold`;
    });
    slider.addEventListener('change', () => {
      fetchCorridorPOIs();
    });
  }

  // Interest Tag Chips
  document.querySelectorAll('.chip').forEach((chip) => {
    chip.addEventListener('click', () => {
      const tag = chip.dataset.tag;
      if (chip.classList.contains('active')) {
        chip.classList.remove('active');
        state.preferredTags = state.preferredTags.filter((t) => t !== tag);
      } else {
        chip.classList.add('active');
        if (!state.preferredTags.includes(tag)) {
          state.preferredTags.push(tag);
        }
      }
      fetchCorridorPOIs();
    });
  });

  // Preferences Header Accordion Toggle
  document.getElementById('pref-toggle-btn')?.addEventListener('click', () => {
    const body = document.getElementById('preferences-body');
    if (body) {
      body.classList.toggle('collapsed');
      const arrow = document.querySelector('.toggle-arrow');
      if (arrow) {
        arrow.textContent = body.classList.contains('collapsed') ? '▸' : '▾';
      }
    }
  });

  // Navigation Tabs
  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const tabKey = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach((c) => c.classList.remove('active'));

      btn.classList.add('active');
      document.getElementById(`tab-${tabKey}-content`)?.classList.add('active');
    });
  });

  // Traffic Light & Restaurant Filter Chips in POI List
  document.querySelectorAll('.poi-filter-chip').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.poi-filter-chip').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      renderPOIList(btn.dataset.filter || 'all');
    });
  });

  // Drawer Close Button
  document.getElementById('drawer-close-btn')?.addEventListener('click', () => {
    closeDrawer();
  });

  // Drawer Action Button (Add/Remove)
  document.getElementById('drawer-action-btn')?.addEventListener('click', () => {
    if (!state.activeDrawerPoi) return;
    toggleStop(state.activeDrawerPoi);
    updateDrawerButtonState();
  });
}

// ==========================================================================
// Mode Switching: Real Current Location vs Demo Presets
// ==========================================================================
function switchMode(mode) {
  state.appMode = mode;

  const btnReal = document.getElementById('btn-mode-real');
  const btnDemo = document.getElementById('btn-mode-demo');
  const realControls = document.getElementById('real-location-controls');
  const demoControls = document.getElementById('demo-preset-controls');
  const floatingCenterBtn = document.getElementById('map-floating-center-btn');
  const legendOriginLabel = document.getElementById('legend-origin-label');

  if (mode === 'real') {
    btnReal?.classList.add('active');
    btnDemo?.classList.remove('active');
    realControls?.classList.remove('hidden');
    demoControls?.classList.add('hidden');
    floatingCenterBtn?.classList.remove('hidden');
    if (legendOriginLabel) legendOriginLabel.textContent = 'Your Location (S)';

    requestBrowserGeolocation();
  } else {
    btnReal?.classList.remove('active');
    btnDemo?.classList.add('active');
    realControls?.classList.add('hidden');
    demoControls?.classList.remove('hidden');
    floatingCenterBtn?.classList.add('hidden');
    if (legendOriginLabel) legendOriginLabel.textContent = 'Transit Hub (Origin S)';

    hideLocationBanner();
    switchPreset(state.currentPresetId || 'paris_hub_marais');
  }
}

// ==========================================================================
// Browser Geolocation Handling (Primary Objective)
// ==========================================================================
function requestBrowserGeolocation() {
  updateLocationState(LocationState.LOCATING);

  if (!navigator.geolocation) {
    handleGeolocationError({
      code: 2,
      message: 'Geolocation is not supported by this browser.',
    });
    return;
  }

  const geoOptions = {
    enableHighAccuracy: true,
    timeout: 10000,
    maximumAge: 0,
  };

  navigator.geolocation.getCurrentPosition(
    (position) => {
      handleGeolocationSuccess(position);
    },
    (error) => {
      handleGeolocationError(error);
    },
    geoOptions
  );
}

function handleGeolocationSuccess(position) {
  const { latitude, longitude, accuracy } = position.coords;
  const timestamp = position.timestamp || Date.now();

  state.locationData = {
    latitude,
    longitude,
    accuracy: Math.round(accuracy),
    timestamp,
  };

  state.source = {
    lat: latitude,
    lon: longitude,
    name: 'Your Current Location',
  };

  updateLocationState(LocationState.LOCATION_READY);
  hideLocationBanner();

  if (state.map) {
    state.map.setView([latitude, longitude], 13);
  }

  initRealLocationCorridor();
}

function handleGeolocationError(error) {
  let mappedState = LocationState.LOCATION_ERROR;
  let userMessage = 'Location access is required to build your itinerary from your current location.';

  if (error.code === 1) {
    mappedState = LocationState.LOCATION_PERMISSION_DENIED;
    userMessage = 'Location permission was denied. Please allow location access in your browser settings to build an itinerary from where you are.';
  } else if (error.code === 2) {
    mappedState = LocationState.LOCATION_UNAVAILABLE;
    userMessage = 'Your current location could not be determined. Check your network or device location settings.';
  } else if (error.code === 3) {
    mappedState = LocationState.LOCATION_TIMEOUT;
    userMessage = 'Location request timed out. Please click Try Again or switch to a demo preset.';
  }

  updateLocationState(mappedState);
  showLocationBanner(userMessage);
  renderLocationRequiredState(userMessage);
}

function updateLocationState(locState) {
  state.locationState = locState;

  const dot = document.getElementById('loc-dot');
  const statusText = document.getElementById('loc-status-text');
  const accuracyTag = document.getElementById('loc-accuracy-tag');

  if (!dot || !statusText) return;

  dot.className = 'status-indicator-dot';

  if (locState === LocationState.LOCATING) {
    dot.classList.add('locating');
    statusText.textContent = 'Locating...';
    accuracyTag?.classList.add('hidden');
  } else if (locState === LocationState.LOCATION_READY) {
    dot.classList.add('ready');
    statusText.textContent = 'Location Ready';
    if (accuracyTag && state.locationData) {
      accuracyTag.textContent = `±${state.locationData.accuracy} m`;
      accuracyTag.classList.remove('hidden');
      if (state.locationData.accuracy > 500) {
        accuracyTag.classList.add('warning');
        accuracyTag.title = 'Low accuracy signal';
      } else {
        accuracyTag.classList.remove('warning');
        accuracyTag.title = 'Accurate GPS / Network location';
      }
    }
  } else {
    dot.classList.add('error');
    statusText.textContent = locState === LocationState.LOCATION_PERMISSION_DENIED ? 'Location Denied' : 'Location Error';
    accuracyTag?.classList.add('hidden');
  }
}

function showLocationBanner(message) {
  const banner = document.getElementById('location-banner-card');
  const msgEl = document.getElementById('loc-banner-msg');
  if (banner) {
    banner.classList.remove('hidden');
    banner.classList.add('error');
    if (msgEl) msgEl.textContent = message;
  }
}

function hideLocationBanner() {
  const banner = document.getElementById('location-banner-card');
  if (banner) banner.classList.add('hidden');
}

function renderLocationRequiredState(message) {
  const timelineContainer = document.getElementById('timeline-list');
  const poisContainer = document.getElementById('pois-list');

  const bannerHtml = `
    <div class="loading-state">
      <div style="font-size: 2rem; margin-bottom: 0.5rem;">📍</div>
      <div style="font-weight: 600; color: var(--text-primary); font-size: 0.95rem;">Location Required</div>
      <div style="text-align: center; max-width: 320px; line-height: 1.4;">${escapeHtml(message)}</div>
      <button class="btn btn-primary btn-sm" style="margin-top: 0.75rem;" onclick="window.requestBrowserGeolocation()">
        Enable Location / Try Again
      </button>
    </div>
  `;

  if (timelineContainer) timelineContainer.innerHTML = bannerHtml;
  if (poisContainer) poisContainer.innerHTML = bannerHtml;
}

function centerMapOnUser() {
  if (state.source && state.map) {
    state.map.flyTo([state.source.lat, state.source.lon], 14, {
      duration: 1.2,
    });
  } else {
    requestBrowserGeolocation();
  }
}

// ==========================================================================
// Real Mode: Nearby Destinations, Hotel Bookings & POI Discovery
// ==========================================================================
async function loadBookings() {
  try {
    const res = await fetch(`${API_BASE}/api/v1/itinerary/bookings`);
    if (!res.ok) throw new Error('Failed to load bookings');
    const data = await res.json();
    state.bookings = data.bookings || [];
    populateBookingDropdown(state.bookings);
  } catch (err) {
    console.error('Error loading bookings:', err);
  }
}

function populateBookingDropdown(bookings) {
  const select = document.getElementById('booking-select');
  if (!select) return;

  let html = `<option value="">-- Use Dynamic / Nearby Hotel --</option>`;
  bookings.forEach((b) => {
    html += `<option value="${b.booking_id}">🏨 ${escapeHtml(b.hotel_name)} (${b.check_in_time} check-in)</option>`;
  });
  select.innerHTML = html;
}

function onBookingSelected(bookingId) {
  if (!bookingId) {
    state.activeBookingId = null;
    if (state.nearbyDestinations.length > 0) {
      onDestinationSelected(state.nearbyDestinations[0].id);
    }
    return;
  }

  const chosen = state.bookings.find((b) => b.booking_id === bookingId);
  if (!chosen) return;

  state.activeBookingId = bookingId;
  state.selectedDestinationId = null;
  state.destination = {
    lat: chosen.lat,
    lon: chosen.lon,
    name: chosen.hotel_name,
  };
  state.checkinTime = chosen.check_in_time;

  const checkinInput = document.getElementById('input-checkin-time');
  if (checkinInput) checkinInput.value = state.checkinTime;

  state.selectedStops = [];
  discoverCorridorPOIs().then(() => refreshAll());
}

async function initRealLocationCorridor() {
  if (!state.source) return;

  try {
    // 1. Fetch nearby candidate destinations / hotels
    const destRes = await fetch(`${API_BASE}/api/v1/itinerary/nearby-destinations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: state.source,
        radius_km: 15.0,
      }),
    });

    if (!destRes.ok) throw new Error(`Destination API error: ${destRes.status}`);
    const destData = await destRes.json();
    state.nearbyDestinations = destData.destinations || [];

    populateDestinationDropdown(state.nearbyDestinations);

    // 2. If no active booking selected, select first nearby hotel
    if (!state.activeBookingId && state.nearbyDestinations.length > 0) {
      const defaultDest = state.nearbyDestinations[0];
      state.selectedDestinationId = defaultDest.id;
      state.destination = {
        lat: defaultDest.lat,
        lon: defaultDest.lon,
        name: defaultDest.name,
      };
    }

    // 3. Discover dynamic candidate POIs along S -> D
    await discoverCorridorPOIs();
    await refreshAll();
  } catch (err) {
    console.error('Error initializing real location corridor:', err);
  }
}

function populateDestinationDropdown(destinations) {
  const select = document.getElementById('destination-select');
  if (!select) return;

  if (destinations.length === 0) {
    select.innerHTML = `<option value="">No hotels found nearby</option>`;
    return;
  }

  select.innerHTML = destinations
    .map(
      (d) => `
      <option value="${d.id}">${escapeHtml(d.name)} (~${d.distance_from_source_km} km)</option>
    `
    )
    .join('');

  if (state.selectedDestinationId) {
    select.value = state.selectedDestinationId;
  }
}

async function onDestinationSelected(destId) {
  const chosen = state.nearbyDestinations.find((d) => d.id === destId);
  if (!chosen) return;

  state.selectedDestinationId = destId;
  state.activeBookingId = null;
  const bookingSelect = document.getElementById('booking-select');
  if (bookingSelect) bookingSelect.value = '';

  state.destination = {
    lat: chosen.lat,
    lon: chosen.lon,
    name: chosen.name,
  };

  state.selectedStops = [];
  await discoverCorridorPOIs();
  await refreshAll();
}

async function discoverCorridorPOIs() {
  if (!state.source || !state.destination) return;

  try {
    const res = await fetch(`${API_BASE}/api/v1/itinerary/discover-corridor`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: state.source,
        destination: state.destination,
        preferences: {
          preferred_tags: state.preferredTags,
          pace: 'moderate',
          max_detour_km: state.detourThresholdKm,
        },
        detour_threshold_km: state.detourThresholdKm,
      }),
    });

    if (!res.ok) throw new Error(`Discover corridor error: ${res.status}`);
    const data = await res.json();
    state.candidatePois = data.candidate_pois || [];
  } catch (err) {
    console.error('Error discovering corridor POIs:', err);
  }
}

// ==========================================================================
// Demo Presets Loading (Explicit Demo Mode Only)
// ==========================================================================
async function loadPresets() {
  try {
    const res = await fetch(`${API_BASE}/api/v1/itinerary/presets`);
    if (!res.ok) throw new Error('Failed to load presets');
    const data = await res.json();
    state.presets = {};
    data.presets.forEach((p) => {
      state.presets[p.id] = p;
    });
  } catch (err) {
    console.error('Error loading presets:', err);
  }
}

function switchPreset(presetId) {
  const preset = state.presets[presetId];
  if (!preset) return;

  state.currentPresetId = presetId;
  state.currentPreset = preset;
  state.source = preset.source;
  state.destination = preset.destination;
  state.candidatePois = preset.candidate_pois;
  state.detourThresholdKm = preset.detour_threshold_km || 3.5;
  state.arrivalTime = preset.transit_arrival_time || '13:30';
  state.checkinTime = preset.check_in_time || '18:00';
  state.transitMode = preset.transit_mode || 'driving';
  state.activeBookingId = null;

  const arrivalInput = document.getElementById('input-arrival-time');
  const checkinInput = document.getElementById('input-checkin-time');
  const slider = document.getElementById('slider-threshold');
  const sliderVal = document.getElementById('slider-threshold-val');
  const thresholdLabel = document.getElementById('current-threshold-label');

  if (arrivalInput) arrivalInput.value = state.arrivalTime;
  if (checkinInput) checkinInput.value = state.checkinTime;
  if (slider) slider.value = state.detourThresholdKm;
  if (sliderVal) sliderVal.textContent = `${state.detourThresholdKm.toFixed(1)} km`;
  if (thresholdLabel) thresholdLabel.textContent = `${state.detourThresholdKm.toFixed(1)} km threshold`;

  state.selectedStops = [];
  refreshAll();
}

async function refreshAll() {
  if (!state.source || !state.destination) return;
  await fetchCorridorPOIs();
  await generateSchedule();
}

// ==========================================================================
// API: Corridor POI Filtering & Ranking
// ==========================================================================
async function fetchCorridorPOIs() {
  if (!state.source || !state.destination) return;

  const payload = {
    source: state.source,
    destination: state.destination,
    candidate_pois: state.candidatePois,
    preferences: {
      preferred_tags: state.preferredTags,
      pace: 'moderate',
      max_detour_km: state.detourThresholdKm,
    },
    detour_threshold_km: state.detourThresholdKm,
    current_time: state.arrivalTime,
  };

  try {
    const res = await fetch(`${API_BASE}/api/v1/itinerary/corridor-pois`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) throw new Error(`HTTP error ${res.status}`);
    const data = await res.json();
    state.corridorPois = data.corridor_pois || [];

    // If no stops currently selected, add top GREEN match + top restaurant
    if (state.selectedStops.length === 0) {
      const topGreen = state.corridorPois.filter((p) => p.is_inside_corridor && p.traffic_light === 'GREEN');
      state.selectedStops = topGreen.slice(0, 2).map(formatStopFromRanked);
    }

    renderPOIList();
    renderMap();
  } catch (err) {
    console.error('Error fetching corridor POIs:', err);
  }
}

// ==========================================================================
// API: Schedule Generation & Strict Buffer Optimizer
// ==========================================================================
async function generateSchedule() {
  if (!state.source || !state.destination) return;

  const payload = {
    transit_arrival_time: state.arrivalTime,
    check_in_time: state.checkinTime,
    source: state.source,
    destination: state.destination,
    stops: state.selectedStops,
    transit_mode: state.transitMode,
    booking_id: state.activeBookingId,
  };

  try {
    const res = await fetch(`${API_BASE}/api/v1/itinerary/generate-schedule`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) throw new Error(`Schedule API error: ${res.status}`);
    const schedule = await res.json();
    state.currentSchedule = schedule;

    renderFeasibilityAndBuffers(schedule);
    renderTimeline(schedule);
    renderMap();
  } catch (err) {
    console.error('Error generating schedule:', err);
  }
}

function formatStopFromRanked(poi) {
  const isRest = poi.category === 'Restaurant' || poi.category === 'Cafe & Dining' || Boolean(poi.cuisine);
  return {
    poi_id: poi.id,
    name: poi.name,
    lat: poi.lat,
    lon: poi.lon,
    dwell_minutes: poi.estimated_dwell_minutes || (isRest ? 55 : 45),
    category: poi.category,
    tags: poi.tags || [],
    preference_score: poi.preference_score,
    traffic_light: poi.traffic_light,
    cuisine: poi.cuisine,
    service_hours: poi.service_hours,
    meal_type: poi.meal_window_match,
    is_restaurant: isRest,
  };
}

// ==========================================================================
// Render: Feasibility & Dynamic Buffer Badges
// ==========================================================================
function renderFeasibilityAndBuffers(schedule) {
  const badge = document.getElementById('feasibility-badge');
  const badgeText = document.getElementById('feasibility-text');
  const alertBox = document.getElementById('warning-alert-box');
  const alertContent = document.getElementById('warning-alert-content');

  const postBox = document.getElementById('post-arrival-buffer-box');
  const postText = document.getElementById('post-arrival-status-text');

  const preBox = document.getElementById('pre-checkin-buffer-box');
  const preText = document.getElementById('pre-checkin-status-text');

  const buf = schedule.buffer_status;

  // 1. Overall Feasibility
  if (schedule.is_feasible) {
    badge?.classList.remove('infeasible');
    if (badgeText) badgeText.textContent = 'FEASIBLE ITINERARY';
    alertBox?.classList.add('hidden');
  } else {
    badge?.classList.add('infeasible');
    if (badgeText) badgeText.textContent = 'BUFFER VIOLATION';
    alertBox?.classList.remove('hidden');
    if (alertContent) {
      alertContent.innerHTML = schedule.warnings.join('<br>') || 'Schedule violates buffer guarantee.';
    }
  }

  // 2. Post-Arrival Buffer (+20m)
  if (buf.post_arrival_buffer_satisfied) {
    postBox?.classList.remove('violated');
    postBox?.classList.add('satisfied');
    if (postText) postText.textContent = `Enforced (${buf.post_arrival_buffer_minutes} min)`;
  } else {
    postBox?.classList.add('violated');
    postBox?.classList.remove('satisfied');
    if (postText) postText.textContent = 'Violated';
  }

  // 3. Pre-Checkin Buffer Guarantee (>=20m)
  if (buf.pre_checkin_buffer_satisfied) {
    preBox?.classList.remove('violated');
    preBox?.classList.add('satisfied');
    if (preText) preText.textContent = `Guaranteed (${buf.pre_checkin_buffer_minutes}m early)`;
  } else {
    preBox?.classList.add('violated');
    preBox?.classList.remove('satisfied');
    if (preText) {
      if (buf.pre_checkin_buffer_minutes < 0) {
        preText.textContent = `Late by ${Math.abs(buf.pre_checkin_buffer_minutes)} min`;
      } else {
        preText.textContent = `Only ${buf.pre_checkin_buffer_minutes}m (Min 20m required)`;
      }
    }
  }

  // Tab Stop Counter
  const stopCountEl = document.getElementById('timeline-stop-count');
  if (stopCountEl) stopCountEl.textContent = `${state.selectedStops.length} stop${state.selectedStops.length === 1 ? '' : 's'}`;
}

// ==========================================================================
// Render: Chronological Timeline
// ==========================================================================
function renderTimeline(schedule) {
  const container = document.getElementById('timeline-list');
  if (!container) return;

  if (!schedule.timeline || schedule.timeline.length === 0) {
    container.innerHTML = `<div class="loading-state">No timeline events scheduled.</div>`;
    return;
  }

  let html = '';

  schedule.timeline.forEach((event, idx) => {
    const isLast = idx === schedule.timeline.length - 1;
    let nodeClass = 'node-transit';
    let iconChar = '🚗';

    if (event.event_type === 'TRANSIT_ARRIVAL') {
      nodeClass = 'node-arrival';
      iconChar = state.appMode === 'real' ? '📍' : '🛬';
    } else if (event.event_type === 'BUFFER') {
      nodeClass = 'node-buffer';
      iconChar = '⏱️';
    } else if (event.event_type === 'MEAL_STOP') {
      nodeClass = 'node-meal';
      iconChar = '🍽️';
    } else if (event.event_type === 'POI_VISIT') {
      if (event.traffic_light === 'GREEN') nodeClass = 'node-poi-green';
      else if (event.traffic_light === 'YELLOW') nodeClass = 'node-poi-yellow';
      else nodeClass = 'node-poi-red';
      iconChar = '📍';
    } else if (event.event_type === 'HOTEL_CHECKIN_ARRIVAL') {
      nodeClass = 'node-hotel';
      iconChar = '🏨';
    } else if (event.event_type === 'TRANSIT') {
      iconChar = state.transitMode === 'transit' ? '🚆' : state.transitMode === 'walking' ? '🚶' : '🚗';
    }

    const poiId = event.details?.poi_id;

    html += `
      <div class="timeline-item">
        <div class="timeline-connector">
          <div class="timeline-icon-node ${nodeClass}">${iconChar}</div>
          ${!isLast ? '<div class="timeline-line"></div>' : ''}
        </div>
        <div class="timeline-card">
          <div class="timeline-card-header">
            <span class="timeline-card-title">${escapeHtml(event.title)}</span>
            <span class="timeline-time-badge">${event.start_time}${event.start_time !== event.end_time ? ' – ' + event.end_time : ''}</span>
          </div>
          <div class="timeline-card-sub">${escapeHtml(event.description || '')}</div>
          
          <div class="timeline-meta-tags">
            ${event.distance_km ? `
              <span class="meta-tag" style="color: #60A5FA; font-weight: 600; background-color: rgba(37, 99, 235, 0.15); border: 1px solid rgba(37, 99, 235, 0.3);">
                🚗 ${event.transit_mode ? event.transit_mode.toUpperCase() : 'ROAD'}: ${event.distance_km.toFixed(1)} km · ${event.duration_minutes} min
              </span>
            ` : ''}

            ${event.cuisine ? `
              <span class="meta-tag" style="color: #FBBF24; font-weight: 600; background-color: rgba(245, 158, 11, 0.15); border: 1px solid rgba(245, 158, 11, 0.3);">
                🍽️ ${escapeHtml(event.cuisine)}
              </span>
            ` : ''}

            ${event.status_badge ? `
              <span class="meta-tag" style="color: ${event.is_buffer_satisfied !== false ? 'var(--color-green)' : 'var(--color-red)'}">
                ${event.is_buffer_satisfied !== false ? '✓ ' : '⚠️ '}${escapeHtml(event.status_badge)}
              </span>
            ` : ''}
          </div>

          ${poiId ? `
            <div class="timeline-meta-tags" style="justify-content: space-between; margin-top: 0.4rem;">
              <span class="meta-tag">⏱️ Dwell: ${event.duration_minutes}m</span>
              <button class="remove-poi-btn" onclick="removeStopById('${poiId}')">✕ Remove</button>
            </div>
          ` : ''}
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// ==========================================================================
// Render: Corridor POI & Restaurant Discovery List
// ==========================================================================
function renderPOIList(filter = 'all') {
  const container = document.getElementById('pois-list');
  if (!container) return;

  const countAll = document.getElementById('count-all');
  const countRestaurant = document.getElementById('count-restaurant');
  const countGreen = document.getElementById('count-green');
  const countYellow = document.getElementById('count-yellow');
  const countRed = document.getElementById('count-red');
  const corridorPoiCount = document.getElementById('corridor-poi-count');

  const insidePois = state.corridorPois.filter((p) => p.is_inside_corridor);
  const restaurantCount = insidePois.filter((p) => p.category === 'Restaurant' || p.cuisine).length;
  const greenCount = insidePois.filter((p) => p.traffic_light === 'GREEN').length;
  const yellowCount = insidePois.filter((p) => p.traffic_light === 'YELLOW').length;
  const redCount = insidePois.filter((p) => p.traffic_light === 'RED').length;

  if (countAll) countAll.textContent = insidePois.length;
  if (countRestaurant) countRestaurant.textContent = restaurantCount;
  if (countGreen) countGreen.textContent = greenCount;
  if (countYellow) countYellow.textContent = yellowCount;
  if (countRed) countRed.textContent = redCount;
  if (corridorPoiCount) corridorPoiCount.textContent = `${insidePois.length} in corridor`;

  let filtered = insidePois;
  if (filter === 'RESTAURANT') {
    filtered = insidePois.filter((p) => p.category === 'Restaurant' || Boolean(p.cuisine));
  } else if (filter !== 'all') {
    filtered = insidePois.filter((p) => p.traffic_light === filter);
  }

  if (filtered.length === 0) {
    container.innerHTML = `<div class="loading-state">No candidate stops match the selected filter within ${state.detourThresholdKm} km.</div>`;
    return;
  }

  let html = '';
  filtered.forEach((poi) => {
    const isAdded = state.selectedStops.some((s) => s.poi_id === poi.id);
    const trafficClass = poi.traffic_light.toLowerCase();
    const estRoadKm = (poi.distance_to_corridor_km * 1.25 + 1.2).toFixed(1);
    const isRest = poi.category === 'Restaurant' || Boolean(poi.cuisine);

    let serviceStr = '';
    if (poi.service_hours) {
      const hours = Object.entries(poi.service_hours)
        .map(([k, v]) => `${k.charAt(0).toUpperCase() + k.slice(1)}: ${v[0]}–${v[1]}`)
        .join(' · ');
      serviceStr = `<span style="font-size: 0.72rem; color: #FBBF24;">🕒 ${escapeHtml(hours)}</span>`;
    }

    html += `
      <div class="poi-item-card ${trafficClass}-match" onclick="openDrawerForPoi('${poi.id}')">
        <div class="poi-card-header">
          <span class="poi-card-name">${escapeHtml(poi.name)}</span>
          <span class="traffic-pill ${trafficClass}">${poi.traffic_light}</span>
        </div>
        <div class="poi-card-meta">
          <span>${isRest ? '🍽️ ' + escapeHtml(poi.cuisine || poi.category) : escapeHtml(poi.category)}</span>
          <span>⭐ ${poi.rating.toFixed(1)}</span>
          <span class="poi-score-pill">Score: ${(poi.preference_score * 100).toFixed(0)}%</span>
          ${poi.meal_window_match ? `<span class="meta-tag" style="color: #FBBF24; background: rgba(245, 158, 11, 0.15);">${escapeHtml(poi.meal_window_match)}</span>` : ''}
        </div>
        ${serviceStr ? `<div class="poi-card-meta">${serviceStr}</div>` : ''}
        <div class="poi-card-meta" style="font-size: 0.72rem; color: #94A3B8;">
          <span>📍 Corridor Detour: <b>${poi.distance_to_corridor_km.toFixed(2)} km</b></span>
          <span>🚗 Road Travel: ~<b>${estRoadKm} km</b></span>
        </div>
        <div class="poi-card-actions" onclick="event.stopPropagation()">
          <span style="font-size: 0.75rem; color: var(--text-muted);">⏱️ ${poi.estimated_dwell_minutes} min dwell</span>
          <button class="btn-add-poi ${isAdded ? 'added' : ''}" onclick="toggleStopById('${poi.id}')">
            ${isAdded ? '✓ Added' : '+ Add to Itinerary'}
          </button>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;
}

// ==========================================================================
// Render: Map Elements (User Pulsing Dot, Hotel Pin, Corridor & Road Routes)
// ==========================================================================
function renderMap() {
  if (!state.map || !state.source || !state.destination) return;

  state.markersLayer.clearLayers();
  state.corridorLayer.clearLayers();
  state.routeLayer.clearLayers();

  const src = state.source;
  const dst = state.destination;

  // 1. Draw Finite Corridor Line (S -> D) - Visual Filtering Reference (Dashed)
  L.polyline([[src.lat, src.lon], [dst.lat, dst.lon]], {
    color: '#38BDF8',
    weight: 2.5,
    opacity: 0.7,
    dashArray: '6, 8',
  }).addTo(state.corridorLayer);

  // 2. Draw ACTUAL ROAD ROUTES for EVERY Itinerary Leg using GeoJSON LineString (Solid)
  const allMapPoints = [[src.lat, src.lon], [dst.lat, dst.lon]];
  let hasGeoJSONRoutes = false;

  if (state.currentSchedule && state.currentSchedule.timeline) {
    const transitEvents = state.currentSchedule.timeline.filter((e) => e.event_type === 'TRANSIT' && e.route_geometry);

    transitEvents.forEach((ev) => {
      hasGeoJSONRoutes = true;
      L.geoJSON(ev.route_geometry, {
        style: {
          color: '#2563EB',
          weight: 5,
          opacity: 0.92,
          lineCap: 'round',
          lineJoin: 'round',
        },
      }).addTo(state.routeLayer);

      if (ev.route_geometry.coordinates) {
        ev.route_geometry.coordinates.forEach((coord) => {
          allMapPoints.push([coord[1], coord[0]]); // [lat, lon]
        });
      }
    });
  }

  // Fallback if schedule is still loading
  if (!hasGeoJSONRoutes) {
    const routePoints = [[src.lat, src.lon]];
    state.selectedStops.forEach((stop) => {
      routePoints.push([stop.lat, stop.lon]);
    });
    routePoints.push([dst.lat, dst.lon]);

    L.polyline(routePoints, {
      color: '#60A5FA',
      weight: 4,
      opacity: 0.9,
    }).addTo(state.routeLayer);
  }

  // 3. Source Marker (S)
  if (state.appMode === 'real') {
    const userIcon = createUserLocationIcon();
    const userMarker = L.marker([src.lat, src.lon], { icon: userIcon, zIndexOffset: 1000 }).addTo(state.markersLayer);
    userMarker.bindPopup(`<b>Your Location (S):</b><br>${escapeHtml(src.name || 'Current Location')}<br><small>Accuracy: ±${state.locationData?.accuracy || 15} m</small>`);
    
    if (state.locationData?.accuracy && state.locationData.accuracy <= 2000) {
      L.circle([src.lat, src.lon], {
        radius: state.locationData.accuracy,
        color: '#38BDF8',
        fillColor: '#38BDF8',
        fillOpacity: 0.1,
        weight: 1,
      }).addTo(state.markersLayer);
    }
  } else {
    const srcIcon = createCustomMarkerSVG('#2563EB', '🛬');
    const srcMarker = L.marker([src.lat, src.lon], { icon: srcIcon }).addTo(state.markersLayer);
    srcMarker.bindPopup(`<b>Origin Hub:</b> ${escapeHtml(src.name || 'Transit Hub')}`);
  }

  // 4. Destination Hotel Marker (D) (Purple pin)
  const dstIcon = createCustomMarkerSVG('#7C3AED', '🏨');
  const dstMarker = L.marker([dst.lat, dst.lon], { icon: dstIcon, zIndexOffset: 900 }).addTo(state.markersLayer);
  const bookingTag = state.activeBookingId ? `<br><small style="color: #A78BFA;">Confirmed Booking (${state.activeBookingId})</small>` : '';
  dstMarker.bindPopup(`<b>Destination:</b> ${escapeHtml(dst.name || 'Hotel')}${bookingTag}`);

  // 5. POI & Restaurant Markers (Traffic Light Colors)
  state.corridorPois.forEach((poi) => {
    let pinColor = '#16A34A'; // Green
    if (poi.traffic_light === 'YELLOW') pinColor = '#D97706';
    if (poi.traffic_light === 'RED') pinColor = '#DC2626';

    const isSelected = state.selectedStops.some((s) => s.poi_id === poi.id);
    const isRestaurant = poi.category === 'Restaurant' || Boolean(poi.cuisine);
    const poiIcon = isRestaurant ? createRestaurantMarkerSVG(pinColor, isSelected) : createPoiMarkerSVG(pinColor, isSelected);

    const marker = L.marker([poi.lat, poi.lon], { icon: poiIcon }).addTo(state.markersLayer);
    marker.on('click', () => {
      openDrawerForPoi(poi.id);
    });

    if (poi.is_inside_corridor || isSelected) {
      allMapPoints.push([poi.lat, poi.lon]);
    }
  });

  // Auto-fit bounds
  if (allMapPoints.length > 0) {
    state.map.fitBounds(allMapPoints, { padding: [40, 40], maxZoom: 14 });
  }
}

// Marker Icons
function createUserLocationIcon() {
  const html = `
    <div class="user-location-marker">
      <div class="user-location-pulse"></div>
      <div class="user-location-dot"></div>
    </div>
  `;
  return L.divIcon({
    html: html,
    className: 'custom-user-leaflet-icon',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
    popupAnchor: [0, -12],
  });
}

function createCustomMarkerSVG(color, emoji) {
  const svgHtml = `
    <div style="position: relative; width: 34px; height: 42px; display: flex; align-items: center; justify-content: center;">
      <svg width="34" height="42" viewBox="0 0 34 42" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M17 0C7.61 0 0 7.61 0 17C0 29.75 17 42 17 42C17 42 34 29.75 34 17C34 7.61 26.39 0 17 0Z" fill="${color}"/>
        <circle cx="17" cy="16" r="12" fill="#0F172A" />
      </svg>
      <span style="position: absolute; top: 7px; font-size: 13px;">${emoji}</span>
    </div>
  `;
  return L.divIcon({
    html: svgHtml,
    className: 'custom-leaflet-marker',
    iconSize: [34, 42],
    iconAnchor: [17, 42],
    popupAnchor: [0, -38],
  });
}

function createRestaurantMarkerSVG(color, isSelected) {
  const stroke = isSelected ? '#FFFFFF' : 'rgba(0,0,0,0.3)';
  const strokeWidth = isSelected ? '3' : '1.5';
  const scale = isSelected ? '1.15' : '1.0';

  const svgHtml = `
    <div style="position: relative; width: 30px; height: 38px; display: flex; align-items: center; justify-content: center; transform: scale(${scale});">
      <svg width="30" height="38" viewBox="0 0 34 42" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M17 0C7.61 0 0 7.61 0 17C0 29.75 17 42 17 42C17 42 34 29.75 34 17C34 7.61 26.39 0 17 0Z" fill="${color}" stroke="${stroke}" stroke-width="${strokeWidth}"/>
        <circle cx="17" cy="16" r="11" fill="#0F172A"/>
      </svg>
      <span style="position: absolute; top: 6px; font-size: 12px;">🍽️</span>
    </div>
  `;
  return L.divIcon({
    html: svgHtml,
    className: 'custom-leaflet-marker',
    iconSize: [30, 38],
    iconAnchor: [15, 38],
    popupAnchor: [0, -34],
  });
}

function createPoiMarkerSVG(color, isSelected) {
  const stroke = isSelected ? '#FFFFFF' : 'rgba(0,0,0,0.3)';
  const strokeWidth = isSelected ? '3' : '1.5';
  const scale = isSelected ? '1.15' : '1.0';

  const svgHtml = `
    <div style="position: relative; width: 28px; height: 36px; display: flex; align-items: center; justify-content: center; transform: scale(${scale});">
      <svg width="28" height="36" viewBox="0 0 28 36" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M14 0C6.27 0 0 6.27 0 14C0 24.5 14 36 14 36C14 36 28 24.5 28 14C28 6.27 21.73 0 14 0Z" fill="${color}" stroke="${stroke}" stroke-width="${strokeWidth}"/>
        <circle cx="14" cy="13" r="5" fill="#FFFFFF"/>
      </svg>
    </div>
  `;
  return L.divIcon({
    html: svgHtml,
    className: 'custom-leaflet-marker',
    iconSize: [28, 36],
    iconAnchor: [14, 36],
    popupAnchor: [0, -32],
  });
}

// ==========================================================================
// POI Detail Drawer & Stop Management
// ==========================================================================
function openDrawerForPoi(poiId) {
  const poi = state.corridorPois.find((p) => p.id === poiId) || state.candidatePois.find((p) => p.id === poiId);
  if (!poi) return;

  state.activeDrawerPoi = poi;

  const drawer = document.getElementById('poi-drawer');
  const title = document.getElementById('drawer-title');
  const cat = document.getElementById('drawer-category');
  const rating = document.getElementById('drawer-rating');
  const cuisineEl = document.getElementById('drawer-cuisine');
  const dwell = document.getElementById('drawer-dwell');
  const desc = document.getElementById('drawer-description');
  const scoreBar = document.getElementById('drawer-score-bar');
  const scoreExpl = document.getElementById('drawer-score-expl');
  const tagsList = document.getElementById('drawer-tags');
  const trafficBadge = document.getElementById('drawer-traffic-badge');

  const corridorDetourEl = document.getElementById('drawer-corridor-detour');
  const roadTravelEl = document.getElementById('drawer-road-travel');
  const serviceHoursEl = document.getElementById('drawer-service-hours');

  const estRoadKm = ((poi.distance_to_corridor_km || 1.0) * 1.25 + 1.2).toFixed(1);
  const estRoadMin = Math.max(3, Math.round(estRoadKm * 2.2));

  if (title) title.textContent = poi.name;
  if (cat) cat.textContent = poi.category || 'Point of Interest';
  if (rating) rating.textContent = `⭐ ${poi.rating ? poi.rating.toFixed(1) : '4.0'}`;

  if (cuisineEl) {
    if (poi.cuisine) {
      cuisineEl.textContent = `🍽️ ${poi.cuisine}`;
      cuisineEl.classList.remove('hidden');
    } else {
      cuisineEl.classList.add('hidden');
    }
  }

  if (corridorDetourEl) corridorDetourEl.textContent = `${(poi.distance_to_corridor_km || 0.0).toFixed(2)} km`;
  if (roadTravelEl) roadTravelEl.textContent = `${estRoadKm} km · ${estRoadMin} min`;

  if (serviceHoursEl) {
    if (poi.service_hours) {
      const hoursStr = Object.entries(poi.service_hours)
        .map(([k, v]) => `${k.charAt(0).toUpperCase() + k.slice(1)}: ${v[0]}–${v[1]}`)
        .join(' | ');
      serviceHoursEl.textContent = hoursStr;
    } else {
      serviceHoursEl.textContent = 'Standard Hours';
    }
  }

  if (dwell) dwell.textContent = `⏱️ ${poi.estimated_dwell_minutes || 45} min dwell`;
  if (desc) desc.textContent = poi.description || 'Explore this curated stop along the transit corridor.';

  const scorePct = Math.round((poi.preference_score || 0.5) * 100);
  if (scoreBar) {
    scoreBar.style.width = `${scorePct}%`;
    scoreBar.style.backgroundColor = poi.traffic_light === 'GREEN' ? 'var(--color-green)' : poi.traffic_light === 'YELLOW' ? 'var(--color-yellow)' : 'var(--color-red)';
  }
  if (scoreExpl) scoreExpl.textContent = poi.match_explanation || `Preference score: ${(poi.preference_score || 0).toFixed(2)}`;

  if (trafficBadge) {
    trafficBadge.textContent = poi.traffic_light === 'GREEN' ? '🟢 TOP PREFERENCE MATCH' : poi.traffic_light === 'YELLOW' ? '🟡 SCENIC / SECONDARY STOP' : '🔴 LOW PRIORITY / CONSTRAINT MISMATCH';
    trafficBadge.style.color = poi.traffic_light === 'GREEN' ? 'var(--color-green)' : poi.traffic_light === 'YELLOW' ? 'var(--color-yellow)' : 'var(--color-red)';
  }

  if (tagsList) {
    tagsList.innerHTML = (poi.tags || []).map((t) => `<span class="meta-tag">${escapeHtml(t)}</span>`).join('');
  }

  updateDrawerButtonState();
  drawer?.classList.remove('closed');
}

function closeDrawer() {
  document.getElementById('poi-drawer')?.classList.add('closed');
  state.activeDrawerPoi = null;
}

function updateDrawerButtonState() {
  const btn = document.getElementById('drawer-action-btn');
  if (!btn || !state.activeDrawerPoi) return;

  const isAdded = state.selectedStops.some((s) => s.poi_id === state.activeDrawerPoi.id);
  if (isAdded) {
    btn.textContent = '✕ Remove from Itinerary';
    btn.style.backgroundColor = 'var(--color-red)';
  } else {
    btn.textContent = '+ Add to Itinerary';
    btn.style.backgroundColor = 'var(--color-blue)';
  }
}

function toggleStopById(poiId) {
  const poi = state.corridorPois.find((p) => p.id === poiId) || state.candidatePois.find((p) => p.id === poiId);
  if (poi) toggleStop(poi);
}

function toggleStop(poi) {
  const existsIndex = state.selectedStops.findIndex((s) => s.poi_id === poi.id);
  if (existsIndex >= 0) {
    state.selectedStops.splice(existsIndex, 1);
  } else {
    state.selectedStops.push(formatStopFromRanked(poi));
  }

  renderPOIList();
  generateSchedule();
}

// Global Exports for testing and inline event handlers
window.removeStopById = function (poiId) {
  state.selectedStops = state.selectedStops.filter((s) => s.poi_id !== poiId);
  renderPOIList();
  generateSchedule();
  if (state.activeDrawerPoi?.id === poiId) {
    updateDrawerButtonState();
  }
};

window.toggleStopById = toggleStopById;
window.openDrawerForPoi = openDrawerForPoi;
window.requestBrowserGeolocation = requestBrowserGeolocation;
window.switchMode = switchMode;
window.switchPreset = switchPreset;
window.onBookingSelected = onBookingSelected;
window.state = state;
window.mockGeolocation = function (latitude, longitude, accuracy = 15) {
  handleGeolocationSuccess({
    coords: {
      latitude,
      longitude,
      accuracy,
    },
    timestamp: Date.now(),
  });
};

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
