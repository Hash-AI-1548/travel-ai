import React, { useState } from "react";
import {
  CloudRain,
  Plane,
  Radio,
  Clock,
  Wrench,
  Truck,
  Shield,
  Users,
  Luggage,
  GitPullRequest,
  HeartPulse,
  RotateCcw,
  X,
  Zap,
  TrendingUp,
  Sparkles,
} from "lucide-react";
import type { DisruptionFactors, SeverityLevel } from "../../types/disruption";
import { PRESET_DISRUPTION_SCENARIOS, DEFAULT_DISRUPTION_FACTORS } from "../../types/disruption";
import { DisruptionInferenceEngine } from "../../engine/disruptionInferenceEngine";
import { puterAiService } from "../../services/puterAiService";
import { sounds } from "../../utils/audio";

interface DisruptionStudioSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentFactors: DisruptionFactors;
  onApplyFactors: (factors: DisruptionFactors) => void;
}

const SEVERITY_LEVELS: SeverityLevel[] = ["NONE", "MINOR", "MODERATE", "SEVERE", "CRITICAL"];

const SEVERITY_COLORS: Record<SeverityLevel, { bg: string; text: string; border: string }> = {
  NONE: { bg: "bg-slate-900", text: "text-slate-500", border: "border-slate-800" },
  MINOR: { bg: "bg-sky-950/60", text: "text-sky-300", border: "border-sky-800" },
  MODERATE: { bg: "bg-amber-950/60", text: "text-amber-300", border: "border-amber-800" },
  SEVERE: { bg: "bg-orange-950/60", text: "text-orange-300", border: "border-orange-700" },
  CRITICAL: { bg: "bg-rose-950/80", text: "text-rose-200", border: "border-rose-600" },
};

export const DisruptionStudioSidebar: React.FC<DisruptionStudioSidebarProps> = ({
  isOpen,
  onClose,
  currentFactors,
  onApplyFactors,
}) => {
  const [factors, setFactors] = useState<DisruptionFactors>(currentFactors || DEFAULT_DISRUPTION_FACTORS);
  const [isAiSynthesizing, setIsAiSynthesizing] = useState<boolean>(false);
  const [aiSynthesizedNotice, setAiSynthesizedNotice] = useState<string | null>(null);

  React.useEffect(() => {
    if (currentFactors) {
      setFactors(currentFactors);
    }
  }, [currentFactors]);

  // Real-time live inference preview
  const liveOutcome = DisruptionInferenceEngine.inferOutcome(factors);

  const updateFactor = (key: keyof DisruptionFactors, value: any) => {
    setFactors((prev) => {
      const next = { ...prev, [key]: value };
      onApplyFactors(next);
      return next;
    });
  };

  const handleApply = () => {
    onApplyFactors(factors);
    sounds.playCockpitChime();
    onClose();
  };

  const handleApplyPreset = (presetFactors: DisruptionFactors) => {
    setFactors(presetFactors);
    onApplyFactors(presetFactors);
    sounds.playSuccessChime();
    onClose();
  };

  const handleAiAutoSynthesize = async () => {
    setIsAiSynthesizing(true);
    sounds.playRadarPing();
    try {
      const res = await puterAiService.autoSynthesizeOperationalSceneWithAI();
      setFactors(res.data);
      onApplyFactors(res.data);
      setAiSynthesizedNotice("✓ Live operational scene synthesized.");
      sounds.playSuccessChime();
    } finally {
      setIsAiSynthesizing(false);
    }
  };

  const handleReset = () => {
    setFactors(DEFAULT_DISRUPTION_FACTORS);
    onApplyFactors(DEFAULT_DISRUPTION_FACTORS);
    setAiSynthesizedNotice(null);
    sounds.playRadarPing();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-xl bg-[#070b14]/98 backdrop-blur-2xl border-l border-slate-800 shadow-2xl flex flex-col font-mono text-xs text-slate-200 select-none animate-in slide-in-from-right duration-300">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-800 bg-[#090e1a]">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-sky-950 border border-sky-800 text-sky-400">
            <Zap className="h-4 w-4" />
          </div>
          <div>
            <h2 className="text-sm font-black tracking-wider text-white uppercase">
              Operational Scene Studio
            </h2>
            <p className="text-[10px] text-slate-400">
              Autonomous Real-Time Condition & Decision Synthesizer
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleReset}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition text-[11px]"
            title="Reset to default scene"
          >
            <RotateCcw className="h-3 w-3" />
            <span>Reset</span>
          </button>

          <button
            onClick={onClose}
            className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Main Scrollable Body */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5">
        {/* Synthesize Scene Button */}
        <div className="space-y-2">
          <button
            onClick={handleAiAutoSynthesize}
            disabled={isAiSynthesizing}
            className={`w-full py-3 px-4 rounded-xl font-bold font-mono text-xs text-white shadow-lg flex items-center justify-center gap-2 transition cursor-pointer border ${
              isAiSynthesizing
                ? "bg-indigo-900/80 border-indigo-500 animate-pulse"
                : "bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 border-sky-400/60 shadow-sky-950/80"
            }`}
          >
            <Zap className="h-4 w-4" />
            <span>{isAiSynthesizing ? "SYNTHESIZING SCENE..." : "SYNTHESIZE SCENE"}</span>
          </button>

          {aiSynthesizedNotice && (
            <div className="p-2 rounded-lg bg-emerald-950/80 border border-emerald-600 text-[10px] text-emerald-300 flex items-center gap-1.5 animate-in fade-in">
              <Sparkles className="h-3.5 w-3.5 text-emerald-400 shrink-0" />
              <span>{aiSynthesizedNotice}</span>
            </div>
          )}
        </div>

        {/* Preset Incident Templates Carousel */}
        <div className="space-y-2">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            ⚡ Quick-Launch Incident Templates
          </span>

          <div className="grid grid-cols-2 gap-2">
            {PRESET_DISRUPTION_SCENARIOS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => handleApplyPreset(preset.factors)}
                className="p-2.5 rounded-lg border border-slate-800 bg-[#0d1322] hover:border-sky-600/80 hover:bg-[#11192e] text-left transition group"
              >
                <span className="text-xs font-bold text-white group-hover:text-sky-300 block">
                  {preset.title}
                </span>
                <span className="text-[10px] text-slate-400 block mt-0.5 line-clamp-2">
                  {preset.description}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Real-time Inferred Outcome Live HUD */}
        <div className="rounded-xl border border-sky-900/60 bg-[#0a101d] p-4 space-y-3 shadow-inner">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="text-xs font-bold text-sky-400 flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4" /> AUTOMATIC PREDICTION & DECISION PREVIEW
            </span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-slate-800 text-white border border-slate-700">
              {liveOutcome.primaryLiability === "WEATHER_FORCE_MAJEURE"
                ? "WEATHER (NO AIRLINE FAULT)"
                : liveOutcome.primaryLiability === "ATC_NAS"
                ? "AIR TRAFFIC CONTROL DELAY"
                : "AIRLINE FAULT (HOTEL & MEALS COVERED)"}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center font-mono">
            <div className="rounded-lg bg-slate-950/80 p-2 border border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase block">Expected Delay</span>
              <span className="text-lg font-black text-amber-400 block mt-0.5">
                +{liveOutcome.totalDelayMinutes} min
              </span>
              <span className="text-[9px] text-slate-400 block">Landing: {liveOutcome.inferredArrivalEta}</span>
            </div>

            <div className="rounded-lg bg-slate-950/80 p-2 border border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase block">Ripple Risk Score</span>
              <span
                className={`text-lg font-black block mt-0.5 ${
                  liveOutcome.isContagionIsolated ? "text-rose-400" : "text-emerald-400"
                }`}
              >
                {liveOutcome.contagionRiskScore.toFixed(2)}
              </span>
              <span className="text-[9px] text-slate-400 block">
                {liveOutcome.isContagionIsolated ? "CONTAINMENT ACTIVE" : "NO SPREAD RISK"}
              </span>
            </div>

            <div className="rounded-lg bg-slate-950/80 p-2 border border-slate-800">
              <span className="text-[9px] text-slate-500 uppercase block">Door-Hold Decision</span>
              <span className="text-xs font-black text-emerald-400 block mt-1.5">
                {liveOutcome.doorHoldFeasibility === "HOLD_APPROVED"
                  ? `HOLD FLIGHT (${liveOutcome.doorHoldMinutes}m)`
                  : "CLOSE DOOR & REBOOK"}
              </span>
              <span className="text-[9px] text-slate-400 block">
                Net Savings: ₹{liveOutcome.netSavingsInr.toLocaleString("en-IN")}
              </span>
            </div>
          </div>

          {/* Breakdown bars */}
          {liveOutcome.delayBreakdown.length > 0 && (
            <div className="space-y-1.5 pt-1 text-[11px]">
              <span className="text-[9px] text-slate-500 uppercase block">Estimated Delay from Each Cause:</span>
              <div className="space-y-1">
                {liveOutcome.delayBreakdown.map((b, idx) => (
                  <div key={idx} className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-400">{b.factor}</span>
                    <span className="font-bold text-white">+{b.minutes} min</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 10 Operational Disruption Factor Selectors */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              🔧 Real-Time Operating Conditions & Delay Factors
            </span>
            <span className="text-[10px] text-slate-500">10 Real-time Factors</span>
          </div>

          <div className="space-y-2.5">
            {/* 1. Severe Weather Conditions */}
            <FactorRow
              icon={<CloudRain className="h-3.5 w-3.5 text-sky-400" />}
              label="Severe Weather Conditions"
              sublabel="Thunderstorms, snowstorms, fog, low visibility"
              value={factors.severeWeather}
              onChange={(val) => updateFactor("severeWeather", val)}
            />

            {/* 2. Late incoming aircraft */}
            <FactorRow
              icon={<Plane className="h-3.5 w-3.5 text-indigo-400" />}
              label="Late Incoming Aircraft"
              sublabel="Inbound plane arriving late from previous flight"
              value={factors.lateIncomingAircraft}
              onChange={(val) => updateFactor("lateIncomingAircraft", val)}
            />

            {/* 3. Air traffic control (ATC) congestion */}
            <FactorRow
              icon={<Radio className="h-3.5 w-3.5 text-amber-400" />}
              label="Air Traffic Control Congestion"
              sublabel="Airport takeoff/landing queues, airspace hold patterns"
              value={factors.atcCongestion}
              onChange={(val) => updateFactor("atcCongestion", val)}
            />

            {/* 4. Crew legal rest limits */}
            <FactorRow
              icon={<Clock className="h-3.5 w-3.5 text-purple-400" />}
              label="Crew Legal Duty Rest Limits"
              sublabel="Pilots or cabin crew reaching maximum work hours"
              value={factors.crewRestLimits}
              onChange={(val) => updateFactor("crewRestLimits", val)}
            />

            {/* 5. Mechanical or maintenance issues */}
            <FactorRow
              icon={<Wrench className="h-3.5 w-3.5 text-rose-400" />}
              label="Mechanical / Maintenance Issues"
              sublabel="Engine check, technical repair, safety clearance"
              value={factors.mechanicalIssues}
              onChange={(val) => updateFactor("mechanicalIssues", val)}
            />

            {/* 6. Airport ground operation delays */}
            <FactorRow
              icon={<Truck className="h-3.5 w-3.5 text-emerald-400" />}
              label="Airport Ground Operation Delays"
              sublabel="Fueling delay, pushback tug shortage, catering delay"
              value={factors.groundOpsDelays}
              onChange={(val) => updateFactor("groundOpsDelays", val)}
            />

            {/* 7. Security checkpoint backups */}
            <FactorRow
              icon={<Shield className="h-3.5 w-3.5 text-sky-400" />}
              label="Security Checkpoint Backups"
              sublabel="Airport security lines congested, passenger queues"
              value={factors.securityBackups}
              onChange={(val) => updateFactor("securityBackups", val)}
            />

            {/* 8. Passenger boarding delays */}
            <FactorRow
              icon={<Users className="h-3.5 w-3.5 text-indigo-400" />}
              label="Passenger Boarding Delays"
              sublabel="Slow jetbridge boarding, full overhead bins"
              value={factors.passengerBoardingDelays}
              onChange={(val) => updateFactor("passengerBoardingDelays", val)}
            />

            {/* 9. Baggage handling issues */}
            <FactorRow
              icon={<Luggage className="h-3.5 w-3.5 text-amber-400" />}
              label="Baggage Handling Issues"
              sublabel="Conveyor belt jam, transfer luggage sorting delay"
              value={factors.baggageHandlingIssues}
              onChange={(val) => updateFactor("baggageHandlingIssues", val)}
            />

            {/* 10. Waiting for connecting passengers */}
            <FactorRow
              icon={<GitPullRequest className="h-3.5 w-3.5 text-teal-400" />}
              label="Waiting for Connecting Passengers"
              sublabel="Holding the plane for passengers from delayed inbound flights"
              value={factors.waitingConnectingPax}
              onChange={(val) => updateFactor("waitingConnectingPax", val)}
            />

            {/* 11. Critical Medical Emergency Escalation Toggle */}
            <div className="rounded-lg border border-slate-800 bg-[#0c1220] p-3 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <HeartPulse className="h-4 w-4 text-rose-500 animate-pulse" />
                <div>
                  <span className="text-xs font-bold text-white block">
                    In-Flight Medical Emergency
                  </span>
                  <span className="text-[10px] text-slate-400">
                    Triggers priority landing, paramedic dispatch & rebooking override
                  </span>
                </div>
              </div>

              <button
                onClick={() => updateFactor("medicalEmergencyFlag", !factors.medicalEmergencyFlag)}
                className={`px-3 py-1 rounded font-bold text-xs transition ${
                  factors.medicalEmergencyFlag
                    ? "bg-rose-600 text-white shadow"
                    : "bg-slate-800 text-slate-400 border border-slate-700"
                }`}
              >
                {factors.medicalEmergencyFlag ? "ACTIVE" : "OFF"}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Sticky Bottom Apply Button */}
      <div className="p-4 border-t border-slate-800 bg-[#090e1a]">
        <button
          onClick={handleApply}
          className="w-full py-3 rounded-lg bg-gradient-to-r from-sky-600 to-emerald-600 hover:from-sky-500 hover:to-emerald-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-sky-950/50 transition cursor-pointer"
        >
          <Zap className="h-4 w-4 fill-current" />
          <span>Apply Scenario & Calculate Decisions Automatically</span>
        </button>
      </div>
    </div>
  );
};

interface FactorRowProps {
  icon: React.ReactNode;
  label: string;
  sublabel: string;
  value: SeverityLevel;
  onChange: (level: SeverityLevel) => void;
}

const FactorRow: React.FC<FactorRowProps> = ({ icon, label, sublabel, value, onChange }) => {
  return (
    <div className="rounded-lg border border-slate-800 bg-[#0c1220] p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {icon}
          <div>
            <span className="text-xs font-bold text-white block">{label}</span>
            <span className="text-[9px] text-slate-500">{sublabel}</span>
          </div>
        </div>

        <span className={`px-2 py-0.5 rounded text-[9px] font-bold border ${SEVERITY_COLORS[value].bg} ${SEVERITY_COLORS[value].text} ${SEVERITY_COLORS[value].border}`}>
          {value}
        </span>
      </div>

      {/* Severity Pills */}
      <div className="grid grid-cols-5 gap-1 pt-1 font-mono text-[10px]">
        {SEVERITY_LEVELS.map((lvl) => (
          <button
            key={lvl}
            onClick={() => onChange(lvl)}
            className={`py-1 rounded border transition font-bold ${
              value === lvl
                ? `${SEVERITY_COLORS[lvl].bg} ${SEVERITY_COLORS[lvl].text} ${SEVERITY_COLORS[lvl].border} ring-1 ring-white/20 shadow`
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200"
            }`}
          >
            {lvl}
          </button>
        ))}
      </div>
    </div>
  );
};
