import React, { useState } from "react";
import { Terminal, Filter, Search, Download } from "lucide-react";
import type { SimulationLogEvent } from "../../types/simulation";

interface ExecutionLogFeedProps {
  logs: SimulationLogEvent[];
}

export const ExecutionLogFeed: React.FC<ExecutionLogFeedProps> = ({ logs }) => {
  const [filterCategory, setFilterCategory] = useState<string>("ALL");
  const [searchTerm, setSearchTerm] = useState<string>("");

  const filteredLogs = logs.filter((log) => {
    const matchesCategory = filterCategory === "ALL" || log.category === filterCategory;
    const matchesSearch =
      searchTerm === "" ||
      log.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getCategoryBadge = (category: SimulationLogEvent["category"]) => {
    switch (category) {
      case "PREVENTOR":
        return <span className="px-1.5 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800 text-[9px] font-bold">RISK DETECTOR</span>;
      case "MANAGER":
        return <span className="px-1.5 py-0.5 rounded bg-sky-950/80 text-sky-300 border border-sky-800 text-[9px] font-bold">DECISION ENGINE</span>;
      case "GATE":
        return <span className="px-1.5 py-0.5 rounded bg-teal-950/80 text-teal-300 border border-teal-800 text-[9px] font-bold">GATE OPS</span>;
      case "RAMP":
        return <span className="px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-800 text-[9px] font-bold">BAGGAGE</span>;
      case "CARE":
        return <span className="px-1.5 py-0.5 rounded bg-purple-950/80 text-purple-300 border border-purple-800 text-[9px] font-bold">HOTEL & MEALS</span>;
      case "MEDICAL":
        return <span className="px-1.5 py-0.5 rounded bg-rose-950 text-rose-200 border border-rose-600 text-[9px] font-black animate-pulse">MEDICAL</span>;
      case "POLICY":
        return <span className="px-1.5 py-0.5 rounded bg-blue-950/80 text-blue-300 border border-blue-800 text-[9px] font-bold">LIABILITY</span>;
      default:
        return <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 text-[9px] font-bold">SYSTEM</span>;
    }
  };

  const getLevelColor = (level: SimulationLogEvent["level"]) => {
    switch (level) {
      case "CRITICAL":
        return "border-l-2 border-rose-500 bg-rose-950/20";
      case "WARN":
        return "border-l-2 border-amber-500 bg-amber-950/20";
      case "SUCCESS":
        return "border-l-2 border-emerald-500 bg-emerald-950/20";
      default:
        return "border-l-2 border-slate-700 bg-slate-950/40";
    }
  };

  const downloadLogs = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement("a");
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `domino-irops-telemetry-${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/80 backdrop-blur-md overflow-hidden shadow-xl">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-slate-800 bg-slate-950/70">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-slate-800 border border-slate-700 text-slate-300">
            <Terminal className="h-3.5 w-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Autonomous Execution Event Bus
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Live Socket.io Telemetry Stream ({filteredLogs.length} Events)
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-1.5 h-3 w-3 text-slate-500" />
            <input
              type="text"
              placeholder="Search telemetry..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="h-6 w-32 rounded bg-slate-950 pl-6 pr-2 text-[10px] font-mono text-slate-200 border border-slate-800 focus:border-sky-500 focus:outline-none"
            />
          </div>

          <button
            onClick={downloadLogs}
            className="p-1 rounded border border-slate-800 bg-slate-950 hover:bg-slate-850 text-slate-400 hover:text-white text-xs transition"
            title="Download JSON Telemetry Log"
          >
            <Download className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1 px-3 py-1.5 border-b border-slate-800/80 bg-slate-950/40 text-[10px] font-mono overflow-x-auto">
        <span className="text-slate-500 flex items-center gap-1 mr-1">
          <Filter className="h-3 w-3" /> Filter:
        </span>
        {[
          { key: "ALL", label: "All Events" },
          { key: "PREVENTOR", label: "Risk Detection" },
          { key: "MANAGER", label: "Decisions" },
          { key: "GATE", label: "Gate Operations" },
          { key: "RAMP", label: "Baggage" },
          { key: "CARE", label: "Hotel & Meals" },
          { key: "MEDICAL", label: "Medical" },
          { key: "POLICY", label: "Liability" },
        ].map((cat) => (
          <button
            key={cat.key}
            onClick={() => setFilterCategory(cat.key)}
            className={`px-2 py-0.5 rounded transition ${
              filterCategory === cat.key
                ? "bg-sky-600 text-white font-bold"
                : "bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Log Feed List */}
      <div className="flex-1 p-3 space-y-2 overflow-y-auto font-mono text-[11px] bg-slate-950/80">
        {filteredLogs.length === 0 ? (
          <div className="h-full flex items-center justify-center text-slate-600 text-xs">
            No events match current filter criteria.
          </div>
        ) : (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className={`p-2.5 rounded border border-slate-800/80 transition-all hover:border-slate-700 ${getLevelColor(
                log.level
              )}`}
            >
              <div className="flex items-center justify-between gap-2 mb-1">
                <div className="flex items-center gap-1.5">
                  {getCategoryBadge(log.category)}
                  <span className="font-bold text-slate-200 text-xs">{log.title}</span>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-slate-400">
                  <span className="text-sky-400 font-bold">{log.timestampSim}</span>
                  <span className="text-slate-600">({log.timestampReal})</span>
                </div>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed pl-1">{log.message}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
