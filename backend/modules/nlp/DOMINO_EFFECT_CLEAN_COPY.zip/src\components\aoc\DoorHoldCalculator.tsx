import React, { useState } from "react";
import { Calculator, CheckCircle2, XCircle, TrendingDown, Sliders } from "lucide-react";
import type { ManagerDoorHoldMetrics } from "../../types/simulation";

interface DoorHoldCalculatorProps {
  manager: ManagerDoorHoldMetrics;
}

export const DoorHoldCalculator: React.FC<DoorHoldCalculatorProps> = ({ manager }) => {
  const [customHoldMin, setCustomHoldMin] = useState<number>(manager.holdMinutes);
  const [paxCount, setPaxCount] = useState<number>(1);
  const [fuelBurnRate, setFuelBurnRate] = useState<number>(1500);
  const [crewRate, setCrewRate] = useState<number>(500);

  const calcFuelCost = fuelBurnRate * customHoldMin;
  const calcCrewCost = crewRate * customHoldMin;
  const calcTotalHold = calcFuelCost + calcCrewCost;

  const calcInterline = 43000 * paxCount;
  const calcHotel = 15000 * paxCount;
  const calcMeals = 4000 * paxCount;
  const calcComp = 8500 * paxCount;
  const calcTotalAbandon = calcInterline + calcHotel + calcMeals + calcComp;

  const netSavings = calcTotalAbandon - calcTotalHold;
  const isHoldRecommended = calcTotalHold < calcTotalAbandon && customHoldMin <= 10;

  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/80 backdrop-blur-md overflow-hidden shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/70">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-indigo-950 border border-indigo-800 text-indigo-400">
            <Calculator className="h-3.5 w-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Door-Hold vs. Passenger Rebooking Cost Optimization
              </h3>
              <span className="px-2 py-0.2 rounded bg-sky-950 border border-sky-600 text-[9px] font-mono font-bold text-sky-300">
                WAIT THRESHOLD: MAX 10 MINS
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              Strict 10-Minute Aviation Door-Hold Limit Enforced · Live Financial Model
            </p>
          </div>
        </div>

        <div
          className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono border font-bold ${
            isHoldRecommended
              ? "bg-emerald-950/80 border-emerald-700 text-emerald-300"
              : "bg-rose-950/80 border-rose-700 text-rose-300"
          }`}
        >
          {isHoldRecommended ? (
            <>
              <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
              <span>HOLD FLIGHT APPROVED ({customHoldMin} mins ≤ 10m threshold)</span>
            </>
          ) : (
            <>
              <XCircle className="h-3.5 w-3.5 text-rose-400" />
              <span>CLOSE DOOR & REBOOK (Threshold Exceeded)</span>
            </>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-4 flex-1 flex flex-col justify-between overflow-y-auto">
        {/* Cost Comparison Cards */}
        <div className="grid grid-cols-2 gap-3">
          {/* C_hold Card */}
          <div
            className={`rounded-lg border p-3 font-mono transition-all ${
              isHoldRecommended
                ? "border-emerald-500/80 bg-emerald-950/30 text-emerald-200 shadow-md ring-1 ring-emerald-500/30"
                : "border-slate-800 bg-slate-950 text-slate-400"
            }`}
          >
            <div className="flex items-center justify-between text-xs pb-1.5 border-b border-slate-800">
              <span className="font-bold text-slate-300">Cost to Hold Aircraft ({customHoldMin} mins)</span>
              <span className="text-lg font-black text-emerald-400">₹{calcTotalHold.toLocaleString('en-IN')}</span>
            </div>
            <div className="mt-2 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Auxiliary Fuel Burn (₹{fuelBurnRate.toLocaleString('en-IN')}/m):</span>
                <span className="text-white">₹{calcFuelCost.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Crew Overtime (₹{crewRate.toLocaleString('en-IN')}/m):</span>
                <span className="text-white">₹{calcCrewCost.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Ripple Delay Risk:</span>
                <span className="text-emerald-400">₹0 (Isolated)</span>
              </div>
            </div>
          </div>

          {/* C_abandon Card */}
          <div
            className={`rounded-lg border p-3 font-mono transition-all ${
              !isHoldRecommended
                ? "border-rose-500/80 bg-rose-950/30 text-rose-200 shadow-md ring-1 ring-rose-500/30"
                : "border-slate-800 bg-slate-950 text-slate-400"
            }`}
          >
            <div className="flex items-center justify-between text-xs pb-1.5 border-b border-slate-800">
              <span className="font-bold text-slate-300">Cost if Passenger Misses Connection ({paxCount} pax)</span>
              <span className="text-lg font-black text-rose-400">₹{calcTotalAbandon.toLocaleString('en-IN')}</span>
            </div>
            <div className="mt-2 space-y-1 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">Partner Airline Ticket (BA212):</span>
                <span className="text-white">₹{calcInterline.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Hilton Airport Hotel:</span>
                <span className="text-white">₹{calcHotel.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Meal Vouchers & Assistance:</span>
                <span className="text-white">₹{calcMeals.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Delay Compensation:</span>
                <span className="text-white">₹{calcComp.toLocaleString('en-IN')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Net Savings Callout */}
        <div className="flex items-center justify-between rounded-lg border border-emerald-800/80 bg-gradient-to-r from-emerald-950/70 to-slate-950 p-3 font-mono">
          <div className="flex items-center gap-2">
            <TrendingDown className="h-5 w-5 text-emerald-400" />
            <div>
              <span className="text-xs font-bold text-slate-200">NET COST SAVED:</span>
              <p className="text-[10px] text-slate-400">
                Holding the door 5 mins avoids ₹{calcTotalAbandon.toLocaleString('en-IN')} in hotel, meal, and rebooking costs
              </p>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xl font-black text-emerald-400 tracking-wider">
              +₹{netSavings.toLocaleString('en-IN')} INR
            </span>
            <span className="block text-[9px] text-emerald-300 font-bold">
              {((netSavings / calcTotalAbandon) * 100).toFixed(0)}% COST REDUCTION
            </span>
          </div>
        </div>

        {/* Interactive Sensitivity Sliders */}
        <div className="rounded-lg border border-slate-800 bg-slate-950/80 p-3 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold">
            <span className="flex items-center gap-1">
              <Sliders className="h-3.5 w-3.5 text-indigo-400" /> ADJUST SCENARIO PARAMETERS
            </span>
            <button
              onClick={() => {
                setCustomHoldMin(5);
                setPaxCount(1);
                setFuelBurnRate(1500);
                setCrewRate(500);
              }}
              className="text-[10px] text-indigo-400 hover:underline"
            >
              Reset Default Values
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Hold Duration (Max 10m):</span>
                <span className="text-white font-bold">{customHoldMin} mins</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={customHoldMin}
                onChange={(e) => setCustomHoldMin(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-[11px] mb-1">
                <span className="text-slate-400">Connecting Passengers at Risk:</span>
                <span className="text-white font-bold">{paxCount} travelers</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={paxCount}
                onChange={(e) => setPaxCount(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
