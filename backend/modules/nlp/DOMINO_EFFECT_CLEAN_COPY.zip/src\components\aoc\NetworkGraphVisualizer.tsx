import React, { useState } from "react";
import type { NetworkGraphNode, NetworkGraphEdge } from "../../types/simulation";
import { ShieldCheck, ShieldAlert, Plane, Users, DoorOpen, User, Sparkles } from "lucide-react";

interface NetworkGraphVisualizerProps {
  nodes: NetworkGraphNode[];
  edges: NetworkGraphEdge[];
  isIsolated: boolean;
  riskScore: number;
}

export const NetworkGraphVisualizer: React.FC<NetworkGraphVisualizerProps> = ({
  nodes,
  edges,
  isIsolated,
  riskScore,
}) => {
  const [selectedNode, setSelectedNode] = useState<NetworkGraphNode | null>(nodes[0] || null);

  const getNodeIcon = (type: NetworkGraphNode["type"]) => {
    switch (type) {
      case "FLIGHT":
        return <Plane className="h-3.5 w-3.5" />;
      case "CREW":
        return <Users className="h-3.5 w-3.5" />;
      case "GATE":
        return <DoorOpen className="h-3.5 w-3.5" />;
      case "PASSENGER":
        return <User className="h-3.5 w-3.5" />;
      default:
        return <Sparkles className="h-3.5 w-3.5" />;
    }
  };

  const getNodeColor = (node: NetworkGraphNode) => {
    if (node.status === "ISOLATED" || (node.riskScore && node.riskScore >= 0.75)) {
      return {
        bg: "fill-rose-950/90",
        stroke: "#f43f5e",
        text: "text-rose-400",
        ring: "stroke-rose-500/40",
      };
    }
    if (node.status === "RECOVERED") {
      return {
        bg: "fill-emerald-950/90",
        stroke: "#10b981",
        text: "text-emerald-400",
        ring: "stroke-emerald-500/40",
      };
    }
    if (node.riskScore && node.riskScore > 0.4) {
      return {
        bg: "fill-amber-950/90",
        stroke: "#f59e0b",
        text: "text-amber-400",
        ring: "stroke-amber-500/40",
      };
    }
    return {
      bg: "fill-slate-900/90",
      stroke: "#38bdf8",
      text: "text-sky-400",
      ring: "stroke-sky-500/30",
    };
  };

  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/80 backdrop-blur-md overflow-hidden shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/70">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-sky-950 border border-sky-800 text-sky-400">
            <Sparkles className="h-3.5 w-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Preventor Engine: Network Hypergraph Topology
            </h3>
            <p className="text-[10px] text-slate-400">
              Real-Time Contagion Vector Graph & Structural Decoupling
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-mono border bg-slate-900 border-slate-800">
            <span className="text-slate-400">NETWORK CONTAGION:</span>
            <span
              className={`font-bold ${
                riskScore >= 0.75
                  ? "text-rose-400"
                  : riskScore > 0.4
                  ? "text-amber-400"
                  : "text-emerald-400"
              }`}
            >
              {(riskScore * 100).toFixed(0)}%
            </span>
          </div>

          <div
            className={`flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono border font-semibold ${
              isIsolated
                ? "bg-rose-950/80 border-rose-700 text-rose-300"
                : "bg-emerald-950/80 border-emerald-700 text-emerald-300"
            }`}
          >
            {isIsolated ? (
              <>
                <ShieldAlert className="h-3 w-3 text-rose-400 animate-pulse" />
                <span>FLIGHT ISOLATED</span>
              </>
            ) : (
              <>
                <ShieldCheck className="h-3 w-3 text-emerald-400" />
                <span>TOPOLOGY CLEAR</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main SVG Graph Canvas */}
      <div className="relative flex-1 bg-slate-950/90 overflow-hidden min-h-[260px]">
        {/* Subtle Grid Pattern */}
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{
            backgroundImage:
              "radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0)",
            backgroundSize: "24px 24px",
          }}
        />

        <svg className="w-full h-full" viewBox="0 0 1000 500" preserveAspectRatio="xMidYMid meet">
          <defs>
            <linearGradient id="edgeGradActive" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.8" />
              <stop offset="100%" stopColor="#818cf8" stopOpacity="0.8" />
            </linearGradient>
            <linearGradient id="edgeGradRisk" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#fb923c" stopOpacity="0.9" />
            </linearGradient>
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="4" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Edges */}
          {edges.map((edge) => {
            const src = nodes.find((n) => n.id === edge.source);
            const tgt = nodes.find((n) => n.id === edge.target);
            if (!src || !tgt) return null;

            const x1 = src.x * 10;
            const y1 = src.y * 5;
            const x2 = tgt.x * 10;
            const y2 = tgt.y * 5;

            return (
              <g key={edge.id} className="transition-all duration-500">
                <line
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke={
                    edge.isIsolated
                      ? "#475569"
                      : edge.isRiskBearing && riskScore >= 0.75
                      ? "#f43f5e"
                      : "#38bdf8"
                  }
                  strokeWidth={edge.isIsolated ? "1.5" : "2.5"}
                  strokeDasharray={edge.isIsolated ? "4 4" : undefined}
                  opacity={edge.isIsolated ? 0.35 : 0.8}
                  filter={edge.isRiskBearing && riskScore >= 0.75 ? "url(#glow)" : undefined}
                />
                <rect
                  x={(x1 + x2) / 2 - 45}
                  y={(y1 + y2) / 2 - 10}
                  width="90"
                  height="18"
                  rx="4"
                  fill="#020617"
                  stroke={edge.isIsolated ? "#334155" : "#1e293b"}
                  strokeWidth="1"
                />
                <text
                  x={(x1 + x2) / 2}
                  y={(y1 + y2) / 2 + 2}
                  textAnchor="middle"
                  fill={edge.isIsolated ? "#94a3b8" : "#cbd5e1"}
                  fontSize="9"
                  fontFamily="monospace"
                  fontWeight="600"
                >
                  {edge.label.length > 14 ? edge.label.substring(0, 14) + ".." : edge.label}
                </text>
              </g>
            );
          })}

          {/* Nodes */}
          {nodes.map((node) => {
            const cx = node.x * 10;
            const cy = node.y * 5;
            const colors = getNodeColor(node);
            const isSelected = selectedNode?.id === node.id;

            return (
              <g
                key={node.id}
                className="cursor-pointer transition-transform duration-300 hover:scale-105"
                onClick={() => setSelectedNode(node)}
              >
                {(node.status === "ISOLATED" || (node.riskScore && node.riskScore >= 0.75)) && (
                  <circle
                    cx={cx}
                    cy={cy}
                    r="28"
                    className="stroke-rose-500/40 animate-ping"
                    fill="none"
                    strokeWidth="1.5"
                  />
                )}

                {isSelected && (
                  <circle
                    cx={cx}
                    cy={cy}
                    r="26"
                    stroke="#38bdf8"
                    strokeWidth="2"
                    strokeDasharray="4 2"
                    fill="none"
                  />
                )}

                <circle
                  cx={cx}
                  cy={cy}
                  r="20"
                  className={colors.bg}
                  stroke={colors.stroke}
                  strokeWidth="2"
                  filter="url(#glow)"
                />

                <text
                  x={cx}
                  y={cy + 34}
                  textAnchor="middle"
                  fill="#f1f5f9"
                  fontSize="11"
                  fontFamily="sans-serif"
                  fontWeight="bold"
                >
                  {node.label.length > 18 ? node.label.substring(0, 18) + ".." : node.label}
                </text>

                {node.riskScore !== undefined && (
                  <text
                    x={cx}
                    y={cy + 46}
                    textAnchor="middle"
                    fill={node.riskScore >= 0.75 ? "#f43f5e" : "#38bdf8"}
                    fontSize="9"
                    fontFamily="monospace"
                  >
                    R: {(node.riskScore * 100).toFixed(0)}%
                  </text>
                )}
              </g>
            );
          })}
        </svg>

        {/* Selected Node Inspector Drawer */}
        {selectedNode && (
          <div className="absolute bottom-2 left-2 right-2 flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/90 px-3 py-2 text-xs backdrop-blur-md">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded bg-slate-800 text-sky-400">
                {getNodeIcon(selectedNode.type)}
              </div>
              <div>
                <span className="font-bold text-white">{selectedNode.label}</span>
                <span className="text-slate-400 ml-2">Type: {selectedNode.type}</span>
                <span className="text-slate-400 ml-2">| {selectedNode.details}</span>
              </div>
            </div>
            <div className="flex items-center gap-2 font-mono">
              <span className="text-slate-400">STATUS:</span>
              <span
                className={`px-2 py-0.5 rounded font-bold ${
                  selectedNode.status === "ISOLATED"
                    ? "bg-rose-950 text-rose-300 border border-rose-800"
                    : selectedNode.status === "RECOVERED"
                    ? "bg-emerald-950 text-emerald-300 border border-emerald-800"
                    : "bg-slate-800 text-slate-300"
                }`}
              >
                {selectedNode.status}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Legend Footer */}
      <div className="flex flex-wrap items-center justify-between px-4 py-1.5 border-t border-slate-800 bg-slate-950/80 text-[10px] font-mono text-slate-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-sky-400" /> Normal Flight
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-rose-500" /> Contagion Isolated
          </span>
          <span className="flex items-center gap-1">
            <span className="h-2 w-2 rounded-full bg-emerald-400" /> Decoupled / Recovered
          </span>
        </div>
        <span className="text-slate-500">Click any node to inspect constraints</span>
      </div>
    </div>
  );
};
