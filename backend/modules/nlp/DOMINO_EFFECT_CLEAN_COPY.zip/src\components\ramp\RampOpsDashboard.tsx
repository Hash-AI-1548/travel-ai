import React from "react";
import { Luggage, Truck, CheckCircle2, Shield, Navigation } from "lucide-react";
import type { BaggageTelemetry, FlightContext } from "../../types/simulation";

interface RampOpsDashboardProps {
  baggage: BaggageTelemetry;
  flight?: FlightContext;
  simMinute: number;
  passengerName?: string;
  paxId?: string;
}

export const RampOpsDashboard: React.FC<RampOpsDashboardProps> = ({
  baggage,
  simMinute,
  passengerName = "Logged In Passenger",
  paxId = "PAX-9921",
}) => {
  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/90 backdrop-blur-md overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950 text-slate-200">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-amber-950 border border-amber-800 text-amber-400">
            <Truck className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider">
              BOS Ramp Operations & Baggage Telemetry Dispatch
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Terminal B Apron Tarmac Tug Fleet #82 · Real-Time BHS Integration
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-2.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
            TARMAC SENSORS: ONLINE
          </span>
        </div>
      </div>

      {/* Main Grid */}
      <div className="p-4 space-y-4 font-mono text-xs flex-1 overflow-y-auto">
        {/* Active Bag Tracking Card */}
        <div className="rounded-xl border border-amber-500/80 bg-gradient-to-r from-amber-950/40 via-slate-950 to-slate-950 p-4 shadow-lg">
          <div className="flex items-center justify-between pb-2 border-b border-amber-900/60">
            <div className="flex items-center gap-2">
              <Luggage className="h-5 w-5 text-amber-400 animate-bounce" />
              <div>
                <span className="text-sm font-black text-white">BAG TAG #{baggage.bagId}</span>
                <span className="block text-[10px] text-slate-400">Passenger: {passengerName} ({paxId})</span>
              </div>
            </div>
            <div className="text-right">
              <span className="px-2.5 py-1 rounded bg-amber-900/80 text-amber-200 border border-amber-700 font-bold text-[10px]">
                {baggage.status}
              </span>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="rounded-lg bg-slate-900/80 p-3 border border-slate-800">
              <span className="text-slate-500 text-[10px]">SOURCE FLIGHT</span>
              <div className="mt-1 text-sm font-bold text-white">AA 142 (JFK)</div>
              <div className="text-[10px] text-slate-400">Stand B10 Arrival</div>
            </div>

            <div className="rounded-lg bg-slate-900/80 p-3 border border-slate-800">
              <span className="text-slate-500 text-[10px]">TARGET FLIGHT</span>
              <div className="mt-1 text-sm font-bold text-sky-400">
                {simMinute >= 20 ? "BA 212 (LHR)" : "AA 142-LHR"}
              </div>
              <div className="text-[10px] text-slate-400">Stand B38 / Gate B12</div>
            </div>

            <div className="rounded-lg bg-slate-900/80 p-3 border border-slate-800">
              <span className="text-slate-500 text-[10px]">TRANSFER SPEED</span>
              <div className="mt-1 text-sm font-bold text-emerald-400">22 km/h (Tug Active)</div>
              <div className="text-[10px] text-slate-400">Autonomous Cart #BOS-82</div>
            </div>
          </div>
        </div>

        {/* Tarmac Ramp Visual Route Simulation */}
        <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-3">
          <div className="flex items-center justify-between text-slate-400 text-[11px] font-bold">
            <span className="flex items-center gap-1.5">
              <Navigation className="h-3.5 w-3.5 text-sky-400" /> TARMAC APRON ROUTING DIRECTORY
            </span>
            <span className="text-sky-400">Last Scanned: {baggage.lastScannedTime}</span>
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between p-2.5 rounded-lg border border-slate-800 bg-slate-900/60">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <div>
                  <span className="font-bold text-white">Stand B10 (Inbound Decoupled)</span>
                  <p className="text-[10px] text-slate-400">Unloaded from Boeing 787 Cargo Hold</p>
                </div>
              </div>
              <span className="text-[10px] text-slate-400">16:18 UTC</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-lg border border-sky-800 bg-sky-950/30">
              <div className="flex items-center gap-2">
                <Truck className="h-4 w-4 text-sky-400 animate-pulse" />
                <div>
                  <span className="font-bold text-sky-300">Transit on Apron Taxiway Bravo</span>
                  <p className="text-[10px] text-slate-400">
                    {simMinute >= 30
                      ? "Direct transfer to Climate Vault Alpha-4"
                      : "Direct transfer to British Airways Stand B38 cart"}
                  </p>
                </div>
              </div>
              <span className="text-[10px] text-sky-400 font-bold">IN TRANSIT</span>
            </div>

            <div className="flex items-center justify-between p-2.5 rounded-lg border border-slate-800 bg-slate-900/60">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-purple-400" />
                <div>
                  <span className="font-bold text-white">
                    {simMinute >= 30 ? "Climate Vault Alpha-4 (Locked)" : "Stand B38 (Loaded on BA212)"}
                  </span>
                  <p className="text-[10px] text-slate-400">
                    {simMinute >= 30
                      ? "Secure warehouse hold overnight for 06:00 UTC flight"
                      : "Target departure 18:00 UTC"}
                  </p>
                </div>
              </div>
              <span className="text-[10px] text-purple-400 font-bold">
                {simMinute >= 30 ? "VAULT SECURED" : "PENDING LOAD"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
