import React from "react";
import { ShieldAlert, HeartPulse, UserCheck, Plane, Ambulance, Radio, CheckCircle } from "lucide-react";
import type { MedicalEmergencyState, PassengerProfile } from "../../types/simulation";

interface MedicalCrisisPanelProps {
  medical: MedicalEmergencyState;
  passenger: PassengerProfile;
  onTriggerEmergency: () => void;
}

export const MedicalCrisisPanel: React.FC<MedicalCrisisPanelProps> = ({
  medical,
  passenger,
  onTriggerEmergency,
}) => {
  return (
    <div
      className={`flex flex-col rounded-xl border backdrop-blur-md overflow-hidden shadow-2xl transition-all duration-500 ${
        medical.isActive
          ? "border-rose-600 bg-slate-900/90 ring-1 ring-rose-500/50 shadow-rose-950/40"
          : "border-slate-800 bg-slate-900/80"
      }`}
    >
      {/* Header */}
      <div
        className={`flex items-center justify-between px-4 py-2.5 border-b ${
          medical.isActive
            ? "border-rose-800/80 bg-rose-950/60 text-rose-200"
            : "border-slate-800 bg-slate-950/70 text-slate-300"
        }`}
      >
        <div className="flex items-center gap-2">
          <div
            className={`p-1 rounded ${
              medical.isActive
                ? "bg-rose-900 text-rose-200 border border-rose-600 animate-pulse"
                : "bg-slate-800 text-slate-400"
            }`}
          >
            <HeartPulse className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider">
              Emergency Escalation: Critical Medical Protocol
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Life-or-Death Urgent Surgical Transfer & Priority Air Ambulance
            </p>
          </div>
        </div>

        <div>
          {medical.isActive ? (
            <span className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-rose-600 text-white font-mono text-[11px] font-black tracking-wider animate-pulse shadow-md">
              <ShieldAlert className="h-3 w-3" />
              <span>ALPHA 1 PRIORITY ACTIVE</span>
            </span>
          ) : (
            <button
              onClick={onTriggerEmergency}
              className="px-3 py-1 rounded bg-rose-950 hover:bg-rose-800 text-rose-300 hover:text-white border border-rose-700 text-xs font-semibold transition"
            >
              Simulate Emergency Trigger
            </button>
          )}
        </div>
      </div>

      {/* Main Grid */}
      <div className="p-4 space-y-3 font-mono text-xs">
        {/* Patient Profile & MEDIF Verification Banner */}
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3">
            <span className="text-slate-500 text-[10px] font-bold">PATIENT IDENTIFIER</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-sm font-bold text-white">{passenger.name}</span>
              <span className="text-[10px] text-sky-400">({passenger.passengerId})</span>
            </div>
            <p className="mt-1 text-[10px] text-slate-400 line-clamp-1">
              Diagnosis: <span className="text-rose-300 font-semibold">{passenger.medicalProfile.conditionName}</span>
            </p>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950 p-3 flex flex-col justify-between">
            <span className="text-slate-500 text-[10px] font-bold">SAFETY COMPLIANCE FRAMEWORK</span>
            <div className="flex items-center justify-between text-[11px] mt-1">
              <span className="flex items-center gap-1 text-emerald-400 font-bold">
                <UserCheck className="h-3.5 w-3.5" /> Doctor MEDIF Form: Verified
              </span>
              <span className="flex items-center gap-1 text-sky-400 font-bold">
                <CheckCircle className="h-3.5 w-3.5" /> Medevac Insurance: Active
              </span>
            </div>
          </div>
        </div>

        {/* 3 Step Protocol Cards */}
        <div className="grid grid-cols-3 gap-3">
          {/* Step 1: Airport Paramedics */}
          <div
            className={`rounded-lg border p-3 transition ${
              medical.isActive
                ? "border-rose-500/80 bg-rose-950/40 text-rose-200"
                : "border-slate-800 bg-slate-950 text-slate-500"
            }`}
          >
            <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-800">
              <span className="font-bold flex items-center gap-1">
                <Ambulance className="h-3.5 w-3.5" /> 1. Airport EMS Squad
              </span>
              <span className="text-[9px] font-bold">{medical.paramedics.status}</span>
            </div>
            <div className="mt-2 space-y-1 text-[10px]">
              <div>Target Gate: <span className="text-white font-bold">{medical.paramedics.targetGate}</span></div>
              <div className="flex items-center justify-between text-rose-300 font-bold">
                <span>Arrival ETA:</span>
                <span>{medical.paramedics.etaSeconds > 0 ? `${medical.paramedics.etaSeconds}s Countdown` : "ON STANDBY AT GATE"}</span>
              </div>
            </div>
          </div>

          {/* Step 2: Interline Settlement Override */}
          <div
            className={`rounded-lg border p-3 transition ${
              medical.isActive
                ? "border-sky-500/80 bg-sky-950/40 text-sky-200"
                : "border-slate-800 bg-slate-950 text-slate-500"
            }`}
          >
            <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-800">
              <span className="font-bold flex items-center gap-1">
                <Radio className="h-3.5 w-3.5" /> 2. Interline Override
              </span>
              <span className="text-[9px] font-bold">SETTLED</span>
            </div>
            <div className="mt-2 space-y-1 text-[10px]">
              <div>Flight: <span className="text-white font-bold">{medical.interlineOverride.targetFlight}</span></div>
              <div className="text-emerald-400 font-semibold">Payment Rules Bypassed</div>
            </div>
          </div>

          {/* Step 3: Priority Medevac Air Ambulance */}
          <div
            className={`rounded-lg border p-3 transition ${
              medical.isActive
                ? "border-purple-500/80 bg-purple-950/40 text-purple-200"
                : "border-slate-800 bg-slate-950 text-slate-500"
            }`}
          >
            <div className="flex items-center justify-between text-[11px] pb-1 border-b border-slate-800">
              <span className="font-bold flex items-center gap-1">
                <Plane className="h-3.5 w-3.5" /> 3. Air Ambulance Medevac
              </span>
              <span className="text-[9px] font-bold">ICU READY</span>
            </div>
            <div className="mt-2 space-y-1 text-[10px]">
              <div>Callsign: <span className="text-white font-bold">{medical.airAmbulanceMedevac.callsign}</span></div>
              <div className="text-purple-300 font-semibold">Priority Medical Airspace (Storm Exempt)</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
