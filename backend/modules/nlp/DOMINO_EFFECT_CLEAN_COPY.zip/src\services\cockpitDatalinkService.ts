export interface CockpitDatalinkMessage {
  id: string;
  timestampUtc: string;
  sender: "AOC_AUTONOMOUS_DISPATCH" | "COCKPIT_CAPTAIN" | "CABIN_PURSER" | "GATE_AGENT_LEAD";
  senderName: string;
  recipient: "COCKPIT_FLIGHT_DECK" | "AOC_DISPATCH" | "CABIN_CREW" | "PASSENGER_MOBILE";
  flightNumber: string;
  tailNumber: string;
  frequencyChannel: string;
  messageType: "DOOR_HOLD_REQUEST" | "PILOT_HOLD_ACK" | "GATE_SWAP_NOTICE" | "CABIN_ESCORT_ALERT" | "PASSENGER_BRIEF";
  acarsPayload: string;
  humanReadableSummary: string;
  status: "TRANSMITTED" | "ACKNOWLEDGED_BY_PILOT" | "DELIVERED_TO_PASSENGER" | "ACTIVE_EXECUTION";
  latencyMs: number;
}

export const INITIAL_DATALINK_LOG: CockpitDatalinkMessage[] = [
  {
    id: "ACARS-TX-8821",
    timestampUtc: "16:08:12 UTC",
    sender: "AOC_AUTONOMOUS_DISPATCH",
    senderName: "DOMINO Autonomous Dispatch Engine",
    recipient: "COCKPIT_FLIGHT_DECK",
    flightNumber: "AA142-LHR",
    tailNumber: "N912AA (B787-9)",
    frequencyChannel: "VHF-DATA 131.550 MHz / CPDLC",
    messageType: "DOOR_HOLD_REQUEST",
    acarsPayload: "/ACARS/UPLINK/AA142LHR/N912AA/REQ_DOOR_HOLD/5MIN/PAX_CT_15/PRIORITY_PAX9921/MCT_BREACH_MITIGATED/APU_BURN_CLEARED/END",
    humanReadableSummary: "Uplink to Flight AA142-LHR Cockpit: Requesting 5-minute gate hold at B12 for 15 tight connecting passengers from feeder AA142.",
    status: "ACKNOWLEDGED_BY_PILOT",
    latencyMs: 124,
  },
  {
    id: "ACARS-RX-8822",
    timestampUtc: "16:08:45 UTC",
    sender: "COCKPIT_CAPTAIN",
    senderName: "Capt. David Thorne (Commander B787-9)",
    recipient: "AOC_DISPATCH",
    flightNumber: "AA142-LHR",
    tailNumber: "N912AA (B787-9)",
    frequencyChannel: "CPDLC-LINK / ARINC 623",
    messageType: "PILOT_HOLD_ACK",
    acarsPayload: "/ACARS/DOWNLINK/AA142LHR/CAPT_THORNE/ACK_HOLD_5MIN_APPROVED/APU_ONLINE/DOORS_ARMED/EST_PUSHBACK_1710UTC/STAND_B12/END",
    humanReadableSummary: "Pilot ACARS Downlink Ack: Capt. Thorne approved 5-minute door hold. APU fuel burn nominal. Boarding door will remain open until 17:10 UTC.",
    status: "ACTIVE_EXECUTION",
    latencyMs: 88,
  },
  {
    id: "ACARS-TX-8823",
    timestampUtc: "16:09:10 UTC",
    sender: "AOC_AUTONOMOUS_DISPATCH",
    senderName: "DOMINO Autonomous Dispatch Engine",
    recipient: "CABIN_CREW",
    flightNumber: "AA142-LHR",
    tailNumber: "N912AA (B787-9)",
    frequencyChannel: "CABIN-INTERCOM DATA LINK",
    messageType: "CABIN_ESCORT_ALERT",
    acarsPayload: "/CABIN/ALERT/PURSER_STERLING/INBOUND_TRANSFER_STAND_B10_TO_B12/25M_WALK/ESCORT_READY/END",
    humanReadableSummary: "Cabin Crew Alert sent to Purser Marcus: Express hallway transfer active. Gate agent positioned at jet bridge B10/B12 for seamless boarding.",
    status: "ACTIVE_EXECUTION",
    latencyMs: 45,
  },
];

export class CockpitDatalinkService {
  private static messages: CockpitDatalinkMessage[] = [...INITIAL_DATALINK_LOG];

  public static getMessages(): CockpitDatalinkMessage[] {
    return [...this.messages];
  }

  public static addMessage(msg: Omit<CockpitDatalinkMessage, "id" | "timestampUtc" | "latencyMs">): CockpitDatalinkMessage {
    const newMsg: CockpitDatalinkMessage = {
      ...msg,
      id: `ACARS-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      timestampUtc: new Date().toISOString().substring(11, 19) + " UTC",
      latencyMs: Math.floor(Math.random() * 80) + 40,
    };
    this.messages = [newMsg, ...this.messages.slice(0, 30)];
    return newMsg;
  }

  public static generateCockpitHoldTransmission(
    flightNumber: string,
    holdMinutes: number,
    passengerName: string,
    pilotName: string = "Capt. David Thorne"
  ): { uplink: CockpitDatalinkMessage; downlink: CockpitDatalinkMessage } {
    const uplink = this.addMessage({
      sender: "AOC_AUTONOMOUS_DISPATCH",
      senderName: "DOMINO Autonomous Dispatcher",
      recipient: "COCKPIT_FLIGHT_DECK",
      flightNumber,
      tailNumber: "N912AA (Boeing 787-9)",
      frequencyChannel: "CPDLC / VHF 131.550 MHz",
      messageType: "DOOR_HOLD_REQUEST",
      acarsPayload: `/ACARS/UPLINK/${flightNumber.replace("-", "")}/REQ_HOLD_${holdMinutes}M/PAX_${passengerName.replace(/\s+/g, "").toUpperCase()}/ECONOMICS_NET_SAVINGS_POSITIVE/END`,
      humanReadableSummary: `Automated Datalink Uplink: Requesting ${holdMinutes}-minute gate hold at B12 for connecting traveler ${passengerName}.`,
      status: "ACKNOWLEDGED_BY_PILOT",
    });

    const downlink = this.addMessage({
      sender: "COCKPIT_CAPTAIN",
      senderName: pilotName,
      recipient: "AOC_DISPATCH",
      flightNumber,
      tailNumber: "N912AA (Boeing 787-9)",
      frequencyChannel: "CPDLC-LINK / ARINC 623",
      messageType: "PILOT_HOLD_ACK",
      acarsPayload: `/ACARS/DOWNLINK/${flightNumber.replace("-", "")}/CAPT_ACK/HOLD_${holdMinutes}M_CONFIRMED/BOARDING_READY_GATE_B12/END`,
      humanReadableSummary: `Pilot Cockpit Response: ${pilotName} acknowledged. Holding boarding doors at Gate B12 for ${holdMinutes} minutes.`,
      status: "ACTIVE_EXECUTION",
    });

    return { uplink, downlink };
  }
}
