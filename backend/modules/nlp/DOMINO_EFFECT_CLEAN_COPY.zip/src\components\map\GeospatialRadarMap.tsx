import React, { useEffect, useRef, useState, useCallback } from "react";
import L from "leaflet";
import {
  Plane,
  Radio,
  MapPin,
  Search,
  Crosshair,
  Globe,
  ArrowRight,
  CloudRain,
  Thermometer,
  Activity,
  RefreshCw,
  Wifi,
  ZoomIn,
  ZoomOut,
  Maximize2,
} from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import {
  fetchAirLabsLiveFlights,
  fetchLiveWeatherByAirportCode,
  fetchLiveWeatherAtCoords,
  type AirLabsLiveFlight,
  type LiveAviationWeather,
} from "../../services/airlabsService";

interface GeospatialRadarMapProps {
  state: SimulationState;
  height?: string;
}

export type MapMode = "CORRIDOR" | "APRON";

export interface GeoLocationNode {
  code: string;
  name: string;
  city: string;
  country: string;
  coords: [number, number]; // [lat, lng]
}

export const GLOBAL_AIRPORTS: GeoLocationNode[] = [
  { code: "JFK", name: "John F. Kennedy Int'l", city: "New York", country: "USA", coords: [40.6413, -73.7781] },
  { code: "BOS", name: "Boston Logan Int'l", city: "Boston", country: "USA", coords: [42.3656, -71.0096] },
  { code: "LHR", name: "London Heathrow", city: "London", country: "UK", coords: [51.4700, -0.4543] },
  { code: "DEL", name: "Indira Gandhi Int'l", city: "New Delhi", country: "India", coords: [28.5562, 77.1000] },
  { code: "BOM", name: "Chhatrapati Shivaji Maharaj", city: "Mumbai", country: "India", coords: [19.0896, 72.8656] },
  { code: "BLR", name: "Kempegowda Int'l", city: "Bengaluru", country: "India", coords: [13.1986, 77.7066] },
  { code: "MAA", name: "Chennai Int'l", city: "Chennai", country: "India", coords: [12.9941, 80.1709] },
  { code: "HYD", name: "Rajiv Gandhi Int'l", city: "Hyderabad", country: "India", coords: [17.2403, 78.4294] },
  { code: "DXB", name: "Dubai Int'l", city: "Dubai", country: "UAE", coords: [25.2532, 55.3657] },
  { code: "SIN", name: "Singapore Changi", city: "Singapore", country: "Singapore", coords: [1.3644, 103.9915] },
  { code: "CDG", name: "Charles de Gaulle", city: "Paris", country: "France", coords: [49.0097, 2.5479] },
  { code: "FRA", name: "Frankfurt Airport", city: "Frankfurt", country: "Germany", coords: [50.0379, 8.5622] },
  { code: "HND", name: "Tokyo Haneda", city: "Tokyo", country: "Japan", coords: [35.5494, 139.7798] },
  { code: "SYD", name: "Kingsford Smith", city: "Sydney", country: "Australia", coords: [-33.9399, 151.1753] },
  { code: "LAX", name: "Los Angeles Int'l", city: "Los Angeles", country: "USA", coords: [33.9416, -118.4085] },
  { code: "ORD", name: "Chicago O'Hare", city: "Chicago", country: "USA", coords: [41.9742, -87.9073] },
  { code: "SFO", name: "San Francisco Int'l", city: "San Francisco", country: "USA", coords: [37.6213, -122.3790] },
];

export const ROUTE_PRESETS = [
  { label: "JFK ➔ BOS ➔ LHR (US-Europe Atlantic)", origin: "JFK", hub: "BOS", dest: "LHR" },
  { label: "DEL ➔ BOM ➔ LHR (India-UK Corridor)", origin: "DEL", hub: "BOM", dest: "LHR" },
  { label: "BLR ➔ DXB ➔ FRA (India-Gulf-Europe)", origin: "BLR", hub: "DXB", dest: "FRA" },
  { label: "SFO ➔ ORD ➔ CDG (US Transcon-Paris)", origin: "SFO", hub: "ORD", dest: "CDG" },
  { label: "HND ➔ SIN ➔ SYD (Asia-Pacific Backbone)", origin: "HND", hub: "SIN", dest: "SYD" },
];

export const GeospatialRadarMap: React.FC<GeospatialRadarMapProps> = ({ state, height = "100%" }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker | L.Polyline | L.CircleMarker }>({});
  const liveFlightMarkersRef = useRef<L.Marker[]>([]);
  const lastRouteKeyRef = useRef<string>("");

  const [mapMode, setMapMode] = useState<MapMode>("CORRIDOR");
  const [originNode, setOriginNode] = useState<GeoLocationNode>(GLOBAL_AIRPORTS[0]); // JFK
  const [hubNode, setHubNode] = useState<GeoLocationNode>(GLOBAL_AIRPORTS[1]); // BOS
  const [destNode, setDestNode] = useState<GeoLocationNode>(GLOBAL_AIRPORTS[2]); // LHR

  const [searchQuery, setSearchQuery] = useState<string>("");
  const [searchResults, setSearchResults] = useState<GeoLocationNode[]>([]);
  const [hoveredCoords, setHoveredCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [clickedCoords, setClickedCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [isSelectorOpen, setIsSelectorOpen] = useState<boolean>(false);

  // AirLabs & OpenWeather Live State
  const [liveFlights, setLiveFlights] = useState<AirLabsLiveFlight[]>([]);
  const [selectedLiveFlight, setSelectedLiveFlight] = useState<AirLabsLiveFlight | null>(null);
  const [weatherOrigin, setWeatherOrigin] = useState<LiveAviationWeather | null>(null);
  const [weatherHub, setWeatherHub] = useState<LiveAviationWeather | null>(null);
  const [weatherDest, setWeatherDest] = useState<LiveAviationWeather | null>(null);
  const [weatherPlane, setWeatherPlane] = useState<LiveAviationWeather | null>(null);
  const [isLiveAirLabsEnabled, setIsLiveAirLabsEnabled] = useState<boolean>(true);
  const [isLoadingLive, setIsLoadingLive] = useState<boolean>(false);
  const [lastLiveSync, setLastLiveSync] = useState<string>("");

  const { flight, simMinute, medical } = state;

  // Flight progress: Leg 1 (Origin→Hub) for T+0 to T+30, Leg 2 (Hub→Dest) for T+40 to T+60
  let currentLat: number = flight.telemetry?.lat ?? originNode.coords[0];
  let currentLng: number = flight.telemetry?.lng ?? originNode.coords[1];
  if (originNode.code !== "JFK" || hubNode.code !== "BOS" || destNode.code !== "LHR") {
    if (simMinute < 30) {
      const progressFraction = Math.min(1, Math.max(0, simMinute / 30));
      currentLat = originNode.coords[0] + (hubNode.coords[0] - originNode.coords[0]) * progressFraction;
      currentLng = originNode.coords[1] + (hubNode.coords[1] - originNode.coords[1]) * progressFraction;
    } else if (simMinute < 40) {
      // On ground at hub
      currentLat = hubNode.coords[0];
      currentLng = hubNode.coords[1];
    } else {
      // Leg 2: Hub → Dest
      const leg2Progress = Math.min(1, Math.max(0, (simMinute - 40) / 20));
      currentLat = hubNode.coords[0] + (destNode.coords[0] - hubNode.coords[0]) * leg2Progress;
      currentLng = hubNode.coords[1] + (destNode.coords[1] - hubNode.coords[1]) * leg2Progress;
    }
  }

  // Apron coordinates (relative to Hub)
  const gateB10Coords: [number, number] = [hubNode.coords[0] + 0.0006, hubNode.coords[1] - 0.0089];
  const gateB12Coords: [number, number] = [hubNode.coords[0] + 0.0008, hubNode.coords[1] - 0.0086];
  const gateB30Coords: [number, number] = [hubNode.coords[0] - 0.0021, hubNode.coords[1] - 0.0139];
  const gateB38Coords: [number, number] = [hubNode.coords[0] + 0.0029, hubNode.coords[1] - 0.0054];

  // Tug progress
  const tugProgress = simMinute >= 20 ? Math.min(1, (simMinute - 20) / 10) : 0;
  const tugLat = gateB10Coords[0] + (gateB38Coords[0] - gateB10Coords[0]) * tugProgress;
  const tugLng = gateB10Coords[1] + (gateB38Coords[1] - gateB10Coords[1]) * tugProgress;

  const currentCoordsRef = useRef<[number, number]>([currentLat, currentLng]);
  useEffect(() => {
    currentCoordsRef.current = [currentLat, currentLng];
  }, [currentLat, currentLng]);

  // Fetch Live AirLabs & OpenWeather Data with non-blocking async execution
  const refreshLiveIntelligence = useCallback(async () => {
    setIsLoadingLive(true);
    try {
      const [cLat, cLng] = currentCoordsRef.current;
      // 1. AirLabs live flights
      const flightsData = await fetchAirLabsLiveFlights({ limit: 40 });
      setLiveFlights(flightsData);

      // 2. OpenWeather for Origin, Hub, Dest & Current Aircraft Lat/Lng
      const [wOrig, wHub, wDest, wPlane] = await Promise.all([
        fetchLiveWeatherByAirportCode(originNode.code),
        fetchLiveWeatherByAirportCode(hubNode.code),
        fetchLiveWeatherByAirportCode(destNode.code),
        fetchLiveWeatherAtCoords(cLat, cLng, "AA142 En-Route Waypoint")
      ]);

      setWeatherOrigin(wOrig);
      setWeatherHub(wHub);
      setWeatherDest(wDest);
      setWeatherPlane(wPlane);
      setLastLiveSync(new Date().toLocaleTimeString());
    } catch (e) {
      console.warn("Live radar sync notice:", e);
    } finally {
      setIsLoadingLive(false);
    }
  }, [originNode.code, hubNode.code, destNode.code]);

  useEffect(() => {
    refreshLiveIntelligence();
    const interval = setInterval(refreshLiveIntelligence, 30000); // 30s auto-refresh
    return () => clearInterval(interval);
  }, [refreshLiveIntelligence]);

  // Handle Search
  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }
    const q = query.toLowerCase();

    // Check if query is raw lat,lng
    const rawCoordsMatch = query.match(/^([-+]?\d{1,2}(?:\.\d+)?),\s*([-+]?\d{1,3}(?:\.\d+)?)$/);
    if (rawCoordsMatch) {
      const lat = parseFloat(rawCoordsMatch[1]);
      const lng = parseFloat(rawCoordsMatch[2]);
      setSearchResults([
        {
          code: "CUSTOM",
          name: `Custom Coordinates (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
          city: "User Defined",
          country: "Custom Location",
          coords: [lat, lng],
        },
      ]);
      return;
    }

    const filtered = GLOBAL_AIRPORTS.filter(
      (a) =>
        a.code.toLowerCase().includes(q) ||
        a.city.toLowerCase().includes(q) ||
        a.name.toLowerCase().includes(q) ||
        a.country.toLowerCase().includes(q)
    );
    setSearchResults(filtered);
  };

  // Select Location as Origin, Hub, or Dest
  const handleAssignLocation = (node: GeoLocationNode, role: "ORIGIN" | "HUB" | "DEST") => {
    if (role === "ORIGIN") setOriginNode(node);
    if (role === "HUB") setHubNode(node);
    if (role === "DEST") setDestNode(node);
    setSearchResults([]);
    setSearchQuery("");
    setClickedCoords(null);
  };

  // Preset Selector
  const applyPreset = (preset: (typeof ROUTE_PRESETS)[0]) => {
    const o = GLOBAL_AIRPORTS.find((a) => a.code === preset.origin) || GLOBAL_AIRPORTS[0];
    const h = GLOBAL_AIRPORTS.find((a) => a.code === preset.hub) || GLOBAL_AIRPORTS[1];
    const d = GLOBAL_AIRPORTS.find((a) => a.code === preset.dest) || GLOBAL_AIRPORTS[2];
    setOriginNode(o);
    setHubNode(h);
    setDestNode(d);
    setIsSelectorOpen(false);
  };

  // Map Pan & Zoom Navigation Handlers
  const handleZoomIn = () => {
    if (mapInstanceRef.current) mapInstanceRef.current.zoomIn();
  };

  const handleZoomOut = () => {
    if (mapInstanceRef.current) mapInstanceRef.current.zoomOut();
  };

  const handleCenterPlane = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([currentLat, currentLng], 7, { duration: 1 });
    }
  };

  const handleCenterHub = () => {
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo(hubNode.coords, 14, { duration: 1 });
    }
  };

  const handleFitRoute = () => {
    if (mapInstanceRef.current) {
      if (mapMode === "CORRIDOR") {
        const bounds = L.latLngBounds([originNode.coords, hubNode.coords, destNode.coords]);
        mapInstanceRef.current.fitBounds(bounds, { padding: [80, 80], maxZoom: 8, duration: 1 });
      } else {
        const bounds = L.latLngBounds([gateB10Coords, gateB12Coords, gateB30Coords, gateB38Coords]);
        mapInstanceRef.current.fitBounds(bounds, { padding: [100, 100], maxZoom: 18, duration: 1 });
      }
    }
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: [30.0, 0.0],
        zoom: 3,
        zoomControl: false,
        attributionControl: false,
        scrollWheelZoom: true,
        dragging: true,
        touchZoom: true,
        doubleClickZoom: true,
      });

      L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        maxZoom: 19,
        subdomains: "abcd",
      }).addTo(map);

      map.on("mousemove", (e: L.LeafletMouseEvent) => {
        setHoveredCoords({ lat: e.latlng.lat, lng: e.latlng.lng });
      });

      map.on("click", (e: L.LeafletMouseEvent) => {
        setClickedCoords({ lat: e.latlng.lat, lng: e.latlng.lng });
      });

      mapInstanceRef.current = map;
    }

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // 1. Static Markers & Base Layers Setup (Only runs when route or mode changes)
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const routeKey = `${mapMode}-${originNode.code}-${hubNode.code}-${destNode.code}`;
    const shouldRefit = lastRouteKeyRef.current !== routeKey;
    lastRouteKeyRef.current = routeKey;

    // Clear old layers
    Object.values(markersRef.current).forEach((layer) => {
      map.removeLayer(layer);
    });
    markersRef.current = {};

    // Clear live flight markers
    liveFlightMarkersRef.current.forEach((m) => map.removeLayer(m));
    liveFlightMarkersRef.current = [];

    if (mapMode === "CORRIDOR") {
      if (shouldRefit) {
        const bounds = L.latLngBounds([originNode.coords, hubNode.coords, destNode.coords]);
        map.fitBounds(bounds, { padding: [80, 80], maxZoom: 8, duration: 1 });
      }

      // Flight Corridor Line: Origin -> Hub -> Dest
      const fullCorridor = L.polyline([originNode.coords, hubNode.coords, destNode.coords], {
        color: "#38bdf8",
        weight: 2.5,
        opacity: 0.8,
        dashArray: "6, 6",
      }).addTo(map);
      markersRef.current["corridor"] = fullCorridor;

      // Trailing In-Flight Active Line (Origin -> Current Plane Position)
      const [cLat, cLng] = currentCoordsRef.current;
      const trailLine = L.polyline([originNode.coords, [cLat, cLng]], {
        color: "#0284c7",
        weight: 3.5,
        opacity: 1,
      }).addTo(map);
      markersRef.current["trail"] = trailLine;

      // 1. Origin Marker
      const originMarker = L.circleMarker(originNode.coords, {
        radius: 8,
        fillColor: "#0ea5e9",
        color: "#ffffff",
        weight: 2,
        fillOpacity: 1,
      }).addTo(map);
      originMarker.bindPopup(`
        <div class="font-mono text-xs p-1">
          <b class="text-sky-400">ORIGIN: ${originNode.code}</b><br/>
          <span>${originNode.name} (${originNode.city})</span><br/>
          ${weatherOrigin ? `<span class="text-amber-300 font-bold">Live Weather: ${weatherOrigin.tempC}°C · ${weatherOrigin.description} (Wind ${weatherOrigin.windSpeedKts} kts ${weatherOrigin.windDirectionText})</span><br/>` : ""}
          <span class="text-[10px] text-slate-400">GPS: ${originNode.coords[0].toFixed(4)}, ${originNode.coords[1].toFixed(4)}</span>
        </div>
      `);
      markersRef.current["origin"] = originMarker;

      // 2. Hub Marker (Connecting Node with Isolation Ring)
      const hubMarker = L.circleMarker(hubNode.coords, {
        radius: 10,
        fillColor: "#10b981",
        color: "#ffffff",
        weight: 2.5,
        fillOpacity: 1,
      }).addTo(map);
      hubMarker.bindPopup(`
        <div class="font-mono text-xs p-1">
          <b class="text-emerald-400">CONNECTING HUB: ${hubNode.code}</b><br/>
          <span>${hubNode.name} (${hubNode.city})</span><br/>
          ${weatherHub ? `<span class="text-emerald-300 font-bold">Live METAR: ${weatherHub.tempC}°C · ${weatherHub.description} (Wind ${weatherHub.windSpeedKts} kts ${weatherHub.windDirectionText})</span><br/>` : ""}
          <span class="text-sky-300 font-bold">Dual-Engine Decoupling Active</span>
        </div>
      `);
      markersRef.current["hub"] = hubMarker;

      // 3. Destination Marker
      const destMarker = L.circleMarker(destNode.coords, {
        radius: 8,
        fillColor: "#818cf8",
        color: "#ffffff",
        weight: 2,
        fillOpacity: 1,
      }).addTo(map);
      destMarker.bindPopup(`
        <div class="font-mono text-xs p-1">
          <b class="text-indigo-400">FINAL DESTINATION: ${destNode.code}</b><br/>
          <span>${destNode.name} (${destNode.city})</span><br/>
          ${weatherDest ? `<span class="text-indigo-300 font-bold">Live Weather: ${weatherDest.tempC}°C · ${weatherDest.description}</span><br/>` : ""}
          <span class="text-emerald-300">Connection Protected</span>
        </div>
      `);
      markersRef.current["dest"] = destMarker;

      // 4. Primary Active Flight Marker (AA142)
      const planeHtml = `
        <div class="relative flex items-center justify-center">
          <div class="absolute -inset-2 rounded-full bg-sky-500/40 animate-ping"></div>
          <div class="h-7 w-7 rounded-full bg-sky-600 border-2 border-white flex items-center justify-center text-white shadow-[0_0_16px_rgba(56,189,248,0.9)]">
            <svg class="h-4 w-4 fill-current transform rotate-45" viewBox="0 0 24 24">
              <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
            </svg>
          </div>
        </div>
      `;

      const planeIcon = L.divIcon({
        className: "custom-plane-icon",
        html: planeHtml,
        iconSize: [28, 28],
        iconAnchor: [14, 14],
      });

      const planeMarker = L.marker([cLat, cLng], { icon: planeIcon }).addTo(map);
      planeMarker.bindPopup(`
        <div class="font-mono text-xs p-1">
          <b class="text-sky-400">FLIGHT AA142 (ACTIVE MISSION)</b><br/>
          <span>${originNode.code} ➔ ${hubNode.code}</span><br/>
          <span>GPS: ${cLat.toFixed(4)}°, ${cLng.toFixed(4)}°</span><br/>
          <span>Airspeed: 480 kts · Altitude: 24,000 ft</span><br/>
          <span class="text-amber-400 font-bold">Delay: +${flight.delayMinutes} min</span><br/>
          ${weatherPlane ? `<span class="text-sky-300 font-semibold">En-Route MET: ${weatherPlane.tempC}°C, Wind ${weatherPlane.windSpeedKts} kts ${weatherPlane.windDirectionText}</span>` : ""}
        </div>
      `);
      markersRef.current["plane"] = planeMarker;

      // 5. AirLabs Live Airborne Flights Overlay
      if (isLiveAirLabsEnabled && liveFlights.length > 0) {
        liveFlights.forEach((f) => {
          if (!f.lat || !f.lng || (Math.abs(f.lat - cLat) < 0.1 && Math.abs(f.lng - cLng) < 0.1)) return;

          const flightIconHtml = `
            <div class="group relative flex items-center justify-center cursor-pointer">
              <div class="h-5 w-5 rounded-full bg-slate-900/90 border border-sky-400/80 flex items-center justify-center text-sky-300 shadow-md transform hover:scale-125 transition-transform" style="transform: rotate(${f.dir || 0}deg)">
                <svg class="h-3 w-3 fill-current" viewBox="0 0 24 24">
                  <path d="M21 16v-2l-8-5V3.5c0-.83-.67-1.5-1.5-1.5S10 2.67 10 3.5V9l-8 5v2l8-2.5V19l-2 1.5V22l3.5-1 3.5 1v-1.5L13 19v-5.5l8 2.5z"/>
                </svg>
              </div>
              <span class="absolute -bottom-3 left-1/2 -translate-x-1/2 px-1 py-0.2 rounded bg-slate-950/90 border border-slate-700 text-[8px] font-mono text-sky-200 font-bold whitespace-nowrap opacity-80 group-hover:opacity-100">
                ${f.flight_iata}
              </span>
            </div>
          `;

          const flightIcon = L.divIcon({
            className: "airlabs-live-flight-icon",
            html: flightIconHtml,
            iconSize: [24, 24],
            iconAnchor: [12, 12],
          });

          const liveMarker = L.marker([f.lat, f.lng], { icon: flightIcon }).addTo(map);
          liveMarker.bindPopup(`
            <div class="font-mono text-xs p-1">
              <div class="flex items-center justify-between gap-2 border-b border-slate-700 pb-1">
                <b class="text-sky-400">FLIGHT ${f.flight_iata}</b>
                <span class="px-1.5 py-0.5 rounded bg-sky-950 text-[9px] text-sky-300 border border-sky-800">AIRLABS LIVE</span>
              </div>
              <div class="mt-1 space-y-0.5 text-[11px]">
                <div><b>Route:</b> ${f.dep_iata || "?"} ➔ ${f.arr_iata || "?"}</div>
                <div><b>Airline:</b> ${f.airline_iata || f.airline_icao || "Airline"} · ${f.aircraft_icao || "Aircraft"}</div>
                <div><b>Altitude:</b> ${f.alt_ft ? f.alt_ft.toLocaleString() + " ft" : f.alt + " m"} (${f.speed_kts ? f.speed_kts + " kts" : f.speed + " km/h"})</div>
                <div><b>Heading:</b> ${f.dir}° · <b>Status:</b> ${f.status} ${f.delayed ? `(+${f.delayed}m delay)` : ""}</div>
                <div class="text-[10px] text-slate-400 pt-1">GPS: ${f.lat.toFixed(4)}°, ${f.lng.toFixed(4)}°</div>
              </div>
            </div>
          `);

          liveMarker.on("click", () => setSelectedLiveFlight(f));
          liveFlightMarkersRef.current.push(liveMarker);
        });
      }

      // 6. Medical Medevac Learjet Route
      if (medical.isActive) {
        const medevacLine = L.polyline([hubNode.coords, [hubNode.coords[0] - 1.5, hubNode.coords[1] - 2.0]], {
          color: "#f43f5e",
          weight: 3,
          dashArray: "4, 4",
        }).addTo(map);
        markersRef.current["medevac"] = medevacLine;
      }
    } else {
      // APRON / TERMINAL RADAR VIEW
      if (shouldRefit) {
        const bounds = L.latLngBounds([gateB10Coords, gateB12Coords, gateB30Coords, gateB38Coords]);
        map.fitBounds(bounds, { padding: [100, 100], maxZoom: 18, duration: 1 });
      }

      const b10 = L.circleMarker(gateB10Coords, {
        radius: 9,
        fillColor: "#10b981",
        color: "#ffffff",
        weight: 2,
        fillOpacity: 1,
      }).addTo(map);
      b10.bindPopup(`<b>Gate B10 (${hubNode.code})</b><br/>Inbound Arrival Stand`);
      markersRef.current["b10"] = b10;

      const b12 = L.circleMarker(gateB12Coords, {
        radius: 9,
        fillColor: "#10b981",
        color: "#ffffff",
        weight: 2,
        fillOpacity: 1,
      }).addTo(map);
      b12.bindPopup(`<b>Gate B12 (${hubNode.code})</b><br/>Departure Swap (Adjacent Hallway)`);
      markersRef.current["b12"] = b12;

      const b30 = L.circleMarker(gateB30Coords, {
        radius: 6,
        fillColor: "#475569",
        color: "#94a3b8",
        weight: 1.5,
        fillOpacity: 0.8,
      }).addTo(map);
      b30.bindPopup(`<b>Gate B30 (${hubNode.code})</b><br/>Old Stand (De-allocated to prevent 18m sprint)`);
      markersRef.current["b30"] = b30;

      const b38 = L.circleMarker(gateB38Coords, {
        radius: 8,
        fillColor: "#a855f7",
        color: "#ffffff",
        weight: 2,
        fillOpacity: 1,
      }).addTo(map);
      b38.bindPopup(`<b>Gate B38 (Interline Stand)</b><br/>Competitor Flight BA212`);
      markersRef.current["b38"] = b38;

      // Hallway Line
      const walkLine = L.polyline([gateB10Coords, gateB12Coords], {
        color: "#10b981",
        weight: 4,
        opacity: 1,
      }).addTo(map);
      markersRef.current["walk"] = walkLine;

      // Old sprint line
      const sprintLine = L.polyline([gateB10Coords, gateB30Coords], {
        color: "#f43f5e",
        weight: 2,
        dashArray: "5, 5",
        opacity: 0.5,
      }).addTo(map);
      markersRef.current["sprint"] = sprintLine;

      // Tug Track Line
      const tugLine = L.polyline([gateB10Coords, gateB38Coords], {
        color: "#f59e0b",
        weight: 2.5,
        dashArray: "4, 6",
        opacity: 0.8,
      }).addTo(map);
      markersRef.current["tugLine"] = tugLine;

      // Live Tug Marker
      const tugIconHtml = `
        <div class="h-5 w-5 rounded bg-amber-500 border border-white flex items-center justify-center text-slate-950 font-black text-[8px] shadow-lg animate-pulse">
          #04
        </div>
      `;
      const tugIcon = L.divIcon({
        className: "custom-tug-icon",
        html: tugIconHtml,
        iconSize: [20, 20],
        iconAnchor: [10, 10],
      });
      const tugMarker = L.marker([tugLat, tugLng], { icon: tugIcon }).addTo(map);
      tugMarker.bindPopup(`<b>Tarmac Baggage Tug #04</b><br/>Dispatching Bag #4552`);
      markersRef.current["tug"] = tugMarker;
    }
  }, [
    mapMode,
    originNode,
    hubNode,
    destNode,
    isLiveAirLabsEnabled,
    liveFlights,
    medical.isActive,
    weatherOrigin,
    weatherHub,
    weatherDest,
    weatherPlane,
  ]);

  // 2. High-Performance Dynamic Coordinate Updates (0ms execution, zero DOM layer reconstruction)
  useEffect(() => {
    if (mapMode === "CORRIDOR") {
      const plane = markersRef.current["plane"] as L.Marker | undefined;
      if (plane) {
        plane.setLatLng([currentLat, currentLng]);
      }
      const trail = markersRef.current["trail"] as L.Polyline | undefined;
      if (trail) {
        trail.setLatLngs([originNode.coords, [currentLat, currentLng]]);
      }
    } else {
      const tug = markersRef.current["tug"] as L.Marker | undefined;
      if (tug) {
        tug.setLatLng([tugLat, tugLng]);
      }
    }
  }, [currentLat, currentLng, tugLat, tugLng, mapMode, originNode.coords]);

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-slate-800 bg-[#060913] shadow-2xl flex flex-col" style={{ height }}>
      {/* Top Location Bar & Mode Switcher */}
      <div className="z-10 flex flex-wrap items-center justify-between gap-3 px-4 py-2 bg-[#090d16]/95 backdrop-blur-md border-b border-slate-800 text-xs font-mono">
        {/* Left: Active Route Node Badges */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 text-sky-400 font-bold border-r border-slate-800 pr-3">
            <Radio className="h-3.5 w-3.5 animate-pulse" />
            <span>GLOBAL RADAR</span>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-300 border border-sky-700 font-bold flex items-center gap-1">
              ORIGIN: {originNode.code}
              {weatherOrigin && <span className="text-[10px] text-amber-300">({weatherOrigin.tempC}°C)</span>}
            </span>
            <ArrowRight className="h-3 w-3 text-slate-500" />
            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 font-bold flex items-center gap-1">
              HUB: {hubNode.code}
              {weatherHub && <span className="text-[10px] text-emerald-300">({weatherHub.tempC}°C)</span>}
            </span>
            <ArrowRight className="h-3 w-3 text-slate-500" />
            <span className="px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-700 font-bold flex items-center gap-1">
              DEST: {destNode.code}
              {weatherDest && <span className="text-[10px] text-indigo-300">({weatherDest.tempC}°C)</span>}
            </span>
          </div>
        </div>

        {/* Right: AirLabs Live Toggle, Presets, Search & Mode */}
        <div className="flex items-center gap-2">
          {/* AirLabs Live Traffic Toggle */}
          <button
            onClick={() => setIsLiveAirLabsEnabled(!isLiveAirLabsEnabled)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded border text-[11px] font-bold transition ${
              isLiveAirLabsEnabled
                ? "bg-sky-950 text-sky-300 border-sky-500 shadow-[0_0_10px_rgba(56,189,248,0.2)]"
                : "bg-slate-900 text-slate-500 border-slate-800"
            }`}
            title="Toggle real-time global flights stream from AirLabs API"
          >
            <Wifi className={`h-3 w-3 ${isLiveAirLabsEnabled ? "text-emerald-400" : "text-slate-600"}`} />
            <span>AirLabs Feed ({liveFlights.length} Flights)</span>
          </button>

          {/* Refresh Button */}
          <button
            onClick={refreshLiveIntelligence}
            disabled={isLoadingLive}
            className="p-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-700 transition"
            title="Refresh AirLabs flights & OpenWeather METAR"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${isLoadingLive ? "animate-spin text-sky-400" : ""}`} />
          </button>

          {/* Preset Routes Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsSelectorOpen(!isSelectorOpen)}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-700 transition"
            >
              <Globe className="h-3 w-3 text-sky-400" />
              <span>Route Presets</span>
            </button>

            {isSelectorOpen && (
              <div className="absolute right-0 top-8 z-50 w-72 rounded-lg bg-[#0d131f] border border-slate-700 shadow-2xl p-2 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase block px-2 pb-1 border-b border-slate-800">
                  Global Flight Corridor Presets
                </span>
                {ROUTE_PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => applyPreset(p)}
                    className="w-full text-left px-2.5 py-1.5 rounded hover:bg-slate-800 text-[11px] text-slate-200 flex flex-col transition"
                  >
                    <span className="font-bold text-white">{p.label}</span>
                    <span className="text-[9px] text-slate-400">
                      {p.origin} ➔ {p.hub} ➔ {p.dest}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Search Coordinates / Airports Bar */}
          <div className="relative">
            <Search className="absolute left-2.5 top-1.5 h-3 w-3 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="Search airport code, city, or lat, lng..."
              className="h-7 w-48 rounded bg-[#0f172a] pl-7 pr-2 text-xs font-sans text-slate-200 border border-slate-800 focus:border-sky-500 focus:outline-none placeholder:text-slate-500"
            />

            {searchResults.length > 0 && (
              <div className="absolute left-0 top-8 z-50 w-80 max-h-64 overflow-y-auto rounded-lg bg-[#0d131f] border border-slate-700 shadow-2xl p-2 space-y-2">
                <span className="text-[10px] text-slate-400 font-bold uppercase block px-1">
                  Assign Location to Active Corridor
                </span>
                {searchResults.map((node, i) => (
                  <div key={i} className="rounded bg-slate-900 p-2 border border-slate-800 space-y-1.5">
                    <div className="flex justify-between">
                      <span className="font-bold text-white text-xs">{node.code} — {node.city}</span>
                      <span className="text-[9px] text-slate-400">{node.country}</span>
                    </div>
                    <p className="text-[10px] text-slate-400">{node.name}</p>
                    <div className="flex gap-1 pt-1">
                      <button
                        onClick={() => handleAssignLocation(node, "ORIGIN")}
                        className="flex-1 px-1.5 py-0.5 rounded bg-sky-900 hover:bg-sky-800 text-sky-100 text-[10px] font-bold"
                      >
                        Set Origin
                      </button>
                      <button
                        onClick={() => handleAssignLocation(node, "HUB")}
                        className="flex-1 px-1.5 py-0.5 rounded bg-emerald-900 hover:bg-emerald-800 text-emerald-100 text-[10px] font-bold"
                      >
                        Set Hub
                      </button>
                      <button
                        onClick={() => handleAssignLocation(node, "DEST")}
                        className="flex-1 px-1.5 py-0.5 rounded bg-indigo-900 hover:bg-indigo-800 text-indigo-100 text-[10px] font-bold"
                      >
                        Set Dest
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Mode Switcher */}
          <div className="flex items-center gap-1 pl-2 border-l border-slate-800">
            <button
              onClick={() => setMapMode("CORRIDOR")}
              className={`flex items-center gap-1 px-2 py-1 rounded transition ${
                mapMode === "CORRIDOR"
                  ? "bg-sky-600 text-white font-bold shadow"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              }`}
            >
              <Plane className="h-3 w-3" />
              <span>Air Corridor</span>
            </button>
            <button
              onClick={() => setMapMode("APRON")}
              className={`flex items-center gap-1 px-2 py-1 rounded transition ${
                mapMode === "APRON"
                  ? "bg-emerald-600 text-white font-bold shadow"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              }`}
            >
              <MapPin className="h-3 w-3" />
              <span>Apron Radar</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Map Canvas */}
      <div className="relative flex-1 w-full">
        <div ref={mapContainerRef} className="h-full w-full z-0" />

        {/* Floating Map Navigation & Zoom Controls */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-1.5 p-1.5 rounded-xl bg-slate-950/90 border border-slate-700/80 backdrop-blur-md shadow-2xl font-mono text-xs pointer-events-auto">
          <button
            onClick={handleZoomIn}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold transition flex items-center justify-center cursor-pointer"
            title="Zoom In (+)"
          >
            <ZoomIn className="h-4 w-4" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold transition flex items-center justify-center cursor-pointer"
            title="Zoom Out (-)"
          >
            <ZoomOut className="h-4 w-4" />
          </button>
          <div className="h-[1px] bg-slate-800 my-0.5" />
          <button
            onClick={handleCenterPlane}
            className="px-2 py-1.5 rounded-lg bg-sky-950 border border-sky-600 hover:bg-sky-900 text-sky-300 font-bold transition flex items-center gap-1.5 cursor-pointer text-[10px]"
            title="Center on Flight AA142"
          >
            <Plane className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Plane</span>
          </button>
          <button
            onClick={handleCenterHub}
            className="px-2 py-1.5 rounded-lg bg-emerald-950 border border-emerald-600 hover:bg-emerald-900 text-emerald-300 font-bold transition flex items-center gap-1.5 cursor-pointer text-[10px]"
            title="Center on Hub (BOS)"
          >
            <MapPin className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Hub</span>
          </button>
          <button
            onClick={handleFitRoute}
            className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition flex items-center gap-1.5 cursor-pointer text-[10px]"
            title="Fit Entire Flight Corridor"
          >
            <Maximize2 className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Fit</span>
          </button>
        </div>

        {/* Click-on-Map Inspector Card (Allows setting ANY custom point on Earth) */}
        {clickedCoords && (
          <div className="absolute top-4 right-28 z-20 w-72 rounded-lg bg-[#090d16]/95 backdrop-blur-md border border-sky-500/80 p-3 shadow-2xl font-mono text-xs space-y-2">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1">
              <span className="text-sky-300 font-bold flex items-center gap-1">
                <Crosshair className="h-3.5 w-3.5 text-sky-400" /> MAP COORDINATE INSPECTOR
              </span>
              <button
                onClick={() => setClickedCoords(null)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="text-[11px] text-slate-300 space-y-0.5">
              <div>Latitude: <span className="text-white font-bold">{clickedCoords.lat.toFixed(6)}°</span></div>
              <div>Longitude: <span className="text-white font-bold">{clickedCoords.lng.toFixed(6)}°</span></div>
            </div>

            <span className="text-[10px] text-slate-400 block">Assign this location to route:</span>
            <div className="flex gap-1.5 pt-1">
              <button
                onClick={() =>
                  handleAssignLocation(
                    {
                      code: "CUSTOM",
                      name: "Custom Map Point",
                      city: `${clickedCoords.lat.toFixed(2)}, ${clickedCoords.lng.toFixed(2)}`,
                      country: "Waypoint",
                      coords: [clickedCoords.lat, clickedCoords.lng],
                    },
                    "ORIGIN"
                  )
                }
                className="flex-1 py-1 rounded bg-sky-900 hover:bg-sky-800 text-white font-bold text-[10px] text-center"
              >
                Set Origin
              </button>
              <button
                onClick={() =>
                  handleAssignLocation(
                    {
                      code: "CUSTOM",
                      name: "Custom Connecting Hub",
                      city: `${clickedCoords.lat.toFixed(2)}, ${clickedCoords.lng.toFixed(2)}`,
                      country: "Waypoint",
                      coords: [clickedCoords.lat, clickedCoords.lng],
                    },
                    "HUB"
                  )
                }
                className="flex-1 py-1 rounded bg-emerald-900 hover:bg-emerald-800 text-white font-bold text-[10px] text-center"
              >
                Set Hub
              </button>
              <button
                onClick={() =>
                  handleAssignLocation(
                    {
                      code: "CUSTOM",
                      name: "Custom Destination",
                      city: `${clickedCoords.lat.toFixed(2)}, ${clickedCoords.lng.toFixed(2)}`,
                      country: "Waypoint",
                      coords: [clickedCoords.lat, clickedCoords.lng],
                    },
                    "DEST"
                  )
                }
                className="flex-1 py-1 rounded bg-indigo-900 hover:bg-indigo-800 text-white font-bold text-[10px] text-center"
              >
                Set Dest
              </button>
            </div>
          </div>
        )}

        {/* Selected Live Flight Inspector Popup */}
        {selectedLiveFlight && (
          <div className="absolute top-4 left-4 z-20 w-80 rounded-lg bg-[#090d16]/95 backdrop-blur-md border border-sky-500 p-3 shadow-2xl font-mono text-xs space-y-2 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-800 pb-1">
              <span className="text-sky-300 font-bold flex items-center gap-1.5">
                <Plane className="h-3.5 w-3.5 text-sky-400" /> AIRLABS FLIGHT {selectedLiveFlight.flight_iata}
              </span>
              <button
                onClick={() => setSelectedLiveFlight(null)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>

            <div className="text-[11px] text-slate-300 space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Route:</span>
                <span className="text-white font-bold">{selectedLiveFlight.dep_iata || "?"} ➔ {selectedLiveFlight.arr_iata || "?"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Airline / Aircraft:</span>
                <span className="text-white">{selectedLiveFlight.airline_iata || "AA"} · {selectedLiveFlight.aircraft_icao || "B789"}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Altitude / Speed:</span>
                <span className="text-sky-300">{selectedLiveFlight.alt_ft ? `${selectedLiveFlight.alt_ft.toLocaleString()} ft` : `${selectedLiveFlight.alt} m`} · {selectedLiveFlight.speed_kts ? `${selectedLiveFlight.speed_kts} kts` : `${selectedLiveFlight.speed} km/h`}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Heading / Status:</span>
                <span className="text-emerald-400 font-semibold">{selectedLiveFlight.dir}° · {selectedLiveFlight.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">GPS Coordinates:</span>
                <span className="text-slate-400">{selectedLiveFlight.lat.toFixed(4)}°, {selectedLiveFlight.lng.toFixed(4)}°</span>
              </div>
            </div>
          </div>
        )}

        {/* Bottom-Left Live Telemetry & OpenWeather METAR HUD */}
        <div className="absolute bottom-3 left-3 z-10 bg-[#090d16]/90 backdrop-blur-md p-3 rounded-lg border border-slate-800 shadow-xl font-mono text-xs space-y-2 max-w-xs pointer-events-auto">
          <div className="flex items-center justify-between border-b border-slate-800 pb-1 text-[11px]">
            <span className="text-slate-400 font-bold flex items-center gap-1">
              <Activity className="h-3.5 w-3.5 text-emerald-400" /> LIVE RADAR FEED
            </span>
            <span className="text-emerald-400 font-bold text-[10px]">AIRLABS & OPENWEATHER</span>
          </div>

          <div className="space-y-1 text-[10px] text-slate-300">
            <div className="flex justify-between">
              <span className="text-slate-500">Active Flight:</span>
              <span className="text-white font-bold">AA142 ({originNode.code} ➔ {hubNode.code})</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Live Aircraft GPS:</span>
              <span className="text-sky-300">{currentLat.toFixed(4)}° N, {currentLng.toFixed(4)}° E</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Airspeed / Altitude:</span>
              <span className="text-white">480 kts · 24,000 ft</span>
            </div>
            {weatherPlane && (
              <div className="flex justify-between text-amber-300 pt-0.5 border-t border-slate-800/60">
                <span className="text-slate-500 flex items-center gap-1"><CloudRain className="h-3 w-3" /> En-Route MET:</span>
                <span>{weatherPlane.tempC}°C · {weatherPlane.condition} ({weatherPlane.windSpeedKts} kts {weatherPlane.windDirectionText})</span>
              </div>
            )}
            {hoveredCoords && (
              <div className="flex justify-between pt-0.5 border-t border-slate-800/60 text-slate-400">
                <span>Cursor Radar:</span>
                <span className="text-slate-200">{hoveredCoords.lat.toFixed(3)}°, {hoveredCoords.lng.toFixed(3)}°</span>
              </div>
            )}
          </div>
        </div>

        {/* Bottom-Right OpenWeather Airport Meteorological Board */}
        <div className="absolute bottom-3 right-3 z-10 bg-[#090d16]/90 backdrop-blur-md p-3 rounded-lg border border-slate-800 shadow-xl font-mono text-xs space-y-1.5 max-w-xs pointer-events-auto hidden sm:block">
          <div className="flex items-center justify-between border-b border-slate-800 pb-1 text-[11px]">
            <span className="text-amber-400 font-bold flex items-center gap-1">
              <Thermometer className="h-3.5 w-3.5 text-amber-400" /> OPENWEATHER METAR
            </span>
            <span className="text-[9px] text-slate-500">{lastLiveSync || "LIVE"}</span>
          </div>

          <div className="space-y-1.5 text-[10px]">
            {weatherHub && (
              <div className="flex items-center justify-between bg-slate-900/60 p-1.5 rounded border border-slate-800">
                <div>
                  <div className="text-white font-bold">{hubNode.code} ({hubNode.city})</div>
                  <div className="text-slate-400">{weatherHub.description}</div>
                </div>
                <div className="text-right">
                  <div className="text-emerald-400 font-bold">{weatherHub.tempC}°C / {weatherHub.tempF}°F</div>
                  <div className="text-[9px] text-slate-500">{weatherHub.windSpeedKts} kts {weatherHub.windDirectionText}</div>
                </div>
              </div>
            )}

            {weatherDest && (
              <div className="flex items-center justify-between bg-slate-900/60 p-1.5 rounded border border-slate-800">
                <div>
                  <div className="text-white font-bold">{destNode.code} ({destNode.city})</div>
                  <div className="text-slate-400">{weatherDest.description}</div>
                </div>
                <div className="text-right">
                  <div className="text-indigo-400 font-bold">{weatherDest.tempC}°C / {weatherDest.tempF}°F</div>
                  <div className="text-[9px] text-slate-500">{weatherDest.windSpeedKts} kts {weatherDest.windDirectionText}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
