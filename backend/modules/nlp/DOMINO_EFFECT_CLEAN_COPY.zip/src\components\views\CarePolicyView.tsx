import React, { useState } from "react";
import { Hotel, Utensils, Shield, QrCode, Key, Zap, CheckCircle2, Plane, Clock, MapPin, Scale, AlertTriangle, Cpu, CloudRain } from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import type { PolicyMode } from "../../types/simulation";
import { DisruptionInferenceEngine } from "../../engine/disruptionInferenceEngine";
import { sounds } from "../../utils/audio";

interface CarePolicyViewProps {
  state: SimulationState;
  onPolicyChange?: (policy: PolicyMode) => void;
}

export const CarePolicyView: React.FC<CarePolicyViewProps> = ({ state }) => {
  const [nfcTapped, setNfcTapped] = useState<boolean>(false);

  const passengerName = state.passenger?.name || "Traveler";
  const disruptionOutcome = DisruptionInferenceEngine.inferOutcome(state.disruptionFactors);
  const isHoldApproved = state.manager.decision === "APPROVED" || disruptionOutcome.doorHoldFeasibility === "HOLD_APPROVED" || disruptionOutcome.doorHoldFeasibility === "NOT_NEEDED";
  const recovery = !isHoldApproved ? state.passenger?.recoveryAllocation : undefined;
  const isAutoRebooked = Boolean(recovery && recovery.status === "REBOOKED");

  const assignedFlight = recovery?.assignedFlight || "AA102";
  const assignedAirline = recovery?.assignedAirline || "American Airlines";
  const assignedGate = recovery?.gate || "Gate B12 (Terminal B)";
  const assignedSeat = recovery?.seat || "14B";
  const departureTime = recovery?.departureTime || "06:00 UTC (Next Morning)";

  const isMedical = Boolean(state.medical?.isActive || state.passenger?.medicalProfile?.isEmergency || state.passenger?.isEmergencyTraveler);
  const isWeather = !isMedical && (state.policy === "WEATHER" || disruptionOutcome.primaryLiability === "WEATHER_FORCE_MAJEURE");
  const isCarrierFault = !isMedical && !isWeather;

  const handleTapKey = () => {
    setNfcTapped(true);
    sounds.playSuccessChime();
    setTimeout(() => setNfcTapped(false), 3000);
  };

  return (
    <div className="flex flex-col gap-4 h-full overflow-y-auto p-4 bg-[#070b12] text-slate-200 font-sans">
      {/* TOP HEADER: AUTOMATED LIABILITY & EXPENSE COVERAGE ENGINE */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-1 border-b border-slate-800/80">
        <div>
          <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">
            AUTOMATED LIABILITY & EXPENSE COVERAGE ENGINE (AI-INFERRED)
          </span>
          <h1 className="text-sm font-bold text-white uppercase tracking-wide font-mono flex items-center gap-2">
            <span>
              {isHoldApproved
                ? "Direct Connection & Rapid Gate Boarding Suite"
                : isAutoRebooked
                ? "Autonomous Passenger Care & Express Transit Suite"
                : "Automated Hotel, Meals & Overnight Care Suite"}
            </span>
            <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-sky-950 text-sky-300 border border-sky-800">
              ZERO MANUAL INPUT REQUIRED
            </span>
          </h1>
        </div>

        {/* AUTOMATED LEGAL POLICY DETERMINATION BADGE */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0d131f] border border-slate-800 shadow-inner text-xs font-mono">
            <Scale className="h-4 w-4 text-emerald-400 shrink-0" />
            <div>
              <span className="text-[10px] text-slate-400 block uppercase">Mandated Regulatory Framework:</span>
              <span className="font-bold text-white">
                {isHoldApproved
                  ? "Direct Ramp & Gate Transfer (Doors Held at Gate B12 — No Hotel Needed)"
                  : isMedical
                  ? "ICAO Annex 9 / Life Safety Priority Protocol (Immediate Escort)"
                  : isWeather
                  ? "DOT 14 CFR Part 259 / Force Majeure Duty of Care"
                  : "IATA MITA Rule 240 / EU261 Controllable Mandate (100% Airline Paid)"}
              </span>
            </div>
          </div>
          <span className="px-3 py-1.5 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-700 font-mono text-[10px] font-bold shadow animate-pulse">
            ✓ {isHoldApproved ? "DIRECT CONNECTION ACTIVE" : "POLICY AUTO-APPLIED"}
          </span>
        </div>
      </div>

      {/* HOLD APPROVED BANNER: ZERO HOTEL & ZERO REBOOK */}
      {isHoldApproved && (
        <div className="w-full p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/90 via-[#0a1814] to-slate-900 border border-emerald-500/80 text-emerald-200 text-xs font-mono flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-2xl">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-900 border border-emerald-500 flex items-center justify-center text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.4)]">
              <CheckCircle2 className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-white uppercase tracking-wider text-xs">
                  🛡️ DIRECT CONNECTION SECURED — FLIGHT WAITING AT GATE B12
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-900 text-emerald-300 border border-emerald-600 text-[9px] font-bold">
                  NO HOTEL OR REBOOKING REQUIRED
                </span>
              </div>
              <span className="text-[11px] text-slate-300 font-sans block mt-0.5">
                Flight <strong>AA142-LHR</strong> is holding boarding doors at adjacent <strong>Gate B12</strong> for <strong>{passengerName}</strong>. Direct transfer across 25 meters eliminates all hotel accommodation and competitor rebooking liabilities.
              </span>
            </div>
          </div>
          <span className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] uppercase shrink-0 shadow-md flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5" /> BOARDING ON SCHEDULE
          </span>
        </div>
      )}

      {/* DETECTED DISRUPTION ROOT CAUSE & CARE DETERMINATION CARD */}
      <div className="rounded-xl border border-slate-800 bg-gradient-to-br from-[#0c121e] to-[#070b12] p-4 shadow-xl space-y-3">
        <div className="flex flex-wrap items-start justify-between gap-3 pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className={`h-8 w-8 rounded-lg flex items-center justify-center text-white shadow-md ${
              isHoldApproved ? "bg-emerald-600" : isMedical ? "bg-rose-600" : isWeather ? "bg-amber-600" : "bg-sky-600"
            }`}>
              {isHoldApproved ? <CheckCircle2 className="h-4 w-4" /> : isMedical ? <AlertTriangle className="h-4 w-4" /> : isWeather ? <CloudRain className="h-4 w-4" /> : <Cpu className="h-4 w-4" />}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xs font-bold text-white font-mono uppercase tracking-wide">
                  {isHoldApproved
                    ? "Autonomous Network Decision: Door-Hold Activated / Direct Gate Transfer"
                    : isMedical
                    ? "Root Cause: Critical Life Safety Emergency Escalation"
                    : isWeather
                    ? "Root Cause: Severe Meteorological Event & Convective Storm"
                    : "Root Cause: Airline Operational Fault (Mechanical Defect / Turnaround Delay)"}
                </h2>
                <span className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
                  isHoldApproved
                    ? "bg-emerald-950 text-emerald-300 border border-emerald-700"
                    : isCarrierFault
                    ? "bg-sky-950 text-sky-300 border border-sky-700"
                    : isWeather
                    ? "bg-amber-950 text-amber-300 border border-amber-700"
                    : "bg-rose-950 text-rose-300 border border-rose-700"
                }`}>
                  {isHoldApproved ? "ZERO HOTEL LIABILITY" : isCarrierFault ? "100% AIRLINE LIABILITY" : isWeather ? "DUTY OF CARE ASSISTANCE" : "LIFE SAFETY OVERRIDE"}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-sans mt-0.5">
                {isHoldApproved
                  ? `Door-hold is active for ${passengerName}. Direct connection to Flight AA142-LHR at Gate B12 preserves on-time London arrival and avoids ₹70,500 in passenger abandonment and overnight accommodation expenses.`
                  : isMedical
                  ? `In-flight medical alert active for ${passengerName}. Standard overnight accommodation is automatically bypassed in favor of zero-wait competitor departure on ${assignedAirline} ${assignedFlight} with dedicated paramedic escort.`
                  : isWeather
                  ? `Severe weather corridor delay (+${disruptionOutcome.totalDelayMinutes || 35} min) detected. Airline provides automated duty of care, lounge access/partner accommodations, and priority rebooking.`
                  : `Inbound flight AA142 experienced a controllable operational delay (+${disruptionOutcome.totalDelayMinutes || 35} min). Airline provides 100% complimentary accommodation on American Airlines fleet (AA102) with Hilton Logan room.`}
              </p>
            </div>
          </div>
        </div>

        {/* Contributing Factors Telemetry Chips */}
        {disruptionOutcome.delayBreakdown.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap pt-1 text-[10px] font-mono text-slate-400">
            <span className="text-slate-500 font-bold uppercase">Detected Disruption Telemetry:</span>
            {disruptionOutcome.delayBreakdown.map((item, i) => (
              <span key={i} className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                {item.factor}: <strong className="text-sky-300">+{item.minutes}m</strong>
              </span>
            ))}
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
              Total Corridor Impact: <strong className="text-emerald-400">+{disruptionOutcome.totalDelayMinutes}m Delay</strong>
            </span>
          </div>
        )}
      </div>

      {/* AUTONOMOUS AUTO-BOOKING CARE CALLOUT BANNER (ONLY ON REBOOKED) */}
      {!isHoldApproved && isAutoRebooked && (
        <div className="w-full p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/90 via-[#0a1814] to-slate-900 border border-emerald-500/80 text-emerald-200 text-xs font-mono flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-2xl">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-900 border border-emerald-500 flex items-center justify-center text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.4)]">
              <Zap className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-white uppercase tracking-wider text-xs">
                  ⚡ RESCHEDULED ON {assignedAirline.toUpperCase()}
                </span>
              </div>
              <span className="text-[11px] text-slate-300 font-sans block mt-0.5">
                Passenger <strong>{passengerName}</strong> is confirmed on <strong>{assignedAirline} {assignedFlight}</strong> (Departs {departureTime} at {assignedGate}). Hilton Boston Logan accommodation allocated.
              </span>
            </div>
          </div>
          <span className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] uppercase shrink-0 shadow-md flex items-center gap-1.5">
            <CheckCircle2 className="h-3.5 w-3.5" /> TICKETED ON {assignedFlight}
          </span>
        </div>
      )}

      <div className="grid grid-cols-12 gap-4 flex-1">
        {/* CARD 1: DIRECT GATE BOARDING / HOTEL / LOUNGE */}
        <div className="col-span-12 lg:col-span-6 rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                {isHoldApproved ? <Plane className="h-4 w-4 text-emerald-400" /> : <Hotel className="h-4 w-4 text-slate-400" />}
                <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  {isHoldApproved
                    ? "Direct Jetbridge Boarding Corridor (Gate B12)"
                    : isAutoRebooked
                    ? "Executive Departure Lounge & Transit Suite"
                    : "Automated Hotel Reservation"}
                </h2>
              </div>
              <span className={`px-2 py-0.5 rounded font-mono text-[9px] font-bold shadow-sm ${
                isHoldApproved
                  ? "bg-emerald-950 border border-emerald-600 text-emerald-300"
                  : "bg-emerald-500 text-slate-950"
              }`}>
                {isHoldApproved ? "DIRECT TRANSFER ACTIVE (NO HOTEL)" : isAutoRebooked ? "AUTONOMOUS PASS ISSUED" : "RESERVED & CONFIRMED"}
              </span>
            </div>

            <div className="mt-3">
              <h3 className="text-sm font-bold text-white">
                {isHoldApproved
                  ? "Flight AA142-LHR — London Heathrow (Adjacent Gate B12)"
                  : isAutoRebooked
                  ? `${assignedAirline} Galleries Club Lounge — Terminal B (Near ${assignedGate.split(" ")[0]})`
                  : "Hilton Airport Terminal — Room 304"}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {isHoldApproved
                  ? "Transfer: 25m stroll from Gate B10 | Boarding Doors Held for Traveler"
                  : isAutoRebooked
                  ? `Access: Immediate Priority Access | Boarding Call: ${departureTime}`
                  : "Check-in: 8:30 PM | Checkout: 6:00 AM"}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3 mt-4">
            <div className="col-span-1 rounded-lg border border-slate-800 bg-[#090d16] p-3 flex flex-col items-center justify-center text-center">
              <QrCode className="h-7 w-7 text-slate-400" />
              <span className="text-[9px] font-mono text-slate-500 mt-1.5 block">
                {isHoldApproved ? "Gate B12 QR" : isAutoRebooked ? "Lounge Pass QR" : "Shuttle Pass QR"}
              </span>
            </div>

            <button
              onClick={handleTapKey}
              className={`col-span-3 rounded-lg border p-3 flex flex-col items-center justify-center text-center transition cursor-pointer ${
                nfcTapped
                  ? "border-emerald-500 bg-emerald-950/40 text-emerald-300"
                  : "border-slate-800 bg-[#090d16] hover:bg-slate-800/60 text-slate-300"
              }`}
            >
              <Key className="h-5 w-5 text-slate-300" />
              <span className="text-xs font-bold text-white mt-1 block">
                {nfcTapped
                  ? isHoldApproved
                    ? "✓ Gate B12 Jetbridge Boarding Pass Validated"
                    : isAutoRebooked
                    ? "✓ Lounge Gate Unlocked"
                    : "✓ Room 304 Door Unlocked"
                  : isHoldApproved
                  ? "Fast-Track Jetbridge Boarding Clearance"
                  : isAutoRebooked
                  ? "Digital Departure Lounge & Express Pass"
                  : "Digital Hotel Room Key"}
              </span>
              <span className="text-[10px] text-slate-500 block">
                {isHoldApproved
                  ? "Tap phone at Gate B12 scanner to board Flight AA142-LHR directly"
                  : isAutoRebooked
                  ? "Tap phone against reader at Executive Lounge & Priority Gate Lane"
                  : "Tap phone against reader at hotel room door"}
              </span>
            </button>
          </div>
        </div>

        {/* CARD 2: DIGITAL MEAL VOUCHERS / TARMAC BAGGAGE */}
        <div className="col-span-12 lg:col-span-6 rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Utensils className="h-4 w-4 text-slate-400" />
                <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  {isHoldApproved
                    ? "In-Flight Dining & Fast Tarmac Transfer"
                    : isAutoRebooked
                    ? "Digital Gourmet & Lounge Dining Allowance"
                    : "Digital Meal Vouchers"}
                </h2>
              </div>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-white font-mono text-[9px] font-bold border border-slate-700">
                {isHoldApproved ? "ONBOARD MEALS INCLUDED" : "DELIVERED"}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 mt-3">
              <div className="rounded-lg border border-slate-800 bg-[#090d16] p-3 font-mono">
                <span className="text-[10px] text-slate-500 uppercase block">
                  {isAutoRebooked ? "LOUNGE GOURMET PASS" : "DINNER VOUCHER"}
                </span>
                <span className="text-xl font-black text-white block mt-0.5">
                  {isAutoRebooked ? "₹2,500" : "₹2,000"}
                </span>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  {isAutoRebooked ? "Executive Lounge Buffet & Dining" : "Airport Terminal Food Court"}
                </span>
              </div>

              <div className="rounded-lg border border-slate-800 bg-[#090d16] p-3 font-mono">
                <span className="text-[10px] text-slate-500 uppercase block">
                  {isAutoRebooked ? "TERMINAL SNACK VOUCHER" : "BREAKFAST VOUCHER"}
                </span>
                <span className="text-xl font-black text-white block mt-0.5">
                  {isAutoRebooked ? "₹1,500" : "₹2,000"}
                </span>
                <span className="text-[10px] text-slate-400 mt-1 block">Airport Terminal Concourse</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
            <span>Total ₹4,000 meal allowance provided</span>
            <span className="text-slate-500">Sent via SMS & In-App Wallet</span>
          </div>
        </div>

        {/* CARD 3: REBOOKED FLIGHT / PRIORITY STANDBY */}
        <div className="col-span-12 lg:col-span-6 rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Plane className="h-4 w-4 text-sky-400" />
                <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  {isAutoRebooked ? "Autonomous Confirmed Flight Rebooking" : "Next Morning Priority Standby (#1 in Line)"}
                </h2>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-mono text-[9px] font-bold">
                {isAutoRebooked ? `✓ CONFIRMED ON ${assignedFlight}` : "QUEUED — POSITION #1"}
              </span>
            </div>

            <div className="flex items-start gap-4 mt-3">
              <div className="h-20 w-20 rounded-lg bg-[#090d16] border border-slate-800 flex flex-col items-center justify-center text-center p-2">
                <span className="text-xl font-black text-emerald-400 font-mono">
                  {isAutoRebooked ? assignedSeat : "#1"}
                </span>
                <span className="text-[8px] font-mono text-slate-400 uppercase tracking-widest mt-0.5">
                  {isAutoRebooked ? "SEAT NUMBER" : "STANDBY POSITION"}
                </span>
              </div>

              <div className="space-y-1 text-xs">
                <h3 className="font-bold text-white text-sm">
                  {isAutoRebooked
                    ? `Flight: ${assignedFlight} — ${assignedAirline}`
                    : "Flight: AA142 — First departure 6:15 AM"}
                </h3>
                <p className="text-[11px] text-slate-300 font-mono flex items-center gap-1.5">
                  <MapPin className="h-3 w-3 text-emerald-400" />
                  <span>Departure Gate: <strong>{assignedGate}</strong> — Priority Boarding Lane</span>
                </p>
                <p className="text-[11px] text-slate-400 font-mono flex items-center gap-1.5">
                  <Clock className="h-3 w-3 text-sky-400" />
                  <span>Departure Time: <strong>{departureTime}</strong></span>
                </p>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
            {isAutoRebooked
              ? `Automated rebooking system cleared seat on ${assignedAirline} with IATA MITA Rule 240 / Electronic FIM endorsement (#FIM-${assignedFlight}-884210).`
              : "Automated rebooking system guaranteed first seat on tomorrow morning's earliest flight."}
          </div>
        </div>

        {/* CARD 4: LUGGAGE RAMP TRANSFER / STORAGE */}
        <div className="col-span-12 lg:col-span-6 rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-slate-400" />
                <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                  {isAutoRebooked ? "Active Interline Ramp Baggage Transfer" : "Secure Overnight Luggage Vault Storage"}
                </h2>
              </div>
              <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-300 font-mono text-[9px] font-bold border border-sky-800">
                {isAutoRebooked ? "RAMP TRANSFER ACTIVE" : "SAFELY STORED"}
              </span>
            </div>

            <div className="mt-3 space-y-1 text-xs font-mono">
              <div className="text-white">
                <span className="text-slate-500">Luggage Tag:</span>{" "}
                <span className="font-bold">
                  {isAutoRebooked
                    ? `Bag #4552 — Rerouted from AA142 to ${assignedFlight}`
                    : "Bag #4552 — Secure Vault Bay W-12"}
                </span>
              </div>
              <div className="text-slate-300">
                <span className="text-slate-500">
                  {isAutoRebooked ? "Transfer Route:" : "Storage Facility:"}
                </span>{" "}
                {isAutoRebooked
                  ? `Stand B10 ➔ ${assignedGate} (Climate-controlled rapid baggage cart)`
                  : "Climate controlled | 24/7 Security Monitored"}
              </div>
              <div className="text-slate-300">
                <span className="text-slate-500">Next Delivery:</span>{" "}
                {isAutoRebooked
                  ? `Directly loaded into ${assignedFlight} cargo hold for departure`
                  : `Automatically moved to ${assignedGate.split(" ")[0]} at 5:30 AM`}
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800/80 text-[11px] font-mono text-slate-400 flex justify-between">
            <span>Luggage verification log:</span>
            <span className="text-white font-bold">
              {isAutoRebooked ? "Tarmac scan verified · Loaded on Stand B38" : "4 security checkpoints verified"}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
