import { createServer } from "http";
import { Server, Socket } from "socket.io";

export interface FlightState {
  flightNumber: string;
  depJFK: string;
  etaBOS: string;
  scheduledLHRDep: string;
  delayMinutes: number;
  arrivalGate: string;
  connectingGate: string;
  holdApproved: boolean;
  status: "NORMAL" | "VOLATILE" | "ISOLATED" | "RECOVERED";
}

export interface MedicalEmergencyPayload {
  paxId: string;
  condition: string;
  medifVerified: boolean;
  medevacActive: boolean;
  paramedicEtaSeconds?: number;
  interlineOverrideFlight?: string;
}

export class IROPSAutonomousEngine {
  private io: Server;
  private simClockSeconds: number = 0; // Starts at T0 (16:00 UTC)
  private timeMultiplier: number = 1000; // 1 real sec = 1 sim min (60x)

  private state: FlightState = {
    flightNumber: "AA142",
    depJFK: "16:00 UTC",
    etaBOS: "17:00 UTC",
    scheduledLHRDep: "17:05 UTC",
    delayMinutes: 30,
    arrivalGate: "B30",
    connectingGate: "C14",
    holdApproved: false,
    status: "NORMAL",
  };

  constructor(server: any) {
    this.io = new Server(server, { cors: { origin: "*" } });
    this.initializeSocketChannels();
  }

  private initializeSocketChannels(): void {
    this.io.on("connection", (socket: Socket) => {
      console.log(`[AOC Telemetry] Terminal UI connected: ${socket.id}`);
      socket.emit("STATE_SYNC", this.state);

      socket.on("TRIGGER_MEDICAL_EMERGENCY", (payload: MedicalEmergencyPayload) => {
        this.executeMedicalEmergencyProtocol(payload);
      });

      socket.on("TOGGLE_POLICY", (policy: "MECHANICAL" | "WEATHER") => {
        this.broadcastPolicyChange(policy);
      });
    });
  }

  public startSimulationLoop(): void {
    setInterval(() => {
      this.simClockSeconds += 60;
      this.evaluateStateTransitions();
    }, this.timeMultiplier);
  }

  private evaluateStateTransitions(): void {
    const elapsedMinutes = this.simClockSeconds / 60;

    // T+5 mins: Preventor detects risk and isolates flight
    if (elapsedMinutes === 5) {
      this.state.status = "VOLATILE";
      this.io.emit("PREVENTOR_ALERT", {
        flight: this.state.flightNumber,
        riskScore: 0.94,
        bottleneck: "BOS_LHR_CONNECTION_BREACH",
        action: "ISOLATE_FLIGHT_GRAPH",
      });
    }

    // T+10 mins: Dynamic Gate Swap executed by Manager Engine
    if (elapsedMinutes === 10) {
      this.state.arrivalGate = "B10";
      this.state.connectingGate = "B12";
      this.io.emit("GATE_REALLOCATION", {
        flight: this.state.flightNumber,
        newArrivalGate: "B10",
        newDepartureGate: "B12",
        transitDeltaReductionMinutes: 18,
      });
    }

    // T+15 mins: Door-Hold Engine checks feasibility (5 min hold vs rebooking)
    if (elapsedMinutes === 15) {
      const holdCost = 120.0;
      const rebookCost = 850.0;
      const holdFeasible = holdCost < rebookCost;

      this.state.holdApproved = holdFeasible;
      this.io.emit("DOOR_HOLD_OPTIMIZATION", {
        holdMinutes: 5,
        holdCostUsd: holdCost,
        abandonCostUsd: rebookCost,
        decision: holdFeasible ? "APPROVED" : "REJECTED",
      });
    }

    // T+20 mins: Autonomous Zero-Touch Interline Engine executes
    if (elapsedMinutes === 20) {
      this.io.emit("PASSENGER_AUTO_REBOOK", {
        paxId: "PAX-9921",
        name: "Jordan Hayes",
        assignedFlight: "BA212",
        departureTime: "18:00 UTC",
        gate: "B38",
        seat: "12A",
        barcodePayload: "QR-BA212-12A-PAX9921",
      });

      this.io.emit("BAGGAGE_REROUTE_DISPATCH", {
        bagId: "BAG-4552",
        sourceStand: "B10",
        targetStand: "B38",
        status: "RAMP_TRANSFER_ACTIVE",
      });
    }

    // T+30 mins: Overnight Stranded Recovery Engine (Zero commercial flights left)
    if (elapsedMinutes === 30) {
      this.io.emit("OVERNIGHT_CARE_DISPATCH", {
        hotel: {
          name: "Hilton Boston Logan",
          room: "304",
          digitalKeyAvailable: true,
          shuttleCode: "QR-SHUTTLE-BOS",
        },
        mealVouchers: [
          { code: "MEAL-25-01", amount: 25 },
          { code: "MEAL-25-02", amount: 25 },
        ],
        morningStandby: { flight: "AA102", departure: "06:00 UTC", queuePosition: 1 },
        baggageVault: "SECURE_BAY_4",
      });
    }

    this.io.emit("TICK", { simClock: this.simClockSeconds, state: this.state });
  }

  private executeMedicalEmergencyProtocol(data: MedicalEmergencyPayload): void {
    console.warn(`[EMERGENCY] Activating Critical Medical Escalation for ${data.paxId}`);

    this.io.emit("MEDICAL_ESCALATION_TRIGGERED", {
      priority: "CRITICAL_ALPHA",
      paxId: data.paxId,
      medifVerified: true,
      insuranceVerified: true,
      actions: [
        {
          team: "AIRPORT_PARAMEDICS",
          destinationGate: "B10",
          etaSeconds: 90,
          status: "DISPATCHED",
        },
        {
          type: "INTERLINE_SETTLEMENT_OVERRIDE",
          targetFlight: "AA100 (17:30 UTC)",
          status: "CONFIRMED",
        },
        {
          type: "AIR_AMBULANCE_MEDEVAC",
          provider: "Air Ambulance Worldwide",
          clearance: "PRIORITY_MEDICAL_AIRSPACE_ACTIVE",
          status: "STANDBY_READY",
        },
      ],
    });
  }

  private broadcastPolicyChange(policy: "MECHANICAL" | "WEATHER"): void {
    this.io.emit("POLICY_UPDATED", {
      policy,
      hotelCoveredByCarrier: policy === "MECHANICAL",
      mealCoveredByCarrier: policy === "MECHANICAL",
      rebookingSupport: "FULL_AUTOMATED",
    });
  }
}

// Spin up execution server
const server = createServer();
const engine = new IROPSAutonomousEngine(server);
server.listen(4000, () => {
  console.log("[Simulation Engine] WebSocket Server live on port 4000");
  engine.startSimulationLoop();
});
