import React, { useState, useEffect } from "react";
import { Zap, Plane, CheckCircle2, Clock, MapPin, RefreshCw, Wifi, Thermometer, ShieldCheck } from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import { simulationEngine } from "../../engine/simulationEngine";
import { sounds } from "../../utils/audio";
import {
  fetchAirLabsAirportSchedules,
  fetchLiveWeatherByAirportCode,
  type AirLabsScheduleItem,
  type LiveAviationWeather
} from "../../services/airlabsService";

interface RecoveryInterlineViewProps {
  state: SimulationState;
}

export const RecoveryInterlineView: React.FC<RecoveryInterlineViewProps> = ({ state }) => {
  const [filter, setFilter] = useState<"ALL" | "REBOOKED" | "WAITLISTED" | "HOTEL" | "MEDICAL">("ALL");
  const [bookingToast, setBookingToast] = useState<string>("");
  const [isScanningGds, setIsScanningGds] = useState<boolean>(false);
  const [liveSchedules, setLiveSchedules] = useState<AirLabsScheduleItem[]>([]);
  const [lhrWeather, setLhrWeather] = useState<LiveAviationWeather | null>(null);

  const passengerName = state.passenger?.name || "Jordan Hayes";
  const isEmergency = Boolean(state.medical?.isActive || state.passenger?.medicalProfile?.isEmergency || state.passenger?.isEmergencyTraveler);
  
  const isHoldApproved = state.manager.decision === "APPROVED" || state.inferredOutcome?.doorHoldFeasibility === "HOLD_APPROVED" || state.inferredOutcome?.doorHoldFeasibility === "NOT_NEEDED";
  const hasRebooking = !isHoldApproved && Boolean(state.passenger?.recoveryAllocation);
  const isAutoRebookActive = hasRebooking;

  const bookedFlight = hasRebooking ? (state.passenger?.recoveryAllocation?.assignedFlight || null) : null;
  const bookedAirline = hasRebooking ? (state.passenger?.recoveryAllocation?.assignedAirline || null) : null;
  const bookedSeat = hasRebooking ? (state.passenger?.recoveryAllocation?.seat || "14B") : "14B";
  const bookedGate = hasRebooking ? (state.passenger?.recoveryAllocation?.gate || "B12") : "Gate B12";

  useEffect(() => {
    fetchLiveWeatherByAirportCode("LHR").then(setLhrWeather).catch(console.warn);
    fetchAirLabsAirportSchedules("BOS", "dep").then(setLiveSchedules).catch(console.warn);
  }, []);

  const competitorFlights = [
    {
      airline: "American Airlines (Owned Fleet)",
      flightNum: "AA102",
      origin: "BOS",
      dest: "LHR",
      destName: "London Heathrow",
      departureTime: "06:00 UTC (Next Morning)",
      gate: "Gate B12 (Terminal B)",
      seatType: "Flagship Business (Seat 14B)",
      seatsVacant: 24,
      alliance: "Operating Carrier (Includes Hilton Logan Room 304 + Meals)",
      settlementRateInr: 0,
      status: "PRIMARY OWNED FLEET REBOOKING",
      urgencyTag: "Complimentary Hotel & Meals Included",
      isPartner: true,
      isOwned: true,
      color: "#10b981"
    },
    {
      airline: "American Airlines (Owned Fleet)",
      flightNum: "AA178",
      origin: "BOS",
      dest: "LHR",
      destName: "London Heathrow",
      departureTime: "21:30 UTC (Tonight)",
      gate: "Gate B10 (Terminal B)",
      seatType: "Main Cabin Extra (Seat 19C)",
      seatsVacant: 7,
      alliance: "Operating Carrier Standby (Same Day)",
      settlementRateInr: 0,
      status: "OWNED FLEET SAME-DAY STANDBY",
      urgencyTag: "Evening Non-Stop",
      isPartner: true,
      isOwned: true,
      color: "#34d399"
    },
    {
      airline: "British Airways",
      flightNum: "BA212",
      origin: "BOS",
      dest: "LHR",
      destName: "London Heathrow",
      departureTime: "18:00 UTC (45m Buffer)",
      gate: "B16 (Adjacent North Concourse)",
      seatType: "Club World Business (Seat 12A)",
      seatsVacant: 15,
      alliance: "Oneworld Partner (Medical Emergency FIM Protocol)",
      settlementRateInr: 42500,
      status: "COMPETITOR RECOVERY (MEDICAL PRIORITY)",
      urgencyTag: "Fastest London Departure",
      isPartner: true,
      isOwned: false,
      color: "#38bdf8"
    },
    {
      airline: "Virgin Atlantic",
      flightNum: "VS12",
      origin: "BOS",
      dest: "LHR",
      destName: "London Heathrow",
      departureTime: "18:45 UTC (90m Buffer)",
      gate: "E04 (Terminal E Skybridge)",
      seatType: "Upper Class Suite (Seat 04K)",
      seatsVacant: 8,
      alliance: "Direct Competitor (Emergency Medical Override)",
      settlementRateInr: 51000,
      status: "COMPETITOR OVERRIDE READY",
      urgencyTag: "Direct Transatlantic Non-Stop",
      isPartner: false,
      isOwned: false,
      color: "#f43f5e"
    },
    {
      airline: "Delta Air Lines",
      flightNum: "DL58",
      origin: "BOS",
      dest: "CDG",
      destName: "Paris Charles de Gaulle",
      departureTime: "19:15 UTC (120m Buffer)",
      gate: "A18 (Terminal A)",
      seatType: "Delta One Suite (Seat 03A)",
      seatsVacant: 6,
      alliance: "SkyTeam Rival (Interline Medical Escrow)",
      settlementRateInr: 48000,
      status: "EUROPEAN GATEWAY BACKUP",
      urgencyTag: "Schengen Connection Ready",
      isPartner: false,
      isOwned: false,
      color: "#a855f7"
    },
    {
      airline: "Air France",
      flightNum: "AF333",
      origin: "BOS",
      dest: "CDG",
      destName: "Paris Charles de Gaulle",
      departureTime: "19:40 UTC (145m Buffer)",
      gate: "E08 (Terminal E)",
      seatType: "Business Class (Seat 05B)",
      seatsVacant: 11,
      alliance: "SkyTeam Interline (IATA Clearing Auto-Billed)",
      settlementRateInr: 46000,
      status: "ALLIANCE EXPEDITED OPTION",
      urgencyTag: "High Seat Capacity",
      isPartner: true,
      isOwned: false,
      color: "#60a5fa"
    },
    {
      airline: "Air Ambulance Worldwide",
      flightNum: "MEDEVAC-ICU-88",
      origin: "BOS",
      dest: "LHR / Surgical ICU",
      destName: "London Harley St ICU",
      departureTime: "Ready in 12 min (Immediate)",
      gate: "Remote Stand A14 (Ambulift Direct)",
      seatType: "Stretcher ICU Suite / On-board Trauma Surgeon",
      seatsVacant: 1,
      alliance: "Critical Medical Priority Clearance (Tail N775AA)",
      settlementRateInr: 185000,
      status: "EXTREME SURGICAL ESCALATION",
      urgencyTag: "Dedicated Air Ambulance",
      isPartner: false,
      isOwned: false,
      color: "#fbbf24"
    }
  ];

  const handleBookCompetitor = (flight: typeof competitorFlights[0]) => {
    const seat = flight.seatType.split("(")[1]?.replace(")", "") || "12A";
    simulationEngine.setCompetitorFlight(flight.flightNum, flight.airline, seat, flight.gate, flight.departureTime);
    sounds.playSuccessChime();
    setBookingToast(
      `✓ Autonomous FIM Endorsement updated to ${flight.airline} ${flight.flightNum} (${flight.seatType}) for ${passengerName} · Baggage Tag BAG-4552 rerouted to ${flight.gate} · IATA Clearing House settled ₹${flight.settlementRateInr.toLocaleString("en-IN")}.`
    );
    setTimeout(() => setBookingToast(""), 8000);
  };

  const handleRefreshGds = async () => {
    setIsScanningGds(true);
    sounds.playRadarPing();
    try {
      const [schedules, weather] = await Promise.all([
        fetchAirLabsAirportSchedules("BOS", "dep"),
        fetchLiveWeatherByAirportCode("LHR")
      ]);
      setLiveSchedules(schedules);
      setLhrWeather(weather);
      setBookingToast("✓ Live AirLabs GDS Global Seat Availability & OpenWeather METAR Refreshed.");
    } catch (e) {
      setBookingToast("✓ Live GDS Global Seat Availability Refreshed across 14 competing airlines.");
    } finally {
      setIsScanningGds(false);
      setTimeout(() => setBookingToast(""), 4000);
    }
  };

  const passengersList = [
    {
      name: `${passengerName} (PAX-9921)`,
      original: "AA142",
      status: isHoldApproved ? "Flight Held (Direct)" : isEmergency ? "Medical Priority" : "Rebooked",
      newFlight: isHoldApproved ? "AA142-LHR (Gate B12)" : (bookedFlight || "AA102"),
      seat: bookedSeat,
      baggage: isHoldApproved ? "Stand B12" : `Stand ${bookedGate?.includes("E") ? "E04" : "B38"}`,
      hotel: isHoldApproved ? "N/A (Flight Held)" : "Hilton Logan Room 304",
      meal: isHoldApproved ? "In-Flight Catering" : "Dispatched",
      notes: isHoldApproved ? "Adjacent Gate B12 Direct Transfer" : `Interline ${bookedAirline || "American"} Auto-Cleared`
    },
    { name: "J. Morrison", original: "AA142", status: "Rebooked", newFlight: "BA212", seat: "14A", baggage: "Stand B38", hotel: "N/A", meal: "Dispatched", notes: "Interline auto-clear" },
    { name: "M. Sterling", original: "AA142", status: "Rebooked", newFlight: "BA212", seat: "14B", baggage: "Stand B38", hotel: "N/A", meal: "Dispatched", notes: "Interline auto-clear" },
    { name: "A. Vance", original: "AA142", status: "Rebooked", newFlight: "BA212", seat: "08C", baggage: "Stand B38", hotel: "N/A", meal: "Dispatched", notes: "Interline auto-clear" },
    { name: "H. Granger", original: "AA142", status: "Rebooked", newFlight: "BA212", seat: "18F", baggage: "Stand B38", hotel: "N/A", meal: "Dispatched", notes: "Interline auto-clear" },
    { name: "R. Weasley", original: "AA142", status: "Rebooked", newFlight: "BA212", seat: "19A", baggage: "Stand B38", hotel: "N/A", meal: "Dispatched", notes: "Interline auto-clear" },
    { name: "S. Connor", original: "AA142", status: "Hotel Assigned", newFlight: "AA904 (Tomorrow)", seat: "22C", baggage: "Warehouse", hotel: "Hilton T5", meal: "Dispatched", notes: "Overnight protection" },
    { name: "T. Stark", original: "AA142", status: "Waitlisted", newFlight: "AA144", seat: "STANDBY", baggage: "JFK Terminal", hotel: "Pending", meal: "N/A", notes: "Priority standby" }
  ];

  const filteredPassengers = passengersList.filter((p) => {
    if (filter === "REBOOKED") return p.status === "Rebooked" || p.status === "Flight Held (Direct)";
    if (filter === "WAITLISTED") return p.status === "Waitlisted";
    if (filter === "HOTEL") return p.status === "Hotel Assigned";
    if (filter === "MEDICAL") return p.status === "Medical Priority";
    return true;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Flight Held (Direct)":
        return <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 font-bold text-[10px] border border-emerald-600 shadow-sm">Flight Held (Direct)</span>;
      case "Rebooked":
        return <span className="px-2 py-0.5 rounded bg-sky-950 text-sky-200 font-bold text-[10px] border border-sky-800">Rebooked</span>;
      case "Hotel Assigned":
        return <span className="px-2 py-0.5 rounded bg-purple-950 text-purple-200 font-bold text-[10px] border border-purple-800">Hotel Assigned</span>;
      case "Waitlisted":
        return <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 font-bold text-[10px] border border-amber-800">Waitlisted</span>;
      case "Medical Priority":
        return <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-bold text-[10px] border border-rose-800 animate-pulse">Medical Priority</span>;
      default:
        return <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">{status}</span>;
    }
  };

  return (
    <div className="flex flex-col gap-4 h-full overflow-y-auto p-4 bg-[#070b12] text-slate-200 font-sans">
      {/* AUTONOMOUS AUTO-BOOKING PRE-AUTHORIZATION BANNER */}
      {isAutoRebookActive && (
        <div className="w-full p-3.5 rounded-xl bg-gradient-to-r from-emerald-950/90 via-[#0a1814] to-slate-900 border border-emerald-500/80 text-emerald-200 text-xs font-mono flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-2xl">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-emerald-900 border border-emerald-500 flex items-center justify-center text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.4)]">
              <ShieldCheck className="h-5 w-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-white uppercase tracking-wider text-xs">
                  ⚡ AUTONOMOUS REBOOKING EXECUTED
                </span>
                <span className="px-2 py-0.5 rounded bg-emerald-900 text-emerald-300 border border-emerald-600 text-[9px] font-bold">
                  {isEmergency ? "MEDICAL OVERRIDE" : "OWNED FLEET"}
                </span>
              </div>
              <span className="text-[11px] text-slate-300 font-sans block mt-0.5">
                {isEmergency ? (
                  <>Medical priority override verified for <strong>{passengerName}</strong>. AI automatically locked in seat <strong>{bookedSeat}</strong> on competitor <strong>{bookedAirline} {bookedFlight}</strong> (Gate {bookedGate}) with zero-wait FIM clearance.</>
                ) : (
                  <>Rebooking policy verified for <strong>{passengerName}</strong> on operating carrier <strong>{bookedAirline} {bookedFlight}</strong> (Gate {bookedGate}, Seat {bookedSeat}) with Hilton Logan accommodation.</>
                )}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-[10px] uppercase shadow-md flex items-center gap-1.5">
              <CheckCircle2 className="h-3.5 w-3.5" /> AUTO-CONFIRMED
            </span>
          </div>
        </div>
      )}

      {/* POLICY BADGE: MEDICAL EXCEPTION vs OWNED FLEET RESCHEDULE */}
      <div className={`p-3 rounded-xl border text-xs font-mono flex items-center justify-between gap-3 ${
        isEmergency
          ? "bg-rose-950/70 border-rose-600 text-rose-200"
          : "bg-emerald-950/60 border-emerald-700 text-emerald-200"
      }`}>
        <div className="flex items-center gap-2">
          <span className="text-base">{isEmergency ? "🚨" : "🛡️"}</span>
          <span>
            {isEmergency ? (
              <strong>CRITICAL MEDICAL EMERGENCY ACTIVE: Immediate competitor interline settlement authorized (Patient cannot wait overnight; direct transfer to fastest carrier).</strong>
            ) : (
              <strong>STANDARD CARRIER RECOVERY POLICY: Rebooking prioritized on American Airlines fleet (AA102 / AA178) with complimentary Hilton Logan accommodation. Competitor interline transfers are restricted to Critical Medical Emergency patients.</strong>
            )}
          </span>
        </div>
      </div>

      {/* REAL-TIME COMPETITOR VACANCY & EMERGENCY MEDICAL INTERLINE SCANNER */}
      <div className="rounded-xl border border-slate-800 bg-[#0c121e] p-4 shadow-xl space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-rose-500 to-amber-600 flex items-center justify-center text-white shadow-md">
              <Zap className="h-4 w-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white font-mono tracking-wide">
                  Live Competitor Vacancy Scanner & Emergency FIM Interline Settlement
                </h2>
                <span className="px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 text-[9px] font-mono font-bold animate-pulse">
                  ZERO-WAIT LIFE SAFETY ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-400 font-sans">
                Scanning global GDS inventory across rival airlines to immediately rebook delayed/medical passengers without overnight delays.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {lhrWeather && (
              <div className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-[11px] font-mono">
                <Thermometer className="h-3 w-3 text-amber-400" />
                <span className="text-slate-400">LHR Dest METAR:</span>
                <span className="text-emerald-400 font-bold">{lhrWeather.tempC}°C · {lhrWeather.description}</span>
              </div>
            )}
            <button
              onClick={handleRefreshGds}
              disabled={isScanningGds}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-mono font-bold text-sky-400 transition"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isScanningGds ? "animate-spin" : ""}`} />
              <span>{isScanningGds ? "Scanning AirLabs GDS..." : "Refresh AirLabs Live Feeds"}</span>
            </button>
          </div>
        </div>

        {/* Live GDS & OpenWeather Connection Indicator */}
        <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 px-1">
          <div className="flex items-center gap-2">
            <span className="flex items-center gap-1 text-emerald-400 font-bold">
              <Wifi className="h-3 w-3 text-emerald-400" /> AIRLABS GDS & OPENWEATHER: CONNECTED
            </span>
            <span className="text-slate-600">|</span>
            <span>Live Schedule Query: BOS / JFK ➔ European Hubs</span>
          </div>
          {liveSchedules.length > 0 && (
            <span className="text-sky-300 font-semibold">
              {liveSchedules.length} Live Airport Departures Verified
            </span>
          )}
        </div>

        {/* Action Confirmation Toast Banner */}
        {bookingToast && (
          <div className="p-3 rounded-lg bg-emerald-950/80 border border-emerald-600 text-emerald-200 text-xs font-mono flex items-center gap-2 shadow-lg animate-in fade-in">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>{bookingToast}</span>
          </div>
        )}

        {/* Competitor Vacancy Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
          {competitorFlights.map((flight, idx) => {
            const isCurrentlyBooked = bookedFlight === flight.flightNum;
            return (
              <div
                key={idx}
                className={`rounded-lg border p-3 flex flex-col justify-between transition-all duration-200 relative overflow-hidden ${
                  isCurrentlyBooked
                    ? "bg-gradient-to-b from-slate-900 to-[#071813] border-emerald-500 shadow-[0_0_20px_rgba(16,185,129,0.3)] ring-1 ring-emerald-500/50"
                    : "bg-[#090d16] border-slate-800/90 hover:border-slate-700"
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-black text-white">{flight.airline}</span>
                    <span
                      className="px-2 py-0.5 rounded text-[9px] font-mono font-bold border"
                      style={{ color: flight.color, borderColor: `${flight.color}40`, backgroundColor: `${flight.color}15` }}
                    >
                      {flight.urgencyTag}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 text-base font-black text-white font-mono">
                      <Plane className="h-4 w-4 text-sky-400" />
                      <span>{flight.flightNum}</span>
                      <span className="text-xs text-slate-400 font-sans font-normal">
                        ({flight.origin} ➔ {flight.dest})
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 font-medium">{flight.destName}</p>
                  </div>

                  <div className="space-y-1 text-[11px] font-mono bg-slate-950/60 p-2 rounded border border-slate-800/80">
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400 flex items-center gap-1">
                        <Clock className="h-3 w-3 text-sky-400" /> Departs:
                      </span>
                      <span className="font-bold text-white">{flight.departureTime}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400 flex items-center gap-1">
                        <MapPin className="h-3 w-3 text-emerald-400" /> Gate:
                      </span>
                      <span className="font-bold text-emerald-400">{flight.gate}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400">Seat Class:</span>
                      <span className="text-sky-300 font-semibold">{flight.seatType}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-300">
                      <span className="text-slate-400">Live Vacancy:</span>
                      <span className="text-emerald-400 font-bold">{flight.seatsVacant} Available</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 pt-1 border-t border-slate-800">
                      <span>Interline Fare:</span>
                      <span className="text-amber-300 font-bold">₹{flight.settlementRateInr.toLocaleString("en-IN")}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-800/80">
                  <button
                    onClick={() => handleBookCompetitor(flight)}
                    className={`w-full py-2 px-3 rounded-lg text-xs font-mono font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md ${
                      isCurrentlyBooked
                        ? "bg-emerald-600 text-white hover:bg-emerald-500 shadow-[0_0_12px_rgba(16,185,129,0.4)]"
                        : "bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700"
                    }`}
                  >
                    {isCurrentlyBooked ? (
                      <>
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>✓ Auto-Booked & FIM Endorsed</span>
                      </>
                    ) : isHoldApproved ? (
                      <>
                        <Plane className="h-3.5 w-3.5 text-slate-400" />
                        <span>Manual Backup Option ({flight.flightNum})</span>
                      </>
                    ) : (
                      <>
                        <Zap className="h-3.5 w-3.5 text-amber-400" />
                        <span>Switch Auto-Booking to {flight.flightNum}</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* TOP SECTION: ZERO-TOUCH INTERLINE & BAGGAGE RAMP TELEMETRY */}
      <div className="grid grid-cols-12 gap-4">
        {/* LEFT 6 COLS: ACTIVE PASSENGER CONFIRMATION CARD */}
        <div className="col-span-12 lg:col-span-6 flex flex-col gap-2">
          <h2 className="text-[11px] font-bold tracking-wider text-slate-400 uppercase font-mono">
            {isHoldApproved ? "Scheduled Flight Boarding & Direct Transfer" : "Automated Passenger Rebooking & Seat Confirmation"}
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-lg border border-slate-800 bg-[#0d131f] p-3.5 shadow-inner">
            {/* Left 2 cols: Table of Rebooked */}
            <div className="md:col-span-2 space-y-2.5">
              <div>
                <h3 className="text-xs font-bold text-white">
                  {isHoldApproved
                    ? `Direct Scheduled Boarding: ${passengerName} ➔ Flight AA142-LHR`
                    : `Active Rebooking: ${passengerName} ➔ ${bookedAirline || "American Airlines"} ${bookedFlight || "AA102"}`}
                </h3>
                <p className="text-[10px] font-mono text-slate-400">
                  {isHoldApproved
                    ? "Flight AA142-LHR — Gate B12 (Adjacent to Arrival Gate B10) — Boarding doors held by Flight Deck"
                    : `${bookedFlight || "AA102"} — Seat ${bookedSeat} — Gate ${bookedGate} — Auto-Settled via IATA Clearing House`}
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-[11px] font-mono text-left">
                  <thead>
                    <tr className="border-b border-slate-800 text-slate-500 text-[10px]">
                      <th className="pb-1 font-semibold">PASSENGER NAME</th>
                      <th className="pb-1 font-semibold">ORIGINAL</th>
                      <th className="pb-1 font-semibold">NEW FLIGHT</th>
                      <th className="pb-1 font-semibold">SEAT</th>
                      <th className="pb-1 font-semibold">STATUS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {passengersList.slice(0, 5).map((p, idx) => (
                      <tr key={idx} className="hover:bg-slate-800/40">
                        <td className="py-1.5 text-white font-medium">{p.name}</td>
                        <td className="py-1.5 text-slate-400">{p.original}</td>
                        <td className="py-1.5 text-sky-400 font-bold">{p.newFlight}</td>
                        <td className="py-1.5 text-white">{p.seat}</td>
                        <td className="py-1.5">{getStatusBadge(p.status)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Right 1 col: SMS Dispatch Active Preview */}
            <div className="flex flex-col rounded-lg border border-slate-800 bg-[#090d16] p-3 text-xs font-mono">
              <span className="text-[10px] text-slate-500 uppercase tracking-wider block mb-2">
                Automated Passenger Notification Preview
              </span>
              <div className="rounded-lg bg-slate-900 border border-slate-800 p-2.5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-[9px] text-slate-500 pb-1 border-b border-slate-800">
                    <span>AIRLINE NOTIFICATION</span>
                    <span>18:42</span>
                  </div>
                  <div className="mt-2 space-y-1">
                    <span className="text-[10px] font-bold text-sky-300 block">
                      {isHoldApproved ? "Flight Door-Hold Active" : "Flight Rebooking Confirmed"}
                    </span>
                    <p className="text-[10px] text-slate-300 leading-snug font-sans">
                      {isHoldApproved
                        ? `Flight AA142-LHR is holding boarding doors for you at adjacent Gate B12 (25m stroll). Your direct London connection is on schedule.`
                        : isEmergency
                        ? `Your medical priority ticket is issued on ${bookedAirline || "British Airways"} ${bookedFlight || "BA212"} (Seat ${bookedSeat}). Gate ${bookedGate}. Paramedic escort is stationed at the jetbridge.`
                        : `Your rescheduled ticket is confirmed on ${bookedAirline || "American Airlines"} ${bookedFlight || "AA102"} (Seat ${bookedSeat}). Hilton Boston Logan Room 304 allocated.`}
                    </p>
                  </div>
                </div>
                <div className="pt-2 text-[9px] text-emerald-400 font-bold">
                  ✓ Delivered to {passengerName}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT 6 COLS: BAGGAGE RAMP TELEMETRY */}
        <div className="col-span-12 lg:col-span-6 flex flex-col gap-2">
          <h2 className="text-[11px] font-bold tracking-wider text-slate-400 uppercase font-mono">
            Live Baggage Transfer & Tarmac Tracking
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 rounded-lg border border-slate-800 bg-[#0d131f] p-3.5 shadow-inner">
            {/* Left 2 cols: Ramp Path Track */}
            <div className="md:col-span-2 space-y-2.5 flex flex-col justify-between">
              <div>
                <h3 className="text-xs font-bold text-white">
                  Transfer Route: Stand A14 ➔ {bookedFlight === "BA212" ? "Stand B38" : "Stand E04"} ({bookedFlight})
                </h3>
              </div>

              {/* Animated Track Visualizer */}
              <div className="h-28 rounded-lg border border-slate-800 bg-[#090d16] p-3 flex flex-col items-center justify-center relative overflow-hidden">
                <div className="flex items-center justify-between w-full px-4 text-xs font-mono">
                  <span className="text-slate-400 font-bold">STAND A14</span>
                  <div className="flex-1 mx-3 h-0.5 border-t border-dashed border-slate-700 relative flex items-center justify-center">
                    <div className="px-2 py-0.5 rounded bg-white text-slate-950 font-mono text-[9px] font-bold shadow-md animate-pulse">
                      TUG #04
                    </div>
                  </div>
                  <span className="text-sky-400 font-bold">{bookedFlight === "BA212" ? "STAND B38" : "STAND E04"}</span>
                </div>
                <span className="mt-3 text-[9px] font-mono text-slate-500 tracking-wider uppercase">
                  Real-Time GPS Tarmac Luggage Movement
                </span>
              </div>
            </div>

            {/* Right 1 col: Bag Info Card */}
            <div className="flex flex-col rounded-lg border border-slate-800 bg-[#090d16] p-3 text-xs font-mono justify-between">
              <div>
                <div className="flex items-center justify-between pb-1 border-b border-slate-800">
                  <span className="font-bold text-white">Bag #4552</span>
                  <span className="text-[9px] text-amber-400 font-bold">Priority Tag</span>
                </div>
                <div className="mt-2 space-y-1 text-[10px] text-slate-300">
                  <div>Passenger: <span className="text-white font-semibold">{passengerName}</span></div>
                  <div className="text-slate-400">Destination: {bookedAirline} {bookedFlight}</div>
                </div>

                {/* Telemetry Status Dots */}
                <div className="mt-3 space-y-1 text-[10px]">
                  <span className="text-slate-500 font-bold block text-[9px]">Luggage Status</span>
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-500" />
                    <span>Unloaded from arrival (18:24)</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-sky-400 font-bold">
                    <span className="h-2 w-2 rounded-full bg-sky-400 animate-ping" />
                    <span>In Transit on Tarmac Cart</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-600">
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-700" />
                    <span>Loaded on {bookedFlight} (Est. 18:48)</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 text-[10px] text-slate-400 flex justify-between">
                <span>Estimated loading time:</span>
                <span className="text-white font-bold">5:45 PM</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* BOTTOM SECTION: PASSENGER RE-ACCOMMODATION STATUS */}
      <div className="rounded-lg border border-slate-800 bg-[#0d131f] p-4 space-y-3 shadow-inner flex-1 flex flex-col justify-between">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-800">
          <h2 className="text-xs font-bold uppercase tracking-wider text-white font-mono">
            Passenger Rebooking & Accommodation Overview
          </h2>

          <div className="flex items-center gap-1 text-xs font-mono">
            <button
              onClick={() => setFilter("ALL")}
              className={`px-3 py-0.5 rounded transition ${
                filter === "ALL"
                  ? "bg-white text-slate-950 font-bold"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              All Passengers (24)
            </button>
            <button
              onClick={() => setFilter("REBOOKED")}
              className={`px-3 py-0.5 rounded transition ${
                filter === "REBOOKED"
                  ? "bg-white text-slate-950 font-bold"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              Rebooked (12)
            </button>
            <button
              onClick={() => setFilter("WAITLISTED")}
              className={`px-3 py-0.5 rounded transition ${
                filter === "WAITLISTED"
                  ? "bg-white text-slate-950 font-bold"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              Waitlisted (6)
            </button>
            <button
              onClick={() => setFilter("HOTEL")}
              className={`px-3 py-0.5 rounded transition ${
                filter === "HOTEL"
                  ? "bg-white text-slate-950 font-bold"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              Hotel Assigned (4)
            </button>
            <button
              onClick={() => setFilter("MEDICAL")}
              className={`px-3 py-0.5 rounded transition ${
                filter === "MEDICAL"
                  ? "bg-rose-600 text-white font-bold"
                  : "bg-slate-800 text-slate-400 hover:text-white"
              }`}
            >
              Medical Priority (2)
            </button>
          </div>
        </div>

        <div className="overflow-x-auto flex-1">
          <table className="w-full text-xs font-mono text-left">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 text-[10px]">
                <th className="pb-2 font-semibold">PASSENGER NAME</th>
                <th className="pb-2 font-semibold">ORIGINAL FLIGHT</th>
                <th className="pb-2 font-semibold">STATUS</th>
                <th className="pb-2 font-semibold">NEW FLIGHT</th>
                <th className="pb-2 font-semibold">SEAT</th>
                <th className="pb-2 font-semibold">BAGGAGE</th>
                <th className="pb-2 font-semibold">HOTEL</th>
                <th className="pb-2 font-semibold">MEAL VOUCHER</th>
                <th className="pb-2 font-semibold">RESOLUTION DETAILS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredPassengers.map((p, idx) => (
                <tr key={idx} className="hover:bg-slate-800/30">
                  <td className="py-2 text-white font-medium">{p.name}</td>
                  <td className="py-2 text-slate-400">{p.original}</td>
                  <td className="py-2">{getStatusBadge(p.status)}</td>
                  <td className="py-2 text-sky-400 font-bold">{p.newFlight}</td>
                  <td className="py-2 text-white">{p.seat}</td>
                  <td className="py-2 text-slate-300">{p.baggage}</td>
                  <td className="py-2 text-purple-300">{p.hotel}</td>
                  <td className="py-2 text-emerald-400">{p.meal}</td>
                  <td className="py-2 text-slate-400 text-[11px]">{p.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
