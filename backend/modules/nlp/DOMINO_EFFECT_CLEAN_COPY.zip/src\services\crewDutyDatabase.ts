export interface CrewMember {
  id: string;
  name: string;
  role: "CAPTAIN" | "FIRST_OFFICER" | "RELIEF_PILOT" | "LEAD_PURSER" | "FLIGHT_ATTENDANT";
  flightNumber: string;
  aircraftType: string;
  domicile: string;
  dutyStartTimeUtc: string;
  scheduledDutyEndUtc: string;
  maxLegalFdpHours: number; // FAA Part 117 Max Flight Duty Period
  currentElapsedDutyHours: number;
  cumulative7DayHours: number;
  max7DayLimitHours: number;
  restPeriodRemainingHours: number;
  status: "LEGAL_OPTIMAL" | "CAUTION_THRESHOLD" | "CRITICAL_DUTY_CAP" | "TIMEOUT_BREACH";
  pilotLicense: string;
  specialQualifications: string[];
}

export interface CrewDutyEvaluation {
  isHoldLegal: boolean;
  maxFeasibleHoldMinutes: number;
  criticalCrewMember?: CrewMember;
  remainingDutyMarginMinutes: number;
  farPart117ComplianceText: string;
  crewDutySummaryNarrative: string;
}

export const INITIAL_CREW_DATABASE: CrewMember[] = [
  {
    id: "CREW-CP-8841",
    name: "Capt. Sarah Miller",
    role: "CAPTAIN",
    flightNumber: "AA142",
    aircraftType: "Boeing 787-9 Dreamliner",
    domicile: "BOS",
    dutyStartTimeUtc: "09:30 UTC",
    scheduledDutyEndUtc: "18:00 UTC",
    maxLegalFdpHours: 12.0,
    currentElapsedDutyHours: 7.2,
    cumulative7DayHours: 24.5,
    max7DayLimitHours: 60.0,
    restPeriodRemainingHours: 4.8,
    status: "LEGAL_OPTIMAL",
    pilotLicense: "ATP-1884129 (Type Rated B787/777)",
    specialQualifications: ["CAT III ILS Certified", "Oceanic ETOPS 180", "Line Check Airman"],
  },
  {
    id: "CREW-FO-9102",
    name: "First Officer Mark Vance",
    role: "FIRST_OFFICER",
    flightNumber: "AA142",
    aircraftType: "Boeing 787-9 Dreamliner",
    domicile: "JFK",
    dutyStartTimeUtc: "09:30 UTC",
    scheduledDutyEndUtc: "18:00 UTC",
    maxLegalFdpHours: 12.0,
    currentElapsedDutyHours: 7.2,
    cumulative7DayHours: 28.0,
    max7DayLimitHours: 60.0,
    restPeriodRemainingHours: 4.8,
    status: "LEGAL_OPTIMAL",
    pilotLicense: "ATP-2910245 (Type Rated B787)",
    specialQualifications: ["RNP-AR Precision Approach", "ETOPS Extended Range"],
  },
  {
    id: "CREW-CP-7721",
    name: "Capt. David Thorne",
    role: "CAPTAIN",
    flightNumber: "AA142-LHR",
    aircraftType: "Boeing 787-9 Dreamliner",
    domicile: "LHR",
    dutyStartTimeUtc: "11:00 UTC",
    scheduledDutyEndUtc: "23:00 UTC",
    maxLegalFdpHours: 13.0,
    currentElapsedDutyHours: 5.1,
    cumulative7DayHours: 19.0,
    max7DayLimitHours: 60.0,
    restPeriodRemainingHours: 7.9,
    status: "LEGAL_OPTIMAL",
    pilotLicense: "ATP-3772190 (Type Rated B787/A350)",
    specialQualifications: ["North Atlantic Track HLA", "Commander EASA/FAA Dual Endorsed"],
  },
  {
    id: "CREW-FO-6631",
    name: "First Officer Emily Chen",
    role: "FIRST_OFFICER",
    flightNumber: "AA142-LHR",
    aircraftType: "Boeing 787-9 Dreamliner",
    domicile: "BOS",
    dutyStartTimeUtc: "11:15 UTC",
    scheduledDutyEndUtc: "23:00 UTC",
    maxLegalFdpHours: 13.0,
    currentElapsedDutyHours: 4.9,
    cumulative7DayHours: 22.4,
    max7DayLimitHours: 60.0,
    restPeriodRemainingHours: 8.1,
    status: "LEGAL_OPTIMAL",
    pilotLicense: "ATP-4663182 (Type Rated B787)",
    specialQualifications: ["NAT-HLA Certified", "CPDLC Datalink Instructor"],
  },
  {
    id: "CREW-PU-3301",
    name: "Purser Marcus Sterling",
    role: "LEAD_PURSER",
    flightNumber: "AA142-LHR",
    aircraftType: "Boeing 787-9 Dreamliner",
    domicile: "BOS",
    dutyStartTimeUtc: "11:00 UTC",
    scheduledDutyEndUtc: "23:30 UTC",
    maxLegalFdpHours: 14.0,
    currentElapsedDutyHours: 5.2,
    cumulative7DayHours: 31.0,
    max7DayLimitHours: 65.0,
    restPeriodRemainingHours: 8.8,
    status: "LEGAL_OPTIMAL",
    pilotLicense: "CABIN-CHIEF-09881",
    specialQualifications: ["VIP & Diamond Medallion Concierge Lead", "Medical Triage Level 3"],
  },
  {
    id: "CREW-FA-3304",
    name: "Flight Attendant Elena Rostova",
    role: "FLIGHT_ATTENDANT",
    flightNumber: "AA142-LHR",
    aircraftType: "Boeing 787-9 Dreamliner",
    domicile: "BOS",
    dutyStartTimeUtc: "11:00 UTC",
    scheduledDutyEndUtc: "23:30 UTC",
    maxLegalFdpHours: 14.0,
    currentElapsedDutyHours: 5.2,
    cumulative7DayHours: 29.5,
    max7DayLimitHours: 65.0,
    restPeriodRemainingHours: 8.8,
    status: "LEGAL_OPTIMAL",
    pilotLicense: "CABIN-FA-12048",
    specialQualifications: ["Multilingual (EN/FR/ES)", "Special Needs Passenger Escort"],
  },
];

export class CrewDutyService {
  private static crewRoster: CrewMember[] = [...INITIAL_CREW_DATABASE];

  public static getCrewRoster(flightNumber?: string): CrewMember[] {
    if (flightNumber) {
      return this.crewRoster.filter((c) => c.flightNumber.includes(flightNumber));
    }
    return [...this.crewRoster];
  }

  public static updateElapsedDuty(additionalMinutes: number): void {
    const hours = additionalMinutes / 60;
    this.crewRoster = this.crewRoster.map((crew) => {
      const newElapsed = Math.min(crew.maxLegalFdpHours, Number((crew.currentElapsedDutyHours + hours).toFixed(2)));
      const remaining = Math.max(0, Number((crew.maxLegalFdpHours - newElapsed).toFixed(2)));

      let status: CrewMember["status"] = "LEGAL_OPTIMAL";
      if (remaining <= 0.5) {
        status = "TIMEOUT_BREACH";
      } else if (remaining <= 1.5) {
        status = "CRITICAL_DUTY_CAP";
      } else if (remaining <= 3.0) {
        status = "CAUTION_THRESHOLD";
      }

      return {
        ...crew,
        currentElapsedDutyHours: newElapsed,
        restPeriodRemainingHours: remaining,
        status,
      };
    });
  }

  public static evaluateHoldLegality(holdMinutes: number, targetFlight: string = "AA142-LHR"): CrewDutyEvaluation {
    const relevantCrew = this.crewRoster.filter((c) => c.flightNumber.includes(targetFlight));

    let minRemainingMinutes = Infinity;
    let criticalCrew: CrewMember | undefined;

    relevantCrew.forEach((c) => {
      const remainingMinutes = Math.round((c.maxLegalFdpHours - c.currentElapsedDutyHours) * 60);
      if (remainingMinutes < minRemainingMinutes) {
        minRemainingMinutes = remainingMinutes;
        criticalCrew = c;
      }
    });

    const isHoldLegal = minRemainingMinutes >= holdMinutes + 15; // Require minimum 15 min legal buffer
    const maxFeasibleHoldMinutes = Math.max(0, minRemainingMinutes - 15);

    const farComplianceText = isHoldLegal
      ? `FAR Part 117 Compliant: Captain David Thorne and flight deck crew have ${minRemainingMinutes}m duty buffer remaining. A ${holdMinutes}m gate hold leaves ${minRemainingMinutes - holdMinutes}m legal reserve before timeout.`
      : `FAR Part 117 Warning: Holding beyond ${maxFeasibleHoldMinutes}m risks violating mandatory FAA 14 CFR § 117.13 Flight Duty Period cap for ${criticalCrew?.name}.`;

    const summaryNarrative = isHoldLegal
      ? `Crew Duty Verified: All 6 crew members on outbound ${targetFlight} are 100% legal for the 5-minute door hold. No crew timeout risk detected.`
      : `Crew Limit Warning: Hold of ${holdMinutes}m approaches mandatory rest boundary. Recommend fast-track boarding.`;

    return {
      isHoldLegal,
      maxFeasibleHoldMinutes,
      criticalCrewMember: criticalCrew,
      remainingDutyMarginMinutes: minRemainingMinutes,
      farPart117ComplianceText: farComplianceText,
      crewDutySummaryNarrative: summaryNarrative,
    };
  }
}
