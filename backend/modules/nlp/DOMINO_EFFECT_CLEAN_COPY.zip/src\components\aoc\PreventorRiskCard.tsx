import React from "react";
import { ShieldAlert, ShieldCheck, AlertTriangle, Cpu } from "lucide-react";
import type { PreventorMetrics, FlightContext } from "../../types/simulation";

interface PreventorRiskCardProps {
  preventor: PreventorMetrics;
  flight: FlightContext;
}

export const PreventorRiskCard: React.FC<PreventorRiskCardProps> = ({ preventor, flight }) => {
  const tDelay = flight.delayMinutes;
  const tBuffer = flight.bufferMinutes;
  const deltaT = 5;
  const mct = 40;
  const phiCrew = flight.crewDutyRisk;

  const term1 = preventor.weights.w1 * (tDelay / tBuffer);
  const term2 = preventor.weights.w2 * (1 - deltaT / mct);
  const term3 = preventor.weights.w3 * phiCrew;
  const calculatedRisk = Math.min(1, term1 + term2 + term3);

  const isCritical = calculatedRisk >= 0.75;

  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/80 backdrop-blur-md overflow-hidden shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/70">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-rose-950 border border-rose-800 text-rose-400">
            <Cpu className="h-3.5 w-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Preventor Engine: Contagion Risk Score Formula
            </h3>
            <p className="text-[10px] text-slate-400">
              Dynamic Volatility Propagation & Structural Immunization
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div
            className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono border font-black ${
              isCritical
                ? "bg-rose-950/80 border-rose-600 text-rose-300 shadow-[0_0_12px_rgba(244,63,94,0.3)]"
                : "bg-emerald-950/80 border-emerald-600 text-emerald-300"
            }`}
          >
            {isCritical ? (
              <>
                <ShieldAlert className="h-3.5 w-3.5 text-rose-400 animate-pulse" />
                <span>R_i = {calculatedRisk.toFixed(2)} (CRITICAL BREACH)</span>
              </>
            ) : (
              <>
                <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />
                <span>R_i = {calculatedRisk.toFixed(2)} (STABLE)</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Formula & Live Calculation Deck */}
      <div className="p-4 space-y-3 flex-1 flex flex-col justify-between overflow-y-auto">
        <div className="rounded-lg border border-slate-800 bg-slate-950 p-3 font-mono text-[11px] text-slate-300">
          <div className="text-slate-400 text-[10px] mb-1 font-bold">MATHEMATICAL MODEL:</div>
          <p className="text-sky-300 font-semibold leading-relaxed">
            R_i = w_1 · (T_delay / T_buffer) + w_2 · ∑ [1 - (Δt_transfer / MCT)] + w_3 · φ_crew
          </p>
          <div className="mt-2 text-[10px] text-slate-400 flex flex-wrap gap-3 border-t border-slate-800/80 pt-2">
            <span>Weights: w1={preventor.weights.w1}, w2={preventor.weights.w2}, w3={preventor.weights.w3}</span>
            <span>Threshold: R ≥ 0.75 → Structural Isolation</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2 font-mono text-xs">
          <div className="rounded-lg border border-slate-800 bg-slate-950/90 p-2.5">
            <span className="text-slate-500 text-[10px]">TERM 1: DELAY BUFFER</span>
            <div className="mt-1 text-sm font-bold text-sky-400">+{term1.toFixed(3)}</div>
            <div className="mt-1 text-[10px] text-slate-400">
              {preventor.weights.w1} · ({tDelay}m / {tBuffer}m)
            </div>
            <div className="mt-1 text-[9px] text-amber-400 font-semibold">Feeder 30m Late</div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/90 p-2.5">
            <span className="text-slate-500 text-[10px]">TERM 2: MCT BREACH</span>
            <div className="mt-1 text-sm font-bold text-rose-400">+{term2.toFixed(3)}</div>
            <div className="mt-1 text-[10px] text-slate-400">
              {preventor.weights.w2} · (1 - {deltaT}m / {mct}m)
            </div>
            <div className="mt-1 text-[9px] text-rose-400 font-semibold">MCT 40m vs 5m Avail</div>
          </div>

          <div className="rounded-lg border border-slate-800 bg-slate-950/90 p-2.5">
            <span className="text-slate-500 text-[10px]">TERM 3: CREW DUTY RISK</span>
            <div className="mt-1 text-sm font-bold text-amber-400">+{term3.toFixed(3)}</div>
            <div className="mt-1 text-[10px] text-slate-400">
              {preventor.weights.w3} · φ_crew ({phiCrew})
            </div>
            <div className="mt-1 text-[9px] text-amber-400 font-semibold">2.1h Before Timeout</div>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-slate-950/90 p-3 text-xs font-mono">
          <div className="flex items-center gap-1.5 text-slate-400 text-[11px] font-bold mb-2">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-400" />
            <span>ACTIVE CONTAGION VECTORS & ISOLATION ACTIONS</span>
          </div>
          <ul className="space-y-1.5 text-[11px]">
            <li className="flex items-center gap-2 text-rose-300">
              <span className="h-1.5 w-1.5 rounded-full bg-rose-400" />
              <span>Downstream Rotation Tail (LHR ➔ FRA) isolated via synthetic decoupling</span>
            </li>
            <li className="flex items-center gap-2 text-sky-300">
              <span className="h-1.5 w-1.5 rounded-full bg-sky-400" />
              <span>Boston Logan gate assigned to adjacent corridor (B10 / B12)</span>
            </li>
            <li className="flex items-center gap-2 text-emerald-300">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
              <span>Automated seat hold locked on British Airways BA212 (18:00 UTC)</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
