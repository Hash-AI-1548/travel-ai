export type SeverityLevel = "NONE" | "MINOR" | "MODERATE" | "SEVERE" | "CRITICAL";

export interface DisruptionFactors {
  severeWeather: SeverityLevel;
  lateIncomingAircraft: SeverityLevel;
  atcCongestion: SeverityLevel;
  crewRestLimits: SeverityLevel;
  mechanicalIssues: SeverityLevel;
  groundOpsDelays: SeverityLevel;
  securityBackups: SeverityLevel;
  passengerBoardingDelays: SeverityLevel;
  baggageHandlingIssues: SeverityLevel;
  waitingConnectingPax: SeverityLevel;
  medicalEmergencyFlag: boolean;
}

export interface InferredDisruptionOutcome {
  totalDelayMinutes: number;
  delayBreakdown: {
    factor: string;
    minutes: number;
    category: "CARRIER" | "WEATHER" | "ATC" | "SECURITY" | "PASSENGER";
  }[];
  primaryLiability: "CARRIER_MECHANICAL" | "WEATHER_FORCE_MAJEURE" | "ATC_NAS";
  contagionRiskScore: number; // 0.00 to 1.00
  riskLevel: "LOW" | "MODERATE" | "HIGH";
  riskBadgeText: string;
  isContagionIsolated: boolean;
  isolationNarrative: string;
  mctBreachProbability: number; // 0 to 100%
  inferredArrivalEta: string; // e.g. "5:18 PM"
  inferredConnectionDeltaT: number; // minutes available
  recommendedGateAction: "ADJACENT_GATE_SWAP" | "HOLD_AT_BAY" | "STANDARD_ASSIGNMENT" | "EXPRESS_TARMAC_SHUTTLE";
  arrivalGate: string;
  outboundGate: string;
  walkingDistanceMeters: number;
  walkingTimeMins: number;
  gateActionTitle: string;
  gateActionDescription: string;
  gateSavingText: string;
  doorHoldFeasibility: "NOT_NEEDED" | "HOLD_APPROVED" | "CLOSE_AND_REBOOK" | "IMPOSSIBLE";
  doorHoldMinutes: number;
  doorHoldDecisionReason: string;
  costHoldInr: number;
  costAbandonInr: number;
  netSavingsInr: number;
  overnightCareNeeded: boolean;
  paramedicDispatchNeeded: boolean;
  protectedFlightsCount: number;
  estimatedNetworkSavingsInr: number;
  financialModelBreakdown?: {
    aircraftRotationSavingsInr: number;
    crewRecoverySavingsInr: number;
    passengerMisconnectSavingsInr: number;
    airportCurfewSavingsInr: number;
    interventionCostInr: number;
    netExpectedAvoidedCostInr: number;
    confidenceScore: number;
    downstreamAircraftSectors: number;
    crewPairingsProtected: number;
    passengerConnectionsProtected: number;
    totalInsulatedNodes: number;
  };
  summaryNarrative: string;
}

export const DEFAULT_DISRUPTION_FACTORS: DisruptionFactors = {
  severeWeather: "NONE",
  lateIncomingAircraft: "MODERATE", // +15 min
  atcCongestion: "MINOR", // +5 min
  crewRestLimits: "MINOR", // +5 min
  mechanicalIssues: "MINOR", // +5 min
  groundOpsDelays: "NONE",
  securityBackups: "NONE",
  passengerBoardingDelays: "NONE",
  baggageHandlingIssues: "MINOR",
  waitingConnectingPax: "NONE",
  medicalEmergencyFlag: false,
};

export const PRESET_DISRUPTION_SCENARIOS: {
  id: string;
  title: string;
  description: string;
  factors: DisruptionFactors;
}[] = [
  {
    id: "default-delay",
    title: "Standard 30m Feeder Inbound Delay",
    description: "Moderate incoming aircraft delay with minor ATC metering. Feeder arrives at T+30m.",
    factors: {
      severeWeather: "NONE",
      lateIncomingAircraft: "MODERATE",
      atcCongestion: "MINOR",
      crewRestLimits: "MINOR",
      mechanicalIssues: "MINOR",
      groundOpsDelays: "NONE",
      securityBackups: "NONE",
      passengerBoardingDelays: "NONE",
      baggageHandlingIssues: "MINOR",
      waitingConnectingPax: "NONE",
      medicalEmergencyFlag: false,
    },
  },
  {
    id: "noreaster-blizzard",
    title: "Severe Winter Storm & ATC Ground Stop",
    description: "Heavy snow squalls, de-icing queue backups, and FAA GDP ground stops.",
    factors: {
      severeWeather: "CRITICAL",
      lateIncomingAircraft: "SEVERE",
      atcCongestion: "CRITICAL",
      crewRestLimits: "MODERATE",
      mechanicalIssues: "NONE",
      groundOpsDelays: "SEVERE",
      securityBackups: "NONE",
      passengerBoardingDelays: "MINOR",
      baggageHandlingIssues: "MODERATE",
      waitingConnectingPax: "MINOR",
      medicalEmergencyFlag: false,
    },
  },
  {
    id: "mechanical-gate-mel",
    title: "Mechanical APU Failure & Ramp Turnaround Lag",
    description: "Hydraulic leak check, pushback tug failure, and MEL sign-off delay.",
    factors: {
      severeWeather: "NONE",
      lateIncomingAircraft: "MINOR",
      atcCongestion: "NONE",
      crewRestLimits: "MINOR",
      mechanicalIssues: "CRITICAL",
      groundOpsDelays: "SEVERE",
      securityBackups: "NONE",
      passengerBoardingDelays: "MINOR",
      baggageHandlingIssues: "MINOR",
      waitingConnectingPax: "NONE",
      medicalEmergencyFlag: false,
    },
  },
  {
    id: "crew-timeout-bhs",
    title: "Crew Rest Timeout & Baggage Belt System Jam",
    description: "Flight deck crew hits Part 117 legal duty cap; baggage conveyor failure in Terminal 5.",
    factors: {
      severeWeather: "NONE",
      lateIncomingAircraft: "MODERATE",
      atcCongestion: "MINOR",
      crewRestLimits: "CRITICAL",
      mechanicalIssues: "NONE",
      groundOpsDelays: "MODERATE",
      securityBackups: "NONE",
      passengerBoardingDelays: "MODERATE",
      baggageHandlingIssues: "CRITICAL",
      waitingConnectingPax: "MODERATE",
      medicalEmergencyFlag: false,
    },
  },
  {
    id: "medical-in-flight",
    title: "Critical In-Flight Cardiac Emergency",
    description: "Passenger MEDIF alert triggers expedited priority descent and airport paramedic dispatch.",
    factors: {
      severeWeather: "NONE",
      lateIncomingAircraft: "MINOR",
      atcCongestion: "NONE",
      crewRestLimits: "NONE",
      mechanicalIssues: "NONE",
      groundOpsDelays: "NONE",
      securityBackups: "NONE",
      passengerBoardingDelays: "NONE",
      baggageHandlingIssues: "NONE",
      waitingConnectingPax: "NONE",
      medicalEmergencyFlag: true,
    },
  },
  {
    id: "terminal-security-surge",
    title: "Terminal Security Surge & Boarding Bottleneck",
    description: "Central checkpoint scanner failure causes massive concourse delays and late boarding.",
    factors: {
      severeWeather: "NONE",
      lateIncomingAircraft: "NONE",
      atcCongestion: "NONE",
      crewRestLimits: "NONE",
      mechanicalIssues: "NONE",
      groundOpsDelays: "MINOR",
      securityBackups: "CRITICAL",
      passengerBoardingDelays: "CRITICAL",
      baggageHandlingIssues: "MODERATE",
      waitingConnectingPax: "SEVERE",
      medicalEmergencyFlag: false,
    },
  },
];
