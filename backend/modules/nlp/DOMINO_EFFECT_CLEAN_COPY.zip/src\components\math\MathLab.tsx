import React, { useState } from "react";
import { Calculator, Cpu, TrendingDown, RefreshCw } from "lucide-react";

export const MathLab: React.FC = () => {
  // Preventor State
  const [tDelay, setTDelay] = useState<number>(30);
  const [tBuffer, setTBuffer] = useState<number>(35);
  const [deltaT, setDeltaT] = useState<number>(5);
  const [mct, setMct] = useState<number>(40);
  const [phiCrew, setPhiCrew] = useState<number>(0.72);
  const [w1, setW1] = useState<number>(0.35);
  const [w2, setW2] = useState<number>(0.45);
  const [w3, setW3] = useState<number>(0.2);

  // Manager Door-Hold State
  const [holdMin, setHoldMin] = useState<number>(5);
  const [fuelBurnPerMin, setFuelBurnPerMin] = useState<number>(1500);
  const [crewOtPerMin, setCrewOtPerMin] = useState<number>(500);
  const [paxCount, setPaxCount] = useState<number>(1);
  const [interlineTicketCost, setInterlineTicketCost] = useState<number>(43000);
  const [hotelCost, setHotelCost] = useState<number>(15000);
  const [mealsCost, setMealsCost] = useState<number>(4000);
  const [compensationCost, setCompensationCost] = useState<number>(8500);

  // Preventor Math
  const term1 = w1 * (tDelay / Math.max(1, tBuffer));
  const term2 = w2 * Math.max(0, 1 - deltaT / Math.max(1, mct));
  const term3 = w3 * phiCrew;
  const totalRiskScore = Math.min(1, Math.max(0, term1 + term2 + term3));
  const isIsolated = totalRiskScore >= 0.75;

  // Manager Math
  const costFuel = fuelBurnPerMin * holdMin;
  const costCrew = crewOtPerMin * holdMin;
  const totalHoldCost = costFuel + costCrew;

  const totalAbandonCost = (interlineTicketCost + hotelCost + mealsCost + compensationCost) * paxCount;
  const netSavings = totalAbandonCost - totalHoldCost;
  const isHoldApproved = totalHoldCost < totalAbandonCost && holdMin <= 15;

  const resetDefaults = () => {
    setTDelay(30);
    setTBuffer(35);
    setDeltaT(5);
    setMct(40);
    setPhiCrew(0.72);
    setW1(0.35);
    setW2(0.45);
    setW3(0.2);
    setHoldMin(5);
    setFuelBurnPerMin(1500);
    setCrewOtPerMin(500);
    setPaxCount(1);
    setInterlineTicketCost(43000);
    setHotelCost(15000);
    setMealsCost(4000);
    setCompensationCost(8500);
  };

  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/90 backdrop-blur-md overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950 text-slate-200">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-purple-950 border border-purple-800 text-purple-400">
            <Calculator className="h-4 w-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider">
              Decision Math & Cost Comparison Sandbox
            </h3>
            <p className="text-[10px] text-slate-400 font-mono">
              Interactive Disruption Spread Score & Door-Hold Cost Simulator
            </p>
          </div>
        </div>

        <button
          onClick={resetDefaults}
          className="flex items-center gap-1 px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition border border-slate-700"
        >
          <RefreshCw className="h-3 w-3" />
          <span>Reset Default Values</span>
        </button>
      </div>

      {/* Grid */}
      <div className="p-5 space-y-5 font-mono text-xs flex-1 overflow-y-auto">
        {/* SECTION 1: PREVENTOR CONTAGION RISK SCORE */}
        <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-4 shadow-lg">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Cpu className="h-4 w-4 text-sky-400" />
              <span className="text-sm font-bold text-white uppercase">
                1. Disruption Spread & Ripple Risk Formula
              </span>
            </div>
            <span
              className={`px-3 py-1 rounded-full font-bold text-xs border ${
                isIsolated
                  ? "bg-rose-950 text-rose-300 border-rose-600 animate-pulse"
                  : "bg-emerald-950 text-emerald-300 border-emerald-600"
              }`}
            >
              Risk Score = {totalRiskScore.toFixed(3)} · {isIsolated ? "DISRUPTION AUTOMATICALLY ISOLATED" : "FLIGHT NETWORK SAFE"}
            </span>
          </div>

          <div className="rounded-lg bg-slate-900 p-3 text-sky-300 text-[11px] font-semibold border border-slate-800 leading-relaxed">
            Risk Score = (0.35 × Delay Ratio) + (0.45 × Missed Connection Penalty) + (0.20 × Crew Timeout Risk)
          </div>

          {/* Sliders */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-[11px]">
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Inbound Delay:</span>
                <span className="text-white font-bold">{tDelay} mins</span>
              </div>
              <input
                type="range"
                min="0"
                max="90"
                value={tDelay}
                onChange={(e) => setTDelay(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Turnaround Buffer:</span>
                <span className="text-white font-bold">{tBuffer} mins</span>
              </div>
              <input
                type="range"
                min="10"
                max="60"
                value={tBuffer}
                onChange={(e) => setTBuffer(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Passenger Transfer Time:</span>
                <span className="text-white font-bold">{deltaT} mins</span>
              </div>
              <input
                type="range"
                min="0"
                max="60"
                value={deltaT}
                onChange={(e) => setDeltaT(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Crew Work Hours Limit Risk:</span>
                <span className="text-white font-bold">{(phiCrew * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={phiCrew * 100}
                onChange={(e) => setPhiCrew(Number(e.target.value) / 100)}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
            </div>
          </div>
        </div>

        {/* SECTION 2: MANAGER DOOR-HOLD OPTIMIZATION */}
        <div className="rounded-xl border border-slate-800 bg-slate-950 p-4 space-y-4 shadow-lg">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <TrendingDown className="h-4 w-4 text-emerald-400" />
              <span className="text-sm font-bold text-white uppercase">
                2. Door-Hold vs. Rebooking Cost Comparison Formula
              </span>
            </div>
            <span
              className={`px-3 py-1 rounded-full font-bold text-xs border ${
                isHoldApproved
                  ? "bg-emerald-950 text-emerald-300 border-emerald-600"
                  : "bg-rose-950 text-rose-300 border-rose-600"
              }`}
            >
              {isHoldApproved ? `HOLD APPROVED (${holdMin} min hold)` : "CLOSE DOOR & REBOOK"} · Net Savings: ₹{netSavings.toLocaleString('en-IN')}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            {/* C_hold Breakdown */}
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 space-y-2">
              <div className="flex justify-between text-slate-300 font-bold border-b border-slate-800 pb-1">
                <span>Cost to Hold Flight = Fuel (₹1,500/m) + Crew (₹500/m)</span>
                <span className="text-emerald-400 text-sm font-black">₹{totalHoldCost.toLocaleString('en-IN')}</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Door Hold Duration: <span className="text-white font-bold">{holdMin} minutes</span>
              </div>
              <input
                type="range"
                min="1"
                max="20"
                value={holdMin}
                onChange={(e) => setHoldMin(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
              />
            </div>

            {/* C_abandon Breakdown */}
            <div className="rounded-lg border border-slate-800 bg-slate-900 p-3 space-y-2">
              <div className="flex justify-between text-slate-300 font-bold border-b border-slate-800 pb-1">
                <span>Cost to Leave Passenger = Ticket + Hotel + Meals + Compensation</span>
                <span className="text-rose-400 text-sm font-black">₹{totalAbandonCost.toLocaleString('en-IN')}</span>
              </div>
              <div className="text-[11px] text-slate-400">
                Passengers at Risk of Missing Connection: <span className="text-white font-bold">{paxCount} travelers</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                value={paxCount}
                onChange={(e) => setPaxCount(Number(e.target.value))}
                className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
