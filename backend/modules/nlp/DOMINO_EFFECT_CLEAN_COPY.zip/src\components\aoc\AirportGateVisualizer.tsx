import React from "react";
import { Plane, Luggage, Navigation, ArrowRight, CheckCircle2, Clock, Footprints } from "lucide-react";
import type { FlightContext, BaggageTelemetry } from "../../types/simulation";

interface AirportGateVisualizerProps {
  flight: FlightContext;
  baggage: BaggageTelemetry;
  simMinute: number;
}

export const AirportGateVisualizer: React.FC<AirportGateVisualizerProps> = ({
  flight,
  baggage,
  simMinute,
}) => {
  const isGateSwapped = flight.currentArrivalGate === "B10" && flight.currentOutboundGate === "B12";

  return (
    <div className="flex flex-col h-full rounded-xl border border-slate-800 bg-slate-900/80 backdrop-blur-md overflow-hidden shadow-xl">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/70">
        <div className="flex items-center gap-2">
          <div className="p-1 rounded bg-teal-950 border border-teal-800 text-teal-400">
            <Navigation className="h-3.5 w-3.5" />
          </div>
          <div>
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">
              Airport Terminal Map & Gate Reassignment Visualizer
            </h3>
            <p className="text-[10px] text-slate-400">
              Boston Logan Airport — Walking distance cut from 18 min sprint to 1 min stroll
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono border bg-slate-900 border-slate-800">
            <Footprints className="h-3.5 w-3.5 text-teal-400" />
            <span className="text-slate-400">Walking Time:</span>
            <span className={isGateSwapped ? "font-bold text-emerald-400" : "font-bold text-rose-400"}>
              {isGateSwapped ? "1 min (25 meters)" : "18 mins (1,200 meters)"}
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Apron Floorplan Blueprint */}
      <div className="relative flex-1 bg-slate-950 p-4 flex flex-col justify-between overflow-hidden">
        {/* Terminal Outline */}
        <div className="relative w-full h-[240px] rounded-lg border border-slate-800/80 bg-slate-900/40 p-3 overflow-hidden">
          {/* Blueprint Grid Lines */}
          <div
            className="absolute inset-0 opacity-10 pointer-events-none"
            style={{
              backgroundImage:
                "linear-gradient(to right, #0ea5e9 1px, transparent 1px), linear-gradient(to bottom, #0ea5e9 1px, transparent 1px)",
              backgroundSize: "20px 20px",
            }}
          />

          {/* Terminal Zone Labels */}
          <div className="absolute top-2 left-3 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
            Terminal B (North Concourse)
          </div>
          <div className="absolute top-2 right-3 text-[10px] font-mono text-slate-500 uppercase tracking-wider">
            Terminal B (South Concourse)
          </div>
          <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 text-[10px] font-mono text-slate-600">
            Tarmac Apron & Ramp Taxiway Alpha
          </div>

          {/* Central Connecting Corridor */}
          <div className="absolute left-1/4 right-1/4 top-1/2 transform -translate-y-1/2 h-8 border-y border-dashed border-slate-700 bg-slate-800/20 flex items-center justify-center">
            <span className="text-[9px] font-mono text-slate-400 flex items-center gap-1">
              <Footprints className="h-3 w-3" />
              {isGateSwapped ? (
                <span className="text-emerald-400 font-bold">
                  Zero-Sprint Corridor (Adjacent Gate Hallway)
                </span>
              ) : (
                <span className="text-rose-400 animate-pulse">
                  18-Minute Cross-Terminal Sprint (MCT Breached)
                </span>
              )}
            </span>
          </div>

          {/* GATE B30 (Old Far Gate) */}
          <div
            className={`absolute left-6 top-8 w-28 rounded-lg border p-2 transition-all duration-500 ${
              isGateSwapped
                ? "border-slate-800 bg-slate-950/70 text-slate-500 opacity-60"
                : "border-rose-500 bg-rose-950/60 text-rose-300 shadow-[0_0_15px_rgba(244,63,94,0.2)]"
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-bold">
              <span>GATE B30</span>
              <span className="text-[9px] font-mono">Stand 30</span>
            </div>
            <div className="mt-1 text-[9px] text-slate-400">
              {isGateSwapped ? "De-allocated" : "Scheduled Arrival (AA142)"}
            </div>
            {!isGateSwapped && (
              <div className="mt-1 flex items-center gap-1 text-[8px] font-mono text-rose-400">
                <Clock className="h-2.5 w-2.5" /> 18m to Gate C14
              </div>
            )}
          </div>

          {/* GATE B10 (New Optimized Arrival Gate) */}
          <div
            className={`absolute left-[38%] top-8 w-32 rounded-lg border p-2 transition-all duration-500 ${
              isGateSwapped
                ? "border-emerald-500 bg-emerald-950/70 text-emerald-300 shadow-[0_0_18px_rgba(16,185,129,0.25)] ring-1 ring-emerald-400"
                : "border-slate-800 bg-slate-950 text-slate-500"
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-bold">
              <div className="flex items-center gap-1">
                <span>GATE B10</span>
                {isGateSwapped && <CheckCircle2 className="h-3 w-3 text-emerald-400" />}
              </div>
              <span className="text-[9px] font-mono">Stand 10</span>
            </div>
            <div className="mt-1 text-[9px] font-semibold text-white">
              {isGateSwapped ? "AA142 Inbound Arrival" : "Available Stand"}
            </div>
            {isGateSwapped && (
              <div className="mt-1 flex items-center gap-1 text-[8px] font-mono text-emerald-400">
                <Footprints className="h-2.5 w-2.5" /> 25m Walk to Gate B12
              </div>
            )}
          </div>

          {/* GATE B12 (Adjacent Optimized Departure Gate) */}
          <div
            className={`absolute right-[36%] top-8 w-32 rounded-lg border p-2 transition-all duration-500 ${
              isGateSwapped
                ? "border-sky-500 bg-sky-950/70 text-sky-300 shadow-[0_0_18px_rgba(56,189,248,0.25)] ring-1 ring-sky-400"
                : "border-slate-800 bg-slate-950 text-slate-500"
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-bold">
              <div className="flex items-center gap-1">
                <span>GATE B12</span>
                {isGateSwapped && <CheckCircle2 className="h-3 w-3 text-sky-400" />}
              </div>
              <span className="text-[9px] font-mono">Stand 12</span>
            </div>
            <div className="mt-1 text-[9px] font-semibold text-white">
              {isGateSwapped ? "AA142-LHR Departure" : "Connecting Flight"}
            </div>
            {isGateSwapped && (
              <div className="mt-1 flex items-center gap-1 text-[8px] font-mono text-sky-300">
                <Plane className="h-2.5 w-2.5 transform -rotate-45" /> Door Hold: 5m Approved
              </div>
            )}
          </div>

          {/* GATE B38 (Interline British Airways Backup Gate) */}
          <div
            className={`absolute right-4 top-8 w-32 rounded-lg border p-2 transition-all duration-500 ${
              simMinute >= 20
                ? "border-indigo-500 bg-indigo-950/70 text-indigo-300 shadow-[0_0_18px_rgba(99,102,241,0.25)]"
                : "border-slate-800 bg-slate-950/70 text-slate-500"
            }`}
          >
            <div className="flex items-center justify-between text-[10px] font-bold">
              <span>GATE B38</span>
              <span className="text-[9px] font-mono">Stand 38</span>
            </div>
            <div className="mt-1 text-[9px] font-semibold text-white">
              BA212 (18:00 UTC)
            </div>
            <div className="mt-1 text-[8px] font-mono text-indigo-400">
              {simMinute >= 20 ? "Interline Backup Rebooked" : "British Airways Stand"}
            </div>
          </div>

          {/* Tarmac Baggage Tug Movement Simulation */}
          <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between bg-slate-950/80 rounded-md border border-slate-800/80 px-3 py-1.5 font-mono text-[10px]">
            <div className="flex items-center gap-2">
              <Luggage className="h-3.5 w-3.5 text-amber-400 animate-bounce" />
              <span className="text-slate-400">Baggage Tug #BOS-82:</span>
              <span className="text-white font-bold">{baggage.bagId}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Route:</span>
              <span className="text-sky-300">{baggage.currentLocation}</span>
              <ArrowRight className="h-3 w-3 text-slate-500" />
              <span className="text-emerald-300 font-bold">{baggage.routedDestination}</span>
            </div>
            <div className="flex items-center gap-1 text-emerald-400 font-bold">
              <span>{baggage.status}</span>
            </div>
          </div>
        </div>

        {/* Bottom Optimization Summary */}
        <div className="mt-3 grid grid-cols-3 gap-2 text-xs font-mono">
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-2.5">
            <span className="text-slate-500 text-[10px]">ARRIVAL GATE</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-base font-bold text-sky-400">{flight.currentArrivalGate}</span>
              <span className="text-[10px] text-slate-400">
                {isGateSwapped ? "(Swapped from B30)" : "Scheduled"}
              </span>
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-2.5">
            <span className="text-slate-500 text-[10px]">CONNECTING GATE</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-base font-bold text-emerald-400">{flight.currentOutboundGate}</span>
              <span className="text-[10px] text-slate-400">
                {isGateSwapped ? "(Swapped from C14)" : "Scheduled"}
              </span>
            </div>
          </div>
          <div className="rounded-lg border border-slate-800 bg-slate-950 p-2.5">
            <span className="text-slate-500 text-[10px]">WALKING DISTANCE SAVED</span>
            <div className="mt-1 flex items-baseline justify-between">
              <span className="text-base font-bold text-teal-300">1,175 meters</span>
              <span className="text-[10px] text-emerald-400 font-bold">-17 mins sprint</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
