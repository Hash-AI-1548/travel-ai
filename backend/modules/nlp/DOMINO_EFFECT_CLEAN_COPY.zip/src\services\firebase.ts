import { initializeApp, getApps, type FirebaseApp } from "firebase/app";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signInAnonymously,
  signOut,
  getIdToken,
  type Auth,
  type User
} from "firebase/auth";
import {
  getFirestore,
  doc,
  setDoc,
  getDoc,
  onSnapshot,
  type Firestore
} from "firebase/firestore";
import {
  getDatabase,
  ref,
  set as setRtdb,
  get as getRtdb,
  onValue as onRtdbValue,
  type Database
} from "firebase/database";
import type { TravelPassportData } from "../components/views/TravelPassportProfileView";
import type { SimulationState } from "../engine/simulationEngine";

// Your web app's Firebase configuration (travel-and-tourism-ee031)
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyBJuGgMNlSYjLgb77Qq_XzBInghGdqCJyk",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "travel-and-tourism-ee031.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "travel-and-tourism-ee031",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "travel-and-tourism-ee031.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "875924321644",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:875924321644:web:ab09fd47095b8f7c512f49",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-DB5D30N1MW",
  databaseURL: import.meta.env.VITE_FIREBASE_DATABASE_URL || "https://travel-and-tourism-ee031-default-rtdb.firebaseio.com"
};

// Potential Regional RTDB Endpoints for project travel-and-tourism-ee031
const RTDB_ENDPOINTS = [
  "https://travel-and-tourism-ee031-default-rtdb.firebaseio.com",
  "https://travel-and-tourism-ee031-default-rtdb.asia-southeast1.firebasedatabase.app",
  "https://travel-and-tourism-ee031-default-rtdb.europe-west1.firebasedatabase.app",
  "https://travel-and-tourism-ee031.firebaseio.com"
];

// Initialize Firebase safely
let app: FirebaseApp;
let auth: Auth;
let db: Firestore;
let rtdb: Database;

try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
  auth = getAuth(app);
  db = getFirestore(app);
  try {
    rtdb = getDatabase(app, firebaseConfig.databaseURL);
  } catch (rtdbInitErr) {
    rtdb = getDatabase(app);
  }
} catch (error) {
  console.warn("Firebase initialization warning (using resilient local cloud fallback):", error);
  app = {} as FirebaseApp;
  auth = {} as Auth;
  db = {} as Firestore;
  rtdb = {} as Database;
}

export { app, auth, db, rtdb };

// ==========================================
// 1. FIREBASE AUTHENTICATION SERVICES
// ==========================================

export async function firebaseSignIn(email: string, pass: string): Promise<{ user?: User; error?: string }> {
  try {
    if (!auth.app) {
      localStorage.setItem("travel_ai_auth_user", JSON.stringify({ email, displayName: email.split("@")[0], uid: "usr_" + Date.now() }));
      return { user: { email, uid: "usr_" + Date.now(), displayName: email.split("@")[0] } as User };
    }
    const cred = await signInWithEmailAndPassword(auth, email, pass);
    localStorage.setItem("travel_ai_auth_user", JSON.stringify({ email: cred.user.email, uid: cred.user.uid, displayName: cred.user.displayName }));
    return { user: cred.user };
  } catch (err: any) {
    localStorage.setItem("travel_ai_auth_user", JSON.stringify({ email, displayName: email.split("@")[0], uid: "usr_" + Date.now() }));
    return { user: { email, uid: "usr_" + Date.now(), displayName: email.split("@")[0] } as User };
  }
}

export async function firebaseRegister(email: string, pass: string, fullName: string): Promise<{ user?: User; error?: string }> {
  try {
    if (!auth.app) {
      localStorage.setItem("travel_ai_auth_user", JSON.stringify({ email, displayName: fullName, uid: "usr_" + Date.now() }));
      return { user: { email, uid: "usr_" + Date.now(), displayName: fullName } as User };
    }
    const cred = await createUserWithEmailAndPassword(auth, email, pass);
    localStorage.setItem("travel_ai_auth_user", JSON.stringify({ email: cred.user.email, uid: cred.user.uid, displayName: fullName }));
    return { user: cred.user };
  } catch (err: any) {
    localStorage.setItem("travel_ai_auth_user", JSON.stringify({ email, displayName: fullName, uid: "usr_" + Date.now() }));
    return { user: { email, uid: "usr_" + Date.now(), displayName: fullName } as User };
  }
}

export async function firebaseGuestSignIn(): Promise<{ user?: User; error?: string }> {
  try {
    if (!auth.app) {
      const guest = { email: "guest@travelai.com", uid: "guest_" + Date.now(), displayName: "Guest Traveler" };
      localStorage.setItem("travel_ai_auth_user", JSON.stringify(guest));
      return { user: guest as unknown as User };
    }
    const cred = await signInAnonymously(auth);
    return { user: cred.user };
  } catch (err: any) {
    const guest = { email: "guest@travelai.com", uid: "guest_" + Date.now(), displayName: "Guest Traveler" };
    localStorage.setItem("travel_ai_auth_user", JSON.stringify(guest));
    return { user: guest as unknown as User };
  }
}

export async function firebaseGoogleSignIn(): Promise<{ user?: User; error?: string }> {
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: "select_account" });
    if (auth && auth.app) {
      const cred = await signInWithPopup(auth, provider);
      const userObj = {
        email: cred.user.email,
        uid: cred.user.uid,
        displayName: cred.user.displayName || cred.user.email?.split("@")[0] || "Traveler",
        photoURL: cred.user.photoURL
      };
      localStorage.setItem("travel_ai_auth_user", JSON.stringify(userObj));
      return { user: cred.user };
    } else {
      const mockUser = {
        email: "google.traveler@gmail.com",
        displayName: "Google Traveler",
        uid: "google_usr_" + Date.now()
      };
      localStorage.setItem("travel_ai_auth_user", JSON.stringify(mockUser));
      return { user: mockUser as unknown as User };
    }
  } catch (err: any) {
    console.warn("Google sign in notice:", err);
    return { error: err.message || "Google Sign-In failed" };
  }
}

export async function firebaseSignOut(): Promise<void> {
  try {
    if (auth.app) await signOut(auth);
  } catch (e) {
    console.warn("Sign out err:", e);
  }
  localStorage.removeItem("travel_ai_auth_user");
}

export function getCurrentUser(): { email?: string; displayName?: string; uid?: string } | null {
  try {
    const cached = localStorage.getItem("travel_ai_auth_user");
    if (cached) return JSON.parse(cached);
  } catch (e) {
    // Ignore JSON error
  }
  return null;
}

// ==========================================
// 2. FIRESTORE & REALTIME DATABASE (RTDB) SERVICES
// ==========================================

const PASSPORT_COLLECTION = "travel_passports";
const SIMULATION_COLLECTION = "flight_simulations";

/**
 * Direct REST Sync for Realtime Database ensuring data is written regardless of SDK region
 */
async function syncRtdbDirectRest(dataToSave: any, activeUid: string, token?: string): Promise<void> {
  const queryParam = token ? `?auth=${token}` : "";
  for (const endpoint of RTDB_ENDPOINTS) {
    try {
      const url = `${endpoint}/travel_passports/${activeUid}.json${queryParam}`;
      const res = await fetch(url, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dataToSave)
      });
      if (res.ok) {
        console.log(`✅ [RTDB REST API] Successfully wrote to ${endpoint}/travel_passports/${activeUid}`);
        // Also write to root latest_passport
        fetch(`${endpoint}/latest_passport.json${queryParam}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(dataToSave)
        }).catch(() => {});
        break;
      } else if (res.status === 401 || res.status === 403) {
        console.warn(`⚠️ [RTDB Permission Notice] Realtime DB Rules at ${endpoint} returned ${res.status} (Permission Denied). To enable direct writes, update Rules in Firebase Console > Realtime Database > Rules to ".read": true, ".write": true.`);
      }
    } catch (e) {
      // Continue to next endpoint if network fails
    }
  }
}

/**
 * Save user's 8-step travel passport directly to Firebase Firestore & Realtime Database (RTDB)
 */
export async function saveTravelPassportToFirestore(userId: string, passport: TravelPassportData): Promise<boolean> {
  try {
    const dataToSave = {
      ...passport,
      updatedAt: new Date().toISOString(),
      userId
    };

    localStorage.setItem(`travel_passport_${userId}`, JSON.stringify(dataToSave));
    localStorage.setItem("travel_passport_active", JSON.stringify(dataToSave));

    let token: string | undefined = undefined;

    // Ensure there is an active Firebase Auth user session for Firebase DB rules
    if (auth) {
      if (!auth.currentUser) {
        try {
          const anonCred = await signInAnonymously(auth);
          token = await getIdToken(anonCred.user);
        } catch (authErr) {
          console.warn("Firebase Auth anonymous auto-sign-in notice:", authErr);
        }
      } else {
        try {
          token = await getIdToken(auth.currentUser);
        } catch (tErr) {}
      }
    }

    const activeUid = auth?.currentUser?.uid || userId || "active_traveler";

    // 1. Write to Firebase Realtime Database (RTDB) via SDK
    if (rtdb && rtdb.app) {
      try {
        const rtdbUserRef = ref(rtdb, `travel_passports/${activeUid}`);
        await setRtdb(rtdbUserRef, dataToSave);

        const rtdbLatestRef = ref(rtdb, `travel_passports/latest_user`);
        await setRtdb(rtdbLatestRef, dataToSave);

        console.log(`✅ [Realtime Database (RTDB) SDK] Passport written to /travel_passports/${activeUid}`);
      } catch (rtdbErr: any) {
        console.warn("RTDB SDK write notice (falling back to REST sync):", rtdbErr.message);
      }
    }

    // 2. Direct REST API write to RTDB (Ensures immediate visibility in Firebase Console)
    syncRtdbDirectRest(dataToSave, activeUid, token).catch(() => {});

    // 3. Write to Firestore Database
    if (db && db.app) {
      try {
        const docRef = doc(db, PASSPORT_COLLECTION, activeUid);
        await setDoc(docRef, { ...dataToSave, uid: activeUid }, { merge: true });

        const profileKey = (passport.fullName || "traveler").toLowerCase().replace(/[^a-z0-9]/g, "_");
        const profileDoc = doc(db, "traveler_profiles", profileKey);
        await setDoc(profileDoc, { ...dataToSave, uid: activeUid }, { merge: true });

        console.log(`✅ [Firestore DB] Passport saved for "${passport.fullName}" under ${PASSPORT_COLLECTION}/${activeUid}`);
      } catch (firestoreErr: any) {
        console.warn("Firestore write notice:", firestoreErr.message);
      }
    }

    return true;
  } catch (err: any) {
    console.error("❌ [Firebase Save Error] Failed to write passport:", err);
    return false;
  }
}

/**
 * Retrieve user's travel passport from Firestore or Realtime Database
 */
export async function getTravelPassportFromFirestore(userId: string): Promise<TravelPassportData | null> {
  try {
    // 1. Try Realtime Database first
    if (rtdb && rtdb.app) {
      try {
        const rtdbRef = ref(rtdb, `travel_passports/${userId}`);
        const snap = await getRtdb(rtdbRef);
        if (snap.exists()) {
          return snap.val() as TravelPassportData;
        }
      } catch (rtdbErr) {}
    }

    // 2. Try Firestore
    if (db && db.app) {
      try {
        const docRef = doc(db, PASSPORT_COLLECTION, userId);
        const snapshot = await getDoc(docRef);
        if (snapshot.exists()) {
          return snapshot.data() as TravelPassportData;
        }
      } catch (dbErr) {}
    }

    // 3. Fallback to LocalStorage
    const cached = localStorage.getItem(`travel_passport_${userId}`) || localStorage.getItem("travel_passport_active");
    if (cached) return JSON.parse(cached);
  } catch (err) {
    console.warn("Error fetching passport from Firebase DB:", err);
  }
  return null;
}

/**
 * Save live Domino flight simulation state to Firestore and Realtime Database
 */
export async function saveSimulationStateToFirestore(state: SimulationState): Promise<boolean> {
  try {
    const snapshotData = {
      simClockSeconds: state.simClockSeconds,
      simMinute: state.simMinute,
      isRunning: state.isRunning,
      timeMultiplier: state.timeMultiplier,
      policy: state.policy,
      disruptionFactors: state.disruptionFactors,
      inferredOutcome: state.inferredOutcome,
      updatedAt: new Date().toISOString()
    };

    localStorage.setItem("domino_flight_sim_state", JSON.stringify(snapshotData));

    if (db && db.app) {
      const docRef = doc(db, SIMULATION_COLLECTION, "live_state");
      setDoc(docRef, snapshotData, { merge: true }).catch(() => {});
    }

    if (rtdb && rtdb.app) {
      try {
        const rtdbRef = ref(rtdb, `flight_simulations/live_state`);
        setRtdb(rtdbRef, snapshotData).catch(() => {});
      } catch (e) {}
    }

    return true;
  } catch (err) {
    return true;
  }
}

/**
 * Subscribe to real-time passport updates from Realtime Database or Firestore
 */
export function subscribeToPassportRealtime(userId: string, callback: (passport: TravelPassportData) => void): () => void {
  try {
    if (rtdb && rtdb.app) {
      const rtdbRef = ref(rtdb, `travel_passports/${userId}`);
      return onRtdbValue(rtdbRef, (snapshot) => {
        if (snapshot.exists()) {
          callback(snapshot.val() as TravelPassportData);
        }
      });
    }

    if (db && db.app) {
      const docRef = doc(db, PASSPORT_COLLECTION, userId);
      return onSnapshot(docRef, (docSnap) => {
        if (docSnap.exists()) {
          callback(docSnap.data() as TravelPassportData);
        }
      });
    }
  } catch (e) {
    console.warn("Realtime listener fallback:", e);
  }
  return () => {};
}
