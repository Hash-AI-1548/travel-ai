import { useEffect, useState, lazy, Suspense } from "react";
import { simulationEngine } from "./engine/simulationEngine";
import type { SimulationState } from "./engine/simulationEngine";
import { TopNavBar, type AOCViewTab } from "./components/aoc/TopNavBar";
import { LeftSidebarNav } from "./components/layout/LeftSidebarNav";
import { DynamicOperationsView } from "./components/views/DynamicOperationsView";
import { TravelPassportProfileView, type TravelPassportData, PROFILE_EURO_TRAVELER } from "./components/views/TravelPassportProfileView";
import { firebaseSignOut } from "./services/firebase";
import type { PolicyMode, ScenarioType } from "./types/simulation";
import type { DisruptionFactors } from "./types/disruption";

// Lazy-load heavy views for ultra-fast LCP (< 1.0s) and minimal main-thread bundle parse time
const GeospatialRadarMap = lazy(() =>
  import("./components/map/GeospatialRadarMap").then((m) => ({ default: m.GeospatialRadarMap }))
);
const AirportTerminalIndoorMap = lazy(() =>
  import("./components/map/AirportTerminalIndoorMap").then((m) => ({ default: m.AirportTerminalIndoorMap }))
);
const RecoveryInterlineView = lazy(() =>
  import("./components/views/RecoveryInterlineView").then((m) => ({ default: m.RecoveryInterlineView }))
);
const CarePolicyView = lazy(() =>
  import("./components/views/CarePolicyView").then((m) => ({ default: m.CarePolicyView }))
);
const CriticalMedicalView = lazy(() =>
  import("./components/views/CriticalMedicalView").then((m) => ({ default: m.CriticalMedicalView }))
);
const MathLab = lazy(() =>
  import("./components/math/MathLab").then((m) => ({ default: m.MathLab }))
);
const DisruptionStudioSidebar = lazy(() =>
  import("./components/sidebar/DisruptionStudioSidebar").then((m) => ({ default: m.DisruptionStudioSidebar }))
);

const OCCLoadingFallback = () => (
  <div className="flex h-full w-full items-center justify-center bg-[#040811] text-slate-400 font-mono text-xs gap-2 select-none">
    <div className="h-4 w-4 rounded-full border-2 border-sky-500 border-t-transparent animate-spin" />
    <span>Loading telemetry view...</span>
  </div>
);

const EMPTY_PASSPORT: TravelPassportData = { ...PROFILE_EURO_TRAVELER };

export function App() {
  const [state, setState] = useState<SimulationState>(simulationEngine.getState());
  // Stage 1: "PROFILE" (Standalone profile window for first-time / non-authenticated users)
  // Stage 2: "DOMINO_WINDOW" (Full Domino Effect flight operations platform for active/signed-in users)
  const [appStage, setAppStage] = useState<"PROFILE" | "DOMINO_WINDOW">(() => {
    try {
      const savedStage = localStorage.getItem("domino_app_stage");
      const authUser = localStorage.getItem("travel_ai_auth_user");
      // If user has already launched operations or signed in, stay in flight operations deck on reload!
      if (savedStage === "DOMINO_WINDOW" || authUser) {
        return "DOMINO_WINDOW";
      }
    } catch (e) {}
    return "PROFILE";
  });
  const [activeTab, setActiveTab] = useState<AOCViewTab>("OPERATIONS");
  const [isStudioOpen, setIsStudioOpen] = useState<boolean>(false);

  // Active persistent passport state across all screens
  const [passport, setPassport] = useState<TravelPassportData>(() => {
    try {
      const cached = localStorage.getItem("travel_passport_active");
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed && parsed.fullName) return parsed;
      }
    } catch (e) {}
    return EMPTY_PASSPORT;
  });

  useEffect(() => {
    const unsubscribe = simulationEngine.subscribe((newState) => {
      setState(newState);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (passport && passport.fullName && passport.fullName.trim()) {
      const tier: "DIAMOND_MEDALLION" | "FIRST_CLASS" | "BUSINESS" | "ECONOMY" =
        passport.budgetTier === "premium_luxury"
          ? "DIAMOND_MEDALLION"
          : passport.budgetTier === "moderate"
          ? "BUSINESS"
          : "ECONOMY";

      const isWheelchair = Boolean(
        passport.accessibilityMobility ||
        passport.accessibilityCustom?.toLowerCase().includes("wheelchair")
      );

      simulationEngine.setPassengerFromPassport(passport.fullName.trim(), tier, {
        isWheelchairUser: isWheelchair,
        specialAssistance: isWheelchair ? "WHEELCHAIR_REQUIRED" : "STANDARD",
        dietaryPreferences: passport.dietaryStandards,
        allergies: passport.allergies,
        autoRebookOnDelay: passport.autoRebookOnDelay,
        autoRebookDelayThresholdMinutes: passport.autoRebookDelayThresholdMinutes,
        isEmergencyTraveler: passport.isEmergencyTraveler,
        emergencyReason: passport.emergencyReason,
        allowCompetitorInterlineRebooking: passport.allowCompetitorInterlineRebooking,
        preferredCompetitorAirlines: passport.preferredCompetitorAirlines,
        autoUpgradeSeatAllowed: passport.autoUpgradeSeatAllowed
      });
    }
  }, [passport]);

  const handlePolicyChange = (policy: PolicyMode) => simulationEngine.setPolicy(policy);
  const handleMedicalTrigger = () => {
    simulationEngine.triggerMedicalEmergency();
    setActiveTab("MEDICAL");
  };

  const handleApplyDisruptionFactors = (factors: DisruptionFactors) => {
    simulationEngine.applyDisruptionFactors(factors);
  };

  const handleProceedToFlightOperations = (customPassport?: TravelPassportData) => {
    const safePassport = customPassport || passport;
    setPassport(safePassport);
    localStorage.setItem("travel_passport_active", JSON.stringify(safePassport));
    localStorage.setItem("domino_app_stage", "DOMINO_WINDOW");

    const tier: "DIAMOND_MEDALLION" | "FIRST_CLASS" | "BUSINESS" | "ECONOMY" =
      safePassport.budgetTier === "premium_luxury"
        ? "DIAMOND_MEDALLION"
        : safePassport.budgetTier === "moderate"
        ? "BUSINESS"
        : "ECONOMY";

    const isWheelchair = Boolean(
      safePassport.accessibilityMobility ||
      safePassport.accessibilityCustom?.toLowerCase().includes("wheelchair")
    );

    simulationEngine.setPassengerFromPassport(safePassport.fullName, tier, {
      isWheelchairUser: isWheelchair,
      specialAssistance: isWheelchair ? "WHEELCHAIR_REQUIRED" : "STANDARD",
      dietaryPreferences: safePassport.dietaryStandards,
      allergies: safePassport.allergies,
      autoRebookOnDelay: safePassport.autoRebookOnDelay,
      autoRebookDelayThresholdMinutes: safePassport.autoRebookDelayThresholdMinutes,
      isEmergencyTraveler: safePassport.isEmergencyTraveler,
      emergencyReason: safePassport.emergencyReason,
      allowCompetitorInterlineRebooking: safePassport.allowCompetitorInterlineRebooking,
      preferredCompetitorAirlines: safePassport.preferredCompetitorAirlines,
      autoUpgradeSeatAllowed: safePassport.autoUpgradeSeatAllowed
    });

    setAppStage("DOMINO_WINDOW");
    setActiveTab("OPERATIONS");
  };

  const handleReturnToProfile = () => {
    setAppStage("PROFILE");
  };

  const handleSignOut = async () => {
    await firebaseSignOut();
    localStorage.removeItem("domino_app_stage");
    localStorage.removeItem("travel_ai_auth_user");
    localStorage.removeItem("travel_passport_active");
    setPassport(EMPTY_PASSPORT);
    simulationEngine.setPassengerFromPassport("Traveler", "ECONOMY");
    setAppStage("PROFILE");
  };

  const handlePlay = () => simulationEngine.start();
  const handlePause = () => simulationEngine.pause();
  const handleReset = (scenario?: ScenarioType) => simulationEngine.reset(scenario);
  const handleSpeedChange = (speed: number) => simulationEngine.setSpeed(speed);
  const handleScenarioChange = (scenario: ScenarioType) => simulationEngine.reset(scenario);

  // STAGE 1: ONLY render the standalone Travel AI Profile window
  if (appStage === "PROFILE") {
    return (
      <TravelPassportProfileView
        state={state}
        passport={passport}
        onUpdatePassport={(p) => {
          setPassport(p);
          localStorage.setItem("travel_passport_active", JSON.stringify(p));
        }}
        onProceedToOperations={handleProceedToFlightOperations}
        onSignOut={handleSignOut}
      />
    );
  }

  // STAGE 2: Render the DOMINO EFFECT Flight Operations Window with Left Sidebar + Top Header
  return (
    <div className="flex h-screen w-screen bg-[#040811] text-slate-100 overflow-hidden font-sans relative">
      {/* Left Sidebar Navigation */}
      <LeftSidebarNav
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === "PROFILE") {
            handleReturnToProfile();
          } else {
            setActiveTab(tab);
          }
        }}
        state={state}
      />

      {/* Main Content Area with Header */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Global Navigation Bar */}
        <TopNavBar
          state={state}
          activeTab={activeTab}
          passport={passport}
          onSignOut={handleSignOut}
          onTabChange={(tab) => {
            if (tab === "PROFILE") {
              handleReturnToProfile();
            } else {
              setActiveTab(tab);
            }
          }}
          onOpenStudio={() => setIsStudioOpen(true)}
        />

        {/* Main Viewport Content */}
        <main className="flex-1 overflow-hidden bg-[#040811]">
          <Suspense fallback={<OCCLoadingFallback />}>
            {activeTab === "OPERATIONS" && (
              <DynamicOperationsView
                state={state}
                onOpenMap={() => setActiveTab("MAP")}
                onOpenTerminalMap={() => setActiveTab("TERMINAL_MAP")}
                onOpenStudio={() => setIsStudioOpen(true)}
                onPlay={handlePlay}
                onPause={handlePause}
                onReset={handleReset}
                onSpeedChange={handleSpeedChange}
                onScenarioChange={handleScenarioChange}
                onMedicalTrigger={() => simulationEngine.triggerMedicalEmergency()}
              />
            )}
            {activeTab === "MAP" && (
              <div className="p-4 h-full w-full bg-[#040811]">
                <GeospatialRadarMap state={state} height="100%" />
              </div>
            )}
            {activeTab === "TERMINAL_MAP" && (
              <div className="p-4 h-full w-full bg-[#040811]">
                <AirportTerminalIndoorMap state={state} />
              </div>
            )}
            {activeTab === "RECOVERY" && <RecoveryInterlineView state={state} />}
            {activeTab === "CARE" && <CarePolicyView state={state} onPolicyChange={handlePolicyChange} />}
            {activeTab === "MEDICAL" && <CriticalMedicalView state={state} onTriggerEmergency={handleMedicalTrigger} />}
            {activeTab === "MATH" && (
              <div className="p-4 h-full bg-[#040811]">
                <MathLab />
              </div>
            )}
          </Suspense>
        </main>
      </div>

      {/* Real-time Operational Disruption Scene Creator Sidebar Drawer */}
      <Suspense fallback={null}>
        <DisruptionStudioSidebar
          isOpen={isStudioOpen}
          onClose={() => setIsStudioOpen(false)}
          currentFactors={state.disruptionFactors}
          onApplyFactors={handleApplyDisruptionFactors}
        />
      </Suspense>
    </div>
  );
}

export default App;

