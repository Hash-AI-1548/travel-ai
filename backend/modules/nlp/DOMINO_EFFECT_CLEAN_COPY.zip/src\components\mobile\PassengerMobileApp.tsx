import React, { useState } from "react";
import {
  Plane,
  Luggage,
  Hotel,
  Utensils,
  MapPin,
  QrCode,
  Wifi,
  Battery,
  Signal,
  Key,
  Bus,
  Sparkles,
  HeartPulse,
  CheckCircle2,
} from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import { sounds } from "../../utils/audio";

interface PassengerMobileAppProps {
  state: SimulationState;
  onTriggerEmergency: () => void;
}

export const PassengerMobileApp: React.FC<PassengerMobileAppProps> = ({
  state,
  onTriggerEmergency,
}) => {
  const [activeTab, setActiveTab] = useState<"FLIGHT" | "GATE" | "CARE" | "BAGS" | "MEDICAL">("FLIGHT");
  const [nfcUnlocked, setNfcUnlocked] = useState<boolean>(false);
  const [redeemedVouchers, setRedeemedVouchers] = useState<Record<string, boolean>>({});

  const { flight, passenger, baggage, overnightCare, simMinute } = state;
  const isRebooked = !!passenger.recoveryAllocation;
  const isCareActive = overnightCare.triggered;

  const toggleVoucher = (voucherId: string) => {
    setRedeemedVouchers((prev) => ({ ...prev, [voucherId]: !prev[voucherId] }));
    sounds.playSuccessChime();
  };

  const unlockHotelRoom = () => {
    setNfcUnlocked(true);
    sounds.playSuccessChime();
    setTimeout(() => setNfcUnlocked(false), 3500);
  };

  return (
    <div className="flex items-center justify-center p-2 sm:p-4 select-none">
      {/* iPhone 16 Pro Style Hardware Frame */}
      <div className="relative w-full max-w-[390px] h-[780px] rounded-[52px] bg-slate-950 p-3.5 shadow-[0_0_60px_rgba(0,0,0,0.85)] border-[5px] border-slate-800 ring-1 ring-slate-700/60 flex flex-col justify-between overflow-hidden">
        {/* Hardware Dynamic Island & Speaker */}
        <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-50 flex items-center justify-center">
          <div className="h-6 w-28 bg-black rounded-full border border-slate-800 flex items-center justify-between px-2.5 shadow-inner">
            <div className="h-2.5 w-2.5 rounded-full bg-slate-900 border border-slate-700" />
            <div className="flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="text-[8px] font-mono text-emerald-400 font-bold">AI PROTECTED</span>
            </div>
          </div>
        </div>

        {/* Status Bar */}
        <div className="flex items-center justify-between px-6 pt-1 text-[11px] font-mono text-slate-300 z-40">
          <span>16:{state.simMinute < 10 ? `0${state.simMinute}` : state.simMinute}</span>
          <div className="flex items-center gap-2">
            <Wifi className="h-3.5 w-3.5 text-sky-400" />
            <Signal className="h-3 w-3 text-slate-400" />
            <Battery className="h-4 w-4 text-emerald-400" />
          </div>
        </div>

        {/* App Main Body */}
        <div className="flex-1 flex flex-col pt-6 pb-2 overflow-y-auto px-1">
          {/* Airline Header */}
          <div className="flex items-center justify-between px-3 py-1 mb-2">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-sky-600 text-white font-black text-xs shadow-md">
                AA
              </div>
              <div>
                <span className="text-xs font-black text-white uppercase tracking-wider">
                  American Airlines
                </span>
                <p className="text-[9px] text-slate-400 font-mono">
                  Concierge Live Radar · {passenger.tier.replace("_", " ")}
                </p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-sky-400 bg-sky-950/80 px-2 py-0.5 rounded border border-sky-800">
              {passenger.name}
            </span>
          </div>

          {/* Real-Time Live Disruption Notice & Pilot ACARS Message Card */}
          {flight.delayMinutes > 0 && !isCareActive && (
            <div className="mx-2 mb-3 rounded-2xl border border-sky-500/40 bg-gradient-to-br from-sky-950/70 via-slate-900 to-indigo-950/70 p-3 shadow-lg space-y-2">
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="flex items-center gap-1.5 text-sky-300">
                  <Sparkles className="h-3.5 w-3.5 text-sky-400 animate-spin-slow" />
                  Connection Immunized
                </span>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700">
                  {simMinute >= 10 ? "Gate Swap Active" : "Auto-Pilot Active"}
                </span>
              </div>

              <p className="text-[11px] text-slate-200 leading-snug">
                {state.passengerBriefing?.body || (simMinute >= 10
                  ? "Don't run across Boston airport! Your London plane was moved to Gate B12, right across the hallway from your landing gate (25m walk)."
                  : "Your NYC flight is 30m late. The AI engine is already securing adjacent gates & backup protection.")}
              </p>

              {/* Direct Pilot ACARS Hold Confirmation */}
              <div className="p-2 rounded-xl bg-[#040813] border border-sky-800/60 text-[10px] font-mono text-sky-300 flex items-start gap-2">
                <span className="text-xs">👨‍✈️</span>
                <div>
                  <span className="font-bold text-white block">Flight Deck Datalink (Capt. David Thorne)</span>
                  <span className="text-[9px] text-emerald-400">
                    {state.passengerBriefing?.pilotMessage || "Confirmed gate hold at B12 (Boeing 787-9). Doors armed and waiting for your transfer."}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 1: FLIGHT STATUS & BOARDING PASS */}
          {activeTab === "FLIGHT" && (
            <div className="space-y-3 px-2">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 shadow-md font-mono text-xs">
                <div className="flex items-center justify-between text-slate-400 text-[10px] pb-2 border-b border-slate-800">
                  <span>FLIGHT {flight.flightNumber}</span>
                  <span className="text-amber-400 font-bold">30m Departure Delay</span>
                </div>

                <div className="mt-3 flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-2xl font-black text-white">JFK</span>
                    <span className="block text-[10px] text-slate-400">New York</span>
                    <span className="text-[10px] text-slate-400">16:00 UTC</span>
                  </div>

                  <div className="flex-1 px-4 flex flex-col items-center">
                    <span className="text-[9px] text-sky-400 font-bold mb-1">
                      {flight.telemetry.etaMinutes > 0
                        ? `Landing in ${flight.telemetry.etaMinutes}m`
                        : "Landed at BOS"}
                    </span>
                    <div className="relative w-full flex items-center">
                      <div className="h-0.5 w-full bg-slate-700" />
                      <Plane className="absolute left-1/2 transform -translate-x-1/2 -rotate-45 h-4 w-4 text-sky-400 animate-pulse" />
                    </div>
                    <span className="text-[8px] text-slate-500 mt-1">
                      {flight.telemetry.altitudeFt > 0
                        ? `${flight.telemetry.altitudeFt.toLocaleString()} ft · ${flight.telemetry.groundSpeedKts} kts`
                        : "Taxiing to Gate B10"}
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-2xl font-black text-white">BOS</span>
                    <span className="block text-[10px] text-slate-400">Boston Logan</span>
                    <span className="text-[10px] text-sky-400 font-bold">17:00 UTC</span>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 rounded-xl bg-slate-950 p-2.5 text-center text-[10px]">
                  <div>
                    <span className="text-slate-500">GATE</span>
                    <span className="block text-sm font-bold text-sky-400">
                      {flight.currentArrivalGate}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500">SEAT</span>
                    <span className="block text-sm font-bold text-white">{passenger.seat}</span>
                  </div>
                  <div>
                    <span className="text-slate-500">STATUS</span>
                    <span className="block text-[10px] font-bold text-emerald-400">IN-AIR</span>
                  </div>
                </div>
              </div>

              {isRebooked && (
                <div className="rounded-2xl border border-indigo-500/80 bg-gradient-to-b from-indigo-950/80 to-slate-950 p-4 shadow-xl font-mono text-xs">
                  <div className="flex items-center justify-between text-[10px] pb-2 border-b border-indigo-900/60">
                    <span className="font-bold text-indigo-300 flex items-center gap-1">
                      <Sparkles className="h-3 w-3" /> ZERO-TOUCH BACKUP TICKET
                    </span>
                    <span className="px-2 py-0.5 rounded bg-indigo-900 text-indigo-200 text-[9px] font-bold">
                      CONFIRMED SEAT
                    </span>
                  </div>

                  <div className="mt-3 flex items-center justify-between">
                    <div>
                      <span className="text-lg font-black text-white">BA 212</span>
                      <span className="block text-[10px] text-slate-400">British Airways</span>
                    </div>
                    <div className="text-right">
                      <span className="text-lg font-black text-indigo-400">18:00 UTC</span>
                      <span className="block text-[10px] text-slate-400">Gate B38 · Seat 12A</span>
                    </div>
                  </div>

                  <div className="mt-3 rounded-lg bg-white p-2.5 flex flex-col items-center justify-center">
                    <div className="h-8 w-full bg-slate-900 flex items-center justify-around px-2">
                      {Array.from({ length: 32 }).map((_, i) => (
                        <div
                          key={i}
                          className={`h-full ${i % 3 === 0 ? "w-1 bg-white" : "w-0.5 bg-slate-400"}`}
                        />
                      ))}
                    </div>
                    <span className="mt-1 text-[8px] font-mono text-slate-900 font-bold">
                      QR-BA212-PAX9921-12A
                    </span>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: TERMINAL GATE NAVIGATION */}
          {activeTab === "GATE" && (
            <div className="space-y-3 px-2">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 font-mono text-xs">
                <div className="flex items-center justify-between text-[10px] pb-2 border-b border-slate-800">
                  <span className="font-bold text-slate-300 flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5 text-teal-400" /> BOSTON LOGAN (BOS) INDOOR RADAR
                  </span>
                  <span className="text-emerald-400 font-bold">{state.inferredOutcome?.walkingTimeMins || 1} Min Walk</span>
                </div>

                <div className="mt-3 space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-sky-950 text-sky-400 border border-sky-800 font-bold text-xs">
                      1
                    </div>
                    <div>
                      <span className="font-bold text-white">Arrive at {state.inferredOutcome?.arrivalGate || state.flight.currentArrivalGate || "Gate B10"}</span>
                      <p className="text-[10px] text-slate-400">Exit jet bridge from Flight AA142</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold text-xs">
                      2
                    </div>
                    <div>
                      <span className="font-bold text-emerald-300">
                        {state.inferredOutcome?.walkingDistanceMeters === 25
                          ? "Walk Across the Hallway (25m)"
                          : `Transfer to Boarding Bay (${state.inferredOutcome?.walkingDistanceMeters || 25}m)`}
                      </span>
                      <p className="text-[10px] text-slate-400">
                        Direct line of sight to {state.inferredOutcome?.outboundGate || state.flight.currentOutboundGate || "Gate B12"} without security re-check
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-indigo-950 text-indigo-400 border border-indigo-800 font-bold text-xs">
                      3
                    </div>
                    <div>
                      <span className="font-bold text-indigo-300">
                        Board London Flight at {state.inferredOutcome?.outboundGate || state.flight.currentOutboundGate || "Gate B12"}
                      </span>
                      <p className="text-[10px] text-slate-400">
                        {state.inferredOutcome?.doorHoldFeasibility === "HOLD_APPROVED"
                          ? `Door held ${state.inferredOutcome?.doorHoldMinutes} minutes for your arrival`
                          : "Direct jetbridge connection on schedule"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: OVERNIGHT CARE SUITE / DIRECT CONNECTION */}
          {activeTab === "CARE" && (
            <div className="space-y-3 px-2">
              {!isCareActive && !isRebooked ? (
                <div className="rounded-2xl border border-emerald-500/80 bg-gradient-to-b from-emerald-950/80 to-slate-950 p-4 font-mono text-xs shadow-xl space-y-3">
                  <div className="flex items-center justify-between text-[10px] pb-2 border-b border-emerald-900">
                    <span className="font-bold text-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" /> DIRECT CONNECTION SECURED
                    </span>
                    <span className="px-2 py-0.5 rounded bg-emerald-900 text-emerald-200 text-[9px] font-bold">
                      NO HOTEL REQUIRED
                    </span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-sm font-bold text-white block">
                      Flight AA142-LHR Waiting at Gate B12
                    </span>
                    <p className="text-[11px] text-slate-300 font-sans leading-relaxed">
                      Capt. David Thorne has confirmed the boarding door hold at adjacent Gate B12 (25m stroll from arrival Gate B10).
                    </p>
                    <div className="p-2 rounded-xl bg-emerald-950/50 border border-emerald-700/60 text-[10px] text-emerald-300 font-mono mt-2">
                      ✓ Direct boarding maintained · No overnight hotel or competitor rebooking needed.
                    </div>
                  </div>

                  <button
                    onClick={unlockHotelRoom}
                    className={`mt-2 w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                      nfcUnlocked
                        ? "bg-emerald-600 text-white shadow-lg"
                        : "bg-emerald-700 hover:bg-emerald-600 text-white shadow-md shadow-emerald-900/50"
                    }`}
                  >
                    <Plane className="h-4 w-4" />
                    <span>{nfcUnlocked ? "✓ Gate B12 Fast-Track Jetbridge Clearance Validated" : "Tap for Gate B12 Boarding NFC"}</span>
                  </button>
                </div>
              ) : (
                <>
                  <div className="rounded-2xl border border-purple-500/80 bg-gradient-to-b from-purple-950/80 to-slate-950 p-4 font-mono text-xs shadow-xl">
                    <div className="flex items-center justify-between text-[10px] pb-2 border-b border-purple-900">
                      <span className="font-bold text-purple-200 flex items-center gap-1">
                        <Hotel className="h-3.5 w-3.5" /> AUTOMATED HOTEL RESERVATION
                      </span>
                      <span className="px-2 py-0.5 rounded bg-purple-900 text-purple-200 text-[9px] font-bold">
                        {overnightCare.isCarrierFunded ? "AIRLINE PAID (100%)" : "SELF-PAY ASSIST"}
                      </span>
                    </div>

                    <div className="mt-3">
                      <span className="text-sm font-bold text-white">
                        {overnightCare.hotelReservation.hotelName}
                      </span>
                      <p className="text-[10px] text-slate-400 mt-0.5">
                        {overnightCare.hotelReservation.address}
                      </p>
                      <div className="mt-2 text-xs font-bold text-purple-300">
                        Room: {overnightCare.hotelReservation.roomNumber}
                      </div>
                    </div>

                    <button
                      onClick={unlockHotelRoom}
                      className={`mt-3 w-full py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all ${
                        nfcUnlocked
                          ? "bg-emerald-600 text-white shadow-lg"
                          : "bg-purple-600 hover:bg-purple-500 text-white shadow-md shadow-purple-900/50"
                      }`}
                    >
                      <Key className="h-4 w-4" />
                      <span>{nfcUnlocked ? "✓ Room 304 Unlocked via NFC" : "Hold Near Door (NFC Digital Key)"}</span>
                    </button>
                  </div>

                  <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-3.5 font-mono text-xs">
                    <div className="flex items-center justify-between text-[10px] pb-2 border-b border-slate-800">
                      <span className="font-bold text-slate-300 flex items-center gap-1">
                        <Bus className="h-3.5 w-3.5 text-sky-400" /> AIRPORT SHUTTLE BUS PASS
                      </span>
                      <span className="text-emerald-400 font-bold">ETA 4 Mins</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      <div>
                        <span className="text-white font-bold">Hilton Express Shuttle #2</span>
                        <p className="text-[10px] text-slate-400">Pick up: Terminal B Ground Floor Bay 2</p>
                      </div>
                      <QrCode className="h-8 w-8 text-sky-400" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <span className="text-[10px] font-mono text-slate-400 font-bold px-1">
                      DIGITAL MEAL COUPONS (₹4,000 TOTAL)
                    </span>
                    {overnightCare.mealVouchers.map((voucher) => {
                      const isRedeemed = redeemedVouchers[voucher.voucherId];
                      return (
                        <div
                          key={voucher.voucherId}
                          className={`rounded-xl border p-3 font-mono text-xs transition ${
                            isRedeemed
                              ? "border-slate-800 bg-slate-950/60 opacity-60"
                              : "border-amber-500/70 bg-amber-950/30 text-amber-200"
                          }`}
                        >
                          <div className="flex items-center justify-between text-[10px] pb-1 border-b border-amber-900/50">
                            <span className="font-bold flex items-center gap-1">
                              <Utensils className="h-3 w-3" /> {voucher.mealType} VOUCHER (₹2,000)
                            </span>
                            <button
                              onClick={() => toggleVoucher(voucher.voucherId)}
                              className="text-[9px] px-2 py-0.5 rounded bg-amber-900 text-amber-100 hover:bg-amber-800"
                            >
                              {isRedeemed ? "Used" : "Tap to Scan"}
                            </button>
                          </div>
                          <div className="mt-2 flex items-center justify-between">
                            <span className="text-[10px] text-slate-300">{voucher.validAt}</span>
                            <span className="text-[9px] font-bold text-white bg-slate-900 px-2 py-1 rounded border border-slate-700">
                              {voucher.barcode}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </>
              )}
            </div>
          )}

          {/* TAB 4: BAGGAGE TRACKER */}
          {activeTab === "BAGS" && (
            <div className="space-y-3 px-2">
              <div className="rounded-2xl border border-slate-800 bg-slate-900/90 p-4 font-mono text-xs">
                <div className="flex items-center justify-between text-[10px] pb-2 border-b border-slate-800">
                  <span className="font-bold text-slate-300 flex items-center gap-1">
                    <Luggage className="h-3.5 w-3.5 text-amber-400" /> BAGGAGE TELEMETRY
                  </span>
                  <span className="text-sky-400 font-bold">{baggage.bagId}</span>
                </div>

                <div className="mt-4 space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="h-3 w-3 rounded-full bg-emerald-400 mt-1" />
                    <div>
                      <span className="text-white font-bold">Checked at JFK Terminal 8</span>
                      <p className="text-[10px] text-slate-400">15:52 UTC · Cargo Hold Bay A</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="h-3 w-3 rounded-full bg-sky-400 mt-1 animate-pulse" />
                    <div>
                      <span className="text-sky-300 font-bold">Tarmac Autonomous Transfer</span>
                      <p className="text-[10px] text-slate-400">
                        {simMinute >= 30
                          ? "Secured in Climate Vault Alpha-4"
                          : simMinute >= 20
                          ? "Rerouted to Stand B38 (BA212)"
                          : "Scheduled for Stand B10 Transfer"}
                      </p>
                    </div>
                  </div>

                  <div className="rounded-lg bg-slate-950 p-2.5 text-[10px] text-slate-400 border border-slate-800">
                    <div>Current Location: <span className="text-white font-bold">{baggage.currentLocation}</span></div>
                    <div>Target Stand: <span className="text-sky-300 font-bold">{baggage.routedDestination}</span></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: MEDICAL SOS & MEDIF */}
          {activeTab === "MEDICAL" && (
            <div className="space-y-3 px-2">
              <div className="rounded-2xl border border-rose-500/80 bg-gradient-to-b from-rose-950/80 to-slate-950 p-4 font-mono text-xs shadow-xl">
                <div className="flex items-center justify-between text-[10px] pb-2 border-b border-rose-900">
                  <span className="font-bold text-rose-200 flex items-center gap-1">
                    <HeartPulse className="h-3.5 w-3.5" /> MEDICAL SAFETY PASSPORT
                  </span>
                  <span className="text-emerald-400 font-bold">MEDIF VERIFIED</span>
                </div>

                <div className="mt-3 space-y-2 text-[11px]">
                  <p className="text-slate-300">
                    Patient: <span className="text-white font-bold">{passenger.name}</span>
                  </p>
                  <p className="text-slate-300">
                    Condition: <span className="text-rose-300 font-bold">{passenger.medicalProfile.conditionName}</span>
                  </p>
                  <p className="text-slate-400 text-[10px]">
                    Pre-cleared with Airline Medical Operations. Priority watch list active.
                  </p>
                </div>

                <button
                  onClick={onTriggerEmergency}
                  className="mt-4 w-full py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg animate-pulse"
                >
                  <HeartPulse className="h-4 w-4" />
                  <span>EMERGENCY SOS: DISPATCH AIRPORT EMS</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Bottom Tab Bar */}
        <div className="flex items-center justify-around border-t border-slate-800/80 bg-slate-950/95 py-2 px-1 rounded-b-[40px] z-40">
          <button
            onClick={() => setActiveTab("FLIGHT")}
            className={`flex flex-col items-center gap-0.5 text-[9px] font-mono transition ${
              activeTab === "FLIGHT" ? "text-sky-400 font-bold" : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <Plane className="h-4 w-4" />
            <span>Trip</span>
          </button>
          <button
            onClick={() => setActiveTab("GATE")}
            className={`flex flex-col items-center gap-0.5 text-[9px] font-mono transition ${
              activeTab === "GATE" ? "text-teal-400 font-bold" : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <MapPin className="h-4 w-4" />
            <span>Radar</span>
          </button>
          <button
            onClick={() => setActiveTab("CARE")}
            className={`flex flex-col items-center gap-0.5 text-[9px] font-mono transition ${
              activeTab === "CARE" ? "text-purple-400 font-bold" : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <Hotel className="h-4 w-4" />
            <span>Care Suite</span>
          </button>
          <button
            onClick={() => setActiveTab("BAGS")}
            className={`flex flex-col items-center gap-0.5 text-[9px] font-mono transition ${
              activeTab === "BAGS" ? "text-amber-400 font-bold" : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <Luggage className="h-4 w-4" />
            <span>Bags</span>
          </button>
          <button
            onClick={() => setActiveTab("MEDICAL")}
            className={`flex flex-col items-center gap-0.5 text-[9px] font-mono transition ${
              activeTab === "MEDICAL" ? "text-rose-400 font-bold" : "text-slate-500 hover:text-slate-300"
            }`}
          >
            <HeartPulse className="h-4 w-4" />
            <span>Medical</span>
          </button>
        </div>
      </div>
    </div>
  );
};
