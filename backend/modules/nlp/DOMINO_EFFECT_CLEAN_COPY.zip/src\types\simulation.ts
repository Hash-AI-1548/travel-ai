export type FlightStatus = "NORMAL" | "VOLATILE" | "ISOLATED" | "RECOVERED" | "DIVERTED" | "GROUNDED";
export type PolicyMode = "MECHANICAL" | "WEATHER";
export type HoldDecision = "PENDING" | "APPROVED" | "REJECTED";
export type ScenarioType = "IN_FLIGHT_SAVE" | "OVERNIGHT_DOMINO" | "MEDICAL_EMERGENCY" | "CUSTOM_SANDBOX";

export interface FlightContext {
  flightNumber: string;
  airline: string;
  aircraftTail: string;
  aircraftModel: string;
  route: {
    origin: string;
    originName: string;
    transit: string;
    transitName: string;
    destination: string;
    destinationName: string;
  };
  scheduledTimes: {
    depOrigin: string; // e.g. "15:30 UTC"
    arrTransit: string; // e.g. "16:30 UTC"
    depTransitDest: string; // e.g. "17:05 UTC"
  };
  actualTimes: {
    depOrigin: string; // e.g. "16:00 UTC" (30 min late)
    estArrTransit: string; // e.g. "17:00 UTC"
  };
  telemetry: {
    altitudeFt: number;
    groundSpeedKts: number;
    remainingDistanceNm: number;
    etaMinutes: number;
    lat: number;
    lng: number;
  };
  delayMinutes: number;
  bufferMinutes: number;
  initialArrivalGate: string;
  currentArrivalGate: string;
  initialOutboundGate: string;
  currentOutboundGate: string;
  crewDutyRemainingHours: number;
  crewDutyRisk: number; // 0 - 1
  status: FlightStatus;
}

export interface PassengerProfile {
  passengerId: string;
  name: string;
  seat: string;
  tier: "DIAMOND_MEDALLION" | "FIRST_CLASS" | "BUSINESS" | "ECONOMY";
  bagTags: string[];
  connectionRiskScore: number;
  medicalProfile: {
    isEmergency: boolean;
    conditionName?: string;
    medifVerified: boolean;
    medevacInsuranceActive: boolean;
    emergencyTriggeredAtSimMinute?: number;
  };
  isWheelchairUser?: boolean;
  specialAssistance?: "WHEELCHAIR_REQUIRED" | "VISUAL_ASSISTANCE" | "HEARING_ASSISTANCE" | "STANDARD";
  dietaryPreferences?: string[];
  allergies?: string;
  autoRebookOnDelay?: boolean;
  autoRebookDelayThresholdMinutes?: number;
  isEmergencyTraveler?: boolean;
  emergencyReason?: string;
  allowCompetitorInterlineRebooking?: boolean;
  preferredCompetitorAirlines?: string[];
  autoUpgradeSeatAllowed?: boolean;
  recoveryAllocation?: {
    status: "STANDBY" | "REBOOKED" | "HOTEL_TRANSFERRED";
    assignedFlight: string;
    assignedAirline: string;
    departureTime: string;
    gate: string;
    seat: string;
    interlineClearingStatus: "AUTO_SETTLED" | "PENDING_CLEARANCE" | "OVERRIDDEN";
    barcodePayload: string;
  };
}

export interface BaggageTelemetry {
  bagId: string;
  paxId: string;
  sourceFlight: string;
  targetFlight: string;
  currentLocation: string;
  routedDestination: string;
  status: "IN_CARGO_HOLD" | "UNLOADED_TARMAC" | "RAMP_TRANSFER_ACTIVE" | "LOADED_ON_TARGET" | "SECURED_IN_VAULT";
  secureVaultId?: string;
  lastScannedTime: string;
  transferSpeedKmh: number;
}

export interface PreventorMetrics {
  riskScore: number; // 0 - 1
  isIsolated: boolean;
  contagionVectors: {
    delayRatioTerm: number; // w1 * (Tdelay / Tbuffer)
    connectionBreachTerm: number; // w2 * sum(1 - DeltaT / MCT)
    crewDutyTerm: number; // w3 * phi_crew
  };
  weights: {
    w1: number; // default 0.35
    w2: number; // default 0.45
    w3: number; // default 0.20
  };
  isolatedAtMinute?: number;
  activeBottlenecks: string[];
}

export interface ManagerDoorHoldMetrics {
  holdMinutes: number;
  maxHoldAllowedMinutes: number;
  fuelBurnRatePerMin: number;
  crewOtRatePerMin: number;
  costFuelBurnUsd: number;
  costCrewOtUsd: number;
  costDownstreamMissesUsd: number;
  costTotalHoldUsd: number;
  costInterlineTicketsUsd: number;
  costHotelUsd: number;
  costMealsUsd: number;
  costEu261CompensationUsd: number;
  costTotalAbandonUsd: number;
  netSavingsUsd: number;
  decision: HoldDecision;
  decisionReason: string;
  gateWalkingTimeBeforeMins: number;
  gateWalkingTimeAfterMins: number;
}

export interface OvernightCarePackage {
  triggered: boolean;
  triggeredAtMinute?: number;
  policyApplied: PolicyMode;
  isCarrierFunded: boolean;
  hotelReservation: {
    hotelName: string;
    roomNumber: string;
    address: string;
    checkInTime: string;
    digitalKeyQr: string;
    shuttlePassCode: string;
    shuttleEtaMins: number;
    shuttleCurrentLocation: string;
  };
  mealVouchers: Array<{
    voucherId: string;
    mealType: "DINNER" | "BREAKFAST" | "SNACK";
    amountUsd: number;
    barcode: string;
    validAt: string;
    isRedeemed: boolean;
  }>;
  morningStandbyPriority: {
    assignedFlight: string;
    departureTime: string;
    queuePosition: number;
    totalStandbyCount: number;
    confirmedSeatEstimate: string;
  };
  luggageWarehouse: {
    vaultId: string;
    bayName: string;
    tempControlled: boolean;
    secureLockHash: string;
    storageStatus: "TRANSIT_TO_VAULT" | "SECURE_LOCKED" | "STAGED_FOR_MORNING";
  };
}

export interface MedicalEmergencyState {
  isActive: boolean;
  priorityLevel: "NORMAL" | "CRITICAL_ALPHA_ICU";
  paxId: string;
  patientName: string;
  diagnosis: string;
  medifVerified: boolean;
  insuranceVerified: boolean;
  paramedics: {
    status: "STANDBY" | "DISPATCHED" | "ON_GATE_WAITING" | "TRIAGE_IN_PROGRESS";
    targetGate: string;
    etaSeconds: number;
    teamId: string;
  };
  interlineOverride: {
    status: "IDLE" | "REQUESTED" | "OVERRIDDEN_CONFIRMED";
    targetFlight: string;
    carrier: string;
    depTime: string;
    clearingHouseBypassed: boolean;
  };
  airAmbulanceMedevac: {
    status: "STANDBY" | "ACTIVE_DISPATCH" | "AIRBORNE_PRIORITY";
    providerName: string;
    tailNumber: string;
    callsign: string;
    specialMedicalAirspaceClearance: boolean;
    estimatedTakeoffMins: number;
  };
}

export interface SimulationLogEvent {
  id: string;
  timestampSim: string;
  timestampReal: string;
  simMinute: number;
  category: "PREVENTOR" | "MANAGER" | "GATE" | "RAMP" | "CARE" | "MEDICAL" | "POLICY" | "SYSTEM";
  level: "INFO" | "WARN" | "CRITICAL" | "SUCCESS";
  title: string;
  message: string;
  payload?: any;
}

export interface AirportGateNode {
  gateId: string;
  terminal: string;
  standNumber: string;
  currentAssignedFlight?: string;
  x: number;
  y: number;
  isAdjacentTo: string[];
}

export interface NetworkGraphNode {
  id: string;
  label: string;
  type: "FLIGHT" | "CREW" | "GATE" | "PASSENGER" | "AIRCRAFT" | "HOTEL";
  status: "NORMAL" | "VOLATILE" | "ISOLATED" | "RECOVERED";
  riskScore?: number;
  x: number;
  y: number;
  details: string;
}

export interface NetworkGraphEdge {
  id: string;
  source: string;
  target: string;
  label: string;
  type: "ROTATION" | "CONNECTION" | "PAIRING" | "ASSIGNMENT" | "BAG_TRANSFER";
  isRiskBearing: boolean;
  isIsolated: boolean;
}

export interface AutonomousAiTelemetry {
  isAutonomousActive: boolean;
  modelEngine: string;
  lastDecisionCycle: string;
  cycleCount: number;
  crewLegalityStatus: "FAR_117_CERTIFIED" | "REST_WARNING" | "TIMEOUT_BREACH";
  pilotSignalStatus: "TRANSMITTED" | "ACKNOWLEDGED_BY_PILOT" | "DOOR_HOLD_ACTIVE";
  paxPushDeliveryStatus: "DELIVERED" | "READ_BY_PASSENGER";
  aiReasoningLog: string[];
}

