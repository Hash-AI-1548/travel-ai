import React, { useState, useEffect, useRef } from "react";
import {
  Shield,
  Plane,
  ArrowRight,
  ArrowLeft,
  Info,
  X,
  Cloud,
  CheckCircle2,
  LogOut,
  Sparkles,
  Plus,
  Trash2,
  FolderOpen,
  Download
} from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import {
  firebaseSignIn,
  firebaseRegister,
  firebaseGuestSignIn,
  firebaseSignOut,
  saveTravelPassportToFirestore,
  getTravelPassportFromFirestore,
  getCurrentUser
} from "../../services/firebase";

export interface BudgetSplitupItem {
  id: string;
  purpose: string;
  amount: number;
  icon: string;
}

export interface TravelPassportData {
  fullName: string;
  age: number;
  gender: string;
  nationality: string;
  homeCity: string;
  languages: string[];
  notes: string;
  travelerType: string;
  travelerTypeCustom: string;
  accessibilityMobility: boolean;
  accessibilityVisual: boolean;
  accessibilityHearing: boolean;
  accessibilitySenior: boolean;
  accessibilityChild: boolean;
  accessibilityNone: boolean;
  accessibilityCustom: string;
  travelStyles: string[];
  travelStylesCustom: string;
  dietaryStandards: string[];
  allergies: string;
  foodCustom: string;
  packStyles: string[];
  modestClothing: boolean;
  hotWeather: boolean;
  clothingCustom: string;
  budgetTier: string;
  budgetCurrency: string;
  budgetCustom: string;
  budgetStandardizedUsd: string;
  budgetBreakdown?: BudgetSplitupItem[];
  isRoundOffActive?: boolean;

  // Flight Delay & Emergency Competitor Rebooking Preferences
  autoRebookOnDelay: boolean;
  autoRebookDelayThresholdMinutes: number; // 30, 45, 60, 90
  isEmergencyTraveler: boolean;
  emergencyReason?: string;
  allowCompetitorInterlineRebooking: boolean;
  preferredCompetitorAirlines?: string[];
  autoUpgradeSeatAllowed?: boolean;
}

export const CURRENCY_RATES: Record<string, { rate: number; symbol: string; name: string }> = {
  EUR: { rate: 1.087, symbol: "€", name: "EUR (€) — Euro (France / EU)" },
  INR: { rate: 0.0119, symbol: "₹", name: "INR (₹) — Indian Rupee" },
  USD: { rate: 1.0, symbol: "$", name: "USD ($) — US Dollar" },
  GBP: { rate: 1.266, symbol: "£", name: "GBP (£) — British Pound" },
  AED: { rate: 0.272, symbol: "د.إ", name: "AED (د.إ) — UAE Dirham" },
  CAD: { rate: 0.735, symbol: "C$", name: "CAD (C$) — Canadian Dollar" },
  AUD: { rate: 0.658, symbol: "A$", name: "AUD (A$) — Australian Dollar" },
  SGD: { rate: 0.746, symbol: "S$", name: "SGD (S$) — Singapore Dollar" },
  JPY: { rate: 0.00658, symbol: "¥", name: "JPY (¥) — Japanese Yen" },
  SAR: { rate: 0.267, symbol: "﷼", name: "SAR (﷼) — Saudi Riyal" },
  QAR: { rate: 0.275, symbol: "QR", name: "QAR (QR) — Qatari Riyal" },
  KWD: { rate: 3.26, symbol: "KD", name: "KWD (KD) — Kuwaiti Dinar" },
  BHD: { rate: 2.65, symbol: "BD", name: "BHD (BD) — Bahraini Dinar" },
  OMR: { rate: 2.60, symbol: "OMR", name: "OMR (OMR) — Omani Rial" },
  CHF: { rate: 1.136, symbol: "Fr", name: "CHF (Fr) — Swiss Franc" },
  CNY: { rate: 0.138, symbol: "¥", name: "CNY (¥) — Chinese Yuan" },
  HKD: { rate: 0.128, symbol: "HK$", name: "HKD (HK$) — Hong Kong Dollar" },
  NZD: { rate: 0.612, symbol: "NZ$", name: "NZD (NZ$) — New Zealand Dollar" },
  THB: { rate: 0.0274, symbol: "฿", name: "THB (฿) — Thai Baht" },
  MYR: { rate: 0.213, symbol: "RM", name: "MYR (RM) — Malaysian Ringgit" },
  IDR: { rate: 0.0000625, symbol: "Rp", name: "IDR (Rp) — Indonesian Rupiah" },
  PHP: { rate: 0.0175, symbol: "₱", name: "PHP (₱) — Philippine Peso" },
  VND: { rate: 0.000039, symbol: "₫", name: "VND (₫) — Vietnamese Dong" },
  KRW: { rate: 0.000725, symbol: "₩", name: "KRW (₩) — South Korean Won" },
  PKR: { rate: 0.0036, symbol: "₨", name: "PKR (₨) — Pakistani Rupee" },
  BDT: { rate: 0.0085, symbol: "৳", name: "BDT (৳) — Bangladeshi Taka" },
  LKR: { rate: 0.0033, symbol: "Rs", name: "LKR (Rs) — Sri Lankan Rupee" },
  NPR: { rate: 0.0075, symbol: "Rs", name: "NPR (Rs) — Nepalese Rupee" },
  BRL: { rate: 0.183, symbol: "R$", name: "BRL (R$) — Brazilian Real" },
  ZAR: { rate: 0.054, symbol: "R", name: "ZAR (R) — South African Rand" },
  TRY: { rate: 0.029, symbol: "₺", name: "TRY (₺) — Turkish Lira" },
  RUB: { rate: 0.011, symbol: "₽", name: "RUB (₽) — Russian Ruble" },
  MXN: { rate: 0.0549, symbol: "Mex$", name: "MXN (Mex$) — Mexican Peso" }
};

// Newly created profile from travel-ai-main/data/processed/user_profiles.json
export const PROFILE_EURO_TRAVELER: TravelPassportData = {
  fullName: "Euro Traveler",
  age: 32,
  gender: "Prefer not to say",
  nationality: "French",
  homeCity: "Paris",
  languages: ["English"],
  notes: "Summer holiday trip",
  travelerType: "couple",
  travelerTypeCustom: "Couple vacation",
  accessibilityMobility: false,
  accessibilityVisual: false,
  accessibilityHearing: false,
  accessibilitySenior: false,
  accessibilityChild: false,
  accessibilityNone: false,
  accessibilityCustom: "",
  travelStyles: ["culture", "nature", "food_wine", "photography"],
  travelStylesCustom: "",
  dietaryStandards: ["vegetarian"],
  allergies: "None",
  foodCustom: "",
  packStyles: ["casual"],
  modestClothing: true,
  hotWeather: false,
  clothingCustom: "",
  budgetTier: "moderate",
  budgetCurrency: "EUR",
  budgetCustom: "1500 - 2000",
  budgetStandardizedUsd: "≈ $1,630 – $2,174 USD (Converted from EUR)",
  budgetBreakdown: [
    { id: "1", purpose: "Accommodation / Stays", amount: 800, icon: "🏨" },
    { id: "2", purpose: "Flights & Local Transit", amount: 500, icon: "✈️" },
    { id: "3", purpose: "Food, Cafes & Dining", amount: 350, icon: "🍽️" },
    { id: "4", purpose: "Sightseeing & Activities", amount: 200, icon: "🎟️" },
    { id: "5", purpose: "Shopping & Emergency Reserve", amount: 150, icon: "🛍️" }
  ],
  isRoundOffActive: false,
  autoRebookOnDelay: true,
  autoRebookDelayThresholdMinutes: 30,
  isEmergencyTraveler: true,
  emergencyReason: "Urgent couple connection & fixed schedule itinerary",
  allowCompetitorInterlineRebooking: true,
  preferredCompetitorAirlines: ["Air France", "British Airways", "Lufthansa", "Delta"],
  autoUpgradeSeatAllowed: true
};

export const PROFILE_EVELYN_THORNE: TravelPassportData = {
  fullName: "Evelyn Thorne",
  age: 29,
  gender: "Female",
  nationality: "Indian",
  homeCity: "Mumbai",
  languages: ["English", "Hindi"],
  notes: "Celebrating 5th wedding anniversary",
  travelerType: "couple",
  travelerTypeCustom: "",
  accessibilityMobility: true,
  accessibilityVisual: false,
  accessibilityHearing: false,
  accessibilitySenior: false,
  accessibilityChild: false,
  accessibilityNone: false,
  accessibilityCustom: "",
  travelStyles: ["adventure", "nature", "culture", "food", "photography"],
  travelStylesCustom: "",
  dietaryStandards: ["vegetarian", "halal"],
  allergies: "Severe peanut allergy, prefers gluten-free options where possible",
  foodCustom: "",
  packStyles: ["western", "casual"],
  modestClothing: true,
  hotWeather: false,
  clothingCustom: "",
  budgetTier: "moderate",
  budgetCurrency: "INR",
  budgetCustom: "50000",
  budgetStandardizedUsd: "≈ $595 USD",
  budgetBreakdown: [
    { id: "1", purpose: "Accommodation / Stays", amount: 20000, icon: "🏨" },
    { id: "2", purpose: "Flights & Local Transit", amount: 15000, icon: "✈️" },
    { id: "3", purpose: "Food, Cafes & Dining", amount: 8000, icon: "🍽️" },
    { id: "4", purpose: "Sightseeing & Activities", amount: 5000, icon: "🎟️" },
    { id: "5", purpose: "Shopping & Emergency Reserve", amount: 2000, icon: "🛍️" }
  ],
  isRoundOffActive: false,
  autoRebookOnDelay: true,
  autoRebookDelayThresholdMinutes: 45,
  isEmergencyTraveler: false,
  emergencyReason: "",
  allowCompetitorInterlineRebooking: true,
  preferredCompetitorAirlines: ["Delta", "British Airways", "Emirates"],
  autoUpgradeSeatAllowed: true
};

const ALL_LANGUAGES = [
  "English", "French", "Spanish", "German", "Mandarin Chinese", "Cantonese",
  "Japanese", "Hindi", "Arabic", "Portuguese", "Russian", "Bengali", "Italian",
  "Korean", "Turkish", "Vietnamese", "Polish", "Dutch", "Swedish", "Greek",
  "Tamil", "Telugu", "Marathi", "Gujarati", "Kannada", "Malayalam", "Hebrew"
];

interface TravelPassportProfileViewProps {
  state?: SimulationState;
  passport?: TravelPassportData;
  onUpdatePassport?: (passport: TravelPassportData) => void;
  onProceedToOperations: (passport: TravelPassportData) => void;
  onSignOut?: () => void;
}

export const TravelPassportProfileView: React.FC<TravelPassportProfileViewProps> = ({
  passport: initialPassport,
  onUpdatePassport,
  onProceedToOperations,
  onSignOut,
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [passport, setPassport] = useState<TravelPassportData>(() => initialPassport || PROFILE_EURO_TRAVELER);
  const [langSearch, setLangSearch] = useState<string>("");
  const [showSuggestions, setShowSuggestions] = useState<boolean>(false);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authTab, setAuthTab] = useState<"login" | "register">("login");
  const [userEmail, setUserEmail] = useState<string>("");
  const [userPassword, setUserPassword] = useState<string>("");
  const [authSuccessMsg, setAuthSuccessMsg] = useState<string>("");
  const [firebaseStatus, setFirebaseStatus] = useState<string>("Firebase RTDB & Cloud DB: Synced");
  const [currentUserId, setCurrentUserId] = useState<string>("usr_guest");
  const [currentUser, setCurrentUser] = useState<any>(() => getCurrentUser());
  const [roundOffActive, setRoundOffActive] = useState<boolean>(() => Boolean(passport.isRoundOffActive));
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load user profile from Firebase or initial props
  useEffect(() => {
    if (initialPassport && initialPassport.fullName) {
      setPassport(initialPassport);
    }
    const user = getCurrentUser();
    setCurrentUser(user);
    const uid: string = user?.uid || "usr_guest";
    setCurrentUserId(uid);

    // Automatically retrieve saved profile from Firebase Firestore / RTDB
    getTravelPassportFromFirestore(uid).then((saved) => {
      if (saved && saved.fullName) {
        setPassport(saved);
        if (onUpdatePassport) onUpdatePassport(saved);
        setFirebaseStatus("Firebase RTDB & Cloud DB: Synced");
      } else {
        // If not in Firebase yet, write initial default to Firebase DB
        saveTravelPassportToFirestore(uid, initialPassport || PROFILE_EURO_TRAVELER);
      }
    });
  }, [initialPassport]);

  const steps = [
    { num: 1, label: "Personal Info" },
    { num: 2, label: "Traveler Type" },
    { num: 3, label: "Accessibility & Emergency" },
    { num: 4, label: "Travel Style" },
    { num: 5, label: "Food" },
    { num: 6, label: "Clothing" },
    { num: 7, label: "Budget" },
    { num: 8, label: "Summary" }
  ];

  const calculateUSDStandard = (customVal: string, currCode: string): string => {
    const code = (currCode || "EUR").trim().toUpperCase();
    const info = CURRENCY_RATES[code] || { rate: 1.0, symbol: code };
    if (!customVal || !customVal.trim()) return `≈ $1,000 USD (Estimated)`;
    const nums = customVal.match(/\b\d+(?:,\d+)*(?:\.\d+)?\b/g);
    if (!nums || nums.length === 0) {
      return `≈ ${customVal} (${code})`;
    }
    if (nums.length >= 2) {
      const lowUsd = Math.round(parseFloat(nums[0].replace(/,/g, "")) * info.rate);
      const highUsd = Math.round(parseFloat(nums[1].replace(/,/g, "")) * info.rate);
      return `≈ $${lowUsd.toLocaleString()} – $${highUsd.toLocaleString()} USD (Converted from ${code})`;
    } else {
      const valUsd = Math.round(parseFloat(nums[0].replace(/,/g, "")) * info.rate);
      return `≈ $${valUsd.toLocaleString()} USD (Converted from ${code})`;
    }
  };

  const saveTimeoutRef = useRef<any>(null);

  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    };
  }, []);

  const persistToFirebase = (updated: TravelPassportData) => {
    // 1. Instantaneous local update with 0ms blocking
    setPassport(updated);
    if (onUpdatePassport) {
      onUpdatePassport(updated);
    }
    // 2. Debounce cloud network persistence by 800ms
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(() => {
      saveTravelPassportToFirestore(currentUserId, updated)
        .then(() => {
          setFirebaseStatus("Firebase RTDB & Cloud DB: Synced");
        })
        .catch(() => {});
    }, 800);
  };

  const handleFetchFromFirebase = async () => {
    setFirebaseStatus("Fetching from Firebase DB...");
    try {
      const saved = await getTravelPassportFromFirestore(currentUserId);
      if (saved && saved.fullName) {
        setPassport(saved);
        if (onUpdatePassport) onUpdatePassport(saved);
        setFirebaseStatus("Firebase RTDB & Cloud DB: Synced");
        alert(`✅ Loaded latest profile for "${saved.fullName}" directly from Firebase Database!`);
      } else {
        setFirebaseStatus("Firebase RTDB & Cloud DB: Synced");
        alert("ℹ️ Initialized current profile with Firebase Database.");
        persistToFirebase(passport);
      }
    } catch (e: any) {
      setFirebaseStatus("Firebase DB: Offline / Local Sync");
      alert(`⚠️ Firebase fetch notice: ${e.message || "Using local storage fallback"}`);
    }
  };

  const handleSaveToFirebase = async () => {
    setFirebaseStatus("Saving to Firebase DB...");
    try {
      await saveTravelPassportToFirestore(currentUserId, passport);
      setFirebaseStatus("Firebase RTDB & Cloud DB: Synced");
      alert(`✅ Profile for "${passport.fullName}" saved to Firebase Realtime Database & Firestore!`);
    } catch (e: any) {
      setFirebaseStatus("Firebase RTDB & Cloud DB: Synced");
    }
  };

  const handleImportJsonFile = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const raw = JSON.parse(e.target?.result as string);
        const data = Array.isArray(raw) ? raw[0] : raw;
        if (data) {
          const imported: TravelPassportData = {
            fullName: data.full_name || data.fullName || "Euro Traveler",
            age: data.age || 32,
            gender: data.gender || "Prefer not to say",
            nationality: data.nationality || "French",
            homeCity: data.home_city || data.homeCity || "Paris",
            languages: data.languages_spoken || data.languages || ["English"],
            notes: data.personal_notes || data.notes || "Imported Profile",
            travelerType: data.traveler_type || data.travelerType || "couple",
            travelerTypeCustom: data.traveler_type_custom || data.travelerTypeCustom || "",
            accessibilityMobility: Boolean(data.accessibility_mobility ?? data.accessibilityMobility),
            accessibilityVisual: Boolean(data.accessibility_visual ?? data.accessibilityVisual),
            accessibilityHearing: Boolean(data.accessibility_hearing ?? data.accessibilityHearing),
            accessibilitySenior: Boolean(data.accessibility_senior ?? data.accessibilitySenior),
            accessibilityChild: Boolean(data.accessibility_child ?? data.accessibilityChild),
            accessibilityNone: Boolean(data.accessibility_none ?? data.accessibilityNone),
            accessibilityCustom: data.accessibility_custom || data.accessibilityCustom || "",
            travelStyles: data.travel_styles || data.travelStyles || ["culture", "nature", "food_wine", "photography"],
            travelStylesCustom: data.travel_styles_custom || data.travelStylesCustom || "",
            dietaryStandards: data.dietary_standards || data.dietaryStandards || ["vegetarian"],
            allergies: data.allergies_restrictions || data.allergies || "None",
            foodCustom: data.food_custom || data.foodCustom || "",
            packStyles: data.pack_styles || data.packStyles || ["casual"],
            modestClothing: Boolean(data.modest_clothing ?? data.modestClothing),
            hotWeather: Boolean(data.prioritize_hot_weather ?? data.hotWeather),
            clothingCustom: data.clothing_custom || data.clothingCustom || "",
            budgetTier: data.budget_tier || data.budgetTier || "moderate",
            budgetCurrency: data.budget_currency || data.budgetCurrency || "EUR",
            budgetCustom: data.budget_custom || data.budgetCustom || "1500 - 2000",
            budgetStandardizedUsd: data.budget_standardized_usd || data.budgetStandardizedUsd || "≈ $1,630 – $2,174 USD (Converted from EUR)",
            budgetBreakdown: data.budget_breakdown || [
              { id: "1", purpose: "Accommodation / Stays", amount: 800, icon: "🏨" },
              { id: "2", purpose: "Flights & Local Transit", amount: 500, icon: "✈️" },
              { id: "3", purpose: "Food, Cafes & Dining", amount: 350, icon: "🍽️" },
              { id: "4", purpose: "Sightseeing & Activities", amount: 200, icon: "🎟️" },
              { id: "5", purpose: "Shopping & Emergency Reserve", amount: 150, icon: "🛍️" }
            ],
            isRoundOffActive: Boolean(data.is_round_off_active ?? data.isRoundOffActive),
            autoRebookOnDelay: Boolean(data.auto_rebook_on_delay ?? data.autoRebookOnDelay ?? true),
            autoRebookDelayThresholdMinutes: data.auto_rebook_delay_threshold_minutes || data.autoRebookDelayThresholdMinutes || 30,
            isEmergencyTraveler: Boolean(data.is_emergency_traveler ?? data.isEmergencyTraveler ?? false),
            emergencyReason: data.emergency_reason || data.emergencyReason || "",
            allowCompetitorInterlineRebooking: Boolean(data.allow_competitor_interline_rebooking ?? data.allowCompetitorInterlineRebooking ?? true),
            preferredCompetitorAirlines: data.preferred_competitor_airlines || data.preferredCompetitorAirlines || ["Air France", "British Airways", "Lufthansa", "Delta"],
            autoUpgradeSeatAllowed: Boolean(data.auto_upgrade_seat_allowed ?? data.autoUpgradeSeatAllowed ?? true)
          };
          persistToFirebase(imported);
          alert(`✅ Successfully loaded profile: "${imported.fullName}" (${imported.nationality}) and synced to Firebase DB!`);
        }
      } catch (err: any) {
        alert(`❌ Failed to parse profile JSON: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  const handleExportJsonFile = () => {
    const exportData = [{
      user_id: 1,
      full_name: passport.fullName,
      age: passport.age,
      gender: passport.gender,
      nationality: passport.nationality,
      home_city: passport.homeCity,
      personal_notes: passport.notes,
      languages_spoken: passport.languages,
      traveler_type: passport.travelerType,
      traveler_type_custom: passport.travelerTypeCustom,
      accessibility_mobility: passport.accessibilityMobility,
      accessibility_visual: passport.accessibilityVisual,
      accessibility_hearing: passport.accessibilityHearing,
      accessibility_senior: passport.accessibilitySenior,
      accessibility_child: passport.accessibilityChild,
      accessibility_none: passport.accessibilityNone,
      accessibility_custom: passport.accessibilityCustom,
      travel_styles: passport.travelStyles,
      travel_styles_custom: passport.travelStylesCustom,
      dietary_standards: passport.dietaryStandards,
      allergies_restrictions: passport.allergies,
      food_custom: passport.foodCustom,
      pack_styles: passport.packStyles,
      modest_clothing: passport.modestClothing,
      prioritize_hot_weather: passport.hotWeather,
      clothing_custom: passport.clothingCustom,
      budget_tier: passport.budgetTier,
      budget_currency: passport.budgetCurrency,
      budget_custom: passport.budgetCustom,
      budget_standardized_usd: passport.budgetStandardizedUsd,
      auto_rebook_on_delay: passport.autoRebookOnDelay,
      auto_rebook_delay_threshold_minutes: passport.autoRebookDelayThresholdMinutes,
      is_emergency_traveler: passport.isEmergencyTraveler,
      emergency_reason: passport.emergencyReason,
      allow_competitor_interline_rebooking: passport.allowCompetitorInterlineRebooking,
      preferred_competitor_airlines: passport.preferredCompetitorAirlines,
      is_completed: true,
      completion_percentage: 100,
      updated_at: new Date().toISOString()
    }];
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `user_profile_${passport.fullName.toLowerCase().replace(/\s+/g, "_")}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleNext = () => {
    if (currentStep < 8) {
      persistToFirebase(passport);
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const toggleLanguage = (lang: string) => {
    const exists = passport.languages.includes(lang);
    const updated = {
      ...passport,
      languages: exists ? passport.languages.filter((l) => l !== lang) : [...passport.languages, lang]
    };
    persistToFirebase(updated);
  };

  const addCustomLanguage = () => {
    if (!langSearch.trim()) return;
    const val = langSearch.trim();
    if (!passport.languages.includes(val)) {
      const updated = { ...passport, languages: [...passport.languages, val] };
      persistToFirebase(updated);
    }
    setLangSearch("");
    setShowSuggestions(false);
  };

  const toggleStyle = (style: string) => {
    const exists = passport.travelStyles.includes(style);
    const updated = {
      ...passport,
      travelStyles: exists ? passport.travelStyles.filter((s) => s !== style) : [...passport.travelStyles, style]
    };
    persistToFirebase(updated);
  };

  const toggleDiet = (diet: string) => {
    const exists = passport.dietaryStandards.includes(diet);
    const updated = {
      ...passport,
      dietaryStandards: exists ? passport.dietaryStandards.filter((d) => d !== diet) : [...passport.dietaryStandards, diet]
    };
    persistToFirebase(updated);
  };

  const togglePackStyle = (pack: string) => {
    const exists = passport.packStyles.includes(pack);
    const updated = {
      ...passport,
      packStyles: exists ? passport.packStyles.filter((p) => p !== pack) : [...passport.packStyles, pack]
    };
    persistToFirebase(updated);
  };

  const handleCurrencyChange = (curr: string) => {
    const usdEst = calculateUSDStandard(passport.budgetCustom, curr);
    const updated = {
      ...passport,
      budgetCurrency: curr,
      budgetStandardizedUsd: usdEst
    };
    persistToFirebase(updated);
  };

  const handleBudgetCustomChange = (val: string) => {
    const usdEst = calculateUSDStandard(val, passport.budgetCurrency);
    const updated = {
      ...passport,
      budgetCustom: val,
      budgetStandardizedUsd: usdEst
    };
    persistToFirebase(updated);
  };

  // Split-up handlers
  const getBreakdown = (): BudgetSplitupItem[] => {
    if (passport.budgetBreakdown && passport.budgetBreakdown.length > 0) {
      return passport.budgetBreakdown;
    }
    return passport.budgetCurrency === "EUR" ? PROFILE_EURO_TRAVELER.budgetBreakdown! : PROFILE_EVELYN_THORNE.budgetBreakdown!;
  };

  const handleUpdateSplitupItem = (id: string, field: "purpose" | "amount", value: any) => {
    const currentList = getBreakdown();
    const updatedList = currentList.map((item) => (item.id === id ? { ...item, [field]: value } : item));
    recalculateFromBreakdown(updatedList, roundOffActive);
  };

  const handleAddSplitupRow = () => {
    const currentList = getBreakdown();
    const newItem: BudgetSplitupItem = {
      id: `${Date.now()}`,
      purpose: "Custom Activity / Reserve",
      amount: passport.budgetCurrency === "EUR" ? 150 : 1000,
      icon: "✨"
    };
    const updatedList = [...currentList, newItem];
    recalculateFromBreakdown(updatedList, roundOffActive);
  };

  const handleRemoveSplitupRow = (id: string) => {
    const currentList = getBreakdown();
    const updatedList = currentList.filter((item) => item.id !== id);
    recalculateFromBreakdown(updatedList, roundOffActive);
  };

  const handleToggleRoundOff = (checked: boolean) => {
    setRoundOffActive(checked);
    recalculateFromBreakdown(getBreakdown(), checked);
  };

  const recalculateFromBreakdown = (breakdown: BudgetSplitupItem[], isRounded: boolean) => {
    let sum = breakdown.reduce((acc, item) => acc + (Number(item.amount) || 0), 0);
    if (isRounded && sum > 0) {
      if (passport.budgetCurrency === "EUR" || passport.budgetCurrency === "USD") {
        sum = Math.round(sum / 50) * 50;
      } else {
        sum = Math.round(sum / 500) * 500;
      }
    }
    const customStr = isRounded ? `${sum} (Rounded)` : `${sum}`;
    const usdEst = calculateUSDStandard(`${sum}`, passport.budgetCurrency);
    const updated: TravelPassportData = {
      ...passport,
      budgetCustom: customStr,
      budgetStandardizedUsd: usdEst,
      budgetBreakdown: breakdown,
      isRoundOffActive: isRounded
    };
    persistToFirebase(updated);
  };

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const derivedName = passport.fullName?.trim() || (userEmail ? userEmail.split("@")[0].charAt(0).toUpperCase() + userEmail.split("@")[0].slice(1) : "Euro Traveler");
    const updatedPassport: TravelPassportData = {
      ...passport,
      fullName: derivedName
    };
    setPassport(updatedPassport);

    if (authTab === "login") {
      const res = await firebaseSignIn(userEmail, userPassword);
      if (res.user) {
        setCurrentUserId(res.user.uid);
        setAuthSuccessMsg(`Welcome back, ${derivedName}! Launching flight operations...`);
      }
    } else {
      const res = await firebaseRegister(userEmail, userPassword, derivedName);
      if (res.user) {
        setCurrentUserId(res.user.uid);
        setAuthSuccessMsg(`Firebase Account created for ${derivedName}! Launching...`);
      }
    }

    persistToFirebase(updatedPassport);
    if (onUpdatePassport) onUpdatePassport(updatedPassport);

    setTimeout(() => {
      setShowAuthModal(false);
      setAuthSuccessMsg("");
      handleLaunchOperations(updatedPassport);
    }, 600);
  };

  const handleGuestSubmit = async () => {
    const res = await firebaseGuestSignIn();
    if (res.user) {
      setCurrentUserId(res.user.uid);
    }
    setShowAuthModal(false);
    handleLaunchOperations();
  };

  const handleSignOut = async () => {
    await firebaseSignOut();
    setCurrentUser(null);
    setCurrentUserId("usr_guest");
    setPassport(PROFILE_EURO_TRAVELER);
    setUserEmail("");
    setUserPassword("");
    setCurrentStep(1);
    setFirebaseStatus("Signed Out");
    localStorage.removeItem("travel_passport_active");
    localStorage.removeItem("travel_ai_auth_user");
    localStorage.removeItem("domino_app_stage");
    if (onUpdatePassport) {
      onUpdatePassport(PROFILE_EURO_TRAVELER);
    }
    if (onSignOut) {
      onSignOut();
    }
  };

  const handleLaunchOperations = (customPassport?: TravelPassportData | any) => {
    const isPassportObj = customPassport && typeof customPassport === "object" && "budgetCurrency" in customPassport;
    const p: TravelPassportData = isPassportObj ? customPassport : passport;
    const finalPassport: TravelPassportData = {
      ...p,
      fullName: p.fullName?.trim() || currentUser?.displayName || "Euro Traveler",
      age: p.age || 32,
      nationality: p.nationality || "French",
      homeCity: p.homeCity || "Paris",
      travelerType: p.travelerType || "couple",
      budgetTier: p.budgetTier || "moderate",
      budgetCurrency: p.budgetCurrency || "EUR",
      budgetCustom: p.budgetCustom || "1500 - 2000",
      budgetStandardizedUsd: p.budgetStandardizedUsd || "≈ $1,630 – $2,174 USD (Converted from EUR)"
    };

    saveTravelPassportToFirestore(currentUserId, finalPassport).catch((err) => {
      console.warn("Firestore save background notice:", err);
    });
    onProceedToOperations(finalPassport);
  };

  const currInfo = CURRENCY_RATES[passport.budgetCurrency] || { symbol: passport.budgetCurrency, rate: 1.0, name: passport.budgetCurrency };

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: "100vh",
        width: "100vw",
        backgroundColor: "#F4F1EA",
        color: "#1C2524",
        fontFamily: "'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif"
      }}
      className="select-none overflow-y-auto h-screen w-screen"
    >
      {/* Top Nav Bar */}
      <header
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "10px 24px",
          backgroundColor: "#FFFFFF",
          borderBottom: "1px solid #E2E8E5",
          fontSize: "13px",
          position: "sticky",
          top: 0,
          zIndex: 50,
          flexWrap: "wrap",
          gap: "10px"
        }}
      >
        <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
          {/* Realtime Firebase DB Status Badge */}
          <span
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "6px",
              backgroundColor: "#E0F5F0",
              color: "#0D6D63",
              fontWeight: 700,
              padding: "6px 14px",
              borderRadius: "20px",
              fontSize: "12px",
              border: "1px solid #B2DFDB"
            }}
          >
            <Cloud style={{ width: "14px", height: "14px" }} />
            {firebaseStatus}
          </span>

          {/* Sync / Load from Firebase DB Button */}
          <button
            onClick={handleFetchFromFirebase}
            title="Load & sync user profile directly from Firebase Realtime Database & Firestore"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "5px",
              backgroundColor: "#F0F7F5",
              color: "#0D6D63",
              border: "1.5px solid #0D6D63",
              padding: "5px 12px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: 700,
              fontSize: "12px"
            }}
          >
            <Sparkles style={{ width: "13px", height: "13px" }} />
            <span>Fetch from Firebase DB</span>
          </button>

          {/* Explicit Save to Firebase DB Button */}
          <button
            onClick={handleSaveToFirebase}
            title="Force immediate save to Firebase Cloud DB & RTDB"
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "5px",
              backgroundColor: "#FFFFFF",
              color: "#1C2524",
              border: "1px solid #BAC4C1",
              padding: "5px 12px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: 700,
              fontSize: "12px"
            }}
          >
            <CheckCircle2 style={{ width: "13px", height: "13px", color: "#0D6D63" }} />
            <span>Save to Firebase DB</span>
          </button>

          {/* Import / Export JSON Buttons */}
          <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              style={{ display: "none" }}
              onChange={handleImportJsonFile}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              title="Import JSON profile from travel-ai-main"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "5px",
                backgroundColor: "#F0F4F2",
                color: "#1C2524",
                border: "1px solid #BAC4C1",
                padding: "5px 10px",
                borderRadius: "6px",
                cursor: "pointer",
                fontWeight: 700,
                fontSize: "11px"
              }}
            >
              <FolderOpen style={{ width: "13px", height: "13px" }} />
              <span>Import JSON</span>
            </button>
            <button
              onClick={handleExportJsonFile}
              title="Export current profile as JSON"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: "5px",
                backgroundColor: "#F0F4F2",
                color: "#1C2524",
                border: "1px solid #BAC4C1",
                padding: "5px 10px",
                borderRadius: "6px",
                cursor: "pointer",
                fontWeight: 700,
                fontSize: "11px"
              }}
            >
              <Download style={{ width: "13px", height: "13px" }} />
              <span>Export JSON</span>
            </button>
          </div>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "12px", fontSize: "13px", color: "#697874" }}>
          <button
            onClick={handleLaunchOperations}
            style={{
              backgroundColor: "#0D6D63",
              color: "white",
              border: "none",
              padding: "8px 18px",
              borderRadius: "8px",
              cursor: "pointer",
              fontWeight: 700,
              fontSize: "13px",
              display: "flex",
              alignItems: "center",
              gap: "8px",
              boxShadow: "0 2px 8px rgba(13,109,99,0.3)"
            }}
          >
            <Plane style={{ width: "16px", height: "16px" }} />
            <span>Launch Flight Operations ➔</span>
          </button>

          <span style={{ fontWeight: 700, color: "#1C2524" }}>{passport.fullName}</span>
          {currentUser ? (
            <button
              onClick={handleSignOut}
              style={{
                backgroundColor: "#FFF5F5",
                color: "#C53030",
                border: "1px solid #FEB2B2",
                padding: "7px 14px",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "12px",
                display: "flex",
                alignItems: "center",
                gap: "5px"
              }}
              title="Sign Out"
            >
              <LogOut style={{ width: "13px", height: "13px" }} />
              <span>Log Out</span>
            </button>
          ) : (
            <button
              onClick={() => setShowAuthModal(true)}
              style={{
                backgroundColor: "#F0F4F2",
                color: "#1C2524",
                border: "1px solid #BAC4C1",
                padding: "7px 14px",
                borderRadius: "8px",
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "12px"
              }}
            >
              Sign In / Register
            </button>
          )}
        </div>
      </header>

      {/* Main Layout (Sidebar + Content Panel) */}
      <div style={{ display: "flex", flex: 1, minHeight: "calc(100vh - 58px)" }}>
        {/* Sidebar */}
        <aside
          style={{
            width: "290px",
            backgroundColor: "#F4F1EA",
            padding: "32px 24px",
            display: "flex",
            flexDirection: "column",
            borderRight: "1px solid rgba(0, 0, 0, 0.06)",
            flexShrink: 0
          }}
        >
          {/* Logo */}
          <div
            onClick={() => setCurrentStep(1)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "12px",
              marginBottom: "36px",
              cursor: "pointer"
            }}
          >
            <svg
              style={{ width: "34px", height: "34px", color: "#0D6D63" }}
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2.5"
            >
              <circle cx="12" cy="12" r="10" />
              <polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" />
            </svg>
            <span
              style={{
                fontSize: "21px",
                fontWeight: 800,
                color: "#1C2524",
                letterSpacing: "-0.5px"
              }}
            >
              Travel AI
            </span>
          </div>

          {/* Steps Navigation */}
          <nav style={{ display: "flex", flexDirection: "column", gap: "8px", flex: 1 }}>
            {steps.map((st) => {
              const isActive = currentStep === st.num;
              const isCompleted = currentStep > st.num;

              return (
                <div
                  key={st.num}
                  onClick={() => setCurrentStep(st.num)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "14px",
                    padding: "11px 14px",
                    borderRadius: "10px",
                    cursor: "pointer",
                    transition: "all 0.2s",
                    backgroundColor: isActive
                      ? "rgba(13, 109, 99, 0.09)"
                      : "transparent"
                  }}
                >
                  <div
                    style={{
                      width: "28px",
                      height: "28px",
                      borderRadius: "50%",
                      backgroundColor: isCompleted
                        ? "#0D6D63"
                        : isActive
                        ? "white"
                        : "transparent",
                      border: isActive
                        ? "1.5px solid #0D6D63"
                        : isCompleted
                        ? "1.5px solid #0D6D63"
                        : "1.5px solid #BAC4C1",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: "12px",
                      fontWeight: 700,
                      color: isCompleted ? "white" : isActive ? "#0D6D63" : "#697874"
                    }}
                  >
                    {isCompleted ? "✓" : st.num}
                  </div>
                  <span
                    style={{
                      fontSize: "14px",
                      fontWeight: isActive ? 700 : 600,
                      color: isActive ? "#1C2524" : "#697874"
                    }}
                  >
                    {st.label}
                  </span>
                </div>
              );
            })}
          </nav>

          {/* Secure Tag Footer */}
          <div style={{ paddingTop: "20px", borderTop: "1px solid #E2E8E5", marginTop: "20px" }}>
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "6px",
                fontSize: "12px",
                fontWeight: 700,
                color: "#1C2524",
                marginBottom: "6px"
              }}
            >
              <Shield style={{ width: "16px", height: "16px", color: "#0D6D63" }} />
              <span>Firebase Cloud Storage</span>
            </div>
            <p style={{ fontSize: "11px", color: "#697874", lineHeight: "1.4" }}>
              Your travel preferences are safely encrypted in Firestore and ready for automated flight and hotel vouchers.
            </p>
          </div>
        </aside>

        {/* Content Panel */}
        <main
          style={{
            flex: 1,
            backgroundColor: "#FFFFFF",
            display: "flex",
            flexDirection: "column",
            padding: "40px 60px 60px 60px",
            overflowY: "auto"
          }}
        >
          {/* Progress Tracker */}
          <div style={{ marginBottom: "26px" }}>
            <span
              style={{
                fontSize: "12px",
                fontWeight: 800,
                letterSpacing: "1px",
                color: "#0D6D63",
                textTransform: "uppercase",
                marginBottom: "8px",
                display: "block"
              }}
            >
              STEP {currentStep} OF 8
            </span>
            <div
              style={{
                width: "220px",
                height: "6px",
                backgroundColor: "#E8EDE9",
                borderRadius: "4px",
                overflow: "hidden"
              }}
            >
              <div
                style={{
                  height: "100%",
                  backgroundColor: "#0D6D63",
                  width: `${(currentStep / 8) * 100}%`,
                  transition: "width 0.3s ease"
                }}
              />
            </div>
          </div>

          {/* STEP 1: PERSONAL INFO */}
          {currentStep === 1 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2
                style={{
                  fontSize: "30px",
                  fontWeight: 800,
                  letterSpacing: "-0.5px",
                  marginBottom: "8px",
                  color: "#1C2524"
                }}
              >
                Tell us about yourself
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                We'll use this basic metadata to formulate age-appropriate, region-contextual flight and stay arrangements.
              </p>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginBottom: "24px" }}>
                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>Full Name</label>
                  <input
                    type="text"
                    value={passport.fullName}
                    onChange={(e) => persistToFirebase({ ...passport, fullName: e.target.value })}
                    placeholder="e.g. Euro Traveler / Evelyn Thorne"
                    style={{
                      padding: "12px 16px",
                      borderRadius: "10px",
                      border: "1.5px solid #E2E8E5",
                      fontSize: "14px",
                      outline: "none"
                    }}
                  />
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>Nationality / Citizenship</label>
                  <input
                    type="text"
                    value={passport.nationality}
                    onChange={(e) => persistToFirebase({ ...passport, nationality: e.target.value })}
                    placeholder="e.g. French, Indian, Canadian, American, British..."
                    style={{
                      padding: "12px 16px",
                      borderRadius: "10px",
                      border: "1.5px solid #E2E8E5",
                      fontSize: "14px",
                      outline: "none"
                    }}
                  />
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>Age</label>
                  <input
                    type="number"
                    value={passport.age}
                    onChange={(e) => persistToFirebase({ ...passport, age: parseInt(e.target.value) || 32 })}
                    style={{
                      padding: "12px 16px",
                      borderRadius: "10px",
                      border: "1.5px solid #E2E8E5",
                      fontSize: "14px",
                      outline: "none"
                    }}
                  />
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
                  <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>Gender (optional)</label>
                  <select
                    value={passport.gender}
                    onChange={(e) => persistToFirebase({ ...passport, gender: e.target.value })}
                    style={{
                      padding: "12px 16px",
                      borderRadius: "10px",
                      border: "1.5px solid #E2E8E5",
                      fontSize: "14px",
                      outline: "none",
                      backgroundColor: "white"
                    }}
                  >
                    <option value="Prefer not to say">Prefer not to say</option>
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Non-binary">Non-binary</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: "6px", gridColumn: "span 2" }}>
                  <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>Home City / Base Location</label>
                  <input
                    type="text"
                    value={passport.homeCity}
                    onChange={(e) => persistToFirebase({ ...passport, homeCity: e.target.value })}
                    placeholder="e.g. Paris | Mumbai | Vancouver | London | Tokyo"
                    style={{
                      padding: "12px 16px",
                      borderRadius: "10px",
                      border: "1.5px solid #E2E8E5",
                      fontSize: "14px",
                      outline: "none"
                    }}
                  />
                </div>
              </div>

              {/* Language Search & Chips */}
              <div style={{ display: "flex", flexDirection: "column", gap: "6px", marginTop: "10px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>
                  Languages Spoken (Search, Add & Multi-Select)
                </label>
                <div style={{ display: "flex", gap: "8px", position: "relative" }}>
                  <input
                    type="text"
                    placeholder="Type to search worldwide languages (e.g., French, English, Spanish, German, Hindi)..."
                    value={langSearch}
                    onChange={(e) => {
                      setLangSearch(e.target.value);
                      setShowSuggestions(true);
                    }}
                    style={{
                      flex: 1,
                      padding: "12px 16px",
                      borderRadius: "10px",
                      border: "1.5px solid #E2E8E5",
                      fontSize: "14px",
                      outline: "none"
                    }}
                  />
                  <button
                    type="button"
                    onClick={addCustomLanguage}
                    style={{
                      backgroundColor: "#0D6D63",
                      color: "white",
                      border: "none",
                      padding: "0 20px",
                      borderRadius: "10px",
                      fontWeight: 700,
                      fontSize: "13px",
                      cursor: "pointer"
                    }}
                  >
                    + Add
                  </button>

                  {showSuggestions && langSearch && (
                    <div
                      style={{
                        position: "absolute",
                        top: "calc(100% + 4px)",
                        left: 0,
                        right: "80px",
                        backgroundColor: "white",
                        border: "1.5px solid #E2E8E5",
                        borderRadius: "10px",
                        maxHeight: "200px",
                        overflowY: "auto",
                        zIndex: 100,
                        boxShadow: "0 8px 24px rgba(0,0,0,0.12)"
                      }}
                    >
                      {ALL_LANGUAGES.filter((l) =>
                        l.toLowerCase().includes(langSearch.toLowerCase())
                      ).map((l) => (
                        <div
                          key={l}
                          onClick={() => {
                            toggleLanguage(l);
                            setLangSearch("");
                            setShowSuggestions(false);
                          }}
                          style={{
                            padding: "10px 16px",
                            fontSize: "13px",
                            cursor: "pointer",
                            borderBottom: "1px solid #F5F7F6"
                          }}
                        >
                          {l}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Selected Languages Chips */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", marginTop: "10px" }}>
                  {passport.languages.map((l) => (
                    <span
                      key={l}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "6px",
                        padding: "6px 14px",
                        backgroundColor: "#D4F4ED",
                        border: "1.5px solid #0D6D63",
                        color: "#1C2524",
                        borderRadius: "20px",
                        fontSize: "13px",
                        fontWeight: 700
                      }}
                    >
                      {l}
                      <span
                        onClick={() => toggleLanguage(l)}
                        style={{ cursor: "pointer", fontSize: "15px", color: "#0D6D63" }}
                      >
                        ×
                      </span>
                    </span>
                  ))}
                </div>

                {/* Quick Add Popular Languages */}
                <div style={{ marginTop: "16px" }}>
                  <span style={{ fontSize: "12px", fontWeight: 700, color: "#697874" }}>
                    Quick-add Popular Languages:
                  </span>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "8px", marginTop: "6px" }}>
                    {["English", "French", "German", "Spanish", "Italian", "Hindi", "Japanese", "Arabic"].map((l) => {
                      const isSelected = passport.languages.includes(l);
                      return (
                        <div
                          key={l}
                          onClick={() => toggleLanguage(l)}
                          style={{
                            padding: "6px 16px",
                            borderRadius: "24px",
                            border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                            backgroundColor: isSelected ? "#D4F4ED" : "white",
                            color: "#1C2524",
                            fontSize: "13px",
                            fontWeight: 600,
                            cursor: "pointer"
                          }}
                        >
                          {l} {isSelected ? "✓" : "+"}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Personal Notes */}
              <div style={{ marginTop: "24px", borderTop: "1px dashed #E2E8E5", paddingTop: "18px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "6px" }}>
                  Other Personal Notes / Special Trip Context (Optional)
                </label>
                <textarea
                  rows={2}
                  value={passport.notes}
                  onChange={(e) => persistToFirebase({ ...passport, notes: e.target.value })}
                  placeholder="e.g. Summer holiday trip, anniversary, conference attendance..."
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>
            </div>
          )}

          {/* STEP 2: TRAVELER TYPE */}
          {currentStep === 2 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                What kind of traveler are you?
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                Your primary traveling configuration modifies the pace, accommodation configurations, and evening entertainment models.
              </p>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "18px" }}>
                {[
                  { key: "solo", title: "Solo", desc: "Autonomous self-guided paths, flexible schedules, single rooms." },
                  { key: "couple", title: "Couple", desc: "Romantic stays, fine dining, intimate private tour routes." },
                  { key: "family", title: "Family", desc: "Kid-friendly attractions, multi-room suites, gentle transit pace." },
                  { key: "friends", title: "Friends", desc: "Group activities, high-energy spots, shared budgets, double beds." },
                  { key: "senior", title: "Senior Traveler", desc: "Comfortable transit, accessible walks, deep cultural pacing." }
                ].map((item) => {
                  const isSelected = passport.travelerType === item.key;
                  return (
                    <div
                      key={item.key}
                      onClick={() => persistToFirebase({ ...passport, travelerType: item.key })}
                      style={{
                        border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        padding: "22px",
                        backgroundColor: isSelected ? "#D4F4ED" : "#FFFFFF",
                        cursor: "pointer",
                        display: "flex",
                        flexDirection: "column",
                        transition: "all 0.2s"
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                        <div style={{ width: "36px", height: "36px", borderRadius: "50%", backgroundColor: "#F0F4F2", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px" }}>
                          ◎
                        </div>
                        <div
                          style={{
                            width: "20px",
                            height: "20px",
                            borderRadius: "50%",
                            border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #BAC4C1",
                            backgroundColor: isSelected ? "#0D6D63" : "white",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                          }}
                        >
                          {isSelected && <div style={{ width: "8px", height: "8px", backgroundColor: "white", borderRadius: "50%" }} />}
                        </div>
                      </div>
                      <div style={{ fontSize: "16px", fontWeight: 800, marginBottom: "6px" }}>{item.title}</div>
                      <div style={{ fontSize: "13px", color: "#697874", lineHeight: "1.4" }}>{item.desc}</div>
                    </div>
                  );
                })}
              </div>

              <div style={{ marginTop: "28px", borderTop: "1px dashed #E2E8E5", paddingTop: "18px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "6px" }}>
                  Other / Custom Group Setup (Optional)
                </label>
                <input
                  type="text"
                  value={passport.travelerTypeCustom}
                  onChange={(e) => persistToFirebase({ ...passport, travelerTypeCustom: e.target.value })}
                  placeholder="e.g. Couple vacation, traveling with a pet, multi-generational family..."
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>

              {/* FLIGHT DELAY AUTONOMOUS REBOOKING QUESTION */}
              <div style={{ marginTop: "32px", borderTop: "2px solid #E2E8E5", paddingTop: "24px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                  <div style={{ width: "32px", height: "32px", borderRadius: "8px", backgroundColor: "#D4F4ED", display: "flex", alignItems: "center", justifyContent: "center", color: "#0D6D63" }}>
                    <Plane style={{ width: "18px", height: "18px" }} />
                  </div>
                  <div>
                    <h3 style={{ fontSize: "18px", fontWeight: 800, color: "#1C2524", margin: 0 }}>
                      Flight Delay & Disruption Auto-Booking
                    </h3>
                    <p style={{ fontSize: "13px", color: "#697874", margin: "2px 0 0 0" }}>
                      When your flight experiences a delay, can our Autonomous AI automatically re-book your tickets without waiting for manual confirmation?
                    </p>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px", marginTop: "16px" }}>
                  <div
                    onClick={() => persistToFirebase({ ...passport, autoRebookOnDelay: true })}
                    style={{
                      border: passport.autoRebookOnDelay ? "2px solid #0D6D63" : "1.5px solid #E2E8E5",
                      borderRadius: "14px",
                      padding: "18px",
                      backgroundColor: passport.autoRebookOnDelay ? "#E0F5F0" : "#FFFFFF",
                      cursor: "pointer",
                      display: "flex",
                      flexDirection: "column",
                      gap: "6px",
                      transition: "all 0.2s"
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontSize: "15px", fontWeight: 800, color: "#0D6D63" }}>
                        ⚡ Yes, Auto-Book My Ticket on Delay
                      </span>
                      <div style={{ width: "18px", height: "18px", borderRadius: "50%", border: passport.autoRebookOnDelay ? "5px solid #0D6D63" : "2px solid #BAC4C1", backgroundColor: "white" }} />
                    </div>
                    <p style={{ fontSize: "12px", color: "#697874", margin: 0, lineHeight: "1.4" }}>
                      Instant autonomous recovery. If a delay threatens your connection, AI locks in replacement tickets immediately with zero queue time.
                    </p>
                  </div>

                  <div
                    onClick={() => persistToFirebase({ ...passport, autoRebookOnDelay: false })}
                    style={{
                      border: !passport.autoRebookOnDelay ? "2px solid #0D6D63" : "1.5px solid #E2E8E5",
                      borderRadius: "14px",
                      padding: "18px",
                      backgroundColor: !passport.autoRebookOnDelay ? "#F0F4F2" : "#FFFFFF",
                      cursor: "pointer",
                      display: "flex",
                      flexDirection: "column",
                      gap: "6px",
                      transition: "all 0.2s"
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <span style={{ fontSize: "15px", fontWeight: 800, color: "#1C2524" }}>
                        ✋ No, Prompt & Ask Me First
                      </span>
                      <div style={{ width: "18px", height: "18px", borderRadius: "50%", border: !passport.autoRebookOnDelay ? "5px solid #0D6D63" : "2px solid #BAC4C1", backgroundColor: "white" }} />
                    </div>
                    <p style={{ fontSize: "12px", color: "#697874", margin: 0, lineHeight: "1.4" }}>
                      Send app notifications with available alternatives and wait for your manual tap approval before issuing new tickets.
                    </p>
                  </div>
                </div>

                {passport.autoRebookOnDelay && (
                  <div style={{ marginTop: "16px", backgroundColor: "#F8FAF9", border: "1px solid #E2E8E5", borderRadius: "10px", padding: "14px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px" }}>
                    <span style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>
                      Auto-rebook when delay exceeds:
                    </span>
                    <div style={{ display: "flex", gap: "8px" }}>
                      {[30, 45, 60, 90].map((mins) => (
                        <button
                          key={mins}
                          type="button"
                          onClick={() => persistToFirebase({ ...passport, autoRebookDelayThresholdMinutes: mins })}
                          style={{
                            padding: "6px 14px",
                            borderRadius: "8px",
                            fontSize: "12px",
                            fontWeight: 700,
                            border: passport.autoRebookDelayThresholdMinutes === mins ? "1.5px solid #0D6D63" : "1px solid #BAC4C1",
                            backgroundColor: passport.autoRebookDelayThresholdMinutes === mins ? "#D4F4ED" : "white",
                            color: passport.autoRebookDelayThresholdMinutes === mins ? "#0D6D63" : "#1C2524",
                            cursor: "pointer"
                          }}
                        >
                          {mins} mins
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 3: ACCESSIBILITY & COMFORT */}
          {currentStep === 3 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                Accessibility & comfort options
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                Completely optional. Select any specific needs so our AI automatically excludes stays with stairs, filters for sensory-friendly spots, or highlights elevators.
              </p>

              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                {[
                  { key: "accessibilityMobility", title: "Mobility / Wheelchair Access", desc: "No stairs, step-free entries, extra wide doorways, roll-in showers." },
                  { key: "accessibilityVisual", title: "Visual Assistance friendly", desc: "High-contrast markings, braille signs, audio guides, guide-dog friendly stays." },
                  { key: "accessibilityHearing", title: "Hearing / Audio support", desc: "Visual fire alarms, captioned assistance devices, vibration indicators." },
                  { key: "accessibilitySenior", title: "Elderly & Senior friendly", desc: "Sturdy handrails, minimal walking distances, elevators highlighted." },
                  { key: "accessibilityChild", title: "Child-friendly (Toddlers/Infants)", desc: "Crib options, high chairs, safety gates available, stroller ramps." },
                  { key: "accessibilityNone", title: "None / Not applicable", desc: "No specific mobility or visual accommodations required." }
                ].map((item) => {
                  const isChecked = (passport as any)[item.key];
                  return (
                    <div
                      key={item.key}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        padding: "16px 20px",
                        border: isChecked ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        backgroundColor: "white"
                      }}
                    >
                      <div>
                        <h4 style={{ fontSize: "15px", fontWeight: 700, marginBottom: "4px" }}>{item.title}</h4>
                        <p style={{ fontSize: "13px", color: "#697874" }}>{item.desc}</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(e) => persistToFirebase({ ...passport, [item.key]: e.target.checked })}
                        style={{ width: "20px", height: "20px", accentColor: "#0D6D63", cursor: "pointer" }}
                      />
                    </div>
                  );
                })}
              </div>

              <div style={{ marginTop: "28px", borderTop: "1px dashed #E2E8E5", paddingTop: "18px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "6px" }}>
                  Other Accessibility, Medical or Sensory Needs (Optional)
                </label>
                <input
                  type="text"
                  value={passport.accessibilityCustom}
                  onChange={(e) => persistToFirebase({ ...passport, accessibilityCustom: e.target.value })}
                  placeholder="e.g. Ground floor room required, CPAP power outlet near bed, sensory-quiet accommodations..."
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>

              {/* EMERGENCY TRAVELER & COMPETITOR AIRLINE AUTO-BOOKING AUTHORIZATION */}
              <div style={{ marginTop: "32px", borderTop: "2px solid #E2E8E5", paddingTop: "24px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "8px" }}>
                  <div style={{ width: "32px", height: "32px", borderRadius: "8px", backgroundColor: "#FEE2E2", display: "flex", alignItems: "center", justifyContent: "center", color: "#DC2626" }}>
                    <Shield style={{ width: "18px", height: "18px" }} />
                  </div>
                  <div>
                    <h3 style={{ fontSize: "18px", fontWeight: 800, color: "#1C2524", margin: 0 }}>
                      Emergency Traveler & Competitor Airline Auto-Booking
                    </h3>
                    <p style={{ fontSize: "13px", color: "#697874", margin: "2px 0 0 0" }}>
                      For urgent trips: Authorize autonomous seat booking across competitor & partner airlines for fastest recovery.
                    </p>
                  </div>
                </div>

                {/* Question 1: Are you an Emergency Traveler? */}
                <div
                  style={{
                    marginTop: "16px",
                    backgroundColor: passport.isEmergencyTraveler ? "#FFF5F5" : "white",
                    border: passport.isEmergencyTraveler ? "1.5px solid #FEB2B2" : "1.5px solid #E2E8E5",
                    borderRadius: "14px",
                    padding: "18px 20px"
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <div>
                      <label htmlFor="chk-emergency" style={{ fontSize: "15px", fontWeight: 800, color: passport.isEmergencyTraveler ? "#C53030" : "#1C2524", cursor: "pointer", display: "flex", alignItems: "center", gap: "8px" }}>
                        <span>🚨 I am an Urgent / Emergency Traveler</span>
                      </label>
                      <p style={{ fontSize: "12px", color: "#697874", margin: "4px 0 0 0" }}>
                        Flag trip as high-priority (e.g. Critical Medical Appointment, Urgent Family Matter, Fixed International Connection, High-Stakes Business Meeting).
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      id="chk-emergency"
                      checked={passport.isEmergencyTraveler}
                      onChange={(e) => persistToFirebase({ ...passport, isEmergencyTraveler: e.target.checked })}
                      style={{ width: "20px", height: "20px", cursor: "pointer", accentColor: "#DC2626" }}
                    />
                  </div>

                  {passport.isEmergencyTraveler && (
                    <div style={{ marginTop: "14px", paddingTop: "12px", borderTop: "1px dashed #FEB2B2" }}>
                      <label style={{ fontSize: "12px", fontWeight: 700, color: "#C53030", display: "block", marginBottom: "6px" }}>
                        Emergency Nature / Urgency Context (Optional)
                      </label>
                      <input
                        type="text"
                        value={passport.emergencyReason || ""}
                        onChange={(e) => persistToFirebase({ ...passport, emergencyReason: e.target.value })}
                        placeholder="e.g. Urgent surgical transfer / Fixed wedding event / Time-sensitive business deal"
                        style={{ width: "100%", padding: "10px 14px", borderRadius: "8px", border: "1px solid #FEB2B2", fontSize: "13px", outline: "none", backgroundColor: "white" }}
                      />
                    </div>
                  )}
                </div>

                {/* Question 2: Competitor Airline Seat Booking Authorization */}
                <div style={{ marginTop: "18px" }}>
                  <label style={{ fontSize: "14px", fontWeight: 800, color: "#1C2524", display: "block", marginBottom: "8px" }}>
                    If you are an emergency traveler or your flight faces severe delay, can we auto-book seats for you on competitor flights?
                  </label>
                  <p style={{ fontSize: "12px", color: "#697874", marginBottom: "12px" }}>
                    (e.g., British Airways, Delta Air Lines, Lufthansa, Air France, United Airlines, Virgin Atlantic, Emirates)
                  </p>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px" }}>
                    <div
                      onClick={() => persistToFirebase({ ...passport, allowCompetitorInterlineRebooking: true })}
                      style={{
                        border: passport.allowCompetitorInterlineRebooking ? "2px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        padding: "16px",
                        backgroundColor: passport.allowCompetitorInterlineRebooking ? "#E0F5F0" : "#FFFFFF",
                        cursor: "pointer",
                        display: "flex",
                        flexDirection: "column",
                        gap: "4px",
                        transition: "all 0.2s"
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontSize: "14px", fontWeight: 800, color: "#0D6D63" }}>
                          🌐 Yes, Auto-Book on Competitor Flights
                        </span>
                        <div style={{ width: "18px", height: "18px", borderRadius: "50%", border: passport.allowCompetitorInterlineRebooking ? "5px solid #0D6D63" : "2px solid #BAC4C1", backgroundColor: "white" }} />
                      </div>
                      <p style={{ fontSize: "12px", color: "#697874", margin: 0, lineHeight: "1.4" }}>
                        Guarantees fastest arrival. Authorizes IATA Rule 240 / FIM electronic interline settlement across rival airlines.
                      </p>
                    </div>

                    <div
                      onClick={() => persistToFirebase({ ...passport, allowCompetitorInterlineRebooking: false })}
                      style={{
                        border: !passport.allowCompetitorInterlineRebooking ? "2px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        padding: "16px",
                        backgroundColor: !passport.allowCompetitorInterlineRebooking ? "#F0F4F2" : "#FFFFFF",
                        cursor: "pointer",
                        display: "flex",
                        flexDirection: "column",
                        gap: "4px",
                        transition: "all 0.2s"
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <span style={{ fontSize: "14px", fontWeight: 800, color: "#1C2524" }}>
                          🔒 No, Same Airline / Alliance Only
                        </span>
                        <div style={{ width: "18px", height: "18px", borderRadius: "50%", border: !passport.allowCompetitorInterlineRebooking ? "5px solid #0D6D63" : "2px solid #BAC4C1", backgroundColor: "white" }} />
                      </div>
                      <p style={{ fontSize: "12px", color: "#697874", margin: 0, lineHeight: "1.4" }}>
                        Rebook only on flights operated by your primary booked airline or its immediate joint venture alliance.
                      </p>
                    </div>
                  </div>

                  {passport.allowCompetitorInterlineRebooking && (
                    <div style={{ marginTop: "14px", backgroundColor: "#F8FAF9", border: "1px solid #E2E8E5", borderRadius: "10px", padding: "14px 18px" }}>
                      <span style={{ fontSize: "12px", fontWeight: 700, color: "#697874", display: "block", marginBottom: "8px" }}>
                        Preferred Competitor & Partner Airlines (Auto-selected for interline recovery):
                      </span>
                      <div style={{ display: "flex", flexWrap: "wrap", gap: "8px" }}>
                        {[
                          { code: "AF", name: "Air France" },
                          { code: "BA", name: "British Airways" },
                          { code: "DL", name: "Delta" },
                          { code: "LH", name: "Lufthansa" },
                          { code: "UA", name: "United" },
                          { code: "VS", name: "Virgin Atlantic" },
                          { code: "EK", name: "Emirates" }
                        ].map((airline) => {
                          const list = passport.preferredCompetitorAirlines || ["Air France", "British Airways", "Lufthansa", "Delta"];
                          const isSelected = list.includes(airline.name);
                          return (
                            <button
                              key={airline.code}
                              type="button"
                              onClick={() => {
                                const nextList = isSelected
                                  ? list.filter((a) => a !== airline.name)
                                  : [...list, airline.name];
                                persistToFirebase({ ...passport, preferredCompetitorAirlines: nextList });
                              }}
                              style={{
                                padding: "5px 12px",
                                borderRadius: "20px",
                                fontSize: "12px",
                                fontWeight: 600,
                                border: isSelected ? "1.5px solid #0D6D63" : "1px solid #BAC4C1",
                                backgroundColor: isSelected ? "#D4F4ED" : "white",
                                color: isSelected ? "#0D6D63" : "#1C2524",
                                cursor: "pointer"
                              }}
                            >
                              {airline.name} {isSelected ? "✓" : "+"}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: TRAVEL STYLES */}
          {currentStep === 4 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                Select your travel styles
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                Choose at least 3 style flags. This heavily calibrates the points of interest (POIs) our travel generator populates in your final plan.
              </p>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "18px" }}>
                {[
                  { key: "adventure", title: "Adventure", icon: "★" },
                  { key: "nature", title: "Nature", icon: "🌲" },
                  { key: "culture", title: "Culture", icon: "🏛️" },
                  { key: "history", title: "History", icon: "📜" },
                  { key: "food_wine", title: "Food & Wine", icon: "🍷" },
                  { key: "food", title: "Food / Gastronomy", icon: "🍽️" },
                  { key: "shopping", title: "Shopping", icon: "🛍️" },
                  { key: "relaxation", title: "Relaxation", icon: "🏖️" },
                  { key: "spiritual", title: "Spiritual", icon: "🕉️" },
                  { key: "photography", title: "Photography", icon: "📷" }
                ].map((item) => {
                  const isSelected = passport.travelStyles.includes(item.key);
                  return (
                    <div
                      key={item.key}
                      onClick={() => toggleStyle(item.key)}
                      style={{
                        border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        padding: "20px",
                        backgroundColor: isSelected ? "#D4F4ED" : "#FFFFFF",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        transition: "all 0.2s"
                      }}
                    >
                      <span style={{ fontSize: "18px" }}>{item.icon}</span>
                      <span style={{ fontSize: "16px", fontWeight: 800 }}>{item.title}</span>
                    </div>
                  );
                })}
              </div>

              {/* Status Callout Badge */}
              <div
                style={{
                  marginTop: "24px",
                  backgroundColor: "#D4F4ED",
                  border: "1.5px solid #80CBC4",
                  borderRadius: "14px",
                  padding: "18px 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "14px"
                }}
              >
                <Info style={{ color: "#0D6D63", width: "20px", height: "20px" }} />
                <span style={{ fontSize: "15px", fontWeight: 700, color: "#0D6D63" }}>
                  {passport.travelStyles.length} styles selected — Great selection! This unlocks specialized local guide layers.
                </span>
              </div>

              <div style={{ marginTop: "28px", borderTop: "1px dashed #E2E8E5", paddingTop: "18px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "6px" }}>
                  Other Custom Activities or Niche Interests (Optional)
                </label>
                <input
                  type="text"
                  value={passport.travelStylesCustom}
                  onChange={(e) => persistToFirebase({ ...passport, travelStylesCustom: e.target.value })}
                  placeholder="e.g. Scuba diving, local pottery workshops, vineyard tours..."
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>
            </div>
          )}

          {/* STEP 5: FOOD PREFERENCES */}
          {currentStep === 5 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                Culinary & food preferences
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                We'll tune the culinary guide layers of your itinerary to match. Select dietary standards and flag any critical allergy constraints.
              </p>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", gap: "18px", marginBottom: "24px" }}>
                {[
                  { key: "vegetarian", title: "Vegetarian", desc: "No meat, poultry, or fish." },
                  { key: "non_vegetarian", title: "Non-vegetarian", desc: "Includes poultry, red meat, seafood." },
                  { key: "vegan", title: "Vegan", desc: "Entirely plant-based culinary tracks." },
                  { key: "halal", title: "Halal", desc: "Strictly Halal-certified dining recommendations." },
                  { key: "jain", title: "Jain", desc: "No meat, root vegetables, or garlic/onions." },
                  { key: "other_custom", title: "Other / Custom", desc: "Specify custom dietary guidelines below." }
                ].map((item) => {
                  const isSelected = passport.dietaryStandards.includes(item.key);
                  return (
                    <div
                      key={item.key}
                      onClick={() => toggleDiet(item.key)}
                      style={{
                        border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        padding: "20px",
                        backgroundColor: isSelected ? "#D4F4ED" : "#FFFFFF",
                        cursor: "pointer",
                        transition: "all 0.2s"
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                        <div style={{ fontSize: "16px", fontWeight: 800 }}>{item.title}</div>
                        <div
                          style={{
                            width: "18px",
                            height: "18px",
                            borderRadius: "50%",
                            border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #BAC4C1",
                            backgroundColor: isSelected ? "#0D6D63" : "white"
                          }}
                        />
                      </div>
                      <div style={{ fontSize: "13px", color: "#697874" }}>{item.desc}</div>
                    </div>
                  );
                })}
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "6px", marginBottom: "20px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524" }}>
                  Allergies & Medical Restrictions (Optional)
                </label>
                <input
                  type="text"
                  value={passport.allergies}
                  onChange={(e) => persistToFirebase({ ...passport, allergies: e.target.value })}
                  placeholder="e.g. None, Severe peanut allergy, celiac disease (gluten-free)..."
                  style={{
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>

              <div style={{ marginTop: "18px", borderTop: "1px dashed #E2E8E5", paddingTop: "18px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "6px" }}>
                  Other Custom Dietary, Cuisine or Kitchen Preferences (Optional)
                </label>
                <input
                  type="text"
                  value={passport.foodCustom}
                  onChange={(e) => persistToFirebase({ ...passport, foodCustom: e.target.value })}
                  placeholder="e.g. Prefer organic farm-to-table restaurants, French bakeries, tea ceremonies..."
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>
            </div>
          )}

          {/* STEP 6: CLOTHING PREFERENCES */}
          {currentStep === 6 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                Clothing & modest dress style
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                Your wardrobe settings guide our local clothing recommendations, modesty guidelines for holy sites, and packing checklists.
              </p>

              <div style={{ marginBottom: "24px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "8px" }}>
                  Pack Styles
                </label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: "10px" }}>
                  {["casual", "western", "traditional", "winter", "summer", "formals", "other"].map((p) => {
                    const isSelected = passport.packStyles.includes(p);
                    return (
                      <div
                        key={p}
                        onClick={() => togglePackStyle(p)}
                        style={{
                          padding: "8px 18px",
                          borderRadius: "24px",
                          border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                          backgroundColor: isSelected ? "#D4F4ED" : "white",
                          fontSize: "13px",
                          fontWeight: 600,
                          cursor: "pointer"
                        }}
                      >
                        {p.toUpperCase()} {isSelected ? "✓" : "+"}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "16px 20px",
                    border: passport.modestClothing ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                    borderRadius: "14px",
                    backgroundColor: "white"
                  }}
                >
                  <div>
                    <h4 style={{ fontSize: "15px", fontWeight: 700, marginBottom: "4px" }}>Modest clothing filters</h4>
                    <p style={{ fontSize: "13px", color: "#697874" }}>Flag temple and local custom friendly outfits covering shoulders & knees.</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={passport.modestClothing}
                    onChange={(e) => persistToFirebase({ ...passport, modestClothing: e.target.checked })}
                    style={{ width: "20px", height: "20px", accentColor: "#0D6D63", cursor: "pointer" }}
                  />
                </div>

                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "16px 20px",
                    border: passport.hotWeather ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                    borderRadius: "14px",
                    backgroundColor: "white"
                  }}
                >
                  <div>
                    <h4 style={{ fontSize: "15px", fontWeight: 700, marginBottom: "4px" }}>Prioritize hot weather comfort</h4>
                    <p style={{ fontSize: "13px", color: "#697874" }}>Suggest light fabrics, breathable synthetics, and sun protection.</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={passport.hotWeather}
                    onChange={(e) => persistToFirebase({ ...passport, hotWeather: e.target.checked })}
                    style={{ width: "20px", height: "20px", accentColor: "#0D6D63", cursor: "pointer" }}
                  />
                </div>
              </div>

              <div style={{ marginTop: "28px", borderTop: "1px dashed #E2E8E5", paddingTop: "18px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", display: "block", marginBottom: "6px" }}>
                  Other Wardrobe, Packing, or Event Attire Notes (Optional)
                </label>
                <input
                  type="text"
                  value={passport.clothingCustom}
                  onChange={(e) => persistToFirebase({ ...passport, clothingCustom: e.target.value })}
                  placeholder="e.g. Need formal evening attire for fine dining, comfortable walking shoes..."
                  style={{
                    width: "100%",
                    padding: "12px 16px",
                    borderRadius: "10px",
                    border: "1.5px solid #E2E8E5",
                    fontSize: "14px",
                    outline: "none"
                  }}
                />
              </div>
            </div>
          )}

          {/* STEP 7: BUDGET & MULTI-CURRENCY WITH PURPOSE SPLIT-UPS */}
          {currentStep === 7 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                Calibrate your budget footprint
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                Select your currency and customize your purpose split-ups. The total budget will automatically sum up all allocations, with a round-off option and live USD conversion.
              </p>

              {/* Standard Tier Selection Cards */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "18px", marginBottom: "28px" }}>
                {[
                  { key: "budget", title: "Budget / Low", range: "€50 – €100 / day ($55–$110 USD)", desc: "Economical & smart. Clean hostels, local transit, street food gems." },
                  { key: "moderate", title: "Moderate / Mid", range: "€150 – €300 / day ($163–$326 USD)", desc: "Balanced comfort. 3-star/4-star boutique stays, private rideshares." },
                  { key: "premium_luxury", title: "Premium / Luxury", range: "€400 – €1,000+ / day ($435–$1,087+ USD)", desc: "Indulgent travel. 5-star luxury resorts, gourmet dining, and VIP access." },
                  { key: "flexible", title: "Flexible Range", range: "€100 – €500 / day ($110–$543 USD)", desc: "Dynamic mix between boutique stays and premium experiences." }
                ].map((item) => {
                  const isSelected = passport.budgetTier === item.key;
                  return (
                    <div
                      key={item.key}
                      onClick={() => persistToFirebase({ ...passport, budgetTier: item.key })}
                      style={{
                        border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #E2E8E5",
                        borderRadius: "14px",
                        padding: "20px",
                        backgroundColor: isSelected ? "#D4F4ED" : "#FFFFFF",
                        cursor: "pointer",
                        transition: "all 0.2s"
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                        <div style={{ fontSize: "16px", fontWeight: 800 }}>{item.title}</div>
                        <div
                          style={{
                            width: "18px",
                            height: "18px",
                            borderRadius: "50%",
                            border: isSelected ? "1.5px solid #0D6D63" : "1.5px solid #BAC4C1",
                            backgroundColor: isSelected ? "#0D6D63" : "white"
                          }}
                        />
                      </div>
                      <div style={{ fontSize: "11px", fontWeight: 800, color: "#0D6D63", backgroundColor: "#E0F5F0", padding: "4px 8px", borderRadius: "6px", display: "inline-block", marginBottom: "8px" }}>
                        {item.range}
                      </div>
                      <div style={{ fontSize: "13px", color: "#697874", lineHeight: "1.4" }}>{item.desc}</div>
                    </div>
                  );
                })}
              </div>

              {/* 33+ World Currencies & Purpose Split-Ups Container */}
              <div style={{ backgroundColor: "#FFFFFF", border: "1.5px solid #E2E8E5", borderRadius: "16px", padding: "28px", boxShadow: "0 4px 14px rgba(0,0,0,0.03)" }}>
                {/* Top Row: Currency & Custom Budget Input */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: "20px", marginBottom: "24px" }}>
                  <div>
                    <label style={{ fontSize: "13px", fontWeight: 800, color: "#1C2524", marginBottom: "8px", display: "block" }}>
                      🌍 Country Currency (160+ World Currencies)
                    </label>
                    <select
                      value={passport.budgetCurrency}
                      onChange={(e) => handleCurrencyChange(e.target.value)}
                      style={{
                        width: "100%",
                        padding: "12px 16px",
                        borderRadius: "10px",
                        border: "1.5px solid #E2E8E5",
                        fontSize: "14px",
                        fontWeight: 700,
                        backgroundColor: "white",
                        outline: "none"
                      }}
                    >
                      {Object.entries(CURRENCY_RATES).map(([code, info]) => (
                        <option key={code} value={code}>
                          {info.name}
                        </option>
                      ))}
                    </select>
                    <span style={{ fontSize: "12px", color: "#697874", marginTop: "6px", display: "block" }}>
                      Select home currency for instant automatic conversion
                    </span>
                  </div>

                  <div>
                    <label style={{ fontSize: "13px", fontWeight: 800, color: "#1C2524", marginBottom: "8px", display: "block" }}>
                      💳 Custom Range / Direct Amount
                    </label>
                    <input
                      type="text"
                      value={passport.budgetCustom}
                      onChange={(e) => handleBudgetCustomChange(e.target.value)}
                      placeholder="e.g. 1500 - 2000 or 50000"
                      style={{
                        width: "100%",
                        padding: "12px 16px",
                        borderRadius: "10px",
                        border: "1.5px solid #E2E8E5",
                        fontSize: "14px",
                        fontWeight: 700,
                        outline: "none"
                      }}
                    />
                    <span style={{ fontSize: "12px", color: "#697874", marginTop: "6px", display: "block" }}>
                      Or fine-tune using purpose split-ups below
                    </span>
                  </div>
                </div>

                {/* Purpose & Expense Split-ups Section */}
                <div style={{ borderTop: "1px dashed #E2E8E5", paddingTop: "20px", marginTop: "20px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: "10px", marginBottom: "14px" }}>
                    <div>
                      <h3 style={{ fontSize: "16px", fontWeight: 800, color: "#0D6D63", margin: 0 }}>
                        📊 Purpose & Expense Split-ups
                      </h3>
                      <p style={{ fontSize: "12px", color: "#697874", margin: "4px 0 0 0" }}>
                        Allocate specific amounts for different travel purposes. The total is calculated automatically.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddSplitupRow}
                      style={{
                        backgroundColor: "#D4F4ED",
                        color: "#0D6D63",
                        fontWeight: 700,
                        border: "none",
                        padding: "8px 14px",
                        borderRadius: "8px",
                        cursor: "pointer",
                        fontSize: "12px",
                        display: "flex",
                        alignItems: "center",
                        gap: "6px"
                      }}
                    >
                      <Plus style={{ width: "14px", height: "14px" }} />
                      <span>+ Add Custom Purpose</span>
                    </button>
                  </div>

                  {/* Split-up rows list */}
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    {getBreakdown().map((item) => (
                      <div
                        key={item.id}
                        style={{
                          display: "flex",
                          gap: "12px",
                          alignItems: "center",
                          backgroundColor: "#F8FAF9",
                          padding: "12px 16px",
                          borderRadius: "10px",
                          border: "1px solid #E2E8E5"
                        }}
                      >
                        <div style={{ flex: 2, display: "flex", alignItems: "center", gap: "8px" }}>
                          <span>{item.icon || "✨"}</span>
                          <input
                            type="text"
                            value={item.purpose}
                            onChange={(e) => handleUpdateSplitupItem(item.id, "purpose", e.target.value)}
                            style={{
                              fontWeight: 700,
                              border: "none",
                              backgroundColor: "transparent",
                              width: "100%",
                              fontSize: "13px",
                              outline: "none"
                            }}
                          />
                        </div>
                        <div style={{ flex: 1, display: "flex", alignItems: "center", gap: "6px" }}>
                          <span style={{ fontWeight: 800, color: "#697874" }}>{currInfo.symbol}</span>
                          <input
                            type="number"
                            value={item.amount}
                            min={0}
                            step={50}
                            onChange={(e) => handleUpdateSplitupItem(item.id, "amount", parseFloat(e.target.value) || 0)}
                            style={{
                              height: "40px",
                              borderRadius: "8px",
                              border: "1.5px solid #E2E8E5",
                              padding: "0 10px",
                              width: "100%",
                              fontWeight: 700,
                              outline: "none"
                            }}
                          />
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveSplitupRow(item.id)}
                          style={{
                            background: "none",
                            border: "none",
                            color: "#C62828",
                            cursor: "pointer",
                            padding: "0 6px"
                          }}
                          title="Remove row"
                        >
                          <Trash2 style={{ width: "16px", height: "16px" }} />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Total Calculation & Round-Off Control Bar */}
                  <div
                    style={{
                      marginTop: "24px",
                      backgroundColor: "#F0F7F5",
                      border: "1.5px solid #B2DFDB",
                      padding: "18px 24px",
                      borderRadius: "12px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: "16px"
                    }}
                  >
                    <div>
                      <div style={{ fontSize: "12px", fontWeight: 700, color: "#697874", textTransform: "uppercase" }}>
                        Calculated Total Sum of Split-ups:
                      </div>
                      <div style={{ fontSize: "24px", fontWeight: 800, color: "#0D6D63", marginTop: "2px" }}>
                        {passport.budgetCurrency} {currInfo.symbol}
                        {passport.budgetCustom}
                        {roundOffActive ? " (Rounded)" : ""}
                      </div>
                    </div>

                    {/* Round Off Option */}
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "10px",
                        backgroundColor: "white",
                        padding: "10px 16px",
                        borderRadius: "10px",
                        border: "1px solid #E2E8E5"
                      }}
                    >
                      <input
                        type="checkbox"
                        id="chk-roundoff"
                        checked={roundOffActive}
                        onChange={(e) => handleToggleRoundOff(e.target.checked)}
                        style={{ width: "18px", height: "18px", cursor: "pointer", accentColor: "#0D6D63" }}
                      />
                      <label htmlFor="chk-roundoff" style={{ fontSize: "13px", fontWeight: 700, color: "#1C2524", cursor: "pointer", margin: 0 }}>
                        🔄 Round off total budget (to nearest 50 / 500)
                      </label>
                    </div>
                  </div>

                  {/* Standardized Conversion Banner */}
                  <div
                    style={{
                      marginTop: "16px",
                      backgroundColor: "#D4F4ED",
                      border: "1.5px solid #80CBC4",
                      padding: "16px 20px",
                      borderRadius: "12px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: "12px"
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: "10px", fontSize: "14px", fontWeight: 700, color: "#0D6D63" }}>
                      <Sparkles style={{ width: "20px", height: "20px" }} />
                      <span>
                        Standardized for Global Itinerary Planning: <strong>{passport.budgetStandardizedUsd}</strong>
                      </span>
                    </div>
                    <span style={{ fontSize: "12px", color: "#697874", fontWeight: 600 }}>
                      Calibrates international hotels, dining & flight vouchers
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 8: SUMMARY REVIEW & LAUNCH */}
          {currentStep === 8 && (
            <div style={{ flex: 1, marginBottom: "30px" }}>
              <h2 style={{ fontSize: "30px", fontWeight: 800, letterSpacing: "-0.5px", marginBottom: "8px", color: "#1C2524" }}>
                Review your travel passport
              </h2>
              <p style={{ fontSize: "15px", color: "#697874", marginBottom: "28px", maxWidth: "680px", lineHeight: "1.5" }}>
                Your AI generation profile is fully configured and synchronized with Firebase Cloud Database. Review the compiled metadata below before launching your flight operations and IROPS platform.
              </p>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: "18px", marginBottom: "24px" }}>
                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Personal Info</h4>
                    <button onClick={() => setCurrentStep(1)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#1C2524", marginBottom: "4px" }}>
                    {passport.fullName}, {passport.age} • {passport.gender} ({passport.nationality})
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    Home: {passport.homeCity || "Not specified"} • {passport.languages.join(", ")}
                    {passport.notes ? ` • Note: ${passport.notes}` : ""}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Traveler Type</h4>
                    <button onClick={() => setCurrentStep(2)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#1C2524", marginBottom: "4px" }}>
                    {passport.travelerType.toUpperCase()} Configuration
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    {passport.travelerTypeCustom ? `Custom: ${passport.travelerTypeCustom}` : "Intimate private tour routes, romantic stays, fine dining"}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Accessibility</h4>
                    <button onClick={() => setCurrentStep(3)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#1C2524", marginBottom: "4px" }}>
                    {passport.accessibilityMobility ? "Mobility / Wheelchair Access" : "Standard Accessibility"}
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    {passport.accessibilityCustom ? `Note: ${passport.accessibilityCustom}` : "Step-free entry, elevators, prioritized accessibility filters"}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Travel Style</h4>
                    <button onClick={() => setCurrentStep(4)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#1C2524", marginBottom: "4px" }}>
                    {passport.travelStyles.map((s) => s.replace("_", " ").toUpperCase()).join(", ")}
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    {passport.travelStyles.length} style layers calibrated for POI selection
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Food Preferences</h4>
                    <button onClick={() => setCurrentStep(5)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#1C2524", marginBottom: "4px" }}>
                    {passport.dietaryStandards.map((d) => d.replace("_", " ").toUpperCase()).join(", ")}
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    Allergies: {passport.allergies || "None"}
                    {passport.foodCustom ? ` • Custom: ${passport.foodCustom}` : ""}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Clothing & Packing</h4>
                    <button onClick={() => setCurrentStep(6)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: "#1C2524", marginBottom: "4px" }}>
                    {passport.packStyles.map((p) => p.toUpperCase()).join(", ")} WEAR
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    {passport.modestClothing ? "Modesty filters active" : "Standard checklist"}
                    {passport.clothingCustom ? ` • ${passport.clothingCustom}` : ""}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Flight Delay Protection</h4>
                    <button onClick={() => setCurrentStep(2)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: passport.autoRebookOnDelay ? "#0D6D63" : "#1C2524", marginBottom: "4px" }}>
                    {passport.autoRebookOnDelay ? "⚡ Autonomous Auto-Rebook Enabled" : "✋ Manual Approval Required"}
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    {passport.autoRebookOnDelay ? `Triggers immediately when delay exceeds ${passport.autoRebookDelayThresholdMinutes || 30} mins` : "Prompts traveler for confirmation before issuing replacement tickets"}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Emergency & Competitor Rebooking</h4>
                    <button onClick={() => setCurrentStep(3)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "15px", fontWeight: 700, color: passport.isEmergencyTraveler ? "#C53030" : "#0D6D63", marginBottom: "4px" }}>
                    {passport.isEmergencyTraveler ? "🚨 Urgent / Emergency Traveler Active" : "Standard Traveler"}
                  </div>
                  <div style={{ fontSize: "12px", color: "#697874" }}>
                    {passport.allowCompetitorInterlineRebooking
                      ? `Competitor Airlines Authorized: ${(passport.preferredCompetitorAirlines || ["Air France", "British Airways", "Lufthansa", "Delta"]).join(", ")}`
                      : "Restricted to Primary Airline network only"}
                  </div>
                </div>

                <div style={{ border: "1.5px solid #E2E8E5", borderRadius: "14px", padding: "20px", backgroundColor: "white", gridColumn: "span 2" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "8px" }}>
                    <h4 style={{ fontSize: "14px", fontWeight: 700, color: "#697874" }}>Budget Footprint & Split-ups</h4>
                    <button onClick={() => setCurrentStep(7)} style={{ background: "none", border: "none", color: "#0D6D63", fontWeight: 700, cursor: "pointer" }}>Edit</button>
                  </div>
                  <div style={{ fontSize: "16px", fontWeight: 800, color: "#0D6D63", marginBottom: "4px" }}>
                    {passport.budgetCurrency} {currInfo.symbol}{passport.budgetCustom} [{passport.budgetStandardizedUsd}]
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "10px", marginTop: "8px" }}>
                    {getBreakdown().map((b) => (
                      <span key={b.id} style={{ backgroundColor: "#F0F4F2", padding: "4px 10px", borderRadius: "6px", fontSize: "12px", fontWeight: 600 }}>
                        {b.icon} {b.purpose}: {currInfo.symbol}{b.amount.toLocaleString()}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Status Callout with Firebase Cloud indication */}
              <div
                style={{
                  backgroundColor: "#D4F4ED",
                  border: "1.5px solid #80CBC4",
                  borderRadius: "14px",
                  padding: "18px 24px",
                  display: "flex",
                  alignItems: "center",
                  gap: "14px",
                  marginBottom: "24px"
                }}
              >
                <CheckCircle2 style={{ color: "#0D6D63", width: "22px", height: "22px" }} />
                <span style={{ fontSize: "15px", fontWeight: 700, color: "#0D6D63" }}>
                  Travel passport successfully synced to Firebase Cloud Database. Itinerary & IROPS algorithms primed for {passport.fullName}!
                </span>
              </div>

              {/* Big Launch Flight Operations Button */}
              <button
                onClick={handleLaunchOperations}
                style={{
                  width: "100%",
                  padding: "18px 24px",
                  borderRadius: "14px",
                  backgroundColor: "#0D6D63",
                  color: "white",
                  border: "none",
                  fontSize: "16px",
                  fontWeight: 800,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "12px",
                  boxShadow: "0 6px 20px rgba(13,109,99,0.3)",
                  transition: "all 0.2s"
                }}
              >
                <Plane style={{ width: "20px", height: "20px" }} />
                <span>Launch Live Flight Operations & IROPS Recovery Deck ➔</span>
              </button>
            </div>
          )}

          {/* Bottom Footer Navigation */}
          <footer
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              paddingTop: "24px",
              borderTop: "1px solid #E2E8E5",
              marginTop: "auto"
            }}
          >
            <button
              onClick={handleBack}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                padding: "12px 24px",
                borderRadius: "10px",
                border: "1.5px solid #BAC4C1",
                backgroundColor: "transparent",
                color: "#1C2524",
                fontWeight: 700,
                fontSize: "14px",
                cursor: currentStep === 1 ? "not-allowed" : "pointer",
                visibility: currentStep === 1 ? "hidden" : "visible"
              }}
            >
              <ArrowLeft style={{ width: "16px", height: "16px" }} />
              Back
            </button>

            {currentStep < 8 ? (
              <button
                onClick={handleNext}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "12px 28px",
                  borderRadius: "10px",
                  backgroundColor: "#0D6D63",
                  color: "white",
                  border: "none",
                  fontWeight: 700,
                  fontSize: "14px",
                  cursor: "pointer",
                  boxShadow: "0 2px 10px rgba(13,109,99,0.2)"
                }}
              >
                Continue
                <ArrowRight style={{ width: "16px", height: "16px" }} />
              </button>
            ) : (
              <button
                onClick={handleLaunchOperations}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "8px",
                  padding: "12px 28px",
                  borderRadius: "10px",
                  backgroundColor: "#0D6D63",
                  color: "white",
                  border: "none",
                  fontWeight: 700,
                  fontSize: "14px",
                  cursor: "pointer",
                  boxShadow: "0 2px 10px rgba(13,109,99,0.2)"
                }}
              >
                Launch Flight Operations
                <ArrowRight style={{ width: "16px", height: "16px" }} />
              </button>
            )}
          </footer>
        </main>
      </div>

      {/* Sign In & Register Modal with Firebase Auth */}
      {showAuthModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            backgroundColor: "rgba(0, 0, 0, 0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000
          }}
        >
          <div
            style={{
              maxWidth: "440px",
              width: "90%",
              backgroundColor: "white",
              borderRadius: "16px",
              padding: "28px",
              boxShadow: "0 20px 40px rgba(0,0,0,0.2)"
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "18px" }}>
              <h3 style={{ fontSize: "20px", fontWeight: 800, color: "#1C2524" }}>Welcome to Travel AI</h3>
              <button onClick={() => setShowAuthModal(false)} style={{ background: "none", border: "none", fontSize: "24px", cursor: "pointer", color: "#697874" }}>
                <X style={{ width: "20px", height: "20px" }} />
              </button>
            </div>

            <div style={{ display: "flex", gap: "8px", marginBottom: "20px", borderBottom: "1.5px solid #E2E8E5", paddingBottom: "12px" }}>
              <button
                type="button"
                onClick={() => setAuthTab("login")}
                style={{
                  flex: 1,
                  padding: "10px",
                  fontWeight: 700,
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  backgroundColor: authTab === "login" ? "#E0F5F0" : "#F0F4F2",
                  color: authTab === "login" ? "#0D6D63" : "#697874"
                }}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => setAuthTab("register")}
                style={{
                  flex: 1,
                  padding: "10px",
                  fontWeight: 700,
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  backgroundColor: authTab === "register" ? "#E0F5F0" : "#F0F4F2",
                  color: authTab === "register" ? "#0D6D63" : "#697874"
                }}
              >
                Create Account
              </button>
            </div>

            {authSuccessMsg && (
              <div style={{ padding: "10px 14px", marginBottom: "14px", backgroundColor: "#E8F5E9", color: "#2E7D32", borderRadius: "8px", fontSize: "13px", fontWeight: 600 }}>
                {authSuccessMsg}
              </div>
            )}

            <form onSubmit={handleAuthSubmit}>
              {authTab === "register" && (
                <div style={{ marginBottom: "14px" }}>
                  <label style={{ fontSize: "13px", fontWeight: 700, display: "block", marginBottom: "6px" }}>Full Name</label>
                  <input
                    type="text"
                    value={passport.fullName}
                    onChange={(e) => setPassport({ ...passport, fullName: e.target.value })}
                    placeholder="e.g. Euro Traveler"
                    style={{ width: "100%", padding: "12px", border: "1.5px solid #E2E8E5", borderRadius: "8px", fontSize: "14px" }}
                  />
                </div>
              )}
              <div style={{ marginBottom: "14px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, display: "block", marginBottom: "6px" }}>Email Address</label>
                <input
                  type="email"
                  required
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  placeholder="user@example.com"
                  style={{ width: "100%", padding: "12px", border: "1.5px solid #E2E8E5", borderRadius: "8px", fontSize: "14px" }}
                />
              </div>
              <div style={{ marginBottom: "20px" }}>
                <label style={{ fontSize: "13px", fontWeight: 700, display: "block", marginBottom: "6px" }}>Password</label>
                <input
                  type="password"
                  required
                  value={userPassword}
                  onChange={(e) => setUserPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  style={{ width: "100%", padding: "12px", border: "1.5px solid #E2E8E5", borderRadius: "8px", fontSize: "14px" }}
                />
              </div>
              <button
                type="submit"
                style={{
                  width: "100%",
                  padding: "14px",
                  fontSize: "15px",
                  fontWeight: 700,
                  backgroundColor: "#0D6D63",
                  color: "white",
                  border: "none",
                  borderRadius: "8px",
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "8px",
                  boxShadow: "0 4px 12px rgba(13,109,99,0.3)"
                }}
              >
                <Plane style={{ width: "18px", height: "18px" }} />
                <span>{authTab === "login" ? "Sign In & Launch Flight Operations ➔" : "Create Account & Launch ➔"}</span>
              </button>
            </form>

            <div style={{ textAlign: "center", marginTop: "16px" }}>
              <button
                type="button"
                onClick={handleGuestSubmit}
                style={{
                  background: "none",
                  border: "none",
                  color: "#0D6D63",
                  fontSize: "13px",
                  fontWeight: 700,
                  cursor: "pointer",
                  textDecoration: "underline"
                }}
              >
                Skip & Launch Flight Operations as Guest ➔
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
