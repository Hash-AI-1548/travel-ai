import React from "react";
import { Bell, Zap, LogOut, Globe } from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import type { TravelPassportData } from "../views/TravelPassportProfileView";

export type AOCViewTab = "PROFILE" | "OPERATIONS" | "MAP" | "TERMINAL_MAP" | "RECOVERY" | "CARE" | "MEDICAL" | "MATH";

interface TopNavBarProps {
  state: SimulationState;
  activeTab: AOCViewTab;
  onTabChange: (tab: AOCViewTab) => void;
  onOpenStudio?: () => void;
  onSearchChange?: (query: string) => void;
  passport?: TravelPassportData;
  onSignOut?: () => void;
}

export const TopNavBar: React.FC<TopNavBarProps> = ({
  state,
  activeTab,
  onTabChange,
  onOpenStudio,
  passport,
  onSignOut,
}) => {
  const elapsedMins = Math.floor(state.simClockSeconds / 60);
  const hours = 18;
  const mins = 42 + Math.floor(elapsedMins / 60);
  const secs = state.simClockSeconds % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  const clockFormatted = `${pad(hours)}:${pad(mins % 60)}:${pad(secs)} UTC`;

  const getHealthStatus = () => {
    if (state.medical.isActive) return { text: "98.2%", label: "Medical Priority Alert", color: "bg-rose-500" };
    if (state.simMinute >= 30) return { text: "98.2%", label: "Active Disruption Mitigation", color: "bg-amber-500" };
    return { text: "98.2%", label: "All Systems Operational", color: "bg-emerald-500" };
  };

  const health = getHealthStatus();
  const displayName = passport?.fullName || state.passenger.name || "Traveler";
  const initials = displayName
    .split(" ")
    .map((n) => n.charAt(0))
    .join("")
    .substring(0, 2)
    .toUpperCase() || "SD";

  return (
    <header className="h-14 bg-[#050811] border-b border-slate-800/80 px-6 flex items-center justify-between shrink-0 z-40 select-none shadow-md">
      {/* Left Title & Status Badges */}
      <div className="flex items-center gap-4">
        <h1 className="font-black text-sm tracking-wider text-slate-100 uppercase">
          OPERATIONS CONTROL CENTER
        </h1>

        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300 font-medium">
          <span className={`h-2 w-2 rounded-full ${health.color} animate-pulse`} />
          <span>Network Health: <strong className="text-white">{health.text}</strong></span>
        </div>

        <div className="hidden md:flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/80 border border-slate-800/80 text-xs text-slate-400 font-medium">
          <span className="h-2 w-2 rounded-full bg-emerald-500" />
          <span>{health.label}</span>
        </div>
      </div>

      {/* Right Controls & User Profile */}
      <div className="flex items-center gap-3">
        {/* UTC Live Clock */}
        <span className="text-xs font-mono font-bold tracking-wider text-slate-300 bg-slate-900/90 px-3 py-1.5 rounded-lg border border-slate-800 shadow-inner">
          {clockFormatted}
        </span>

        {/* Live Map Quick Action */}
        <button
          onClick={() => onTabChange(activeTab === "MAP" ? "OPERATIONS" : "MAP")}
          className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-medium transition cursor-pointer ${
            activeTab === "MAP"
              ? "bg-sky-600 border-sky-500 text-white"
              : "bg-slate-900 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700"
          }`}
        >
          <Globe className="h-3.5 w-3.5 text-sky-400" />
          <span>Live Map</span>
        </button>

        {/* Disruption Studio / Simulation Button */}
        {onOpenStudio && (
          <button
            onClick={onOpenStudio}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold shadow-md shadow-sky-600/30 transition cursor-pointer"
          >
            <Zap className="h-3.5 w-3.5 fill-current" />
            <span>Simulation</span>
          </button>
        )}

        {/* Notification Bell */}
        <button
          onClick={() => onTabChange("RECOVERY")}
          className="relative p-2 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          title="Notifications & IROPS Events"
        >
          <Bell className="h-4 w-4" />
          {state.medical.isActive ? (
            <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-rose-500 animate-ping" />
          ) : (
            <span className="absolute top-1.5 right-1.5 h-1.5 w-1.5 rounded-full bg-sky-400" />
          )}
        </button>

        {/* User Profile Avatar Pill */}
        <button
          onClick={() => onTabChange("PROFILE")}
          className="h-8 w-8 rounded-full bg-gradient-to-br from-sky-500 to-indigo-600 hover:scale-105 flex items-center justify-center text-white text-xs font-extrabold shadow-md transition cursor-pointer border border-sky-400/40"
          title={`Traveler Profile: ${displayName}`}
        >
          {initials}
        </button>

        {/* Sign Out */}
        {onSignOut && (
          <button
            onClick={onSignOut}
            className="p-2 rounded-lg hover:bg-rose-950/60 hover:text-rose-300 text-slate-500 transition cursor-pointer"
            title="Log Out"
          >
            <LogOut className="h-4 w-4" />
          </button>
        )}
      </div>
    </header>
  );
};

