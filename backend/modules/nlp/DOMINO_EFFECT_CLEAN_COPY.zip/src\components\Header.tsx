import React from "react";
import {
  Play,
  Pause,
  RotateCcw,
  ShieldAlert,
  Volume2,
  VolumeX,
  Plane,
  Smartphone,
  Layers,
  Luggage,
  Calculator,
  Flame,
  Radio,
  Clock,
  Sparkles,
  CloudRain,
} from "lucide-react";
import type { SimulationState } from "../engine/simulationEngine";
import type { PolicyMode, ScenarioType } from "../types/simulation";
import { sounds } from "../utils/audio";

interface HeaderProps {
  state: SimulationState;
  onPlay: () => void;
  onPause: () => void;
  onReset: (scenario?: ScenarioType) => void;
  onSpeedChange: (speed: number) => void;
  onSeek: (minute: number) => void;
  onPolicyChange?: (policy: PolicyMode) => void;
  onMedicalTrigger: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  currentView: "DUAL" | "AOC" | "MOBILE" | "RAMP" | "MATH";
  onViewChange: (view: "DUAL" | "AOC" | "MOBILE" | "RAMP" | "MATH") => void;
}

export const Header: React.FC<HeaderProps> = ({
  state,
  onPlay,
  onPause,
  onReset,
  onSpeedChange,
  onSeek,
  onMedicalTrigger,
  soundEnabled,
  onToggleSound,
  currentView,
  onViewChange,
}) => {
  const elapsedMins = Math.floor(state.simClockSeconds / 60);
  const hours = 16 + Math.floor(elapsedMins / 60);
  const mins = elapsedMins % 60;
  const secs = state.simClockSeconds % 60;
  const pad = (n: number) => n.toString().padStart(2, "0");
  const simClockFormatted = `${pad(hours)}:${pad(mins)}:${pad(secs)} UTC`;

  return (
    <header className="flex flex-col border-b border-slate-800 bg-slate-950 text-slate-100 select-none shadow-2xl z-30">
      {/* Top Primary Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-2.5 bg-slate-900/90 border-b border-slate-800/80 backdrop-blur-md">
        {/* Brand & Status Badges */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-sky-500/20 border border-sky-400/40 text-sky-400 shadow-[0_0_15px_rgba(56,189,248,0.25)]">
              <Plane className="h-4 w-4 transform -rotate-45 text-sky-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-black tracking-wider text-white uppercase bg-clip-text text-transparent bg-gradient-to-r from-sky-400 via-teal-300 to-indigo-400">
                  DOMINO EFFECT
                </span>
                <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-sky-950/80 text-sky-300 border border-sky-800/60">
                  v2.4-IROPS
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono">
                Autonomous Aviation Immunization & Passenger Care Core
              </p>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-2 text-[11px] font-mono pl-3 border-l border-slate-800">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-950/60 text-emerald-400 border border-emerald-700/50">
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Disruption Risk: Live</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-sky-950/60 text-sky-400 border border-sky-700/50">
              <Sparkles className="h-3 w-3 text-sky-300" />
              <span>Aircraft Swap: Active</span>
            </div>
            <div className="flex items-center gap-1 px-2.5 py-1 rounded bg-indigo-950/40 text-indigo-300 border border-indigo-800/40">
              <Radio className="h-3 w-3 text-indigo-400 animate-pulse" />
              <span>Response Time: 4ms</span>
            </div>
          </div>
        </div>

        {/* View Mode Switcher Tabs */}
        <div className="flex items-center rounded-lg bg-slate-900 border border-slate-800 p-1 text-xs">
          <button
            onClick={() => onViewChange("DUAL")}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
              currentView === "DUAL"
                ? "bg-gradient-to-r from-sky-600 to-indigo-600 text-white shadow-md shadow-sky-900/30"
                : "text-slate-400 hover:text-white"
            }`}
            title="Side-by-side Dual Command Deck"
          >
            <Layers className="h-3.5 w-3.5" />
            <span>Side-by-Side View</span>
          </button>
          <button
            onClick={() => onViewChange("AOC")}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
              currentView === "AOC"
                ? "bg-sky-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
            title="Operations Control Center"
          >
            <Plane className="h-3.5 w-3.5" />
            <span>Operations Center</span>
          </button>
          <button
            onClick={() => onViewChange("MOBILE")}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
              currentView === "MOBILE"
                ? "bg-teal-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
            title="Passenger Mobile Experience"
          >
            <Smartphone className="h-3.5 w-3.5" />
            <span>Passenger Mobile App</span>
          </button>
          <button
            onClick={() => onViewChange("RAMP")}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
              currentView === "RAMP"
                ? "bg-amber-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
            title="Tarmac Baggage & Ramp Ops"
          >
            <Luggage className="h-3.5 w-3.5" />
            <span>Baggage & Tarmac Ops</span>
          </button>
          <button
            onClick={() => onViewChange("MATH")}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md font-medium transition-all ${
              currentView === "MATH"
                ? "bg-purple-600 text-white shadow-md"
                : "text-slate-400 hover:text-white"
            }`}
            title="Mathematical Models & Sandbox"
          >
            <Calculator className="h-3.5 w-3.5" />
            <span>Decision Math Lab</span>
          </button>
        </div>

        {/* Global Action Triggers */}
        <div className="flex items-center gap-3">
          {/* Live Inferred Disruption Cause Indicator */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-slate-700 bg-slate-800 text-xs font-mono">
            {state.policy === "WEATHER" ? (
              <>
                <CloudRain className="h-3.5 w-3.5 text-amber-400 shrink-0" />
                <span className="text-slate-300">Cause: <strong className="text-amber-300">Severe Weather (Force Majeure)</strong></span>
              </>
            ) : (
              <>
                <Flame className="h-3.5 w-3.5 text-sky-400 shrink-0" />
                <span className="text-slate-300">Cause: <strong className="text-sky-300">Mechanical Fault (IATA Rule 240)</strong></span>
              </>
            )}
          </div>

          {/* Critical Medical Escalation Button */}
          <button
            onClick={() => {
              onMedicalTrigger();
              sounds.playEmergencySiren();
            }}
            className={`flex items-center gap-1.5 rounded-lg px-3 py-1 text-xs font-bold uppercase transition-all duration-300 shadow-lg ${
              state.medical.isActive
                ? "bg-rose-600 text-white animate-pulse border border-rose-400 ring-2 ring-rose-500/50"
                : "bg-rose-950/80 hover:bg-rose-800 text-rose-300 border border-rose-700/60 hover:text-white"
            }`}
            title="Trigger Critical Medical Priority Escalation"
          >
            <ShieldAlert className="h-3.5 w-3.5 text-rose-400" />
            <span>{state.medical.isActive ? "Medical Emergency Active" : "Simulate Medical Emergency"}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={onToggleSound}
            className={`p-1.5 rounded-lg border text-xs transition ${
              soundEnabled
                ? "border-sky-700 bg-sky-950/60 text-sky-300"
                : "border-slate-800 bg-slate-900 text-slate-500"
            }`}
            title={soundEnabled ? "Mute audio alerts" : "Enable cockpit audio alerts"}
          >
            {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Bottom Timeline & Master Simulation Controls */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-2 bg-slate-950/95 border-b border-slate-800/60">
        {/* Clock & Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-slate-900 px-3 py-1 rounded-md border border-slate-800 font-mono text-xs">
            <Clock className="h-3.5 w-3.5 text-sky-400 animate-spin-slow" />
            <span className="text-slate-400">Simulation Time:</span>
            <span className="font-bold text-white tracking-widest">{simClockFormatted}</span>
            <span className="text-[10px] text-sky-400 ml-1">
              (T+{state.simMinute}m)
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {state.isRunning ? (
              <button
                onClick={() => {
                  onPause();
                  sounds.playRadarPing();
                }}
                className="flex items-center gap-1 px-3 py-1 rounded bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow transition"
              >
                <Pause className="h-3.5 w-3.5 fill-current" />
                <span>Pause</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  onPlay();
                  sounds.playCockpitChime();
                }}
                className="flex items-center gap-1 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow transition"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Start Sim</span>
              </button>
            )}

            <button
              onClick={() => {
                onReset();
                sounds.playRadarPing();
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs transition border border-slate-700"
              title="Reset Simulation to T0"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Speed Presets */}
          <div className="flex items-center gap-1 pl-2 border-l border-slate-800 text-[11px] font-mono">
            <span className="text-slate-400 mr-1">Speed:</span>
            {[1, 5, 10, 30, 60].map((spd) => (
              <button
                key={spd}
                onClick={() => {
                  onSpeedChange(spd);
                  sounds.playRadarPing();
                }}
                className={`px-2 py-0.5 rounded border transition ${
                  state.timeMultiplier === spd
                    ? "border-sky-500 bg-sky-950 text-sky-300 font-bold"
                    : "border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200"
                }`}
              >
                {spd === 60 ? "60× (1 sec = 1 min)" : `${spd}×`}
              </button>
            ))}
          </div>
        </div>

        {/* Milestone Quick Jump Buttons */}
        <div className="flex items-center gap-1.5 text-xs font-mono">
          <span className="text-slate-400 mr-1 text-[11px]">Jump to Phase:</span>
          <button
            onClick={() => {
              onSeek(0);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute === 0
                ? "bg-sky-900 border-sky-600 text-white"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            Start — 30 min Delay Detected
          </button>
          <button
            onClick={() => {
              onSeek(5);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 5 && state.simMinute < 10
                ? "bg-rose-950 border-rose-600 text-rose-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            5 min — Ripple Risk Contained
          </button>
          <button
            onClick={() => {
              onSeek(10);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 10 && state.simMinute < 15
                ? "bg-emerald-950 border-emerald-600 text-emerald-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            10 min — Gates Reassigned
          </button>
          <button
            onClick={() => {
              onSeek(15);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 15 && state.simMinute < 20
                ? "bg-sky-950 border-sky-600 text-sky-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            15 min — Door Held for Passenger
          </button>
          <button
            onClick={() => {
              onSeek(20);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 20 && state.simMinute < 30
                ? "bg-indigo-950 border-indigo-600 text-indigo-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            20 min — Rebooked on Partner Flight
          </button>
          <button
            onClick={() => {
              onSeek(30);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 30 && state.simMinute < 35
                ? "bg-purple-950 border-purple-600 text-purple-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            30 min — Hotel & Meals Ready
          </button>
          <button
            onClick={() => {
              onSeek(35);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 35 && state.simMinute < 40
                ? "bg-emerald-950 border-emerald-600 text-emerald-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            35 min — Passenger Onboard
          </button>
          <button
            onClick={() => {
              onSeek(40);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 40 && state.simMinute < 50
                ? "bg-sky-950 border-sky-600 text-sky-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            40 min — London Flight Departed
          </button>
          <button
            onClick={() => {
              onSeek(50);
              sounds.playRadarPing();
            }}
            className={`px-2 py-0.5 rounded text-[11px] border transition ${
              state.simMinute >= 50
                ? "bg-indigo-950 border-indigo-600 text-indigo-300"
                : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            50 min — Cruising to London
          </button>
        </div>
      </div>
    </header>
  );
};
