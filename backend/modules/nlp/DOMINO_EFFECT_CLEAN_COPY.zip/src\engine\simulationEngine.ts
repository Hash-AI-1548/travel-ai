import type {
  FlightContext,
  PassengerProfile,
  BaggageTelemetry,
  PreventorMetrics,
  ManagerDoorHoldMetrics,
  OvernightCarePackage,
  MedicalEmergencyState,
  PolicyMode,
  SimulationLogEvent,
  ScenarioType,
  NetworkGraphNode,
  NetworkGraphEdge,
  AutonomousAiTelemetry,
} from "../types/simulation";
import type { DisruptionFactors, InferredDisruptionOutcome } from "../types/disruption";
import { DEFAULT_DISRUPTION_FACTORS } from "../types/disruption";
import { DisruptionInferenceEngine } from "./disruptionInferenceEngine";
import { CrewDutyService, type CrewMember, type CrewDutyEvaluation } from "../services/crewDutyDatabase";
import { CockpitDatalinkService, type CockpitDatalinkMessage } from "../services/cockpitDatalinkService";
import { puterAiService } from "../services/puterAiService";

export interface SimulationState {
  simClockSeconds: number;
  simMinute: number;
  timeMultiplier: number;
  isRunning: boolean;
  activeScenario: ScenarioType;
  policy: PolicyMode;
  flight: FlightContext;
  passenger: PassengerProfile;
  baggage: BaggageTelemetry;
  preventor: PreventorMetrics;
  manager: ManagerDoorHoldMetrics;
  overnightCare: OvernightCarePackage;
  medical: MedicalEmergencyState;
  logs: SimulationLogEvent[];
  graphNodes: NetworkGraphNode[];
  graphEdges: NetworkGraphEdge[];
  terminalWalkingReductionMins: number;
  disruptionFactors: DisruptionFactors;
  inferredOutcome: InferredDisruptionOutcome;
  crewRoster: CrewMember[];
  crewEvaluation: CrewDutyEvaluation;
  cockpitMessages: CockpitDatalinkMessage[];
  passengerBriefing: {
    headline: string;
    body: string;
    pilotMessage: string;
  };
  autonomousTelemetry: AutonomousAiTelemetry;
}

type StateListener = (state: SimulationState) => void;
type LogListener = (event: SimulationLogEvent) => void;

function getInitialPassengerName(): string {
  try {
    if (typeof window !== "undefined") {
      const cached = localStorage.getItem("travel_passport_active");
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed?.fullName && parsed.fullName.trim()) {
          return parsed.fullName.trim();
        }
      }
      const user = localStorage.getItem("travel_ai_auth_user");
      if (user) {
        const u = JSON.parse(user);
        if (u?.displayName && u.displayName.trim()) return u.displayName.trim();
        if (u?.email) {
          const emailName = u.email.split("@")[0];
          return emailName.charAt(0).toUpperCase() + emailName.slice(1);
        }
      }
    }
  } catch (e) {}
  return "Logged In Traveler";
}

export class SimulationEngine {
  private state: SimulationState;
  private timer: any = null;
  private stateListeners: Set<StateListener> = new Set();
  private logListeners: Set<LogListener> = new Set();

  constructor() {
    this.state = this.getInitialState("IN_FLIGHT_SAVE");
  }

  public getInitialState(scenario: ScenarioType = "IN_FLIGHT_SAVE"): SimulationState {
    const initialName = getInitialPassengerName();

    const defaultFlight: FlightContext = {
      flightNumber: "AA142",
      airline: "American Airlines",
      aircraftTail: "N912AA",
      aircraftModel: "Boeing 787-9 Dreamliner",
      route: {
        origin: "JFK",
        originName: "New York John F. Kennedy",
        transit: "BOS",
        transitName: "Boston Logan International",
        destination: "LHR",
        destinationName: "London Heathrow",
      },
      scheduledTimes: {
        depOrigin: "15:30 UTC",
        arrTransit: "16:30 UTC",
        depTransitDest: "17:05 UTC",
      },
      actualTimes: {
        depOrigin: "16:00 UTC",
        estArrTransit: "17:00 UTC",
      },
      telemetry: {
        altitudeFt: 31000,
        groundSpeedKts: 480,
        remainingDistanceNm: 42,
        etaMinutes: 60,
        lat: 41.52,
        lng: -71.95,
      },
      delayMinutes: 30,
      bufferMinutes: 35,
      initialArrivalGate: "B30",
      currentArrivalGate: "B30",
      initialOutboundGate: "C14",
      currentOutboundGate: "C14",
      crewDutyRemainingHours: 2.1,
      crewDutyRisk: 0.72,
      status: "NORMAL",
    };

    const defaultPassenger: PassengerProfile = {
      passengerId: "PAX-9921",
      name: initialName,
      seat: "14B",
      tier: "DIAMOND_MEDALLION",
      bagTags: ["BAG-4552"],
      connectionRiskScore: 0.62,
      medicalProfile: {
        isEmergency: false,
        conditionName: "Post-Cardiac Valve Replacement / Urgent Surgery Transmit",
        medifVerified: true,
        medevacInsuranceActive: true,
      },
    };

    const defaultBaggage: BaggageTelemetry = {
      bagId: "BAG-4552",
      paxId: "PAX-9921",
      sourceFlight: "AA142",
      targetFlight: "AA142-LHR",
      currentLocation: "IN_FLIGHT_CARGO_BAY_A",
      routedDestination: "BOS_RAMP_STAND_B30",
      status: "IN_CARGO_HOLD",
      lastScannedTime: "15:52 UTC (JFK Ramp)",
      transferSpeedKmh: 0,
    };

    const defaultPreventor: PreventorMetrics = {
      riskScore: 0.62,
      isIsolated: false,
      contagionVectors: {
        delayRatioTerm: 0.35 * (30 / 35),
        connectionBreachTerm: 0.45 * (1 - 5 / 40),
        crewDutyTerm: 0.2 * 0.72,
      },
      weights: {
        w1: 0.35,
        w2: 0.45,
        w3: 0.2,
      },
      activeBottlenecks: ["BOS_MCT_VIOLATION_5M"],
    };

    const defaultManager: ManagerDoorHoldMetrics = {
      holdMinutes: 5,
      maxHoldAllowedMinutes: 15,
      fuelBurnRatePerMin: 18,
      crewOtRatePerMin: 6,
      costFuelBurnUsd: 90,
      costCrewOtUsd: 30,
      costDownstreamMissesUsd: 0,
      costTotalHoldUsd: 120,
      costInterlineTicketsUsd: 520,
      costHotelUsd: 180,
      costMealsUsd: 50,
      costEu261CompensationUsd: 100,
      costTotalAbandonUsd: 850,
      netSavingsUsd: 730,
      decision: "PENDING",
      decisionReason: "Analyzing real-time ground telemetry & transit distances",
      gateWalkingTimeBeforeMins: 18,
      gateWalkingTimeAfterMins: 1,
    };

    const defaultOvernightCare: OvernightCarePackage = {
      triggered: false,
      policyApplied: "MECHANICAL",
      isCarrierFunded: true,
      hotelReservation: {
        hotelName: "Hilton Boston Logan Airport",
        roomNumber: "304 (Deluxe King)",
        address: "1 Hotel Dr, Boston, MA 02128 (Direct Skybridge Access)",
        checkInTime: "17:30 UTC",
        digitalKeyQr: "DATA:KEY_NFC_HTL_BOS_304_SECURE",
        shuttlePassCode: "QR-SHUTTLE-BOS-EXPRESS",
        shuttleEtaMins: 4,
        shuttleCurrentLocation: "Terminal B Ground Transit Bay 2",
      },
      mealVouchers: [
        {
          voucherId: "VCH-01",
          mealType: "DINNER",
          amountUsd: 25.0,
          barcode: "9812-7391-8273-01",
          validAt: "Boston Beer Works / Legal Sea Foods / Cibo Express",
          isRedeemed: false,
        },
        {
          voucherId: "VCH-02",
          mealType: "BREAKFAST",
          amountUsd: 25.0,
          barcode: "9812-7391-8274-02",
          validAt: "Dunkin' / Starbucks / Airport Bistro",
          isRedeemed: false,
        },
      ],
      morningStandbyPriority: {
        assignedFlight: "AA102",
        departureTime: "06:00 UTC (Next Day)",
        queuePosition: 1,
        totalStandbyCount: 14,
        confirmedSeatEstimate: "Seat 04C (First Class Priority Protection)",
      },
      luggageWarehouse: {
        vaultId: "BOS-SECURE-VAULT-4",
        bayName: "Climate Vault Alpha-4",
        tempControlled: true,
        secureLockHash: "SHA256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069",
        storageStatus: "TRANSIT_TO_VAULT",
      },
    };

    const defaultMedical: MedicalEmergencyState = {
      isActive: false,
      priorityLevel: "NORMAL",
      paxId: "PAX-9921",
      patientName: initialName,
      diagnosis: "Post-Infarction Emergency Surgical Transfer (Transplant Window: 4 hrs)",
      medifVerified: true,
      insuranceVerified: true,
      paramedics: {
        status: "STANDBY",
        targetGate: "B10",
        etaSeconds: 90,
        teamId: "BOS-EMS-SQUAD-3",
      },
      interlineOverride: {
        status: "IDLE",
        targetFlight: "AA100 (17:30 UTC)",
        carrier: "American Airlines",
        depTime: "17:30 UTC",
        clearingHouseBypassed: true,
      },
      airAmbulanceMedevac: {
        status: "STANDBY",
        providerName: "Air Ambulance Worldwide (Learjet 75 Medevac ICU)",
        tailNumber: "N775AA",
        callsign: "MEDEVAC-ICU-88",
        specialMedicalAirspaceClearance: true,
        estimatedTakeoffMins: 12,
      },
    };

    const graphNodes: NetworkGraphNode[] = [
      { id: "N-AA142", label: "Flight AA142 (JFK->BOS)", type: "FLIGHT", status: "NORMAL", riskScore: 0.62, x: 20, y: 35, details: "Feeder flight (30m delay)" },
      { id: "N-BOSLHR", label: "Flight AA142-LHR", type: "FLIGHT", status: "NORMAL", riskScore: 0.45, x: 50, y: 25, details: "Outbound London leg" },
      { id: "N-LHREFRA", label: "Flight AA143 (LHR->FRA)", type: "FLIGHT", status: "NORMAL", riskScore: 0.15, x: 80, y: 20, details: "Downstream rotation tail" },
      { id: "N-CREW", label: "Crew Rotation C101", type: "CREW", status: "NORMAL", riskScore: 0.72, x: 45, y: 75, details: "Duty limit at 19:15 UTC" },
      { id: "N-PAX", label: `PAX-9921 (${initialName})`, type: "PASSENGER", status: "NORMAL", riskScore: 0.62, x: 20, y: 70, details: "Tight 5m connection" },
      { id: "N-GATE-B30", label: "Gate B30", type: "GATE", status: "NORMAL", x: 25, y: 15, details: "Original Terminal B arrival" },
      { id: "N-GATE-B10", label: "Gate B10", type: "GATE", status: "NORMAL", x: 50, y: 50, details: "Optimized arrival gate" },
      { id: "N-GATE-B12", label: "Gate B12", type: "GATE", status: "NORMAL", x: 65, y: 50, details: "Adjacent outbound gate" },
      { id: "N-BA212", label: "Flight BA212 (British Airways)", type: "FLIGHT", status: "NORMAL", riskScore: 0.05, x: 80, y: 65, details: "Interline backup (18:00 UTC)" },
    ];

    const graphEdges: NetworkGraphEdge[] = [
      { id: "E-PAX-AA142", source: "N-PAX", target: "N-AA142", label: "Booked On", type: "CONNECTION", isRiskBearing: true, isIsolated: false },
      { id: "E-AA142-BOSLHR", source: "N-AA142", target: "N-BOSLHR", label: "Passenger Feeder (5m MCT)", type: "CONNECTION", isRiskBearing: true, isIsolated: false },
      { id: "E-BOSLHR-LHREFRA", source: "N-BOSLHR", target: "N-LHREFRA", label: "Airframe Tail Rotation", type: "ROTATION", isRiskBearing: true, isIsolated: false },
      { id: "E-CREW-BOSLHR", source: "N-CREW", target: "N-BOSLHR", label: "Operating Crew Pairing", type: "PAIRING", isRiskBearing: true, isIsolated: false },
      { id: "E-GATE-OLD", source: "N-AA142", target: "N-GATE-B30", label: "Scheduled Gate", type: "ASSIGNMENT", isRiskBearing: false, isIsolated: false },
    ];

    const initialLog: SimulationLogEvent = {
      id: "LOG-INIT",
      timestampSim: "16:00:00 UTC",
      timestampReal: new Date().toLocaleTimeString(),
      simMinute: 0,
      category: "SYSTEM",
      level: "INFO",
      title: "IROPS Engine Initialized",
      message: "Master Simulation Clock started at T0 (16:00 UTC). Telemetry link established with Flight AA142.",
    };

    return {
      simClockSeconds: 0,
      simMinute: 0,
      timeMultiplier: 1,
      isRunning: false,
      activeScenario: scenario,
      policy: "MECHANICAL",
      flight: defaultFlight,
      passenger: defaultPassenger,
      baggage: defaultBaggage,
      preventor: defaultPreventor,
      manager: defaultManager,
      overnightCare: defaultOvernightCare,
      medical: defaultMedical,
      logs: [initialLog],
      graphNodes,
      graphEdges,
      terminalWalkingReductionMins: 0,
      disruptionFactors: { ...DEFAULT_DISRUPTION_FACTORS },
      inferredOutcome: DisruptionInferenceEngine.inferOutcome(DEFAULT_DISRUPTION_FACTORS),
      crewRoster: CrewDutyService.getCrewRoster(),
      crewEvaluation: CrewDutyService.evaluateHoldLegality(5, "AA142-LHR"),
      cockpitMessages: CockpitDatalinkService.getMessages(),
      passengerBriefing: {
        headline: "⚡ Connection Monitoring Active",
        body: `Flight AA142 operating inbound to Boston Logan. Autonomous Neural Engine is pre-allocating Gate B10/B12 adjacent corridors and flight deck datalink standby.`,
        pilotMessage: "Cockpit Standby: Flight deck datalink connected on VHF 131.550 MHz.",
      },
      autonomousTelemetry: {
        isAutonomousActive: true,
        modelEngine: "GPT-5.4 Nano Autonomous Dispatcher",
        lastDecisionCycle: "16:00:00 UTC",
        cycleCount: 1,
        crewLegalityStatus: "FAR_117_CERTIFIED",
        pilotSignalStatus: "TRANSMITTED",
        paxPushDeliveryStatus: "DELIVERED",
        aiReasoningLog: [
          "Neural Dispatch Initialized: Keyless Puter AI reasoning core online.",
          "Crew Database Linked: FAR Part 117 legality verified for 6 active crew members.",
          "Cockpit CPDLC Datalink active with Flight Deck AA142-LHR (Capt. Thorne).",
        ],
      },
    };
  }

  public applyDisruptionFactors(factors: DisruptionFactors): void {
    const outcome = DisruptionInferenceEngine.inferOutcome(factors);
    this.state.disruptionFactors = { ...factors };
    this.state.inferredOutcome = outcome;

    // Update flight delay and risk
    this.state.flight.delayMinutes = outcome.totalDelayMinutes;
    this.state.flight.currentArrivalGate = outcome.arrivalGate;
    this.state.flight.currentOutboundGate = outcome.outboundGate;
    this.state.preventor.riskScore = outcome.contagionRiskScore;
    this.state.preventor.isIsolated = outcome.isContagionIsolated;
    this.state.preventor.activeBottlenecks = outcome.delayBreakdown.map((b) => b.factor);

    // Update manager economics
    const isApproved = outcome.doorHoldFeasibility === "HOLD_APPROVED" || outcome.doorHoldFeasibility === "NOT_NEEDED";
    this.state.manager.decision = isApproved ? "APPROVED" : "REJECTED";
    this.state.manager.holdMinutes = outcome.doorHoldFeasibility === "NOT_NEEDED" ? 0 : outcome.doorHoldMinutes;
    this.state.manager.costTotalHoldUsd = outcome.doorHoldFeasibility === "NOT_NEEDED" ? 0 : outcome.costHoldInr;
    this.state.manager.costTotalAbandonUsd = outcome.costAbandonInr;
    this.state.manager.netSavingsUsd = outcome.netSavingsInr;
    this.state.manager.decisionReason = outcome.doorHoldDecisionReason;

    // Update policy mode
    const nextPolicy: PolicyMode = outcome.primaryLiability === "WEATHER_FORCE_MAJEURE" ? "WEATHER" : "MECHANICAL";
    this.state.policy = nextPolicy;
    this.state.overnightCare.policyApplied = nextPolicy;
    this.state.overnightCare.isCarrierFunded = nextPolicy === "MECHANICAL";

    // Medical flag
    if (factors.medicalEmergencyFlag) {
      this.triggerMedicalEmergency();
    } else {
      this.state.medical.isActive = false;
    }

    this.log(
      "PREVENTOR",
      outcome.riskLevel === "HIGH" ? "CRITICAL" : "INFO",
      `Operational Scene Synthesized: +${outcome.totalDelayMinutes}m Delay (${isApproved ? "Direct / Hold Approved" : "Close & Rebook"})`,
      outcome.summaryNarrative
    );

    this.notify();
  }

  public subscribe(listener: StateListener): () => void {
    this.stateListeners.add(listener);
    listener(this.state);
    return () => {
      this.stateListeners.delete(listener);
    };
  }

  public subscribeLogs(listener: LogListener): () => void {
    this.logListeners.add(listener);
    return () => {
      this.logListeners.delete(listener);
    };
  }

  private notify(): void {
    const clone = JSON.parse(JSON.stringify(this.state));
    this.stateListeners.forEach((l) => l(clone));
  }

  private log(
    category: SimulationLogEvent["category"],
    level: SimulationLogEvent["level"],
    title: string,
    message: string,
    payload?: any
  ): void {
    const elapsedMins = Math.floor(this.state.simClockSeconds / 60);
    const hours = 16 + Math.floor(elapsedMins / 60);
    const mins = elapsedMins % 60;
    const secs = this.state.simClockSeconds % 60;
    const pad = (n: number) => n.toString().padStart(2, "0");
    const timestampSim = `${pad(hours)}:${pad(mins)}:${pad(secs)} UTC`;

    const event: SimulationLogEvent = {
      id: `LOG-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestampSim,
      timestampReal: new Date().toLocaleTimeString(),
      simMinute: elapsedMins,
      category,
      level,
      title,
      message,
      payload,
    };

    this.state.logs = [event, ...this.state.logs.slice(0, 49)];
    this.logListeners.forEach((l) => l(event));
    this.notify();
  }

  public start(): void {
    if (this.state.isRunning) return;
    this.state.isRunning = true;
    this.tickLoop();
    this.notify();
  }

  public pause(): void {
    this.state.isRunning = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.notify();
  }

  public reset(scenario?: ScenarioType): void {
    this.pause();
    const nextScenario = scenario || this.state.activeScenario;
    this.state = this.getInitialState(nextScenario);
    this.log(
      "SYSTEM",
      "INFO",
      "Simulation Reset",
      `Simulation state reset to T0 for scenario [${nextScenario}].`
    );
  }

  public setSpeed(multiplier: number): void {
    this.state.timeMultiplier = multiplier;
    this.notify();
  }


  public setPolicy(policy: PolicyMode): void {
    this.state.policy = policy;
    this.state.overnightCare.policyApplied = policy;
    this.state.overnightCare.isCarrierFunded = policy === "MECHANICAL";
    this.log(
      "POLICY",
      "INFO",
      `Policy Shift: ${policy}`,
      policy === "MECHANICAL"
        ? "Mechanical fault classified under carrier liability (100% hotel & meals funded by airline ledger)."
        : "Weather / Force Majeure classified (Automated booking assistance active; expenses billed to traveler/insurance per DOT rules)."
    );
  }

  public triggerMedicalEmergency(): void {
    this.state.medical.isActive = true;
    this.state.medical.priorityLevel = "CRITICAL_ALPHA_ICU";
    this.state.medical.paramedics.status = "DISPATCHED";
    this.state.medical.interlineOverride.status = "OVERRIDDEN_CONFIRMED";
    this.state.medical.airAmbulanceMedevac.status = "ACTIVE_DISPATCH";
    this.state.passenger.medicalProfile.isEmergency = true;
    this.state.passenger.medicalProfile.emergencyTriggeredAtSimMinute = this.state.simMinute;

    this.log(
      "MEDICAL",
      "CRITICAL",
      "🚨 CRITICAL MEDICAL ESCALATION ACTIVATED",
      `Passenger PAX-9921 flagged with urgent surgical transfer deadline. Paramedics dispatched to Gate B10 (ETA 90s). Interline settlement overridden for immediate competitor flight. Air Ambulance Worldwide Medevac on standby.`
    );
  }

  public setPassengerFromPassport(
    name: string,
    tier?: "DIAMOND_MEDALLION" | "FIRST_CLASS" | "BUSINESS" | "ECONOMY",
    options?: {
      isWheelchairUser?: boolean;
      specialAssistance?: "WHEELCHAIR_REQUIRED" | "VISUAL_ASSISTANCE" | "HEARING_ASSISTANCE" | "STANDARD";
      dietaryPreferences?: string[];
      allergies?: string;
      autoRebookOnDelay?: boolean;
      autoRebookDelayThresholdMinutes?: number;
      isEmergencyTraveler?: boolean;
      emergencyReason?: string;
      allowCompetitorInterlineRebooking?: boolean;
      preferredCompetitorAirlines?: string[];
      autoUpgradeSeatAllowed?: boolean;
    }
  ): void {
    const safeName = name?.trim() || getInitialPassengerName();
    this.state.passenger.name = safeName;
    if (tier) this.state.passenger.tier = tier;
    this.state.medical.patientName = safeName;
    if (options) {
      if (options.isWheelchairUser !== undefined) this.state.passenger.isWheelchairUser = options.isWheelchairUser;
      if (options.specialAssistance) this.state.passenger.specialAssistance = options.specialAssistance;
      if (options.dietaryPreferences) this.state.passenger.dietaryPreferences = options.dietaryPreferences;
      if (options.allergies) this.state.passenger.allergies = options.allergies;
      if (options.autoRebookOnDelay !== undefined) this.state.passenger.autoRebookOnDelay = options.autoRebookOnDelay;
      if (options.autoRebookDelayThresholdMinutes !== undefined) this.state.passenger.autoRebookDelayThresholdMinutes = options.autoRebookDelayThresholdMinutes;
      if (options.isEmergencyTraveler !== undefined) {
        this.state.passenger.isEmergencyTraveler = options.isEmergencyTraveler;
        if (options.isEmergencyTraveler) {
          this.state.passenger.medicalProfile.isEmergency = true;
          this.state.passenger.medicalProfile.conditionName = options.emergencyReason || "Urgent Connection / Critical Travel Escalation";
        }
      }
      if (options.emergencyReason) this.state.passenger.emergencyReason = options.emergencyReason;
      if (options.allowCompetitorInterlineRebooking !== undefined) this.state.passenger.allowCompetitorInterlineRebooking = options.allowCompetitorInterlineRebooking;
      if (options.preferredCompetitorAirlines) this.state.passenger.preferredCompetitorAirlines = options.preferredCompetitorAirlines;
      if (options.autoUpgradeSeatAllowed !== undefined) this.state.passenger.autoUpgradeSeatAllowed = options.autoUpgradeSeatAllowed;

      // Competitor interline auto-allocation is strictly reserved for Critical Emergency Travelers!
      if (options.isEmergencyTraveler || this.state.medical.isActive || this.state.passenger.medicalProfile.isEmergency) {
        const preferred = options.preferredCompetitorAirlines?.[0] || "British Airways";
        const flightCode = "BA212";
        this.state.passenger.recoveryAllocation = {
          status: "REBOOKED",
          assignedFlight: flightCode,
          assignedAirline: preferred,
          departureTime: "18:00 UTC (45m Buffer)",
          gate: "B16",
          seat: "12A",
          interlineClearingStatus: "AUTO_SETTLED",
          barcodePayload: `QR-${flightCode}-12A-${safeName.replace(/\s+/g, "").toUpperCase()}-EMERGENCY`
        };
        this.state.baggage.targetFlight = flightCode;
      } else {
        this.state.passenger.recoveryAllocation = undefined;
      }
    }
    this.state.graphNodes = this.state.graphNodes.map((node) => {
      if (node.type === "PASSENGER" || node.id === "N-PAX") {
        return {
          ...node,
          label: `${this.state.passenger.passengerId} (${safeName})`,
        };
      }
      return node;
    });
    this.notify();
  }

  public setCompetitorFlight(
    flightNum: string,
    airline: string,
    seat: string,
    gate: string,
    departureTime: string
  ): void {
    const safeName = this.state.passenger.name || "Traveler";
    this.state.passenger.recoveryAllocation = {
      status: "REBOOKED",
      assignedFlight: flightNum,
      assignedAirline: airline,
      departureTime: departureTime,
      gate: gate,
      seat: seat,
      interlineClearingStatus: "AUTO_SETTLED",
      barcodePayload: `QR-${flightNum}-${seat}-${safeName.replace(/\s+/g, "").toUpperCase()}-FIM`
    };
    this.state.baggage.targetFlight = flightNum;
    this.state.baggage.status = "RAMP_TRANSFER_ACTIVE";
    this.state.baggage.routedDestination = `BOS_RAMP_STAND_${gate.split(" ")[0].replace(/[^A-Z0-9]/gi, "")}`;
    this.notify();
  }

  public seekToMinute(targetMinute: number): void {
    const wasRunning = this.state.isRunning;
    this.pause();
    this.state = this.getInitialState(this.state.activeScenario);
    
    for (let m = 0; m <= targetMinute; m++) {
      this.state.simClockSeconds = m * 60;
      this.state.simMinute = m;
      this.evaluateStateTransitions(m);
    }
    
    if (wasRunning) {
      this.start();
    } else {
      this.notify();
    }
  }

  private tickLoop = (): void => {
    if (!this.state.isRunning) return;

    const stepSeconds = Math.max(1, Math.round(this.state.timeMultiplier / 5));
    this.state.simClockSeconds += stepSeconds;

    if (this.state.simClockSeconds > 3600) {
      this.state.simClockSeconds = 3600;
      this.pause();
      this.log("SYSTEM", "SUCCESS", "Full Lifecycle Complete", "60-minute IROPS disruption ➔ recovery ➔ connecting departure lifecycle completed successfully.");
      return;
    }

    const previousMinute = this.state.simMinute;
    this.state.simMinute = Math.floor(this.state.simClockSeconds / 60);

    this.updateInFlightTelemetry();

    if (this.state.simMinute !== previousMinute) {
      this.evaluateStateTransitions(this.state.simMinute);
    }

    this.timer = setTimeout(this.tickLoop, 200);
    this.notify();
  };

  private updateInFlightTelemetry(): void {
    const min = this.state.simMinute;

    // Phase 1: T+0 to T+25 — Inbound leg (JFK -> BOS approach)
    if (min < 25) {
      const progress = Math.min(1, this.state.simClockSeconds / (25 * 60));
      this.state.flight.telemetry.altitudeFt = Math.round(31000 * (1 - progress * 0.9));
      this.state.flight.telemetry.groundSpeedKts = Math.round(480 - progress * 260);
      this.state.flight.telemetry.remainingDistanceNm = Math.max(2, Math.round(42 * (1 - progress)));
      this.state.flight.telemetry.etaMinutes = Math.max(1, 25 - min);
      // Smooth GPS coordinates interpolation from JFK (40.6413, -73.7781) to BOS (42.3656, -71.0096)
      this.state.flight.telemetry.lat = Number((40.6413 + progress * (42.3656 - 40.6413)).toFixed(4));
      this.state.flight.telemetry.lng = Number((-73.7781 + progress * (-71.0096 - -73.7781)).toFixed(4));
    }
    // Phase 2: T+25 to T+40 — On ground at BOS (taxiing, gate ops, boarding connector)
    else if (min < 40) {
      this.state.flight.telemetry.altitudeFt = 0;
      this.state.flight.telemetry.groundSpeedKts = min < 35 ? 18 : 0;
      this.state.flight.telemetry.remainingDistanceNm = 0;
      this.state.flight.telemetry.etaMinutes = 0;
      this.state.flight.telemetry.lat = 42.3656;
      this.state.flight.telemetry.lng = -71.0096;
    }
    // Phase 3: T+40 to T+60 — Connecting flight BOS -> LHR airborne
    else {
      const airborneProgress = Math.min(1, (this.state.simClockSeconds - 40 * 60) / (20 * 60));
      this.state.flight.telemetry.altitudeFt = Math.round(Math.min(38000, 38000 * Math.min(1, airborneProgress * 3)));
      this.state.flight.telemetry.groundSpeedKts = Math.round(240 + airborneProgress * 290);
      this.state.flight.telemetry.remainingDistanceNm = Math.round(2980 * (1 - airborneProgress));
      this.state.flight.telemetry.etaMinutes = Math.max(0, Math.round(360 * (1 - airborneProgress)));
      // Smooth GPS coordinates interpolation from BOS (42.3656, -71.0096) towards LHR (51.4700, -0.4543)
      this.state.flight.telemetry.lat = Number((42.3656 + airborneProgress * (51.4700 - 42.3656)).toFixed(4));
      this.state.flight.telemetry.lng = Number((-71.0096 + airborneProgress * (-0.4543 - -71.0096)).toFixed(4));
    }

    if (this.state.medical.isActive && this.state.medical.paramedics.status === "DISPATCHED") {
      this.state.medical.paramedics.etaSeconds = Math.max(0, this.state.medical.paramedics.etaSeconds - 2);
      if (this.state.medical.paramedics.etaSeconds === 0) {
        this.state.medical.paramedics.status = "ON_GATE_WAITING";
        this.log(
          "MEDICAL",
          "SUCCESS",
          "Paramedics On Gate",
          "Airport EMS Squad 3 stationed at Gate B10 jet bridge ready for immediate passenger extraction."
        );
      }
    }
  }

  private evaluateStateTransitions(minute: number): void {
    if (minute === 2) {
      this.executeAutonomousCrewAudit();
    }
    if (minute === 5) {
      this.executePreventorIsolation();
    }
    if (minute === 8) {
      this.executeCockpitDatalinkDispatch();
    }
    if (minute === 10) {
      this.executeGateReallocation();
    }
    if (minute === 12) {
      this.executePassengerBriefingPush();
    }
    if (minute === 15) {
      this.executeDoorHoldOptimization();
    }
    if (minute === 20) {
      this.executeZeroTouchInterlineAndBaggage();
    }
    if (minute === 25) {
      this.executeFeederLanding();
    }
    if (minute === 30) {
      this.executeOvernightCareSuite();
    }
    if (minute === 35) {
      this.executeConnectingBoardingComplete();
    }
    if (minute === 40) {
      this.executeConnectingFlightDeparture();
    }
    if (minute === 45) {
      this.executeBaggageConfirmedOnboard();
    }
    if (minute === 50) {
      this.executeCruiseAltitudeReached();
    }
    if (minute === 60) {
      this.executeFullLifecycleComplete();
    }
  }

  public setAutonomousMode(enabled: boolean): void {
    this.state.autonomousTelemetry.isAutonomousActive = enabled;
    this.notify();
  }

  public async runAutonomousPuterCycle(): Promise<void> {
    this.state.autonomousTelemetry.cycleCount += 1;
    this.state.autonomousTelemetry.lastDecisionCycle = new Date().toLocaleTimeString() + " UTC";

    // 1. Audit crew duty hours via Puter AI
    const crewRes = await puterAiService.evaluateCrewLegalityWithAI(5, "AA142-LHR");
    this.state.crewEvaluation = crewRes.data;

    // 2. Dispatch ACARS datalink to pilot
    const pilotRes = await puterAiService.dispatchCockpitPilotSignalWithAI(
      "AA142-LHR",
      5,
      this.state.passenger.name
    );
    this.state.cockpitMessages = CockpitDatalinkService.getMessages();

    // 3. Generate VIP Passenger briefing
    const paxRes = await puterAiService.generatePassengerBriefingWithAI(
      this.state.passenger.name,
      this.state.flight.delayMinutes,
      5,
      this.state.flight.currentArrivalGate,
      this.state.flight.currentOutboundGate
    );
    this.state.passengerBriefing = paxRes.data;

    this.state.autonomousTelemetry.aiReasoningLog = [
      `Cycle #${this.state.autonomousTelemetry.cycleCount}: ${crewRes.data.aiAnalysis}`,
      pilotRes.data.cockpitTranscript,
      `Push Briefing: ${paxRes.data.headline}`,
    ];

    this.log(
      "SYSTEM",
      "SUCCESS",
      `Autonomous AI Cycle Completed (${crewRes.model})`,
      `Puter AI evaluated crew duty (FAR Part 117 Compliant), transmitted ACARS signal to Capt. David Thorne, and pushed briefing to ${this.state.passenger.name}.`
    );

    this.notify();
  }

  private executeAutonomousCrewAudit(): void {
    CrewDutyService.updateElapsedDuty(2);
    const evalRes = CrewDutyService.evaluateHoldLegality(5, "AA142-LHR");
    this.state.crewEvaluation = evalRes;
    this.state.crewRoster = CrewDutyService.getCrewRoster();

    this.log(
      "PREVENTOR",
      "INFO",
      "Automated Crew Database Scan (FAR Part 117)",
      evalRes.farPart117ComplianceText
    );

    // Asynchronously call Puter AI in background
    puterAiService.evaluateCrewLegalityWithAI(5, "AA142-LHR").then((res) => {
      if (res.success) {
        this.state.crewEvaluation.crewDutySummaryNarrative = res.data.aiAnalysis;
        this.notify();
      }
    });
  }

  private executeCockpitDatalinkDispatch(): void {
    CockpitDatalinkService.generateCockpitHoldTransmission(
      "AA142-LHR",
      5,
      this.state.passenger.name,
      "Capt. David Thorne"
    );
    this.state.cockpitMessages = CockpitDatalinkService.getMessages();
    this.state.autonomousTelemetry.pilotSignalStatus = "ACKNOWLEDGED_BY_PILOT";

    this.log(
      "MANAGER",
      "SUCCESS",
      "ACARS Datalink: Pilot Hold Acknowledged",
      `Capt. David Thorne (Flight AA142-LHR, Boeing 787-9) confirmed 5-minute door hold at Gate B12 via CPDLC VHF 131.550 MHz.`
    );

    // Call Puter AI in background to update cockpit transcript
    puterAiService.dispatchCockpitPilotSignalWithAI("AA142-LHR", 5, this.state.passenger.name).then((res) => {
      if (res.success) {
        this.state.cockpitMessages = CockpitDatalinkService.getMessages();
        this.notify();
      }
    });
  }

  private executePassengerBriefingPush(): void {
    const defaultBriefing = {
      headline: "⚡ Gate B12 Secured — Flight Door Held For You",
      body: `Hi ${this.state.passenger.name}, don't rush across Boston airport! Your London flight was moved to Gate B12, right next to your arrival Gate B10 (25m stroll). Captain David Thorne is holding the flight door for you.`,
      pilotMessage: "Flight Deck Acknowledged: Captain David Thorne (Flight AA142-LHR) confirmed gate hold at B12.",
    };
    this.state.passengerBriefing = defaultBriefing;
    this.state.autonomousTelemetry.paxPushDeliveryStatus = "DELIVERED";

    this.log(
      "CARE",
      "SUCCESS",
      "Passenger Real-Time Push Briefing Delivered",
      `Autonomous briefing delivered to ${this.state.passenger.name}'s mobile device with confirmed adjacent gate walking route and pilot hold status.`
    );

    // Call Puter AI in background to personalize briefing
    puterAiService
      .generatePassengerBriefingWithAI(
        this.state.passenger.name,
        this.state.flight.delayMinutes,
        5,
        this.state.flight.currentArrivalGate,
        this.state.flight.currentOutboundGate
      )
      .then((res) => {
        if (res.success) {
          this.state.passengerBriefing = res.data;
          this.notify();
        }
      });
  }

  private executePreventorIsolation(): void {
    this.state.flight.status = "VOLATILE";
    this.state.preventor.riskScore = 0.94;
    this.state.preventor.isIsolated = true;
    this.state.preventor.isolatedAtMinute = 5;
    this.state.preventor.activeBottlenecks = [
      "BOS_LHR_CONNECTION_BREACH (MCT 40m breached, only 5m remaining)",
      "CREW_DUTY_LIMIT_PROXIMITY (19:15 UTC hard timeout)",
      "DOWNSTREAM_ROTATION_CONTAGION_RISK",
    ];

    this.state.graphNodes = this.state.graphNodes.map((n) => {
      if (n.id === "N-AA142") {
        return { ...n, status: "ISOLATED", riskScore: 0.94, details: "Flight isolated from schedule hypergraph" };
      }
      if (n.id === "N-LHREFRA") {
        return { ...n, details: "Protected by synthetic tail decoupling" };
      }
      return n;
    });

    this.state.graphEdges = this.state.graphEdges.map((e) => {
      if (e.id === "E-BOSLHR-LHREFRA") {
        return { ...e, isIsolated: true, label: "Tail Decoupled [Immunized]" };
      }
      return e;
    });

    this.log(
      "PREVENTOR",
      "CRITICAL",
      "Network Contagion Detected (R = 0.94)",
      "Preventor Engine calculated contagion coefficient Ri = 0.94 >= 0.75. Flight AA142 isolated from network hypergraph to protect downstream rotations."
    );
  }

  private executeGateReallocation(): void {
    this.state.flight.currentArrivalGate = "B10";
    this.state.flight.currentOutboundGate = "B12";
    this.state.terminalWalkingReductionMins = 17;
    this.state.manager.gateWalkingTimeBeforeMins = 18;
    this.state.manager.gateWalkingTimeAfterMins = 1;

    this.state.graphNodes = this.state.graphNodes.map((n) => {
      if (n.id === "N-GATE-B10") {
        return { ...n, status: "RECOVERED", details: "Assigned Arrival Gate (Feeder AA142)" };
      }
      if (n.id === "N-GATE-B12") {
        return { ...n, status: "RECOVERED", details: "Assigned Departure Gate (Connecting BOS-LHR)" };
      }
      return n;
    });

    this.log(
      "GATE",
      "SUCCESS",
      "Dynamic Gate Swap Executed (B30 -> B10 & B12)",
      "Manager Engine swapped arrival from Gate B30 to B10, and outbound to adjacent Gate B12. Terminal transit distance reduced from 1,200m (18m sprint) to 25m (1m hallway stroll)."
    );
  }

  private executeDoorHoldOptimization(): void {
    const isApproved = this.state.flight.delayMinutes <= 40;
    this.state.manager.decision = isApproved ? "APPROVED" : "REJECTED";
    this.state.manager.holdMinutes = isApproved ? 5 : 0;
    this.state.manager.costTotalHoldUsd = isApproved ? 10000 : 232000;
    this.state.manager.costTotalAbandonUsd = 70500;
    this.state.manager.netSavingsUsd = isApproved ? 60500 : 161500;
    this.state.manager.decisionReason = isApproved
      ? "Hold 5m approved: Net savings of ₹60,500 vs passenger abandonment. Zero downstream connection conflicts on LHR leg."
      : "Hold rejected: Delay threshold exceeded. Departing on schedule to protect transatlantic slot.";
    this.state.flight.status = "RECOVERED";

    this.log(
      "MANAGER",
      "SUCCESS",
      isApproved ? "Door-Hold Optimization: APPROVED (5 Min Hold)" : "Door-Hold Optimization: REJECTED (Departing)",
      isApproved
        ? "Calculated C_hold (₹10,000) << C_abandon (₹70,500). Pilot advisory and gate agent dispatch cleared to hold door 5 minutes."
        : "Delay exceeds maximum waiting threshold. Door closed to protect 180 onward passengers."
    );
  }

  private executeZeroTouchInterlineAndBaggage(): void {
    const isHoldApproved = this.state.manager.decision === "APPROVED";
    const isMedical = Boolean(
      this.state.medical.isActive ||
      this.state.passenger.medicalProfile.isEmergency ||
      this.state.passenger.isEmergencyTraveler ||
      this.state.disruptionFactors.medicalEmergencyFlag
    );

    if (isHoldApproved) {
      // Direct Connection: Passenger connects onto scheduled AA142-LHR at adjacent Gate B12!
      // No hotel or competitor ticket is needed because the flight is waiting for them!
      this.state.passenger.recoveryAllocation = undefined;
      this.state.baggage.status = "RAMP_TRANSFER_ACTIVE";
      this.state.baggage.targetFlight = "AA142-LHR";
      this.state.baggage.currentLocation = "BOS_RAMP_STAND_B10";
      this.state.baggage.routedDestination = "BOS_RAMP_STAND_B12";
      this.state.baggage.transferSpeedKmh = 22;
      this.state.baggage.lastScannedTime = "16:20 UTC (BOS Tarmac Dispatch)";

      this.log(
        "RAMP",
        "SUCCESS",
        "Direct Ramp Baggage Transfer Active (Stand B10 -> B12)",
        "Baggage tag BAG-4552 transferred directly across 25m ramp to connecting flight AA142-LHR at Stand B12."
      );
    } else {
      // Hold Rejected:
      if (isMedical) {
        // Medical Emergency Patient: Route to immediate competitor airline (British Airways BA212 in 45m)
        this.state.passenger.recoveryAllocation = {
          status: "REBOOKED",
          assignedFlight: "BA212",
          assignedAirline: "British Airways",
          departureTime: "18:00 UTC",
          gate: "B38",
          seat: "12A",
          interlineClearingStatus: "AUTO_SETTLED",
          barcodePayload: "QR-BA212-12A-PAX9921-MEDIF",
        };
        this.state.baggage.targetFlight = "BA212";
        this.state.baggage.routedDestination = "BOS_RAMP_STAND_B38";
        this.log(
          "RAMP",
          "SUCCESS",
          "Medical Emergency: Competitor Airline Interline Rebooking Active (BA212)",
          "Patient PAX-9921 rebooked on British Airways BA212 (18:00 UTC) with dedicated medical priority."
        );
      } else {
        // Standard Passenger: Rebook on Airline's OWN next flight (American Airlines AA102) + Allocate Hotel!
        this.state.passenger.recoveryAllocation = {
          status: "REBOOKED",
          assignedFlight: "AA102",
          assignedAirline: "American Airlines",
          departureTime: "06:00 UTC (Next Morning)",
          gate: "B12",
          seat: "14B",
          interlineClearingStatus: "AUTO_SETTLED",
          barcodePayload: "QR-AA102-14B-PAX9921-RESCHEDULED",
        };
        this.state.baggage.targetFlight = "AA102";
        this.state.baggage.routedDestination = "BOS_LUGGAGE_VAULT_3";
        this.log(
          "CARE",
          "SUCCESS",
          "Owned Airline Reschedule (AA102) & Hilton Hotel Allocated",
          "Passenger PAX-9921 rescheduled on American Airlines AA102 (06:00 UTC). Hilton Boston Logan Room 304 & meal vouchers allocated."
        );
      }

      this.state.baggage.status = "RAMP_TRANSFER_ACTIVE";
      this.state.baggage.currentLocation = "BOS_RAMP_STAND_B10";
      this.state.baggage.transferSpeedKmh = 22;
      this.state.baggage.lastScannedTime = "16:20 UTC (BOS Tarmac Dispatch)";
    }
  }

  private executeFeederLanding(): void {
    this.state.flight.status = "RECOVERED";
    this.state.flight.telemetry.altitudeFt = 0;
    this.state.flight.telemetry.groundSpeedKts = 18;
    this.log(
      "SYSTEM",
      "SUCCESS",
      "Feeder AA142 Landed at BOS Gate B10",
      `Inbound flight AA142 has touched down at Boston Logan and is taxiing to Gate B10. Passenger PAX-9921 is deplaning. Adjacent gate B12 departure boarding is in progress.`
    );
  }

  private executeOvernightCareSuite(): void {
    const isHoldApproved = this.state.manager.decision === "APPROVED";

    if (!isHoldApproved || this.state.activeScenario === "OVERNIGHT_DOMINO") {
      // Hotel is ONLY allocated when flight hold was rejected or overnight delay occurred!
      this.state.overnightCare.triggered = true;
      this.state.overnightCare.triggeredAtMinute = 30;
      this.state.overnightCare.luggageWarehouse.storageStatus = "SECURE_LOCKED";

      this.log(
        "CARE",
        "INFO",
        "Overnight Care Package Activated (Hold Rejected)",
        `Care suite allocated: Hilton Logan Room 304, 2x ₹2,000 meal vouchers, Priority Standby #1 for AA102 (06:00 UTC).`
      );
    } else {
      // When flight waited for user, hotel is NOT needed!
      this.state.overnightCare.triggered = false;
      this.log(
        "CARE",
        "SUCCESS",
        "Direct Connection Maintained — Hotel Not Needed",
        `Passenger successfully transferring to held Flight AA142-LHR at Gate B12. Overnight hotel accommodation not required.`
      );
    }
  }

  private executeConnectingBoardingComplete(): void {
    this.state.baggage.status = "RAMP_TRANSFER_ACTIVE";
    this.state.baggage.currentLocation = "BOS_RAMP_STAND_B12";
    this.state.baggage.routedDestination = "LHR_TERMINAL_5";

    this.log(
      "GATE",
      "SUCCESS",
      "Passenger Boarded Connecting Flight at B12",
      `PAX-9921 has walked 25 meters from B10 to adjacent Gate B12 and boarded the London flight. Boarding door remains open per approved 5-minute hold clearance. Baggage tug #04 transferring Bag #4552 to cargo hold.`
    );
  }

  private executeConnectingFlightDeparture(): void {
    this.state.flight.status = "RECOVERED";
    this.log(
      "SYSTEM",
      "SUCCESS",
      "✈️ Connecting Flight BOS ➔ LHR — PUSHBACK & DEPARTURE",
      `London-bound flight has closed doors with PAX-9921 onboard (Seat 14B). Pushback from Gate B12 initiated. Taxi to Runway 22R at Boston Logan. Estimated flight time: 6h 10m.`
    );
  }

  private executeBaggageConfirmedOnboard(): void {
    this.state.baggage.status = "LOADED_ON_TARGET";
    this.state.baggage.currentLocation = "CARGO_HOLD_CONNECTING_FLIGHT";
    this.state.baggage.lastScannedTime = "16:45 UTC (Cargo Door Scan)";

    this.log(
      "RAMP",
      "SUCCESS",
      "Baggage #4552 Confirmed Loaded on Connecting Flight",
      `Bag #4552 has been scanned and confirmed loaded in the aft cargo hold of the London flight. Tug #04 returned to Stand B10. All ramp operations completed successfully.`
    );
  }

  private executeCruiseAltitudeReached(): void {
    this.log(
      "SYSTEM",
      "SUCCESS",
      "Connecting Flight at Cruise Altitude FL380",
      `BOS ➔ LHR flight has reached cruise altitude 38,000 ft over the North Atlantic. Ground speed 530 kts. Remaining distance: 2,980 nm. ETA London Heathrow: 6h 00m. Passenger PAX-9921 and Bag #4552 are both confirmed onboard.`
    );
  }

  private executeFullLifecycleComplete(): void {
    this.log(
      "SYSTEM",
      "SUCCESS",
      "🏁 FULL IROPS LIFECYCLE COMPLETE — DISRUPTION FULLY RECOVERED",
      `The DOMINO EFFECT dual-engine pipeline has completed its full cycle: Disruption detected mid-air ➔ Contagion isolated ➔ Gate dynamically swapped ➔ Door held ➔ Passenger boarded connecting flight ➔ Baggage confirmed loaded ➔ Aircraft airborne to London. Total recovery time: 40 minutes. Net savings: ₹60,500. Zero passengers stranded.`
    );
  }

  public getState(): SimulationState {
    return JSON.parse(JSON.stringify(this.state));
  }
}

export const simulationEngine = new SimulationEngine();
