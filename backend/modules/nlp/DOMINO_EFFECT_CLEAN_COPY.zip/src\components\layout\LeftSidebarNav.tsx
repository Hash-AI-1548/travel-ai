import React from "react";
import {
  LayoutDashboard,
  Globe,
  Plane,
  Briefcase,
  Hotel,
  HeartPulse,
  Calculator,
  Settings,
} from "lucide-react";
import type { AOCViewTab } from "../aoc/TopNavBar";
import type { SimulationState } from "../../engine/simulationEngine";

interface LeftSidebarNavProps {
  activeTab: AOCViewTab;
  onTabChange: (tab: AOCViewTab) => void;
  state: SimulationState;
}

interface NavItem {
  id: AOCViewTab;
  label: string;
  icon: React.ElementType;
  badge?: string;
  isEmergency?: boolean;
}

export const LeftSidebarNav: React.FC<LeftSidebarNavProps> = ({
  activeTab,
  onTabChange,
  state,
}) => {
  const navItems: NavItem[] = [
    { id: "OPERATIONS", label: "Operations Cockpit", icon: LayoutDashboard },
    { id: "MAP", label: "Global Radar & Aircraft Tracking", icon: Globe },
    { id: "TERMINAL_MAP", label: "Terminal Indoor Map & Gates", icon: Plane },
    { id: "RECOVERY", label: "Passenger Rebooking & Baggage", icon: Briefcase },
    { id: "CARE", label: "Hotel, Meals & Liability Suite", icon: Hotel },
    {
      id: "MEDICAL",
      label: "Medical Emergency Response",
      icon: HeartPulse,
      badge: state.medical.isActive ? "!" : undefined,
      isEmergency: state.medical.isActive,
    },
    { id: "MATH", label: "Decision Math Models", icon: Calculator },
  ];

  return (
    <aside className="w-16 bg-[#050811] border-r border-slate-800/80 flex flex-col items-center py-3 select-none shrink-0 z-50">
      {/* Top Logo */}
      <button
        onClick={() => onTabChange("OPERATIONS")}
        className="h-10 w-10 rounded-xl bg-gradient-to-br from-sky-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-sky-950/50 mb-6 hover:scale-105 transition cursor-pointer"
        title="DOMINO EFFECT Operations"
      >
        <Plane className="h-5 w-5 -rotate-45" />
      </button>

      {/* Main Navigation Stack */}
      <nav className="flex-1 flex flex-col items-center gap-2.5 w-full px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              title={item.label}
              className={`relative h-11 w-11 rounded-xl flex items-center justify-center transition-all cursor-pointer group ${
                isActive
                  ? "bg-sky-600 text-white shadow-lg shadow-sky-600/30 scale-105"
                  : item.isEmergency
                  ? "bg-rose-950/80 text-rose-300 border border-rose-600/80 hover:bg-rose-900"
                  : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/60"
              }`}
            >
              <Icon className="h-5 w-5" />

              {/* Active Indicator Bar on left */}
              {isActive && (
                <span className="absolute -left-2 top-2 bottom-2 w-1 rounded-r bg-sky-400 shadow-[0_0_8px_rgba(56,189,248,0.8)]" />
              )}

              {/* Emergency Alert Indicator */}
              {item.badge && (
                <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center animate-ping">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Settings / Profile Icon */}
      <div className="pt-3 border-t border-slate-800/80 w-full px-2 flex flex-col items-center gap-2">
        <button
          onClick={() => onTabChange("PROFILE")}
          title="Travel Passport & User Profile Settings"
          className={`h-11 w-11 rounded-xl flex items-center justify-center transition-all cursor-pointer ${
            activeTab === "PROFILE"
              ? "bg-sky-600 text-white shadow-lg shadow-sky-600/30"
              : "text-slate-400 hover:text-slate-100 hover:bg-slate-800/60"
          }`}
        >
          <Settings className="h-5 w-5" />
        </button>
      </div>
    </aside>
  );
};
