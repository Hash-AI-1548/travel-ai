import React, { useState, useEffect } from "react";
import {
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Users,
  UserCheck,
  TrendingUp,
  Plane,
  Building,
  Play,
  Pause,
  RotateCcw,
  Clock,
  ShieldAlert,
  ExternalLink,
  ChevronRight,
  Radio,
  Sparkles,
  Cpu,
  Send,
} from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import { simulationEngine } from "../../engine/simulationEngine";
import type { ScenarioType } from "../../types/simulation";
import {
  fetchLiveWeatherAtCoords,
  type LiveAviationWeather,
} from "../../services/airlabsService";
import { sounds } from "../../utils/audio";

interface DynamicOperationsViewProps {
  state: SimulationState;
  onOpenMap?: () => void;
  onOpenTerminalMap?: () => void;
  onOpenStudio?: () => void;
  onPlay?: () => void;
  onPause?: () => void;
  onReset?: (scenario?: ScenarioType) => void;
  onSpeedChange?: (speed: number) => void;
  onScenarioChange?: (scenario: ScenarioType) => void;
  onMedicalTrigger?: () => void;
}

export const DynamicOperationsView: React.FC<DynamicOperationsViewProps> = ({
  state,
  onOpenMap,
  onOpenTerminalMap,
  onPlay,
  onPause,
  onReset,
  onSpeedChange,
  onScenarioChange,
  onMedicalTrigger,
}) => {
  const { flight, inferredOutcome, medical, activeScenario, simMinute, simClockSeconds, isRunning, timeMultiplier, crewRoster, crewEvaluation, cockpitMessages, passengerBriefing, autonomousTelemetry } = state;

  const [weatherBOS, setWeatherBOS] = useState<LiveAviationWeather | null>(null);
  const [weatherJFK, setWeatherJFK] = useState<LiveAviationWeather | null>(null);
  const [isAiRunning, setIsAiRunning] = useState<boolean>(false);

  const handleTriggerAiCycle = async () => {
    setIsAiRunning(true);
    sounds.playRadarPing();
    try {
      await simulationEngine.runAutonomousPuterCycle();
      sounds.playSuccessChime();
    } finally {
      setIsAiRunning(false);
    }
  };

  useEffect(() => {
    let isMounted = true;
    const fetchLiveOps = async () => {
      try {
        const bosWeather = await fetchLiveWeatherAtCoords(42.3656, -71.0096, "Boston Logan");
        const jfkWeather = await fetchLiveWeatherAtCoords(40.6413, -73.7781, "New York JFK");
        if (isMounted) {
          setWeatherBOS(bosWeather);
          setWeatherJFK(jfkWeather);
        }
      } catch (err) {
        console.warn("Live ops sync notice:", err);
      }
    };

    fetchLiveOps();
    const interval = setInterval(fetchLiveOps, 60000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, []);

  const totalDelayMin = inferredOutcome?.totalDelayMinutes ?? flight.delayMinutes ?? 33;
  const isDirectConnection = inferredOutcome
    ? (inferredOutcome.doorHoldFeasibility === "HOLD_APPROVED" || inferredOutcome.doorHoldFeasibility === "NOT_NEEDED")
    : totalDelayMin <= 40;
  const isHoldApproved = isDirectConnection;
  const isNoHoldNeeded = inferredOutcome ? inferredOutcome.doorHoldFeasibility === "NOT_NEEDED" : totalDelayMin <= 10;
  const holdMinutes = isNoHoldNeeded ? 0 : (inferredOutcome ? inferredOutcome.doorHoldMinutes : (isHoldApproved ? 4 : 0));
  const holdCost = isNoHoldNeeded ? 0 : (inferredOutcome ? inferredOutcome.costHoldInr : (isHoldApproved ? 2500 : 232000));
  const abandonCost = inferredOutcome ? inferredOutcome.costAbandonInr : 70500;
  const netSavings = isNoHoldNeeded ? 70500 : (inferredOutcome ? inferredOutcome.netSavingsInr : (isHoldApproved ? 62500 : 161500));
  const netCostFormatted = inferredOutcome
    ? (inferredOutcome.estimatedNetworkSavingsInr >= 10000000
        ? `₹${(inferredOutcome.estimatedNetworkSavingsInr / 10000000).toFixed(3)} Cr`
        : `₹${inferredOutcome.estimatedNetworkSavingsInr.toLocaleString("en-IN")}`)
    : (isHoldApproved ? "₹0.464 Cr" : "₹0.161 Cr");
  const riskScore = inferredOutcome?.contagionRiskScore ? inferredOutcome.contagionRiskScore.toFixed(2) : (state.preventor?.riskScore ? state.preventor.riskScore.toFixed(2) : "0.72");
  const flightsProtected = inferredOutcome?.financialModelBreakdown?.downstreamAircraftSectors ?? inferredOutcome?.protectedFlightsCount ?? 45;
  const crewImpactAvoided = inferredOutcome?.financialModelBreakdown?.crewPairingsProtected ?? 12;
  const paxProtected = inferredOutcome?.financialModelBreakdown?.passengerConnectionsProtected ?? 15;
  const estimatedLandingTime = inferredOutcome?.inferredArrivalEta ?? "4:35 PM";

  return (
    <div className="flex flex-col h-full overflow-y-auto p-4 lg:p-5 bg-[#040811] text-slate-200 font-sans space-y-3.5 select-none">
      {/* 1. SIMULATION CONTROL & TELEMETRY STATUS BAR */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 px-4 py-2 rounded-xl bg-[#080d1a] border border-slate-800 text-xs font-mono shadow-lg">
        {/* Playback Controls & Clock */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2 bg-[#050811] px-2.5 py-1 rounded-lg border border-slate-800">
            <Clock className="h-3.5 w-3.5 text-sky-400" />
            <span className="text-slate-400">Elapsed:</span>
            <span className="font-bold text-white tracking-wider">
              T+{simMinute}m ({simClockSeconds}s)
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            {isRunning ? (
              <button
                onClick={() => {
                  onPause?.();
                  sounds.playRadarPing();
                }}
                className="flex items-center gap-1 px-3 py-1 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold shadow transition cursor-pointer"
              >
                <Pause className="h-3.5 w-3.5 fill-current" />
                <span>Pause</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  onPlay?.();
                  sounds.playCockpitChime();
                }}
                className="flex items-center gap-1 px-3 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold shadow transition cursor-pointer"
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Start Sim</span>
              </button>
            )}

            <button
              onClick={() => {
                onReset?.();
                sounds.playRadarPing();
              }}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              title="Reset Simulation"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Speed Multipliers */}
          <div className="flex items-center gap-1 bg-[#050811] p-0.5 rounded-lg border border-slate-800 text-[10px]">
            <span className="text-slate-500 px-1 font-bold">Speed:</span>
            {[1, 5, 10, 20].map((s) => (
              <button
                key={s}
                onClick={() => onSpeedChange?.(s)}
                className={`px-1.5 py-0.5 rounded font-bold transition cursor-pointer ${
                  timeMultiplier === s
                    ? "bg-sky-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
        </div>

        {/* Puter AI Autonomous Cycle Trigger & Scenario Controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleTriggerAiCycle}
            disabled={isAiRunning}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-bold text-xs shadow-md transition cursor-pointer border ${
              isAiRunning
                ? "bg-indigo-950 border-indigo-500 text-indigo-200 animate-pulse"
                : "bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 text-white border-sky-400/50 shadow-indigo-950/60"
            }`}
            title="Execute Keyless Puter AI Autonomous Decision Loop"
          >
            <Sparkles className={`h-3.5 w-3.5 ${isAiRunning ? "animate-spin" : "text-amber-300"}`} />
            <span>{isAiRunning ? "AI DISPATCH RUNNING..." : "RUN AUTONOMOUS AI CYCLE"}</span>
          </button>

          <select
            value={activeScenario}
            onChange={(e) => onScenarioChange?.(e.target.value as ScenarioType)}
            aria-label="Select Disruption Scenario"
            className="bg-[#050811] border border-slate-700 text-sky-300 rounded-lg px-2.5 py-1 text-xs font-semibold focus:outline-none focus:border-sky-500 cursor-pointer"
          >
            <option value="MECHANICAL_FAILURE">⚙ Case: Mechanical Fault (IATA Rule 240)</option>
            <option value="ATC_GROUND_HOLD">⏱ Case: ATC Airspace Hold</option>
            <option value="WEATHER_CONVECTIVE">⛈ Case: Severe Weather Storm</option>
          </select>

          <button
            onClick={() => {
              onMedicalTrigger?.();
              sounds.playEmergencySiren();
            }}
            disabled={medical.isActive}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg font-bold text-xs transition cursor-pointer ${
              medical.isActive
                ? "bg-rose-900/60 border border-rose-500 text-rose-200 animate-pulse cursor-not-allowed"
                : "bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-950/60"
            }`}
          >
            <ShieldAlert className="h-3.5 w-3.5" />
            <span>{medical.isActive ? "🚨 MEDICAL ACTIVE" : "SIMULATE MEDICAL"}</span>
          </button>
        </div>
      </div>

      {/* 2. AUTONOMOUS AI ORCHESTRATOR & CREW/PILOT TELEMETRY BANNER */}
      <div className="rounded-2xl border border-sky-900/60 bg-gradient-to-r from-[#061021] via-[#09152b] to-[#081224] p-3.5 shadow-xl font-mono text-xs text-slate-200 space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-sky-900/50">
          <div className="flex items-center gap-2">
            <div className="p-1 rounded bg-sky-950 border border-sky-700 text-sky-400">
              <Cpu className="h-4 w-4" />
            </div>
            <div>
              <span className="font-black text-white uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                AUTONOMOUS NEURAL OPS ENGINE
                <span className="px-2 py-0.2 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-600 text-[9px] font-bold animate-pulse">
                  LIVE AUTO-PILOT
                </span>
              </span>
              <p className="text-[10px] text-slate-400 font-sans">
                Keyless OpenAI Intelligence Core ({autonomousTelemetry?.modelEngine || "GPT-5.4 Nano"}) · Zero Manual Input Required
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-400">
              Cycle: <strong className="text-sky-300">#{autonomousTelemetry?.cycleCount ?? 1}</strong> ({autonomousTelemetry?.lastDecisionCycle ?? "16:00:00 UTC"})
            </span>
          </div>
        </div>

        {/* 4 Live Autonomous Indicators */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-[11px]">
          <div className="bg-[#040914]/90 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[9px] text-slate-400 block font-bold uppercase">CREW DUTY STATUS</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1 mt-0.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                FAR Part 117 Legal
              </span>
            </div>
            <span className="text-[10px] font-bold text-slate-300 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-700">
              7.9h Buffer
            </span>
          </div>

          <div className="bg-[#040914]/90 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[9px] text-slate-400 block font-bold uppercase">COCKPIT ACARS DATALINK</span>
              <span className="text-sky-400 font-bold flex items-center gap-1 mt-0.5">
                <Radio className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
                Capt. Thorne (B787)
              </span>
            </div>
            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-700">
              HOLD ACK'D
            </span>
          </div>

          <div className="bg-[#040914]/90 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[9px] text-slate-400 block font-bold uppercase">GATE REALLOCATION</span>
              <span className="text-emerald-400 font-bold flex items-center gap-1 mt-0.5">
                <Building className="h-3.5 w-3.5 text-emerald-400" />
                {(inferredOutcome?.arrivalGate || state.flight.currentArrivalGate || "Gate B10").replace("Gate ", "")} ➔ {(inferredOutcome?.outboundGate || state.flight.currentOutboundGate || "Gate B12").replace("Gate ", "")} ({inferredOutcome?.walkingDistanceMeters ? `${inferredOutcome.walkingDistanceMeters}m` : "Adjacent"})
              </span>
            </div>
            <span className="text-[10px] font-bold text-emerald-300 bg-emerald-950/80 px-1.5 py-0.5 rounded border border-emerald-700">
              {inferredOutcome?.walkingTimeMins || 1}m Walk
            </span>
          </div>

          <div className="bg-[#040914]/90 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <div>
              <span className="text-[9px] text-slate-400 block font-bold uppercase">PAX MOBILE BRIEFING</span>
              <span className="text-indigo-300 font-bold flex items-center gap-1 mt-0.5">
                <Send className="h-3.5 w-3.5 text-indigo-400" />
                Delivered to Phone
              </span>
            </div>
            <span className="text-[10px] font-bold text-indigo-300 bg-indigo-950/80 px-1.5 py-0.5 rounded border border-indigo-700">
              REAL-TIME
            </span>
          </div>
        </div>
      </div>

      {/* 2. REAL-TIME AI TELEMETRY QUICK STATUS CHIPS */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs font-mono">
        <div className="flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-[#090e1a] border border-slate-800">
          <span className="text-slate-400 text-[11px]">Disruption Risk Score:</span>
          <span className="font-bold text-amber-400 flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />
            {riskScore} (Isolated)
          </span>
        </div>

        <div className="flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-[#090e1a] border border-slate-800">
          <span className="text-slate-400 text-[11px]">Gate Allocation:</span>
          <span className="font-bold text-emerald-400 flex items-center gap-1">
            {inferredOutcome?.arrivalGate || state.flight.currentArrivalGate || "Gate B10"} ➔ {inferredOutcome?.outboundGate || state.flight.currentOutboundGate || "Gate B12"} <strong className="text-slate-300 font-normal">({inferredOutcome?.walkingTimeMins || 1}m walk)</strong>
          </span>
        </div>

        <div className="flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-[#090e1a] border border-slate-800">
          <span className="text-slate-400 text-[11px]">Door-Hold Decision:</span>
          <span className={`font-bold flex items-center gap-1 ${isHoldApproved ? "text-emerald-400" : "text-amber-400"}`}>
            {isHoldApproved
              ? (inferredOutcome?.doorHoldMinutes === 0
                ? "Flight Waiting & Doors Ready (₹0 Cost)"
                : `Hold ${inferredOutcome?.doorHoldMinutes || 4}m Approved (+₹${(inferredOutcome?.netSavingsInr || 62500).toLocaleString('en-IN')} Savings)`)
              : "Close & Rebook (Threshold Exceeded)"}
          </span>
        </div>
      </div>

      {/* 3. MAIN DASHBOARD 3-COLUMN WORKSPACE */}
      <div className="grid grid-cols-12 gap-3.5">
        {/* ================= COLUMN 1: FLIGHT CARD, CORRIDOR VISUALIZER, WEATHER, FINANCIAL BREAKDOWN ================= */}
        <div className="col-span-12 lg:col-span-4 xl:col-span-3 space-y-3">
          {/* Disruption Spread Visualizer */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-3.5 shadow-xl space-y-2.5">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                DISRUPTION SPREAD VISUALIZER
              </span>
              {onOpenMap && (
                <button
                  onClick={onOpenMap}
                  className="text-[10px] font-mono text-sky-400 hover:text-sky-300 flex items-center gap-0.5 cursor-pointer"
                >
                  <span>Radar View</span>
                  <ExternalLink className="h-2.5 w-2.5" />
                </button>
              )}
            </div>

            {/* Interactive 3-Node Flight Corridor Line with Moving Plane */}
            <div className="flex items-center justify-between px-2 py-2.5 bg-[#050811] rounded-xl border border-slate-800 text-xs font-mono relative overflow-hidden">
              <div className="flex flex-col items-center z-10">
                <span className="px-2 py-0.5 rounded bg-sky-950 border border-sky-600 text-sky-300 font-bold text-[10px]">
                  AA142
                </span>
                <span className="text-[9px] text-slate-500 mt-0.5">JFK</span>
              </div>

              {/* Dynamic Flight Corridor Progress Track */}
              <div className="flex-1 h-2 mx-3 bg-slate-900 rounded-full relative overflow-visible border border-slate-800">
                <div
                  className="h-full bg-gradient-to-r from-sky-500 via-emerald-400 to-indigo-500 rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(56,189,248,0.7)]"
                  style={{
                    width: `${Math.min(100, Math.max(8, simMinute < 25 ? (simMinute / 25) * 50 : 50 + ((simMinute - 40) / 20) * 50))}%`,
                  }}
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 z-20 flex items-center justify-center transition-all duration-300 pointer-events-none"
                  style={{
                    left: `${Math.min(95, Math.max(5, simMinute < 25 ? (simMinute / 25) * 50 : 50 + ((simMinute - 40) / 20) * 50))}%`,
                  }}
                >
                  <div className="p-1 rounded-full bg-sky-500 border-2 border-white text-white shadow-lg shadow-sky-500/80 animate-pulse">
                    <Plane className="h-3 w-3 transform -rotate-45" />
                  </div>
                </div>
              </div>

              <div className="flex flex-col items-center z-10">
                <span className="px-2 py-0.5 rounded bg-emerald-950 border border-emerald-500 text-emerald-300 font-bold text-[10px]">
                  BOS
                </span>
                <span className="text-[9px] text-emerald-400 font-semibold mt-0.5">Landing Hub</span>
              </div>

              <div className="flex flex-col items-center z-10 ml-2">
                <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-400 font-bold text-[10px]">
                  LHR
                </span>
                <span className="text-[9px] text-slate-500 mt-0.5">London</span>
              </div>
            </div>
          </div>

          {/* Active Flight Card */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-[#0f172a] border border-slate-700 text-xs font-mono font-bold text-slate-200">
                  AA142
                </span>
                <span className="px-2 py-0.5 rounded bg-sky-950 text-[9px] font-mono font-bold text-sky-300 border border-sky-800">
                  {simMinute < 25 ? "IN-FLIGHT" : simMinute < 40 ? "ON-GROUND" : "AIRBORNE"}
                </span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-purple-950/80 border border-purple-600/60 text-[9px] font-mono font-bold text-purple-300 uppercase">
                HIGH RISK — CONTAINED
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2.5 text-2xl font-black text-white tracking-tight">
                <span>JFK</span>
                <ArrowRight className="h-5 w-5 text-slate-500" />
                <span>BOS</span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">New York ➔ Boston Logan</p>
            </div>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800/80 font-mono">
              <div className="bg-[#050811] p-2 rounded-xl border border-slate-800/70">
                <span className="text-[9px] text-slate-400 block">Total Delay</span>
                <span className="text-sm font-black text-amber-400 block mt-0.5">+{totalDelayMin} min</span>
              </div>
              <div className="bg-[#050811] p-2 rounded-xl border border-slate-800/70">
                <span className="text-[9px] text-slate-400 block">Status / ETA</span>
                <span className="text-xs font-bold text-white block mt-1">
                  {flight.telemetry.etaMinutes > 0 ? `ETA ${flight.telemetry.etaMinutes}m (${estimatedLandingTime})` : "Landed (BOS)"}
                </span>
              </div>
              <div className="bg-[#050811] p-2 rounded-xl border border-slate-800/70">
                <span className="text-[9px] text-slate-400 block">Gate Closes</span>
                <span className="text-[11px] font-bold text-slate-300 block mt-1">5:05 PM (BOS)</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-400">
              <span>
                GPS: <strong className="text-sky-400 font-bold">{flight.telemetry.lat.toFixed(4)}°, {flight.telemetry.lng.toFixed(4)}°</strong>
              </span>
              <span className="text-emerald-400 font-bold">
                {flight.telemetry.altitudeFt.toLocaleString()} FT · {flight.telemetry.groundSpeedKts} KTS
              </span>
            </div>
          </div>

          {/* OpenWeather Live METAR Feed */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-3.5 shadow-xl space-y-2.5">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
                OPENWEATHER METAR FEED
              </span>
              <span className="flex items-center gap-1 text-[9px] font-mono text-emerald-400 font-bold">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                LIVE SYNC
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs font-mono">
              <div className="bg-[#050811] p-2.5 rounded-xl border border-slate-800/80">
                <div className="text-[10px] text-slate-400 font-bold">BOS (Boston Logan)</div>
                <div className="text-sm font-black text-amber-300 mt-0.5">
                  {weatherBOS ? `${weatherBOS.tempC}°C / ${weatherBOS.tempF}°F` : "20.1°C / 68°F"}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">
                  {weatherBOS ? `${weatherBOS.description} · Wind ${weatherBOS.windSpeedKts} kts` : "Overcast clouds · Wind 14 kts"}
                </div>
              </div>

              <div className="bg-[#050811] p-2.5 rounded-xl border border-slate-800/80">
                <div className="text-[10px] text-slate-400 font-bold">JFK (New York)</div>
                <div className="text-sm font-black text-sky-300 mt-0.5">
                  {weatherJFK ? `${weatherJFK.tempC}°C / ${weatherJFK.tempF}°F` : "22.7°C / 73°F"}
                </div>
                <div className="text-[9px] text-slate-400 mt-0.5">
                  {weatherJFK ? `${weatherJFK.description} · Wind ${weatherJFK.windSpeedKts} kts` : "Broken clouds · Wind 11 kts"}
                </div>
              </div>
            </div>
          </div>

          {/* Detailed Cost Avoidance Financial Breakdown */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-3.5 shadow-xl space-y-2">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800/80 text-xs font-mono">
              <span className="text-[10px] text-slate-400 font-bold">11 GRAPH SECTORS</span>
              <span className="text-emerald-400 font-black">NET COST AVOIDED: {netCostFormatted}</span>
            </div>

            <div className="space-y-1 text-[11px] font-mono">
              <div className="flex justify-between text-slate-300">
                <span>• Aircraft Tail Cascade (4 rotations):</span>
                <span className="text-emerald-400 font-bold">+₹27.60L</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>• Crew Duty Limits Pairing C101 + Reserve:</span>
                <span className="text-emerald-400 font-bold">+₹11.80L</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>• Passenger Misconnect Mitigation (15 Pax):</span>
                <span className="text-emerald-400 font-bold">+₹6.77L</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>• LHR Night Slot & UK261 Curfew Exposure:</span>
                <span className="text-emerald-400 font-bold">+₹3.18L</span>
              </div>
              <div className="flex justify-between text-slate-400 border-t border-slate-800/60 pt-1">
                <span>• Autonomous Intervention Cost (5m Hold/Tug):</span>
                <span className="text-rose-400 font-bold">-₹0.38L</span>
              </div>
              <div className="flex justify-between text-white font-bold border-t border-slate-700/80 pt-1">
                <span>Net Expected Cost Avoided:</span>
                <span className="text-emerald-400 text-xs font-black">{netCostFormatted}</span>
              </div>
            </div>
          </div>
        </div>

        {/* ================= COLUMN 2: RECOVERY PIPELINE, REASSIGNMENTS, GATES, DOOR-HOLD & 4 KPIS ================= */}
        <div className="col-span-12 lg:col-span-8 xl:col-span-6 space-y-3">

          {/* Aircraft & Crew Reassignment Timeline */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-2.5">
            <h2 className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase">
              AIRCRAFT & CREW REASSIGNMENT TIMELINE
            </h2>

            <div className="space-y-2 text-xs font-mono">
              <div className="flex items-center justify-between p-2.5 bg-[#050811] rounded-xl border border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-bold">AIRCRAFT:</span>
                  <span className="text-white font-bold">N789AA</span>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-500" />
                  <span className="text-slate-400">Separated from delayed flight</span>
                </div>
                <span className="text-emerald-400 font-bold">Replaced with: N441AA</span>
              </div>

              <div className="flex items-center justify-between p-2.5 bg-[#050811] rounded-xl border border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-bold">CREW:</span>
                  <span className="text-white font-bold">Crew C-114</span>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-500" />
                  <span className="text-slate-400">Rest hours protected</span>
                </div>
                <span className="text-emerald-400 font-bold">Replaced with: Crew C-226</span>
              </div>
            </div>
          </div>

          {/* Dynamic Gate Reallocation Module */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-2.5">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800/80">
              <h2 className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase">
                {inferredOutcome?.gateActionTitle || "ARRIVAL & DEPARTURE GATES PLACED SIDE-BY-SIDE"}
              </h2>
              {onOpenTerminalMap && (
                <button
                  onClick={onOpenTerminalMap}
                  className="text-xs font-mono text-sky-400 hover:text-sky-300 font-bold flex items-center gap-1 cursor-pointer"
                >
                  <span>View Terminal Map</span>
                  <ChevronRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            <div className="flex items-center gap-4 bg-[#050811] p-3 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2 font-mono">
                <div className="p-2 rounded-lg bg-emerald-950 border border-emerald-500 text-center min-w-[90px]">
                  <div className="text-sm font-black text-emerald-300">
                    {inferredOutcome?.arrivalGate || state.flight.currentArrivalGate || "Gate B10"}
                  </div>
                  <div className="text-[9px] text-slate-400">LANDING HUB</div>
                </div>

                <ArrowRight className="h-4 w-4 text-emerald-400 shrink-0" />

                <div className="p-2 rounded-lg bg-emerald-950 border border-emerald-500 text-center min-w-[90px]">
                  <div className="text-sm font-black text-emerald-300">
                    {inferredOutcome?.outboundGate || state.flight.currentOutboundGate || "Gate B12"}
                  </div>
                  <div className="text-[9px] text-slate-400">BOARDING HUB</div>
                </div>
              </div>

              <div className="flex-1 text-xs">
                <p className="text-white font-bold">
                  {inferredOutcome?.gateActionDescription || "London departure placed at Gate B12 next to arrival Gate B10 — only 25 meters apart."}
                </p>
                <p className="text-emerald-400 text-[11px] font-mono mt-0.5">
                  {inferredOutcome?.gateSavingText || "✓ Walking time cut from 18 min sprint to 1 min stroll (25 meters)"}
                </p>
              </div>
            </div>
          </div>

          {/* ================= NEW: COCKPIT ACARS & CPDLC INTER-CREW DATALINK STATION ================= */}
          <div className="rounded-2xl border border-sky-900/60 bg-[#090e1a] p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-1 rounded bg-sky-950 border border-sky-600 text-sky-400">
                  <Radio className="h-3.5 w-3.5 animate-pulse" />
                </div>
                <div>
                  <h2 className="text-xs font-mono font-bold tracking-wider text-slate-200 uppercase">
                    COCKPIT ACARS & CPDLC INTER-CREW DATALINK
                  </h2>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Direct AOC ➔ Flight Deck Signaling (VHF 131.550 MHz / ARINC 623)
                  </span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500 text-[9px] font-mono text-emerald-300 font-bold flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                PILOT CONNECTED
              </span>
            </div>

            {/* Datalink Messages Feed */}
            <div className="space-y-2 font-mono text-xs max-h-48 overflow-y-auto pr-1">
              {cockpitMessages?.slice(0, 3).map((msg) => (
                <div
                  key={msg.id}
                  className="p-2.5 rounded-xl bg-[#050811] border border-slate-800/80 hover:border-sky-800 transition space-y-1"
                >
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="font-bold text-sky-400 flex items-center gap-1">
                      {msg.sender === "COCKPIT_CAPTAIN" ? "👨‍✈️ " : msg.sender === "CABIN_PURSER" ? "👔 " : "📡 "}
                      {msg.senderName}
                    </span>
                    <span className="text-slate-400 flex items-center gap-1.5">
                      <span className="px-1.5 py-0.2 rounded bg-slate-900 border border-slate-700 text-[9px] text-slate-300">
                        {msg.latencyMs}ms
                      </span>
                      <span>{msg.timestampUtc}</span>
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-200 font-sans leading-snug">
                    {msg.humanReadableSummary}
                  </p>

                  <div className="flex items-center justify-between text-[9px] text-slate-500 pt-0.5 border-t border-slate-800/50">
                    <span className="truncate max-w-[280px] text-slate-400">{msg.acarsPayload}</span>
                    <span className="text-emerald-400 font-bold">{msg.status.replace(/_/g, " ")}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* ================= NEW: CREW DATABASE & FAR PART 117 LEGALITY MONITOR ================= */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-1 rounded bg-indigo-950 border border-indigo-700 text-indigo-400">
                  <Users className="h-3.5 w-3.5" />
                </div>
                <div>
                  <h2 className="text-xs font-mono font-bold tracking-wider text-slate-200 uppercase">
                    CREW ROSTER DATABASE & FAR PART 117 LEGALITY MONITOR
                  </h2>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Autonomous Flight Duty Period (FDP) & Rest Rule Evaluation
                  </span>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-emerald-950 border border-emerald-500 text-[9px] font-mono text-emerald-300 font-bold">
                100% LEGAL BUFFER
              </span>
            </div>

            {/* Crew Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
              {crewRoster?.slice(0, 4).map((crew) => (
                <div
                  key={crew.id}
                  className="p-2.5 rounded-xl bg-[#050811] border border-slate-800 flex flex-col justify-between space-y-1.5"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white text-[11px] block">{crew.name}</span>
                      <span className="text-[9px] text-slate-400">{crew.role.replace(/_/g, " ")} · Flight {crew.flightNumber}</span>
                    </div>
                    <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-600">
                      LEGAL
                    </span>
                  </div>

                  <div className="space-y-1 text-[10px] text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Duty Elapsed:</span>
                      <span className="font-bold text-slate-200">{crew.currentElapsedDutyHours}h / {crew.maxLegalFdpHours}h Max</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Legal Margin:</span>
                      <span className="font-bold text-emerald-400">+{crew.restPeriodRemainingHours}h remaining</span>
                    </div>
                  </div>

                  <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-sky-400 rounded-full"
                      style={{ width: `${Math.round((crew.currentElapsedDutyHours / crew.maxLegalFdpHours) * 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Puter AI Legality Summary */}
            <div className="p-2.5 rounded-xl bg-[#050811] border border-slate-800 text-[11px] text-emerald-300 font-mono flex items-start gap-2">
              <Sparkles className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
              <span>
                <strong>FAA Part 117 Compliance Verified:</strong> {crewEvaluation?.crewDutySummaryNarrative || "Captain David Thorne and crew have 7.9h remaining duty time. The 5-minute gate hold consumes <0.1h and maintains full legal rest buffer with zero timeout risk."}
              </span>
            </div>
          </div>

          {/* 4 Large KPI Metric Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
            <div className="bg-[#050811] p-3 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] font-mono uppercase font-bold">FLIGHTS PROTECTED</span>
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
              </div>
              <div className="mt-1.5">
                <span className="text-2xl font-black text-white font-mono">{flightsProtected}</span>
                <span className="text-[10px] text-slate-400 block">Downstream</span>
              </div>
            </div>

            <div className="bg-[#050811] p-3 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] font-mono uppercase font-bold">CREW IMPACT AVOIDED</span>
                <UserCheck className="h-4 w-4 text-sky-400" />
              </div>
              <div className="mt-1.5">
                <span className="text-2xl font-black text-white font-mono">{crewImpactAvoided}</span>
                <span className="text-[10px] text-slate-400 block">Crew Pairings</span>
              </div>
            </div>

            <div className="bg-[#050811] p-3 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] font-mono uppercase font-bold">PASSENGER CONNECTIONS</span>
                <Users className="h-4 w-4 text-indigo-400" />
              </div>
              <div className="mt-1.5">
                <span className="text-2xl font-black text-white font-mono">{paxProtected}</span>
                <span className="text-[10px] text-slate-400 block">Protected</span>
              </div>
            </div>

            <div className="bg-[#050811] p-3 rounded-xl border border-slate-800 flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-400">
                <span className="text-[10px] font-mono uppercase font-bold">NET COST AVOIDED</span>
                <TrendingUp className="h-4 w-4 text-emerald-400" />
              </div>
              <div className="mt-1.5">
                <span className="text-2xl font-black text-emerald-400 font-mono">{netCostFormatted}</span>
                <span className="text-[10px] text-slate-400 block">Estimated</span>
              </div>
            </div>
          </div>
        </div>

        {/* ================= COLUMN 3: DOOR-HOLD DECISION, REBOOKING & CONNECTING PROTECTION ================= */}
        <div className="col-span-12 lg:col-span-12 xl:col-span-3 space-y-3">
          {/* ================= NEW: REAL-TIME PASSENGER MOBILE BRIEFING FEED ================= */}
          <div className="rounded-2xl border border-indigo-900/60 bg-[#090e1a] p-4 shadow-xl space-y-2.5">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800">
              <div className="flex items-center gap-1.5">
                <Send className="h-3.5 w-3.5 text-indigo-400" />
                <h2 className="text-xs font-mono font-bold tracking-wider text-indigo-300 uppercase">
                  PASSENGER REAL-TIME BRIEFING
                </h2>
              </div>
              <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-indigo-950 text-indigo-300 border border-indigo-700">
                PHONE PUSH
              </span>
            </div>

            <div className="p-3 rounded-xl bg-gradient-to-br from-[#0a1122] to-[#0c162e] border border-indigo-800/60 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-white">{passengerBriefing?.headline || "⚡ Gate B12 Secured — Flight Door Held"}</span>
                <span className="text-[9px] font-mono text-emerald-400 font-bold">DELIVERED</span>
              </div>

              <p className="text-[11px] text-slate-300 leading-relaxed font-sans">
                {passengerBriefing?.body || `Hi ${state.passenger.name}, don't rush across Boston airport! Your London flight was moved to Gate B12, right next to your arrival Gate B10 (25m stroll). Captain David Thorne is holding the flight door for you.`}
              </p>

              <div className="p-2 rounded-lg bg-[#050811] border border-slate-800 text-[10px] font-mono text-sky-300 flex items-center gap-1.5">
                <Radio className="h-3 w-3 text-sky-400 shrink-0" />
                <span>{passengerBriefing?.pilotMessage || "Flight Deck: Capt. David Thorne confirmed gate hold at B12."}</span>
              </div>
            </div>
          </div>

          {/* Door-Hold Decision Card */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-2.5">
            <div className="flex items-center justify-between pb-1.5 border-b border-slate-800/80">
              <h2 className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase">
                DOOR-HOLD DECISION
              </h2>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                isHoldApproved
                  ? "bg-emerald-950 border border-emerald-600 text-emerald-300"
                  : "bg-amber-950 border border-amber-600 text-amber-300"
              }`}>
                {isHoldApproved ? "APPROVED" : "CLOSE & REBOOK"}
              </span>
            </div>

            <div>
              <h3 className="text-lg font-black text-white">
                {isNoHoldNeeded
                  ? `Direct Connection (${inferredOutcome?.inferredConnectionDeltaT || 30}m Buffer)`
                  : (isHoldApproved ? `Hold Door ${holdMinutes} min` : "Close Door & Rebook")}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                {isNoHoldNeeded ? (
                  <span className="text-emerald-400 font-bold">Feeder lands at {estimatedLandingTime} · Gate closes 5:05 PM · Flight waiting at Gate B12</span>
                ) : isHoldApproved ? (
                  <>Cost of holding the aircraft: <strong className="text-slate-200">₹{holdCost.toLocaleString("en-IN")}</strong></>
                ) : (
                  <span className="text-amber-400">Waiting threshold (10 min) exceeded — Depart on schedule</span>
                )}
              </p>
            </div>

            <button className={`w-full py-2.5 px-4 rounded-xl text-white font-mono text-xs font-bold shadow-lg flex items-center justify-center gap-1.5 transition cursor-pointer ${
              isHoldApproved
                ? "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-950/50"
                : "bg-sky-600 hover:bg-sky-500 shadow-sky-950/50"
            }`}>
              <CheckCircle2 className="h-4 w-4" />
              <span>
                {isNoHoldNeeded
                  ? "FLIGHT WAITING & DOORS READY"
                  : (isHoldApproved ? "APPROVED & SENT TO PILOT" : "AUTONOMOUS REBOOKING EXECUTED")}
              </span>
            </button>
          </div>

          {/* Cost Comparison Card */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-2.5">
            <h2 className="text-xs font-mono font-bold tracking-wider text-slate-300 uppercase">
              COST COMPARISON
            </h2>

            <div className="space-y-1.5">
              <div className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-mono ${
                isHoldApproved
                  ? "border-emerald-500/60 bg-[#061510] text-emerald-300"
                  : "border-slate-800 bg-[#050811] text-slate-400"
              }`}>
                <span className={isHoldApproved ? "font-bold text-emerald-300" : ""}>
                  {isNoHoldNeeded
                    ? "Direct Connection (On Schedule)"
                    : (isHoldApproved ? `Hold Door ${holdMinutes} min` : "Hold Aircraft (>10 min)")}
                </span>
                <span className={isHoldApproved ? "font-black text-emerald-400" : "text-slate-500 line-through"}>
                  {isNoHoldNeeded ? "₹0" : `₹${holdCost.toLocaleString("en-IN")}`}
                </span>
              </div>

              <div className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-mono ${
                !isHoldApproved
                  ? "border-emerald-500/60 bg-[#061510] text-emerald-300"
                  : "border-slate-800 bg-[#050811] text-slate-400"
              }`}>
                <div>
                  <span className={`block font-medium ${!isHoldApproved ? "text-emerald-300 font-bold" : "text-slate-300"}`}>
                    Close & Rebook
                  </span>
                  <span className="text-[10px] text-slate-500">(Hotel, Meals & Rebooking)</span>
                </div>
                <span className={`font-bold ${!isHoldApproved ? "text-emerald-400 font-black" : "text-slate-300"}`}>
                  ₹{abandonCost.toLocaleString("en-IN")}
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-[#050811] border border-slate-800 space-y-0.5">
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase block">
                DECISION RATIONALE
              </span>
              <p className="text-[11px] text-emerald-400 font-sans leading-relaxed">
                {inferredOutcome?.doorHoldDecisionReason || inferredOutcome?.summaryNarrative || (isNoHoldNeeded ? (
                  <><strong>Flight On Schedule:</strong> Feeder lands at {estimatedLandingTime} with ample connection buffer. Passenger transfers directly across adjacent Gates B10 ➔ B12 with doors waiting.</>
                ) : isHoldApproved ? (
                  <><strong>Hold {holdMinutes} min approved:</strong> Net savings of ₹{netSavings.toLocaleString("en-IN")} vs passenger abandonment liability. Zero downstream conflicts on LHR leg.</>
                ) : (
                  <><strong>Hold rejected:</strong> Inbound delay exceeds 10-minute maximum waiting threshold. Door closed to protect onward passengers.</>
                ))}
              </p>
            </div>
          </div>

          {/* Connecting Flight Protection Alerts */}
          <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-3.5 shadow-xl space-y-2">
            <h2 className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-400">
              CONNECTING FLIGHT PROTECTION ALERTS
            </h2>

            <div className="space-y-1.5 text-xs font-mono">
              <div className="p-2 bg-[#050811] rounded-xl border border-slate-800/80 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-sky-400">AA208 LHR ➔ CDG</span>
                  <span className="px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-600 text-emerald-300 text-[9px] font-bold">
                    AUTO-PROTECTED
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-sans">
                  12 passengers at risk. Model dynamically reserved seats on partner flight BA212.
                </p>
              </div>

              <div className="p-2 bg-[#050811] rounded-xl border border-slate-800/80 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-sky-400">AA455 BOS ➔ ORD</span>
                  <span className="px-1.5 py-0.2 rounded bg-emerald-950 border border-emerald-600 text-emerald-300 text-[9px] font-bold">
                    GATE CONFIRMED
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-sans">
                  8 passengers. Model automatically swapped departure gate to adjacent corridor.
                </p>
              </div>

              <div className="p-2 bg-[#050811] rounded-xl border border-slate-800/80 space-y-1">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-sky-400">AA612 JFK ➔ MIA</span>
                  <span className="px-1.5 py-0.2 rounded bg-slate-900 border border-slate-700 text-slate-400 text-[9px] font-bold">
                    MONITORED
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-sans">
                  4 passengers under automated observation. Disruption Risk: 0.18 (Low).
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4. BOTTOM SECTION: MULTI-LEG ROTATION TIMELINE */}
      <div className="rounded-2xl border border-slate-800 bg-[#090e1a] p-4 shadow-xl space-y-2">
        <h2 className="text-xs font-mono font-bold tracking-wider text-slate-400 uppercase">
          AIRCRAFT ROTATION — N789AA
        </h2>

        <div className="flex items-center justify-between px-4 py-2 bg-[#050811] rounded-xl border border-slate-800 overflow-x-auto text-xs font-mono">
          <div className="flex flex-col items-center">
            <span className="font-bold text-white">JFK</span>
            <span className="text-[10px] text-slate-500">14:05</span>
            <span className="text-[9px] text-slate-500">Departed</span>
          </div>

          <div className="flex-1 h-0.5 mx-3 bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />

          <div className="flex flex-col items-center">
            <span className="font-bold text-emerald-400">BOS</span>
            <span className="text-[10px] text-amber-400 font-bold">17:35 (+33m)</span>
            <span className="text-[9px] text-emerald-400">Hub Active</span>
          </div>

          <div className="flex-1 h-0.5 mx-3 bg-sky-500" />

          <div className="flex flex-col items-center">
            <span className="font-bold text-sky-300">LHR</span>
            <span className="text-[10px] text-slate-400">06:10</span>
            <span className="text-[9px] text-sky-400">Protected</span>
          </div>

          <div className="flex-1 h-0.5 mx-3 bg-slate-700" />

          <div className="flex flex-col items-center">
            <span className="font-bold text-slate-300">FRA</span>
            <span className="text-[10px] text-slate-500">10:45</span>
            <span className="text-[9px] text-slate-500">Scheduled</span>
          </div>

          <div className="flex-1 h-0.5 mx-3 bg-slate-700" />

          <div className="flex flex-col items-center">
            <span className="font-bold text-slate-300">DFW</span>
            <span className="text-[10px] text-slate-500">16:30</span>
            <span className="text-[9px] text-slate-500">Scheduled</span>
          </div>

          <div className="flex-1 h-0.5 mx-3 bg-slate-700" />

          <div className="flex flex-col items-center">
            <span className="font-bold text-slate-300">MIA</span>
            <span className="text-[10px] text-slate-500">20:15</span>
            <span className="text-[9px] text-slate-500">Scheduled</span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-600/40 text-[11px] text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Disruption Contained:</strong> Inbound feeder delay contained at Boston Logan. Downstream transatlantic rotation N789AA immunized against cascade contagion via synthetic tail decoupling.
          </span>
        </div>
      </div>
    </div>
  );
};
