import React, { useState } from "react";
import { ShieldAlert, Ambulance, Plane, ShieldCheck } from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import { sounds } from "../../utils/audio";

interface CriticalMedicalViewProps {
  state: SimulationState;
  onTriggerEmergency: () => void;
}

export const CriticalMedicalView: React.FC<CriticalMedicalViewProps> = ({
  state,
  onTriggerEmergency,
}) => {
  const { medical, passenger } = state;
  const [liveLocationTracked, setLiveLocationTracked] = useState<boolean>(false);
  const [escalated, setEscalated] = useState<boolean>(false);

  const handleTrackLocation = () => {
    setLiveLocationTracked(true);
    sounds.playRadarPing();
    setTimeout(() => setLiveLocationTracked(false), 4000);
  };

  const handleEscalate = () => {
    setEscalated(true);
    sounds.playEmergencySiren();
  };

  return (
    <div className="flex flex-col gap-4 h-full overflow-y-auto p-4 bg-[#070b12] text-slate-200 font-sans">
      <div className="flex items-center justify-between rounded-md bg-white text-slate-950 px-4 py-2.5 shadow-md font-mono text-xs font-bold">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-4 w-4 text-slate-950" />
          <span className="tracking-wide">
            CRITICAL MEDICAL EMERGENCY RESPONSE — PASSENGER FLAGGED FOR URGENT CARE ({passenger.name} / {passenger.passengerId})
          </span>
        </div>

        {!medical.isActive && (
          <button
            onClick={onTriggerEmergency}
            className="px-3 py-1 rounded bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs uppercase shadow transition"
          >
            Activate Emergency Protocol
          </button>
        )}
      </div>

      <div className="flex flex-col gap-3.5 flex-1">
        <div className="rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Ambulance className="h-4 w-4 text-slate-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Airport Paramedic Emergency Dispatch
              </h2>
            </div>
            <span className="px-2.5 py-0.5 rounded bg-slate-800 text-white font-mono text-[9px] font-bold border border-slate-700">
              {medical.paramedics.status === "ON_GATE_WAITING" ? "STATIONED AT GATE B10" : "EN ROUTE — 4 MIN ETA"}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center mt-3">
            <div className="md:col-span-3 rounded-lg border border-slate-800 bg-[#090d16] p-3 text-center font-mono text-xs text-slate-300">
              <span>Terminal Route: Gate B10 ············· Paramedic Squad 7</span>
            </div>

            <div className="md:col-span-6 space-y-1 text-xs">
              <div className="text-white font-bold">
                Location: <span className="font-semibold">Gate B10 — Terminal 5 Jet Bridge</span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Assigned Team: Paramedic Squad 7 | Equipment: Defibrillator, oxygen, trauma kit ready
              </p>
            </div>

            <div className="md:col-span-3 text-right">
              <button
                onClick={handleTrackLocation}
                className="px-4 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-white text-xs font-mono font-bold border border-slate-700 transition"
              >
                {liveLocationTracked ? "GPS Link: Terminal 5 Jet Bridge" : "Track Live Location"}
              </button>
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-slate-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Instant Competitor Flight Rebooking Override
              </h2>
            </div>
            <span className="px-2.5 py-0.5 rounded bg-slate-800 text-white font-mono text-[9px] font-bold border border-slate-700">
              TRANSFER CONFIRMED
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 mt-3 text-xs">
            <div className="space-y-1">
              <div className="text-white font-bold">
                Instant transfer to earliest flight AA100 — 5:30 PM departure
              </div>
              <p className="text-[11px] text-slate-400 font-mono">
                Standard ticketing billing bypassed for immediate emergency flight transfer
              </p>
            </div>

            <div className="text-right font-mono">
              <span className="text-sm font-black text-white block">Emergency authorization: ₹2,00,000</span>
              <span className="text-[10px] text-slate-500 block mt-0.5">
                Pre-approved under critical passenger medical policy
              </span>
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Plane className="h-4 w-4 text-slate-400" />
              <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Air Ambulance & ICU Medevac Standby
              </h2>
            </div>
            <span className="px-2.5 py-0.5 rounded bg-slate-800 text-white font-mono text-[9px] font-bold border border-slate-700">
              STANDBY — READY
            </span>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 mt-3 text-xs font-mono">
            <div className="space-y-1">
              <div className="text-white font-bold">
                Medical Aircraft: <span className="text-sky-300">Learjet 45XR (Airborne Intensive Care Unit)</span>
              </div>
              <div className="text-slate-400 text-[11px]">
                Medical Team: Critical Care Flight Nurse + Paramedic &nbsp;|&nbsp; Runway Clearance: <span className="text-emerald-400 font-bold">PRE-APPROVED</span>
              </div>
            </div>

            <div className="text-right">
              <span className="text-sm font-black text-white block">Takeoff ready: 22 minutes</span>
              <span className="text-[10px] text-slate-500 block">Air traffic priority clearance: MEDEVAC-ICU-88</span>
            </div>
          </div>
        </div>

        <div className="rounded-lg border border-slate-800 bg-[#0d131f] p-4 flex flex-col justify-between shadow-inner">
          <div className="pb-2 border-b border-slate-800">
            <h2 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Medical Clearance Form & Insurance Verification
            </h2>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 mt-3 text-xs">
            <div className="flex flex-wrap items-center gap-3">
              <span className="px-2.5 py-1 rounded bg-slate-800 text-white font-mono text-xs font-bold border border-slate-700">
                Medical Clearance Form — VERIFIED ✓
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-800 text-white font-mono text-xs font-bold border border-slate-700">
                Emergency Insurance — ACTIVE ✓
              </span>
              <span className="text-slate-400 text-[11px] font-mono pl-2">
                Coverage: Global Medevac & Hospitalization | Provider: International SOS
              </span>
            </div>

            <div className="flex items-center gap-2 font-mono text-xs">
              <button
                onClick={() => sounds.playRadarPing()}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
              >
                Download Medical Form
              </button>
              <button
                onClick={() => sounds.playRadarPing()}
                className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
              >
                Contact Insurer
              </button>
              <button
                onClick={handleEscalate}
                className="px-3 py-1.5 rounded bg-white hover:bg-slate-200 text-slate-950 font-bold transition shadow-sm"
              >
                {escalated ? "✓ Escalated to Operations Director" : "Escalate to Airport Operations Director"}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
