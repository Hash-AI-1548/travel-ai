import React from "react";
import {
  Play,
  Pause,
  RotateCcw,
  Clock,
  ShieldAlert,
  Flame,
  CloudRain,
  Volume2,
  VolumeX,
} from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";
import type { PolicyMode } from "../../types/simulation";
import { sounds } from "../../utils/audio";

interface SimControlBarProps {
  state: SimulationState;
  onPlay: () => void;
  onPause: () => void;
  onReset: () => void;
  onSpeedChange: (speed: number) => void;
  onPolicyChange?: (policy: PolicyMode) => void;
  onMedicalTrigger: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const SimControlBar: React.FC<SimControlBarProps> = ({
  state,
  onPlay,
  onPause,
  onReset,
  onSpeedChange,
  onMedicalTrigger,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-2 bg-[#090d16] border-b border-slate-800 text-xs font-mono text-slate-300 select-none">
      {/* Playback Controls & Simulation Clock */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 bg-[#0f172a] px-3 py-1 rounded border border-slate-800">
          <Clock className="h-3.5 w-3.5 text-sky-400" />
          <span className="text-slate-400">Elapsed Time:</span>
          <span className="font-bold text-white tracking-wider">
            T+{state.simMinute}m ({state.simClockSeconds}s)
          </span>
        </div>

        <div className="flex items-center gap-1">
          {state.isRunning ? (
            <button
              onClick={() => {
                onPause();
                sounds.playRadarPing();
              }}
              className="flex items-center gap-1 px-3 py-1 rounded bg-amber-600 hover:bg-amber-500 text-white font-semibold shadow transition"
            >
              <Pause className="h-3.5 w-3.5 fill-current" />
              <span>Pause</span>
            </button>
          ) : (
            <button
              onClick={() => {
                onPlay();
                sounds.playCockpitChime();
              }}
              className="flex items-center gap-1 px-3 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold shadow transition"
            >
              <Play className="h-3.5 w-3.5 fill-current" />
              <span>Start Sim</span>
            </button>
          )}

          <button
            onClick={() => {
              onReset();
              sounds.playRadarPing();
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition border border-slate-700"
            title="Reset to T0"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset</span>
          </button>
        </div>

        {/* Speed Controls */}
        <div className="flex items-center gap-1 pl-2 border-l border-slate-800 text-[11px]">
          <span className="text-slate-500">Playback Speed:</span>
          {[1, 5, 10, 60].map((spd) => (
            <button
              key={spd}
              onClick={() => {
                onSpeedChange(spd);
                sounds.playRadarPing();
              }}
              className={`px-2 py-0.5 rounded border transition ${
                state.timeMultiplier === spd
                  ? "border-sky-500 bg-sky-950 text-sky-300 font-bold"
                  : "border-slate-800 bg-slate-900 text-slate-400 hover:text-slate-200"
              }`}
            >
              {spd === 60 ? "60× (1 sec = 1 min)" : `${spd}×`}
            </button>
          ))}
        </div>
      </div>

      {/* Global Triggers & Status */}
      <div className="flex items-center gap-3">
        {/* Live Inferred Disruption Cause Indicator */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded border border-slate-800 bg-[#0f172a] text-[11px] font-mono">
          {state.policy === "WEATHER" ? (
            <>
              <CloudRain className="h-3.5 w-3.5 text-amber-400 shrink-0" />
              <span className="text-slate-300">Cause: <strong className="text-amber-300">Severe Weather (Force Majeure)</strong></span>
            </>
          ) : (
            <>
              <Flame className="h-3.5 w-3.5 text-sky-400 shrink-0" />
              <span className="text-slate-300">Cause: <strong className="text-sky-300">Mechanical Fault (IATA Rule 240)</strong></span>
            </>
          )}
        </div>

        {/* Medical Override Trigger */}
        <button
          onClick={() => {
            onMedicalTrigger();
            sounds.playEmergencySiren();
          }}
          className={`flex items-center gap-1.5 px-3 py-1 rounded text-xs font-bold uppercase transition shadow-md ${
            state.medical.isActive
              ? "bg-rose-600 text-white animate-pulse"
              : "bg-rose-950 hover:bg-rose-900 text-rose-300 border border-rose-700/80"
          }`}
        >
          <ShieldAlert className="h-3.5 w-3.5" />
          <span>{state.medical.isActive ? "Medical Emergency Active" : "Simulate Medical Emergency"}</span>
        </button>

        {/* Audio Toggle */}
        <button
          onClick={onToggleSound}
          className="p-1 rounded border border-slate-800 bg-[#0f172a] text-slate-400 hover:text-white"
          title={soundEnabled ? "Mute sound FX" : "Enable sound FX"}
        >
          {soundEnabled ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5" />}
        </button>
      </div>
    </div>
  );
};
