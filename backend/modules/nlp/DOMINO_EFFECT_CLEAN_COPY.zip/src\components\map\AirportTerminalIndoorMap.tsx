import React, { useState, useMemo, useRef } from "react";
import {
  Footprints,
  Clock,
  Compass,
  Search,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Move,
} from "lucide-react";
import type { SimulationState } from "../../engine/simulationEngine";

export interface TerminalNode {
  id: string;
  label: string;
  category: "GATE" | "SECURITY" | "FACILITY" | "CONNECTOR" | "TARMAC" | "LOUNGE";
  level: number; // 0: Tarmac & Baggage, 1: Main Concourse Departures, 2: VIP & Mezzanine
  x: number;
  y: number;
  gateNumber?: string;
  assignedFlight?: string;
  statusText?: string;
  isAccessible?: boolean;
  isArrival?: boolean;
  isDeparture?: boolean;
  description?: string;
}

export const AIRPORT_TERMINAL_NODES: Record<string, TerminalNode> = {
  curbside_dropoff: {
    id: "curbside_dropoff",
    label: "Curbside Drop-off & Check-in",
    category: "FACILITY",
    level: 1,
    x: 70,
    y: 220,
    isAccessible: true,
    description: "Passenger dropoff, baggage check-in kiosks, and priority airline ticketing."
  },
  main_atrium_fids: {
    id: "main_atrium_fids",
    label: "Central Atrium & Master Flight Board",
    category: "FACILITY",
    level: 1,
    x: 250,
    y: 220,
    isAccessible: true,
    description: "Central gathering rotunda with live multi-lingual flight information displays."
  },
  medical_emergency_clinic: {
    id: "medical_emergency_clinic",
    label: "Airport Paramedic Station & Clinic",
    category: "FACILITY",
    level: 1,
    x: 250,
    y: 130,
    isAccessible: true,
    description: "On-site 24/7 emergency medical triage and ICU paramedic response dispatch."
  },
  duty_free_concourse: {
    id: "duty_free_concourse",
    label: "Duty Free Plaza & Retail Boulevard",
    category: "FACILITY",
    level: 1,
    x: 340,
    y: 220,
    isAccessible: true,
    description: "Airside shopping, currency exchange, duty-free retail, and charging stations."
  },
  airline_admirals_lounge: {
    id: "airline_admirals_lounge",
    label: "American Airlines Executive Lounge",
    category: "LOUNGE",
    level: 2,
    x: 340,
    y: 130,
    isAccessible: true,
    description: "First & Business class lounge, private work suites, dining, and showers."
  },
  food_court_hub: {
    id: "food_court_hub",
    label: "Boston Harbor Food Court & Restrooms",
    category: "FACILITY",
    level: 1,
    x: 340,
    y: 310,
    isAccessible: true,
    description: "Accessible restrooms, family care rooms, cafes, and grab-and-go meal outlets."
  },

  // Vertical Hubs & Connectors
  lift_north_hub: {
    id: "lift_north_hub",
    label: "Elevator North (Level 0-1-2)",
    category: "CONNECTOR",
    level: 1,
    x: 430,
    y: 140,
    isAccessible: true,
    description: "High-capacity glass elevator connecting Apron Tarmac, Departures, and Lounges."
  },
  esc_north_hub: {
    id: "esc_north_hub",
    label: "Escalator North",
    category: "CONNECTOR",
    level: 1,
    x: 430,
    y: 170,
    isAccessible: false,
    description: "Up/Down moving escalator corridor to North Concourse."
  },
  lift_south_hub: {
    id: "lift_south_hub",
    label: "Elevator South (Level 0-1)",
    category: "CONNECTOR",
    level: 1,
    x: 430,
    y: 270,
    isAccessible: true,
    description: "Elevator connector to baggage claim, south gates, and ground transport."
  },

  // NORTH CONCOURSE GATES (B10, B12, B14, B16)
  gate_b10: {
    id: "gate_b10",
    label: "Gate B10 — Inbound Feeder Landing Bay",
    category: "GATE",
    gateNumber: "B10",
    level: 1,
    x: 530,
    y: 110,
    assignedFlight: "AA142 (JFK ➔ BOS)",
    statusText: "INBOUND FEATHER ARRIVAL",
    isAccessible: true,
    isArrival: true,
    description: "Widebody jetbridge gate with direct adjacent transfer corridor to Gate B12."
  },
  gate_b12: {
    id: "gate_b12",
    label: "Gate B12 — Outbound London Departure",
    category: "GATE",
    gateNumber: "B12",
    level: 1,
    x: 600,
    y: 110,
    assignedFlight: "AA142-LHR (BOS ➔ LHR)",
    statusText: "BOARDING GATE (ADJACENT)",
    isAccessible: true,
    isDeparture: true,
    description: "Adjacent widebody gate positioned only 25 meters from Gate B10 for 1-minute transfer."
  },
  gate_b14: {
    id: "gate_b14",
    label: "Gate B14 — Domestic Departure",
    category: "GATE",
    gateNumber: "B14",
    level: 1,
    x: 670,
    y: 110,
    assignedFlight: "AA840 (BOS ➔ ORD)",
    statusText: "ON SCHEDULE",
    isAccessible: true,
    description: "Standard narrowbody jetbridge gate serving domestic routes."
  },
  gate_b16: {
    id: "gate_b16",
    label: "Gate B16 — International Departure",
    category: "GATE",
    gateNumber: "B16",
    level: 1,
    x: 740,
    y: 110,
    assignedFlight: "BA212 (BOS ➔ LHR)",
    statusText: "INTERLINE BACKUP READY",
    isAccessible: true,
    description: "Partner British Airways widebody gate used for interline automated rebooking."
  },

  // SOUTH CONCOURSE GATES (B24, B30, B38)
  gate_b24: {
    id: "gate_b24",
    label: "Gate B24 — Regional Jet Stand",
    category: "GATE",
    gateNumber: "B24",
    level: 1,
    x: 530,
    y: 310,
    assignedFlight: "AA4410 (BOS ➔ DCA)",
    statusText: "DEPARTED",
    isAccessible: true,
    description: "Regional jet boarding gate."
  },
  gate_b30: {
    id: "gate_b30",
    label: "Gate B30 — Standard Arrival Bay",
    category: "GATE",
    gateNumber: "B30",
    level: 1,
    x: 630,
    y: 310,
    assignedFlight: "AA142 (Original Assignment)",
    statusText: "ORIGINAL FAR GATE",
    isAccessible: true,
    description: "Far south concourse gate requiring 18 minutes (1,200m) sprint to reach north concourse."
  },
  gate_b38: {
    id: "gate_b38",
    label: "Gate B38 — Transatlantic Bay",
    category: "GATE",
    gateNumber: "B38",
    level: 1,
    x: 740,
    y: 310,
    assignedFlight: "AA142-LHR (Original Schedule)",
    statusText: "FAR SOUTH GATE",
    isAccessible: true,
    description: "Far south international departure gate with long cross-terminal connection time."
  },

  // LEVEL 0: Tarmac Apron & Ground Operations
  apron_shuttle_station: {
    id: "apron_shuttle_station",
    label: "Apron Tarmac Shuttle Departure Gate",
    category: "TARMAC",
    level: 0,
    x: 430,
    y: 400,
    isAccessible: true,
    description: "Ground-level express bus lounge with low-floor VIP apron transfer shuttles."
  },
  stand_a14_apron: {
    id: "stand_a14_apron",
    label: "Remote Apron Stand A14 (De-icing & Hardstand)",
    category: "TARMAC",
    gateNumber: "A14",
    level: 0,
    x: 550,
    y: 430,
    assignedFlight: "AA142 (Severe Weather / Apron Diversion)",
    statusText: "REMOTE TARMAC STAND",
    isAccessible: true,
    description: "Outer apron remote parking stand with air-stairs and direct tarmac bus transfer."
  },
  baggage_sorting_bhs: {
    id: "baggage_sorting_bhs",
    label: "BHS Matrix & High-Speed Luggage Belt",
    category: "TARMAC",
    level: 0,
    x: 300,
    y: 400,
    isAccessible: true,
    description: "Automated RFID barcode luggage sorting matrix with conveyor belt to ramp tugs."
  },
  baggage_vault_storage: {
    id: "baggage_vault_storage",
    label: "Secure Overnight Luggage Vault (Vault-4)",
    category: "TARMAC",
    level: 0,
    x: 180,
    y: 400,
    isAccessible: true,
    description: "Climate-controlled, SHA-256 locked vault for delayed and rebooked passengers."
  }
};

export const TERMINAL_CONNECTIONS: [string, string][] = [
  ["curbside_dropoff", "sec_checkpoint_north"],
  ["curbside_dropoff", "sec_checkpoint_south"],
  ["sec_checkpoint_north", "main_atrium_fids"],
  ["sec_checkpoint_south", "main_atrium_fids"],
  ["main_atrium_fids", "medical_emergency_clinic"],
  ["main_atrium_fids", "duty_free_concourse"],
  ["duty_free_concourse", "airline_admirals_lounge"],
  ["duty_free_concourse", "food_court_hub"],
  ["duty_free_concourse", "lift_north_hub"],
  ["duty_free_concourse", "esc_north_hub"],
  ["food_court_hub", "lift_south_hub"],

  // North Concourse Walkway
  ["esc_north_hub", "gate_b10"],
  ["lift_north_hub", "gate_b10"],
  ["gate_b10", "gate_b12"], // Direct 25-meter corridor!
  ["gate_b12", "gate_b14"],
  ["gate_b14", "gate_b16"],

  // South Concourse Walkway
  ["lift_south_hub", "gate_b24"],
  ["gate_b24", "gate_b30"],
  ["gate_b30", "gate_b38"],

  // Cross-Concourse Long Corridor (18 min sprint route)
  ["esc_north_hub", "lift_south_hub"],

  // Ground Tarmac Connectors
  ["lift_north_hub", "apron_shuttle_station"],
  ["lift_south_hub", "apron_shuttle_station"],
  ["apron_shuttle_station", "stand_a14_apron"],
  ["apron_shuttle_station", "baggage_sorting_bhs"],
  ["baggage_sorting_bhs", "baggage_vault_storage"]
];

interface AirportTerminalIndoorMapProps {
  state: SimulationState;
  onClose?: () => void;
}

const AirportTerminalIndoorMapComponent: React.FC<AirportTerminalIndoorMapProps> = ({
  state,
  onClose
}) => {
  const { flight, inferredOutcome, passenger } = state;
  const isWheelchair = Boolean(passenger.isWheelchairUser || passenger.specialAssistance === "WHEELCHAIR_REQUIRED");

  const [activeFloor, setActiveFloor] = useState<"ALL" | 1 | 0 | 2>("ALL");
  const [selectedNodeId, setSelectedNodeId] = useState<string>("gate_b10");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Interactive Pan & Zoom Navigation State
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [panPosition, setPanPosition] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const mapContainerRef = useRef<HTMLDivElement>(null);

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(3.5, prev + 0.25));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(0.6, prev - 0.25));
  const handleResetZoom = () => {
    setZoomLevel(1);
    setPanPosition({ x: 0, y: 0 });
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY < 0 ? 0.15 : -0.15;
    setZoomLevel((prev) => Math.min(3.5, Math.max(0.6, prev + delta)));
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX - panPosition.x, y: e.clientY - panPosition.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPanPosition({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    });
  };

  const handleMouseUp = () => setIsDragging(false);

  const outcome = inferredOutcome;
  const isAdjacentSwap = outcome?.recommendedGateAction === "ADJACENT_GATE_SWAP" || (flight.delayMinutes > 10 && flight.delayMinutes <= 40);
  const isRemoteStand = outcome?.recommendedGateAction === "EXPRESS_TARMAC_SHUTTLE" || flight.delayMinutes > 40;
  const isStandardGates = outcome?.recommendedGateAction === "STANDARD_ASSIGNMENT" || flight.delayMinutes <= 10;

  // Active highlighted path based on live simulation scenario and wheelchair assistance profile
  const activeRoutePath = useMemo(() => {
    if (isAdjacentSwap) {
      // 25 meter direct corridor (100% Level 1 step-free)
      return {
        mode: "ADJACENT",
        title: isWheelchair
          ? "♿ Wheelchair Accessible Adjacent Gate Transfer (1 min / 25m - Step Free)"
          : "Optimized Adjacent Stroll (1 min / 25 meters)",
        color: "#10b981", // Emerald
        glow: "rgba(16, 185, 129, 0.4)",
        nodes: ["gate_b10", "gate_b12"],
        distance: 25,
        walkingTimeMins: 1,
        speedRating: isWheelchair ? "Level Concourse Wheelchair Stroll (0.8 m/s)" : "Relaxed 1.2 m/s Stroll",
        steps: [
          "Deplane Flight AA142 at Gate B10 Jetbridge.",
          "Turn right into wide, step-free secure international transit corridor.",
          "Traverse 25 meters directly to Gate B12 (London Departure) — Zero stairs/elevators required.",
          "Present boarding pass at Gate B12 accessible boarding lane."
        ]
      };
    } else if (isRemoteStand) {
      // Apron shuttle route with low-floor ADA ramp bus
      return {
        mode: "REMOTE",
        title: isWheelchair
          ? "♿ Low-Floor ADA Apron Shuttle & Elevator Hub (5 min / 450m)"
          : "Tarmac Express Shuttle (4 min / 450 meters)",
        color: "#06b6d4", // Cyan
        glow: "rgba(6, 182, 212, 0.4)",
        nodes: ["stand_a14_apron", "apron_shuttle_station", "lift_south_hub", "gate_b38"],
        distance: 450,
        walkingTimeMins: isWheelchair ? 5 : 4,
        speedRating: isWheelchair ? "Wheelchair-Accessible Low-Floor Apron Bus" : "Dedicated VIP Apron Bus (25 km/h)",
        steps: [
          "Deplane at Remote Stand A14 via accessible ambulift / boarding ramp.",
          "Board low-floor wheelchair accessible tarmac transfer shuttle.",
          "Transit across airport apron service road (3 mins).",
          "Enter Terminal B ground station and take Elevator South (Lift-2) directly to Gate B38."
        ]
      };
    } else {
      // Standard cross-concourse route: If wheelchair user, avoid escalator esc_north_hub and route strictly via Elevator Hubs
      return {
        mode: "STANDARD",
        title: isWheelchair
          ? "♿ Step-Free Elevator Route (Stairs & Escalators Blocked - 20 min)"
          : "Standard Cross-Concourse Route (18 min / 1,200 meters)",
        color: isWheelchair ? "#3b82f6" : "#f59e0b", // Blue for ADA, Amber for standard
        glow: isWheelchair ? "rgba(59, 130, 246, 0.4)" : "rgba(245, 158, 11, 0.4)",
        nodes: isWheelchair
          ? ["gate_b30", "gate_b24", "lift_south_hub", "food_court_hub", "duty_free_concourse", "lift_north_hub", "gate_b10", "gate_b12"]
          : ["gate_b30", "gate_b24", "lift_south_hub", "esc_north_hub", "gate_b10", "gate_b12"],
        distance: isWheelchair ? 1280 : 1200,
        walkingTimeMins: isWheelchair ? 20 : 18,
        speedRating: isWheelchair ? "Wheelchair Transit (0.85 m/s + Elevator Dwell)" : "Standard 1.4 m/s Walking Pace",
        steps: isWheelchair
          ? [
              "Deplane at South Concourse Gate B30 (Airport Wheelchair Assist Agent deployed).",
              "Transit along level corridor past Gate B24 to South Hub.",
              "🚫 Bypassing North Escalator (Escalator blocked for safety).",
              "Route through Central Retail & Food Concourse level corridor.",
              "Take Elevator North (Lift-1) step-free access to North Concourse.",
              "Arrive at Gate B12 for priority accessible pre-boarding."
            ]
          : [
              "Deplane at South Concourse Gate B30.",
              "Walk 400m past Gate B24 toward central connector hub.",
              "Traverse moving walkway/escalator connecting South & North Concourses.",
              "Navigate through North Concourse retail zone to reach Gate B12."
            ]
      };
    }
  }, [isAdjacentSwap, isRemoteStand, isStandardGates, isWheelchair]);

  const selectedNode = AIRPORT_TERMINAL_NODES[selectedNodeId] || AIRPORT_TERMINAL_NODES.gate_b10;

  // Filter nodes by floor and search query
  const filteredNodes = useMemo(() => {
    return Object.values(AIRPORT_TERMINAL_NODES).filter((node) => {
      const matchFloor = activeFloor === "ALL" || node.level === activeFloor;
      const matchSearch =
        searchQuery === "" ||
        node.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.gateNumber?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        node.assignedFlight?.toLowerCase().includes(searchQuery.toLowerCase());
      return matchFloor && matchSearch;
    });
  }, [activeFloor, searchQuery]);

  // Compute SVG polyline points for active route
  const activeRoutePolyline = useMemo(() => {
    return activeRoutePath.nodes
      .map((nodeId) => {
        const n = AIRPORT_TERMINAL_NODES[nodeId];
        return n ? `${n.x},${n.y}` : "";
      })
      .filter(Boolean)
      .join(" ");
  }, [activeRoutePath]);

  return (
    <div className="flex flex-col h-full w-full bg-[#05080f] text-slate-100 font-sans select-none overflow-hidden rounded-xl border border-slate-800/80 shadow-2xl">
      {/* TOP HEADER BAR */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#080d18] border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-sky-950/80 border border-sky-700 text-sky-400 shadow-[0_0_12px_rgba(56,189,248,0.25)]">
            <Compass className="h-5 w-5 animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white tracking-wide">
                Airport Terminal Digital Twin & Gate Routing Graph
              </h2>
              <span className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-700 flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                BOSTON LOGAN (BOS) · LIVE DIGITAL TWIN
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              Spatial coordinate topology mapping arrival bays, departure gates, and transfer walking corridors
            </p>
          </div>
        </div>

        {/* Floor Switcher & Controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs font-mono">
            <button
              onClick={() => setActiveFloor("ALL")}
              className={`px-3 py-1 rounded transition ${
                activeFloor === "ALL" ? "bg-sky-600 text-white font-bold shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              All Levels
            </button>
            <button
              onClick={() => setActiveFloor(1)}
              className={`px-3 py-1 rounded transition ${
                activeFloor === 1 ? "bg-sky-600 text-white font-bold shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              Level 1 (Departures & Gates)
            </button>
            <button
              onClick={() => setActiveFloor(0)}
              className={`px-3 py-1 rounded transition ${
                activeFloor === 0 ? "bg-sky-600 text-white font-bold shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              Level 0 (Tarmac & Apron)
            </button>
            <button
              onClick={() => setActiveFloor(2)}
              className={`px-3 py-1 rounded transition ${
                activeFloor === 2 ? "bg-sky-600 text-white font-bold shadow" : "text-slate-400 hover:text-white"
              }`}
            >
              Level 2 (Lounges)
            </button>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono transition"
            >
              Close Map
            </button>
          )}
        </div>
      </div>

      {/* MAIN CONTENT AREA: MAP CANVAS + SIDE INSPECTOR */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        {/* LEFT / CENTER: INTERACTIVE SVG CANVAS */}
        <div
          ref={mapContainerRef}
          onWheel={handleWheel}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          className={`flex-1 relative bg-[#070b14] overflow-hidden flex items-center justify-center p-2 select-none ${
            isDragging ? "cursor-grabbing" : "cursor-grab"
          }`}
        >
          {/* Blueprint Grid Background */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage:
                "linear-gradient(to right, #0284c7 1px, transparent 1px), linear-gradient(to bottom, #0284c7 1px, transparent 1px)",
              backgroundSize: "32px 32px",
            }}
          />

          {/* Top Route Banner Overlay */}
          <div className="absolute top-3 left-4 right-4 z-10 flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-lg bg-slate-950/90 border border-slate-800/80 backdrop-blur-md shadow-lg font-mono text-xs pointer-events-auto">
            <div className="flex items-center gap-3">
              <div
                className="h-3 w-3 rounded-full animate-pulse shadow-[0_0_10px]"
                style={{ backgroundColor: activeRoutePath.color, boxShadow: `0 0 12px ${activeRoutePath.color}` }}
              />
              <span className="font-bold text-white">{activeRoutePath.title}</span>
            </div>
            <div className="flex items-center gap-4 text-slate-300 text-[11px]">
              <span className="flex items-center gap-1">
                <Footprints className="h-3.5 w-3.5 text-emerald-400" />
                <span>Distance:</span>
                <strong className="text-white">{activeRoutePath.distance} meters</strong>
              </span>
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5 text-sky-400" />
                <span>Estimated Time:</span>
                <strong className="text-white">{activeRoutePath.walkingTimeMins} mins</strong>
              </span>
              <span className="flex items-center gap-1 text-slate-400">
                <span>Speed:</span>
                <span className="text-amber-300">{activeRoutePath.speedRating}</span>
              </span>
            </div>
          </div>

          {/* SVG Map Canvas with Pan & Zoom Transform */}
          <div
            style={{
              transform: `translate(${panPosition.x}px, ${panPosition.y}px) scale(${zoomLevel})`,
              transformOrigin: "center center",
              transition: isDragging ? "none" : "transform 0.15s ease-out",
            }}
            className="w-full h-full flex items-center justify-center pointer-events-auto"
          >
            <svg
              viewBox="0 0 820 480"
              className="w-full h-full max-h-[560px] object-contain select-none transition-all duration-300"
            >
            <defs>
              {/* Glowing Filters */}
              <filter id="glow-emerald" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
              <filter id="glow-cyan" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>
              <filter id="glow-amber" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feComposite in="SourceGraphic" in2="blur" operator="over" />
              </filter>

              {/* Animated line dash */}
              <linearGradient id="route-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#38bdf8" />
                <stop offset="100%" stopColor="#10b981" />
              </linearGradient>
            </defs>

            {/* Zone Boundaries / Terminal Footprint Outlines */}
            {/* Terminal B Outline */}
            <rect
              x="40"
              y="60"
              width="740"
              height="280"
              rx="16"
              fill="#0b1324"
              fillOpacity="0.6"
              stroke="#1e293b"
              strokeWidth="2"
            />
            {/* Apron Tarmac Zone */}
            <rect
              x="120"
              y="360"
              width="660"
              height="100"
              rx="12"
              fill="#060c18"
              fillOpacity="0.8"
              stroke="#334155"
              strokeWidth="1.5"
              strokeDasharray="6 4"
            />

            {/* Zone Labels */}
            <text x="55" y="85" fill="#475569" fontSize="10" fontFamily="monospace" fontWeight="bold">
              TERMINAL B · NORTH CONCOURSE (GATES B10–B16)
            </text>
            <text x="55" y="275" fill="#475569" fontSize="10" fontFamily="monospace" fontWeight="bold">
              TERMINAL B · SOUTH CONCOURSE (GATES B24–B38)
            </text>
            <text x="135" y="380" fill="#38bdf8" fontSize="10" fontFamily="monospace" fontWeight="bold">
              ✈️ BOSTON LOGAN APRON TARMAC & BAGGAGE RAMP (LEVEL 0)
            </text>

            {/* Background Corridors / Edges */}
            {TERMINAL_CONNECTIONS.map(([srcId, dstId], idx) => {
              const src = AIRPORT_TERMINAL_NODES[srcId];
              const dst = AIRPORT_TERMINAL_NODES[dstId];
              if (!src || !dst) return null;

              const isConnectedOnActiveFloor =
                activeFloor === "ALL" || (src.level === activeFloor && dst.level === activeFloor);

              return (
                <line
                  key={`edge-${idx}`}
                  x1={src.x}
                  y1={src.y}
                  x2={dst.x}
                  y2={dst.y}
                  stroke={isConnectedOnActiveFloor ? "#1e293b" : "#0f172a"}
                  strokeWidth={srcId === "gate_b10" && dstId === "gate_b12" ? 4 : 2}
                  strokeDasharray={src.level !== dst.level ? "4 3" : undefined}
                />
              );
            })}

            {/* Active Route Glowing Animated Polyline */}
            {activeRoutePolyline && (
              <polyline
                points={activeRoutePolyline}
                fill="none"
                stroke={activeRoutePath.color}
                strokeWidth="4"
                strokeDasharray="8 6"
                className="animate-pulse"
                style={{
                  filter: `drop-shadow(0 0 8px ${activeRoutePath.color})`,
                }}
              />
            )}

            {/* Render Nodes */}
            {filteredNodes.map((node) => {
              const isSelected = selectedNodeId === node.id;
              const isPartOfActiveRoute = activeRoutePath.nodes.includes(node.id);

              let nodeColor = "#38bdf8"; // default Sky
              let nodeRadius = 7;

              if (node.category === "GATE") {
                if (node.id === "gate_b10") {
                  nodeColor = "#10b981"; // Emerald
                  nodeRadius = 11;
                } else if (node.id === "gate_b12") {
                  nodeColor = "#10b981"; // Emerald
                  nodeRadius = 11;
                } else if (node.id === "gate_b30") {
                  nodeColor = "#f43f5e"; // Rose
                  nodeRadius = 9;
                } else if (node.id === "gate_b38") {
                  nodeColor = "#f59e0b"; // Amber
                  nodeRadius = 9;
                } else {
                  nodeColor = "#64748b";
                }
              } else if (node.category === "SECURITY") {
                nodeColor = "#eab308";
              } else if (node.category === "TARMAC") {
                nodeColor = "#06b6d4";
              } else if (node.category === "LOUNGE") {
                nodeColor = "#a855f7";
              }

              return (
                <g
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className="cursor-pointer transition-all duration-200"
                >
                  {/* Outer Pulsing Aura for active arrival and departure */}
                  {(node.id === "gate_b10" || node.id === "gate_b12" || node.id === "stand_a14_apron") && (
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={nodeRadius + 8}
                      fill="none"
                      stroke={nodeColor}
                      strokeWidth="1.5"
                      opacity="0.4"
                      className="animate-ping"
                    />
                  )}

                  {/* Selected Aura Ring */}
                  {isSelected && (
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r={nodeRadius + 6}
                      fill="none"
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                  )}

                  {/* Main Node Circle */}
                  <circle
                    cx={node.x}
                    cy={node.y}
                    r={nodeRadius}
                    fill={nodeColor}
                    stroke="#0f172a"
                    strokeWidth="2"
                    style={{
                      filter: isPartOfActiveRoute ? `drop-shadow(0 0 6px ${nodeColor})` : undefined,
                    }}
                  />

                  {/* Blocked Indicator for Non-Accessible Stairs/Escalators */}
                  {isWheelchair && !node.isAccessible && (
                    <g>
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r={nodeRadius + 4}
                        fill="rgba(244, 63, 94, 0.2)"
                        stroke="#f43f5e"
                        strokeWidth="2"
                        strokeDasharray="3 2"
                      />
                      <line
                        x1={node.x - 7}
                        y1={node.y - 7}
                        x2={node.x + 7}
                        y2={node.y + 7}
                        stroke="#f43f5e"
                        strokeWidth="2.5"
                      />
                      <text
                        x={node.x}
                        y={node.y + nodeRadius + 12}
                        fill="#f43f5e"
                        fontSize="7.5"
                        fontWeight="bold"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        🚫 BLOCKED (ESCALATOR)
                      </text>
                    </g>
                  )}

                  {/* Wheelchair Accessible Elevator Indicator */}
                  {isWheelchair && (node.id === "lift_north_hub" || node.id === "lift_south_hub") && (
                    <g>
                      <circle
                        cx={node.x}
                        cy={node.y}
                        r={nodeRadius + 5}
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="2"
                        strokeDasharray="4 2"
                      />
                      <text
                        x={node.x}
                        y={node.y + nodeRadius + 12}
                        fill="#38bdf8"
                        fontSize="8"
                        fontWeight="bold"
                        fontFamily="monospace"
                        textAnchor="middle"
                      >
                        ♿ ELEVATOR
                      </text>
                    </g>
                  )}

                  {/* Node Label Text */}
                  <text
                    x={node.x}
                    y={node.y - (nodeRadius + 4)}
                    fill={isSelected ? "#ffffff" : isPartOfActiveRoute ? "#38bdf8" : "#94a3b8"}
                    fontSize={node.category === "GATE" ? "9" : "8"}
                    fontWeight={isSelected || isPartOfActiveRoute ? "bold" : "normal"}
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {node.gateNumber ? `Gate ${node.gateNumber}` : node.label.split("(")[0]}
                  </text>
                </g>
              );
            })}
            </svg>
          </div>

          {/* Floating Pan & Zoom Toolbar */}
          <div className="absolute bottom-12 right-4 z-20 flex items-center gap-1.5 p-1.5 rounded-xl bg-slate-950/90 border border-slate-700/80 backdrop-blur-md shadow-2xl font-mono text-xs pointer-events-auto">
            <button
              onClick={handleZoomIn}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold transition flex items-center gap-1 cursor-pointer"
              title="Zoom In (+)"
            >
              <ZoomIn className="h-4 w-4" />
            </button>
            <button
              onClick={handleZoomOut}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold transition flex items-center gap-1 cursor-pointer"
              title="Zoom Out (-)"
            >
              <ZoomOut className="h-4 w-4" />
            </button>
            <button
              onClick={handleResetZoom}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold transition flex items-center gap-1 cursor-pointer"
              title="Reset View (100%)"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-[10px] text-sky-400 font-bold">
              {Math.round(zoomLevel * 100)}%
            </span>
            <span className="text-[10px] text-slate-400 pl-1 border-l border-slate-800 flex items-center gap-1">
              <Move className="h-3 w-3 text-slate-500" /> Drag to Pan · Scroll to Zoom
            </span>
          </div>

          {/* Bottom Canvas Legend */}
          <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between px-3 py-1.5 rounded-lg bg-slate-950/80 border border-slate-800 text-[10px] font-mono text-slate-400 pointer-events-auto">
            <div className="flex items-center gap-4">
              {isWheelchair && (
                <span className="flex items-center gap-1.5 text-sky-400 font-bold bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800">
                  <span>♿ Wheelchair Mode: Escalators Blocked</span>
                </span>
              )}
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-400" />
                <span>Arrival/Departure Gate</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-amber-400" />
                <span>Standard Far Gate</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-cyan-400" />
                <span>Tarmac Apron Stand</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2.5 w-2.5 rounded-full bg-purple-400" />
                <span>Executive Lounge</span>
              </span>
            </div>
            <span className="text-slate-500">Click any gate or node on the map to inspect live data</span>
          </div>
        </div>

        {/* RIGHT: NODE INSPECTOR & TURN-BY-TURN HUD */}
        <div className="w-full lg:w-80 bg-[#090e1a] border-l border-slate-800 flex flex-col p-4 space-y-4 overflow-y-auto font-mono text-xs">
          {/* Search Bar */}
          <div className="relative">
            <Search className="h-3.5 w-3.5 text-slate-500 absolute left-2.5 top-2.5" />
            <input
              type="text"
              placeholder="Search Gate, Lounge, TSA..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-200 placeholder-slate-500 text-xs focus:outline-none focus:border-sky-500 font-mono"
            />
          </div>

          {/* Selected Node Details Card */}
          <div className="p-3.5 rounded-lg border border-slate-800 bg-[#0d131f] space-y-2.5">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <span className="text-[10px] text-sky-400 uppercase tracking-wider font-bold">
                NODE INSPECTOR · LEVEL {selectedNode.level}
              </span>
              <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-slate-800 text-slate-300">
                {selectedNode.category}
              </span>
            </div>

            <div>
              <h3 className="text-xs font-bold text-white tracking-wide">{selectedNode.label}</h3>
              <p className="text-[11px] text-slate-400 mt-1 font-sans leading-relaxed">
                {selectedNode.description || "Active terminal point in Boston Logan International Airport."}
              </p>
            </div>

            {selectedNode.assignedFlight && (
              <div className="p-2 rounded bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[9px] text-slate-500 uppercase block">Active Flight Assignment</span>
                <span className="text-xs font-bold text-emerald-300 block">{selectedNode.assignedFlight}</span>
                <span className="text-[10px] text-slate-400 block">{selectedNode.statusText}</span>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 pt-1 text-[10px]">
              <div className="p-1.5 rounded bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-500 block">Accessibility</span>
                <span className="font-bold text-emerald-400">
                  {selectedNode.isAccessible ? "✓ Step-Free / Lift" : "Stairs Only"}
                </span>
              </div>
              <div className="p-1.5 rounded bg-slate-900 border border-slate-800 text-center">
                <span className="text-slate-500 block">Coordinates</span>
                <span className="font-bold text-sky-300">
                  ({selectedNode.x}, {selectedNode.y})
                </span>
              </div>
            </div>
          </div>

          {/* Turn-by-Turn Passenger Wayfinding HUD */}
          <div className="p-3.5 rounded-lg border border-slate-800 bg-[#0d131f] space-y-3">
            <div className="flex items-center justify-between pb-1 border-b border-slate-800">
              <span className="text-[10px] text-emerald-400 uppercase tracking-wider font-bold">
                PASSENGER WAYFINDING HUD
              </span>
              <span className="text-[9px] text-slate-400">{activeRoutePath.walkingTimeMins} min transit</span>
            </div>

            <div className="space-y-2">
              {activeRoutePath.steps.map((step, idx) => (
                <div key={idx} className="flex items-start gap-2 text-[11px]">
                  <span className="flex h-4 w-4 items-center justify-center rounded-full bg-emerald-950 border border-emerald-700 text-emerald-300 text-[9px] font-bold mt-0.5 shrink-0">
                    {idx + 1}
                  </span>
                  <span className="text-slate-300 font-sans leading-snug">{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Route Switcher */}
          <div className="p-3 rounded-lg border border-slate-800 bg-slate-900/60 space-y-2">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-bold">
              SIMULATION ROUTE COMPARISON
            </span>
            <div className="space-y-1.5">
              <div className={`p-2 rounded border text-[11px] ${
                isAdjacentSwap ? "border-emerald-600 bg-emerald-950/40 text-emerald-300" : "border-slate-800 bg-slate-900 text-slate-400"
              }`}>
                <div className="flex justify-between font-bold">
                  <span>Adjacent Stroll (B10 ➔ B12)</span>
                  <span>1 min (25m)</span>
                </div>
                <span className="text-[10px] text-slate-500">Active when 10m-40m delay</span>
              </div>

              <div className={`p-2 rounded border text-[11px] ${
                isStandardGates ? "border-amber-600 bg-amber-950/40 text-amber-300" : "border-slate-800 bg-slate-900 text-slate-400"
              }`}>
                <div className="flex justify-between font-bold">
                  <span>Standard Route (B30 ➔ B38)</span>
                  <span>18 min (1,200m)</span>
                </div>
                <span className="text-[10px] text-slate-500">Active when minimal delay</span>
              </div>

              <div className={`p-2 rounded border text-[11px] ${
                isRemoteStand ? "border-cyan-600 bg-cyan-950/40 text-cyan-300" : "border-slate-800 bg-slate-900 text-slate-400"
              }`}>
                <div className="flex justify-between font-bold">
                  <span>Tarmac Shuttle (Stand A14)</span>
                  <span>4 min (450m)</span>
                </div>
                <span className="text-[10px] text-slate-500">Active when severe delay/ground stop</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const AirportTerminalIndoorMap = React.memo(AirportTerminalIndoorMapComponent, (prev, next) => {
  return (
    prev.state.flight.delayMinutes === next.state.flight.delayMinutes &&
    prev.state.flight.status === next.state.flight.status &&
    prev.state.passenger.isWheelchairUser === next.state.passenger.isWheelchairUser &&
    prev.state.passenger.specialAssistance === next.state.passenger.specialAssistance &&
    prev.state.inferredOutcome?.recommendedGateAction === next.state.inferredOutcome?.recommendedGateAction &&
    prev.onClose === next.onClose
  );
});
