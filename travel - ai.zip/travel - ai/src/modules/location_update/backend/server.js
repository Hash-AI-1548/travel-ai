import express from 'express';
import cors from 'cors';
import { getNearbyHazards, submitHazardProof, voteHazard } from './controllers/hazardController.js';

const app = express();
const PORT = process.env.PORT || 5001;

app.use(cors());
app.use(express.json({ limit: '50mb' }));

// API Endpoints
app.get('/api/hazards', getNearbyHazards);
app.post('/api/hazards', submitHazardProof);
app.post('/api/hazards/:id/vote', voteHazard);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'Travel-AI Location Update API' });
});

app.listen(PORT, () => {
  console.log(`Location Update Backend Server running on http://localhost:${PORT}`);
});
