import { AiVisionService } from '../services/aiVisionService.js';
import { SpatialIndexService } from '../services/spatialIndexService.js';

// In-memory hazard state cache for the backend
let hazardsDB = [];

export const getNearbyHazards = async (req, res) => {
  try {
    const { lat, lng, radiusKm = 25 } = req.query;
    if (!lat || !lng) {
      return res.json({ success: true, count: hazardsDB.length, hazards: hazardsDB });
    }

    const centerLat = parseFloat(lat);
    const centerLng = parseFloat(lng);
    const radiusMeters = parseFloat(radiusKm) * 1000;

    const matched = hazardsDB.filter((h) => {
      const dist = SpatialIndexService.haversineDistanceMeters(
        centerLat,
        centerLng,
        h.latitude,
        h.longitude
      );
      return dist <= radiusMeters;
    });

    res.json({ success: true, count: matched.length, hazards: matched });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const submitHazardProof = async (req, res) => {
  try {
    const { title, hazardType, latitude, longitude, altitude, heading, description, mediaUrl, mediaType } = req.body;

    if (!latitude || !longitude || !mediaUrl) {
      return res.status(400).json({ success: false, message: 'Coordinates and media proof are mandatory.' });
    }

    // Run AI Inspection
    const aiResult = await AiVisionService.inspectRoadHazardImage({
      imageBase64: mediaUrl,
      telemetry: { latitude, longitude, altitude, heading },
      declaredHazardType: hazardType
    });

    const newRecord = {
      id: 'haz_' + Date.now(),
      title: title || 'Road Obstruction',
      hazardType: hazardType || 'BROKEN_BRIDGE',
      severity: aiResult.detectedSeverity,
      latitude: parseFloat(latitude),
      longitude: parseFloat(longitude),
      altitude: parseFloat(altitude || 0),
      heading: parseInt(heading || 0, 10),
      description: description || '',
      mediaType: mediaType || 'PHOTO',
      mediaUrl,
      aiVerified: aiResult.aiVerified,
      aiConfidence: aiResult.aiConfidence,
      aiSummary: aiResult.summary,
      upvotes: 1,
      downvotes: 0,
      status: 'AI_VERIFIED',
      createdAt: new Date().toISOString()
    };

    hazardsDB.unshift(newRecord);

    res.status(201).json({ success: true, hazard: newRecord });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

export const voteHazard = async (req, res) => {
  try {
    const { id } = req.params;
    const { isUpvote } = req.body;

    const item = hazardsDB.find((h) => h.id === id);
    if (!item) {
      return res.status(404).json({ success: false, message: 'Hazard not found' });
    }

    if (isUpvote) {
      item.upvotes += 1;
    } else {
      item.downvotes += 1;
    }

    res.json({ success: true, hazard: item });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
