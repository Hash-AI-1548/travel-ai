-- SQL Schema for Location Update & Ground-Truth Hazard Avoidance System

CREATE TABLE IF NOT EXISTS road_hazards (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    hazard_type VARCHAR(64) NOT NULL, -- BROKEN_BRIDGE, ROAD_COLLAPSE, etc.
    severity VARCHAR(32) NOT NULL,     -- IMPASSABLE, HIGH_RISK, SLOWDOWN
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    altitude DECIMAL(8, 2) DEFAULT 0,
    heading INT DEFAULT NULL,
    description TEXT,
    media_type VARCHAR(32) NOT NULL,   -- PHOTO, PANORAMA, VIDEO
    media_url TEXT NOT NULL,
    ai_verified BOOLEAN DEFAULT FALSE,
    ai_confidence DECIMAL(5, 4) DEFAULT 0.0,
    ai_summary TEXT,
    upvotes INT DEFAULT 0,
    downvotes INT DEFAULT 0,
    status VARCHAR(32) DEFAULT 'AI_VERIFIED', -- AI_VERIFIED, PENDING_REVIEW, REJECTED
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS verification_votes (
    id VARCHAR(64) PRIMARY KEY,
    hazard_id VARCHAR(64) NOT NULL REFERENCES road_hazards(id) ON DELETE CASCADE,
    user_id VARCHAR(64) NOT NULL,
    is_upvote BOOLEAN NOT NULL,
    voted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Spatial index query optimization for radius searches
CREATE INDEX IF NOT EXISTS idx_hazards_lat_lng ON road_hazards(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_hazards_status ON road_hazards(status, severity);
