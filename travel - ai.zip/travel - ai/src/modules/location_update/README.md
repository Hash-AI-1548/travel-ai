# Location Update & Ground-Truth Hazard Verification Module

## Overview
This module solves the critical limitation of legacy navigation tools (like Google Maps): **routing through impassable hazards (e.g., collapsed bridges, landslides, flooded passes) due to lack of real-time passive traffic data**.

When a bridge breaks on a one-way road:
1. No cars travel across it, so speed algorithms show zero traffic slowdowns.
2. Drivers are routed into dead-ends or hazardous drops.
3. This module empowers drivers and locals to capture **tamper-evident Geotagged Media** (Photos, 360° sweeps, or Videos) with sensor-level telemetry (GPS coordinates, compass bearing, altitude, timestamp).
4. An integrated **Vision AI Verification Engine** verifies the hazard authenticity and passability.
5. The **Dynamic Avoidance Routing Engine** immediately invalidates the road segment and dynamically reroutes approaching drivers onto verified detours.

## Directory Layout
```
src/modules/location_update/
├── README.md
├── package.json
├── index.html
├── vite.config.js
├── src/
│   ├── index.js
│   ├── types/
│   │   └── locationUpdate.types.js
│   ├── config/
│   │   └── constants.js
│   ├── services/
│   │   ├── geoCameraService.js
│   │   ├── aiHazardVerificationService.js
│   │   ├── dynamicRoutingService.js
│   │   └── hazardStoreService.js
│   ├── mockData/
│   │   └── sampleHazards.js
│   ├── components/
│   │   ├── LocationUpdateTab.jsx
│   │   ├── GeotagMediaCapture.jsx
│   │   ├── HazardReviewForm.jsx
│   │   ├── LiveProofMap.jsx
│   │   └── HazardDetailModal.jsx
│   └── styles/
│       └── locationUpdate.css
└── backend/
    ├── server.js
    ├── controllers/
    │   └── hazardController.js
    ├── services/
    │   ├── aiVisionService.js
    │   └── spatialIndexService.js
    └── database/
        └── schema.sql
```
