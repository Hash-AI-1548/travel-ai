import { sampleHazards } from '../mockData/sampleHazards.js';

const STORAGE_KEY = 'TRAVEL_AI_ROAD_HAZARDS';

export class HazardStoreService {
  static getHazards() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(sampleHazards));
        return sampleHazards;
      }
      return JSON.parse(stored);
    } catch (e) {
      return sampleHazards;
    }
  }

  static addHazard(newHazard) {
    const current = this.getHazards();
    const hazardRecord = {
      id: 'haz_' + Date.now(),
      upvotes: 1,
      downvotes: 0,
      verifiedByAi: true,
      status: 'AI_VERIFIED',
      createdAt: new Date().toISOString(),
      ...newHazard
    };

    const updated = [hazardRecord, ...current];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return hazardRecord;
  }

  static voteHazard(hazardId, isUpvote = true) {
    const current = this.getHazards();
    const updated = current.map((h) => {
      if (h.id === hazardId) {
        return {
          ...h,
          upvotes: isUpvote ? h.upvotes + 1 : h.upvotes,
          downvotes: !isUpvote ? h.downvotes + 1 : h.downvotes
        };
      }
      return h;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return updated;
  }
}
