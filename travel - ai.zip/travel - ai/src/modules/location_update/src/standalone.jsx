import React from 'react';
import ReactDOM from 'react-dom/client';
import { LocationUpdateTab } from './components/LocationUpdateTab.jsx';
import './styles/locationUpdate.css';

function StandaloneApp() {
  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '16px' }}>
      <LocationUpdateTab />
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <StandaloneApp />
  </React.StrictMode>
);
