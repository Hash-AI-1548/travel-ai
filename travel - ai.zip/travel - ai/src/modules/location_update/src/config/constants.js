import { HAZARD_TYPES, SEVERITY_LEVELS } from '../types/locationUpdate.types.js';

export const HAZARD_CONFIG = {
  [HAZARD_TYPES.BROKEN_BRIDGE]: {
    label: 'Broken / Collapsed Bridge',
    icon: '🌉',
    color: '#ef4444',
    defaultSeverity: SEVERITY_LEVELS.IMPASSABLE,
    routePenaltyFactor: 10000.0,
    decayHours: 720,
    vehicleRestrictions: ['CAR_SEDAN', 'SUV_4X4', 'HEAVY_TRUCK', 'MOTORCYCLE', 'BICYCLE']
  },
  [HAZARD_TYPES.ROAD_COLLAPSE]: {
    label: 'Road Washed Away / Cave-In',
    icon: '⚠️',
    color: '#dc2626',
    defaultSeverity: SEVERITY_LEVELS.IMPASSABLE,
    routePenaltyFactor: 10000.0,
    decayHours: 360,
    vehicleRestrictions: ['CAR_SEDAN', 'SUV_4X4', 'HEAVY_TRUCK', 'MOTORCYCLE', 'BICYCLE']
  },
  [HAZARD_TYPES.FLOODING]: {
    label: 'Deep Water / Flash Flood',
    icon: '🌊',
    color: '#0284c7',
    defaultSeverity: SEVERITY_LEVELS.IMPASSABLE,
    routePenaltyFactor: 500.0,
    decayHours: 24,
    vehicleRestrictions: ['CAR_SEDAN', 'MOTORCYCLE', 'BICYCLE']
  },
  [HAZARD_TYPES.LANDSLIDE_OBSTRUCTION]: {
    label: 'Landslide / Fallen Rocks',
    icon: '🪨',
    color: '#d97706',
    defaultSeverity: SEVERITY_LEVELS.IMPASSABLE,
    routePenaltyFactor: 1000.0,
    decayHours: 48,
    vehicleRestrictions: ['CAR_SEDAN', 'HEAVY_TRUCK']
  },
  [HAZARD_TYPES.NARROW_PASSAGE]: {
    label: 'Extremely Narrow Lane / Alley',
    icon: '↔️',
    color: '#a855f7',
    defaultSeverity: SEVERITY_LEVELS.HIGH_RISK,
    routePenaltyFactor: 4.0,
    decayHours: 2160,
    vehicleRestrictions: ['HEAVY_TRUCK', 'SUV_4X4']
  },
  [HAZARD_TYPES.LOW_CLEARANCE_BARRIER]: {
    label: 'Low Height Clearance Underpass',
    icon: '⛔',
    color: '#8b5cf6',
    defaultSeverity: SEVERITY_LEVELS.HIGH_RISK,
    routePenaltyFactor: 50.0,
    decayHours: 2160,
    vehicleRestrictions: ['HEAVY_TRUCK']
  },
  [HAZARD_TYPES.TEMPORARY_BLOCKADE]: {
    label: 'Construction / Roadblock',
    icon: '🚧',
    color: '#eab308',
    defaultSeverity: SEVERITY_LEVELS.SLOWDOWN,
    routePenaltyFactor: 5.0,
    decayHours: 12,
    vehicleRestrictions: ['HEAVY_TRUCK']
  },
  [HAZARD_TYPES.NEW_ROAD_OPENED]: {
    label: 'Newly Built Road / Shortcut',
    icon: '✨',
    color: '#22c55e',
    defaultSeverity: SEVERITY_LEVELS.INFORMATIONAL,
    routePenaltyFactor: 0.8,
    decayHours: 2160,
    vehicleRestrictions: []
  }
};

export const AI_VISION_PROMPT = `
Analyze this road/bridge camera capture or uploaded geotagged proof.
Determine:
1. Is there physical damage, bridge collapse, water logging, or roadblock?
2. Estimate vehicle clearance (sedans, trucks, SUVs, bikes, bicycles).
3. Determine elevation context: Is this at Ground Level (Service Road) or on an Elevated Flyover?
Return a strict JSON object with:
{
  "detectedHazard": "BROKEN_BRIDGE | ROAD_COLLAPSE | FLOODING | NARROW_PASSAGE | LOW_CLEARANCE_BARRIER | CLEAR",
  "confidence": 0.0 to 1.0,
  "severity": "IMPASSABLE | HIGH_RISK | SLOWDOWN | INFORMATIONAL",
  "minRoadWidthMeters": 3.0,
  "flyoverLevel": "GROUND_LEVEL | ELEVATED_FLYOVER",
  "passableVehicles": ["CAR_SEDAN", "SUV_4X4", "HEAVY_TRUCK", "MOTORCYCLE", "BICYCLE"],
  "summary": "Clear explanation of ground truth proof",
  "recommendedAction": "REROUTE_VEHICLE_SPECIFIC | TAKE_FLYOVER"
}
`;
