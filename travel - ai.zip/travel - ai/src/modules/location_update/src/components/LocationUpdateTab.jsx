import React, { useState } from 'react';
import { Camera, Map, PlusCircle, ShieldAlert, ListFilter } from 'lucide-react';
import { GeotagMediaCapture } from './GeotagMediaCapture.jsx';
import { HazardReviewForm } from './HazardReviewForm.jsx';
import { LiveProofMap } from './LiveProofMap.jsx';
import { HazardDetailModal } from './HazardDetailModal.jsx';
import { HazardStoreService } from '../services/hazardStoreService.js';

export const LocationUpdateTab = () => {
  const [hazards, setHazards] = useState(() => HazardStoreService.getHazards());
  const [activeSubView, setActiveSubView] = useState('MAP'); // 'MAP' | 'CAPTURE' | 'REVIEW'
  const [stagedMedia, setStagedMedia] = useState(null);
  const [selectedHazard, setSelectedHazard] = useState(null);

  const handleMediaCaptured = (data) => {
    setStagedMedia(data);
    setActiveSubView('REVIEW');
  };

  const handlePublishHazard = (hazardPayload) => {
    const created = HazardStoreService.addHazard(hazardPayload);
    setHazards(HazardStoreService.getHazards());
    setActiveSubView('MAP');
    setSelectedHazard(created);
  };

  const handleVote = (hazardId, isUpvote) => {
    const updated = HazardStoreService.voteHazard(hazardId, isUpvote);
    setHazards(updated);
    if (selectedHazard && selectedHazard.id === hazardId) {
      setSelectedHazard(updated.find((h) => h.id === hazardId));
    }
  };

  return (
    <div className="location-update-module-root">
      {/* Module Top Navbar */}
      <header className="location-update-nav">
        <div className="module-brand">
          <ShieldAlert className="brand-icon" />
          <div>
            <h3>LOCATION UPDATE</h3>
            <span className="brand-sub">Crowdsourced Geotag Proof & Dynamic Avoidance Engine</span>
          </div>
        </div>

        <div className="nav-actions">
          <button
            className={`btn-tab-toggle ${activeSubView === 'MAP' ? 'active' : ''}`}
            onClick={() => setActiveSubView('MAP')}
          >
            <Map size={16} /> Live Hazard Map
          </button>
          <button
            className="btn-report-hazard"
            onClick={() => setActiveSubView('CAPTURE')}
          >
            <PlusCircle size={16} /> Report Road Hazard / Update
          </button>
        </div>
      </header>

      {/* Main Tab Views */}
      <main className="location-update-content">
        {activeSubView === 'MAP' && (
          <LiveProofMap
            hazards={hazards}
            onSelectHazard={setSelectedHazard}
          />
        )}

        {activeSubView === 'CAPTURE' && (
          <GeotagMediaCapture
            onMediaCaptured={handleMediaCaptured}
            onCancel={() => setActiveSubView('MAP')}
          />
        )}

        {activeSubView === 'REVIEW' && stagedMedia && (
          <HazardReviewForm
            capturedData={stagedMedia}
            onSubmit={handlePublishHazard}
            onBack={() => setActiveSubView('CAPTURE')}
          />
        )}
      </main>

      {/* Inspection Modal */}
      {selectedHazard && (
        <HazardDetailModal
          hazard={selectedHazard}
          onClose={() => setSelectedHazard(null)}
          onVote={handleVote}
        />
      )}
    </div>
  );
};
