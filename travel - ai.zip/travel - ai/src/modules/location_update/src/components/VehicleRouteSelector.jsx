import React from 'react';
import { VEHICLE_TYPES } from '../types/locationUpdate.types.js';
import { Truck, Car, ShieldAlert, Bike, Sparkles } from 'lucide-react';

export const VehicleRouteSelector = ({
  selectedVehicle,
  onSelectVehicle,
  routeData
}) => {
  const { primaryRoute, smallVehicleRoute } = routeData || {};
  const isTruck = selectedVehicle === 'HEAVY_TRUCK';
  const isSmallVehicle = selectedVehicle === 'BICYCLE' || selectedVehicle === 'MOTORCYCLE';

  return (
    <div className="vehicle-selector-panel">
      <div className="vehicle-header">
        <span className="panel-title">🚗 Vehicle Profile & Shortcut Routing</span>
        <span className="vehicle-badge-active">
          {VEHICLE_TYPES[selectedVehicle]?.icon} {VEHICLE_TYPES[selectedVehicle]?.label}
        </span>
      </div>

      {/* Vehicle Type Selector Buttons */}
      <div className="vehicle-button-row">
        {Object.values(VEHICLE_TYPES).map((v) => {
          const isSelected = selectedVehicle === v.id;
          return (
            <button
              key={v.id}
              className={`vehicle-btn ${isSelected ? 'active' : ''}`}
              onClick={() => onSelectVehicle(v.id)}
            >
              <span className="v-icon">{v.icon}</span>
              <span className="v-label">{v.label}</span>
            </button>
          );
        })}
      </div>

      {/* Small Vehicle (Cycle / Bike) Shortcut Banner */}
      {isSmallVehicle && smallVehicleRoute && (
        <div className="small-vehicle-advantage-banner">
          <Sparkles size={16} color="#06b6d4" />
          <div>
            <h5>🚲 Small Vehicle Shortcut Active</h5>
            <p>
              Navigating through <b>narrow alleys & intact pedestrian footbridge</b>.
              Saves <b>{smallVehicleRoute.timeSavedMins} mins & {smallVehicleRoute.distanceSavedKm} km</b> over standard car detour! (Inaccessible to cars & trucks).
            </p>
          </div>
        </div>
      )}

      {/* Heavy Truck Warning */}
      {isTruck && (
        <div className="truck-restriction-alert">
          <ShieldAlert size={16} color="#f59e0b" />
          <span>
            <b>Truck Mode Active:</b> Narrow city alleys (&lt;3.5m) and low clearance underpasses are strictly avoided. Routed via primary wide arterial highway.
          </span>
        </div>
      )}
    </div>
  );
};
