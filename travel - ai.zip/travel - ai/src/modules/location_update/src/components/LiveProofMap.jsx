import React, { useState } from 'react';
import { AlertOctagon, Navigation, ShieldCheck, MapPin, Compass, ArrowRight } from 'lucide-react';
import { HAZARD_CONFIG } from '../config/constants.js';
import { DynamicRoutingService } from '../services/dynamicRoutingService.js';
import { LiveLeafletMap } from './LiveLeafletMap.jsx';
import { VehicleRouteSelector } from './VehicleRouteSelector.jsx';
import { FlyoverGuidanceCard } from './FlyoverGuidanceCard.jsx';

export const LiveProofMap = ({ hazards, onSelectHazard, userLocation }) => {
  const [activeRouteType, setActiveRouteType] = useState('DETOUR'); // 'BLOCKED' vs 'DETOUR'
  const [selectedVehicle, setSelectedVehicle] = useState('BICYCLE');
  const [calculatedRouteData, setCalculatedRouteData] = useState(null);

  const brokenBridgeHazard =
    hazards.find((h) => h.type === 'BROKEN_BRIDGE') ||
    hazards[0] || {
      title: 'River North Bridge Collapse',
      type: 'BROKEN_BRIDGE',
      latitude: 12.9752,
      longitude: 77.5998
    };

  const activeRoute =
    activeRouteType === 'BLOCKED'
      ? calculatedRouteData?.naiveBlockedRoute
      : selectedVehicle === 'BICYCLE' || selectedVehicle === 'MOTORCYCLE'
      ? calculatedRouteData?.smallVehicleRoute || calculatedRouteData?.primaryRoute
      : calculatedRouteData?.primaryRoute;

  return (
    <div className="map-view-wrapper">
      {/* Route Status Alert Header */}
      <div className="route-advisor-banner">
        <div className="advisor-left">
          <AlertOctagon className="alert-pulse-icon" size={24} />
          <div>
            <h4>Real-Road Hazard Interception & Shortcut Engine</h4>
            <p>
              Avoided 1 Broken Bridge at <b>{brokenBridgeHazard.title}</b>.
              {activeRoute && (
                <> Active ETA: <b>{activeRoute.durationMins} mins</b> ({activeRoute.distanceKm} km, Snapped to actual streets).</>
              )}
            </p>
          </div>
        </div>

        <div className="advisor-toggles">
          <button
            className={`route-btn ${activeRouteType === 'DETOUR' ? 'active-detour' : ''}`}
            onClick={() => setActiveRouteType('DETOUR')}
          >
            🛡️ Safe Detour / Shortcut
          </button>
          <button
            className={`route-btn ${activeRouteType === 'BLOCKED' ? 'active-blocked' : ''}`}
            onClick={() => setActiveRouteType('BLOCKED')}
          >
            ❌ Naive Route (Broken Bridge)
          </button>
        </div>
      </div>

      {/* Vehicle Type & Shortcut Preferences Panel */}
      <VehicleRouteSelector
        selectedVehicle={selectedVehicle}
        onSelectVehicle={setSelectedVehicle}
        routeData={calculatedRouteData}
      />

      {/* Main Interactive Leaflet Map with Real-Road Snapping & Satellite Imagery Option */}
      <div className="map-interactive-viewport">
        <LiveLeafletMap
          hazards={hazards}
          onSelectHazard={onSelectHazard}
          userLocation={userLocation}
          activeRouteType={activeRouteType}
          selectedVehicle={selectedVehicle}
          onRouteCalculated={setCalculatedRouteData}
        />

        {/* Hazard List overlay tray */}
        <div className="hazard-cards-tray">
          {hazards.map((hazard) => {
            const config = HAZARD_CONFIG[hazard.type] || HAZARD_CONFIG.BROKEN_BRIDGE;
            return (
              <div
                key={hazard.id}
                className="hazard-summary-chip"
                onClick={() => onSelectHazard(hazard)}
              >
                <span className="chip-icon">{config.icon}</span>
                <div className="chip-details">
                  <h5>{hazard.title}</h5>
                  <div className="chip-meta">
                    <span className="verified-tag">
                      <ShieldCheck size={12} /> AI Verified
                    </span>
                    <span>👍 {hazard.upvotes}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Dedicated Flyover vs. Service Road Guidance Card */}
      {activeRoute?.flyoverGuidance && (
        <FlyoverGuidanceCard
          guidance={activeRoute.flyoverGuidance}
          activeRouteId={activeRoute.id}
        />
      )}
    </div>
  );
};
