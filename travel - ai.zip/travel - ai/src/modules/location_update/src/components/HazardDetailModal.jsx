import React from 'react';
import { X, ShieldCheck, ThumbsUp, ThumbsDown, Navigation, Calendar, MapPin, Compass } from 'lucide-react';
import { HAZARD_CONFIG } from '../config/constants.js';

export const HazardDetailModal = ({ hazard, onClose, onVote }) => {
  if (!hazard) return null;
  const config = HAZARD_CONFIG[hazard.type] || HAZARD_CONFIG.BROKEN_BRIDGE;

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="hazard-modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="modal-close-btn" onClick={onClose}>
          <X size={20} />
        </button>

        {/* Geotagged Proof Image with HUD */}
        <div className="modal-media-header">
          <img src={hazard.imageUrl} alt={hazard.title} className="modal-img" />
          <div className="modal-badge-row">
            <span className="hazard-type-pill" style={{ backgroundColor: config.color }}>
              {config.icon} {config.label}
            </span>
            <span className="severity-pill">{hazard.severity}</span>
          </div>
        </div>

        <div className="modal-body">
          <h3>{hazard.title}</h3>
          <p className="hazard-description">{hazard.description}</p>

          {/* Proof Telemetry Grid */}
          <div className="telemetry-info-grid">
            <div className="telemetry-box">
              <MapPin size={16} color="#38bdf8" />
              <div>
                <label>Exact Coordinates</label>
                <span>{hazard.latitude?.toFixed(6)}°, {hazard.longitude?.toFixed(6)}°</span>
              </div>
            </div>
            <div className="telemetry-box">
              <Compass size={16} color="#38bdf8" />
              <div>
                <label>Camera Heading</label>
                <span>{hazard.heading ? `${hazard.heading}°` : '085° (East)'}</span>
              </div>
            </div>
            <div className="telemetry-box">
              <Calendar size={16} color="#38bdf8" />
              <div>
                <label>Reported</label>
                <span>{new Date(hazard.createdAt).toLocaleTimeString()}</span>
              </div>
            </div>
            <div className="telemetry-box">
              <ShieldCheck size={16} color="#22c55e" />
              <div>
                <label>AI Verification</label>
                <span>{((hazard.aiConfidence || 0.95) * 100).toFixed(0)}% Confidence</span>
              </div>
            </div>
          </div>

          {/* Community Verification Actions */}
          <div className="modal-vote-actions">
            <span className="vote-question">Did you pass by this location? Verify status:</span>
            <div className="vote-btn-group">
              <button className="btn-vote up" onClick={() => onVote(hazard.id, true)}>
                <ThumbsUp size={16} /> Still Blocked ({hazard.upvotes})
              </button>
              <button className="btn-vote down" onClick={() => onVote(hazard.id, false)}>
                <ThumbsDown size={16} /> Road Cleared ({hazard.downvotes})
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
