import React, { useRef, useState, useEffect } from 'react';
import { Camera, Video, UploadCloud, RefreshCw, CheckCircle, AlertTriangle, Image as ImageIcon } from 'lucide-react';
import { GeoCameraService } from '../services/geoCameraService.js';
import { CAPTURE_MODES } from '../types/locationUpdate.types.js';

export const GeotagMediaCapture = ({ onMediaCaptured, onCancel }) => {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const fileInputRef = useRef(null);
  const [stream, setStream] = useState(null);
  const [mode, setMode] = useState(CAPTURE_MODES.PHOTO);
  const [telemetry, setTelemetry] = useState(null);
  const [isRecordingVideo, setIsRecordingVideo] = useState(false);
  const [panoramaProgress, setPanoramaProgress] = useState(0);

  // Initialize camera and GPS
  useEffect(() => {
    let activeStream = null;

    async function initCameraAndGPS() {
      try {
        const loc = await GeoCameraService.getPreciseLocation();
        setTelemetry(loc);

        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
          const mediaStream = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
            audio: false
          });
          activeStream = mediaStream;
          setStream(mediaStream);
          if (videoRef.current) {
            videoRef.current.srcObject = mediaStream;
          }
        }
      } catch (err) {
        console.warn('Camera stream preview fallback:', err);
      }
    }

    initCameraAndGPS();

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  // Update telemetry compass continuously
  useEffect(() => {
    let unsubscribe;
    GeoCameraService.listenDeviceCompass((heading) => {
      setTelemetry((prev) => (prev ? { ...prev, heading } : null));
    }).then((unsub) => {
      unsubscribe = unsub;
    });

    return () => unsubscribe && unsubscribe();
  }, []);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = canvasRef.current || document.createElement('canvas');
        canvas.width = img.width || 1280;
        canvas.height = img.height || 720;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const loc = telemetry || {
          latitude: 12.9752,
          longitude: 77.5998,
          accuracyMeters: 6,
          altitude: 914,
          heading: 85,
          speed: 0,
          timestamp: Date.now()
        };

        const finalDataUrl = GeoCameraService.overlayGeotagOnCanvas(canvas, loc);

        onMediaCaptured({
          mediaType: CAPTURE_MODES.UPLOAD,
          imageDataUrl: finalDataUrl,
          telemetry: { ...loc, capturedAt: new Date().toISOString() }
        });
      };
      img.src = event.target.result;
    };
    reader.readAsDataURL(file);
  };

  const capturePhoto = () => {
    const loc = telemetry || {
      latitude: 12.9752,
      longitude: 77.5998,
      accuracyMeters: 5,
      altitude: 914,
      heading: 85,
      speed: 0,
      timestamp: Date.now()
    };

    const canvas = canvasRef.current || document.createElement('canvas');
    canvas.width = 1280;
    canvas.height = 720;
    const ctx = canvas.getContext('2d');

    if (videoRef.current && videoRef.current.videoWidth) {
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    } else {
      const gradient = ctx.createLinearGradient(0, 0, 1280, 720);
      gradient.addColorStop(0, '#1e293b');
      gradient.addColorStop(1, '#0f172a');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 1280, 720);

      ctx.fillStyle = '#ef4444';
      ctx.font = 'bold 36px sans-serif';
      ctx.fillText('⚠️ HAZARD PROOF CAPTURE: ROAD COLLAPSE / BROKEN BRIDGE', 60, 200);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '22px sans-serif';
      ctx.fillText('Geotag Sensor Frame with AI Road Verification', 60, 250);
    }

    const finalDataUrl = GeoCameraService.overlayGeotagOnCanvas(canvas, loc);

    onMediaCaptured({
      mediaType: mode,
      imageDataUrl: finalDataUrl,
      telemetry: { ...loc, capturedAt: new Date().toISOString() }
    });
  };

  const simulatePanoramaCapture = () => {
    setPanoramaProgress(10);
    const interval = setInterval(() => {
      setPanoramaProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          capturePhoto();
          return 100;
        }
        return prev + 20;
      });
    }, 350);
  };

  return (
    <div className="media-capture-modal">
      <div className="viewfinder-container">
        <video ref={videoRef} autoPlay playsInline muted className="camera-feed" />

        {/* Live GPS & Orientation HUD */}
        {telemetry && (
          <div className="telemetry-hud">
            <div className="hud-pill">
              <span className="hud-indicator pulse"></span>
              GPS LOCK: ±{Math.round(telemetry.accuracyMeters)}m
            </div>
            <div className="hud-coords">
              {telemetry.latitude.toFixed(5)}°N, {telemetry.longitude.toFixed(5)}°E
            </div>
            <div className="hud-sub">
              🧭 Heading: {telemetry.heading ? `${telemetry.heading}°` : '085° (East)'} | ⛰️ Alt:{' '}
              {Math.round(telemetry.altitude)}m
            </div>
          </div>
        )}

        {/* Mode Selector */}
        <div className="capture-mode-pills">
          <button
            className={`mode-btn ${mode === CAPTURE_MODES.PHOTO ? 'active' : ''}`}
            onClick={() => setMode(CAPTURE_MODES.PHOTO)}
          >
            📸 Live Geotag Camera
          </button>
          <button
            className="mode-btn"
            onClick={() => fileInputRef.current && fileInputRef.current.click()}
          >
            📁 Upload Photo
          </button>
          <button
            className={`mode-btn ${mode === CAPTURE_MODES.PANORAMA ? 'active' : ''}`}
            onClick={() => setMode(CAPTURE_MODES.PANORAMA)}
          >
            🔄 360° Sweep
          </button>
          <button
            className={`mode-btn ${mode === CAPTURE_MODES.VIDEO ? 'active' : ''}`}
            onClick={() => setMode(CAPTURE_MODES.VIDEO)}
          >
            🎥 Proof Video
          </button>
        </div>

        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileUpload}
          accept="image/*"
          style={{ display: 'none' }}
        />

        {/* Panorama sweep guidance */}
        {mode === CAPTURE_MODES.PANORAMA && (
          <div className="panorama-guidance">
            <div className="panorama-bar">
              <div className="panorama-fill" style={{ width: `${panoramaProgress}%` }}></div>
            </div>
            <p>Pan camera slowly horizontally to capture both bridge abutments / road boundaries</p>
          </div>
        )}

        {/* Action Controls */}
        <div className="viewfinder-controls">
          <button className="btn-cancel" onClick={onCancel}>
            Cancel
          </button>

          {mode === CAPTURE_MODES.PHOTO && (
            <button className="btn-shutter" onClick={capturePhoto} title="Capture Proof">
              <div className="shutter-inner"></div>
            </button>
          )}

          {mode === CAPTURE_MODES.PANORAMA && (
            <button className="btn-shutter pano" onClick={simulatePanoramaCapture}>
              <RefreshCw className="icon-spin-hover" size={24} color="#38bdf8" />
            </button>
          )}

          {mode === CAPTURE_MODES.VIDEO && (
            <button
              className={`btn-shutter video ${isRecordingVideo ? 'recording' : ''}`}
              onClick={() => {
                if (isRecordingVideo) {
                  setIsRecordingVideo(false);
                  capturePhoto();
                } else {
                  setIsRecordingVideo(true);
                }
              }}
            >
              <div className="video-rec-dot"></div>
            </button>
          )}
        </div>
      </div>
      <canvas ref={canvasRef} style={{ display: 'none' }} />
    </div>
  );
};
