import React, { useState, useEffect } from 'react';
import { ShieldCheck, AlertCircle, ArrowLeft, Send, Sparkles, Truck, Car, Layers } from 'lucide-react';
import { HAZARD_TYPES, SEVERITY_LEVELS, VEHICLE_TYPES } from '../types/locationUpdate.types.js';
import { HAZARD_CONFIG } from '../config/constants.js';
import { AiHazardVerificationService } from '../services/aiHazardVerificationService.js';

export const HazardReviewForm = ({ capturedData, onSubmit, onBack }) => {
  const [hazardType, setHazardType] = useState(HAZARD_TYPES.BROKEN_BRIDGE);
  const [title, setTitle] = useState('Broken Bridge / Road Collapse Warning');
  const [description, setDescription] = useState(
    'Bridge is broken and completely impassable. Vehicles must turn around.'
  );
  const [isVerifyingAi, setIsVerifyingAi] = useState(true);
  const [aiReport, setAiReport] = useState(null);

  useEffect(() => {
    async function runAiInspection() {
      setIsVerifyingAi(true);
      const report = await AiHazardVerificationService.verifyHazardImage({
        imageDataUrl: capturedData.imageDataUrl,
        userSelectedType: hazardType,
        location: capturedData.telemetry
      });
      setAiReport(report);
      setIsVerifyingAi(false);
    }

    runAiInspection();
  }, [hazardType, capturedData]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const config = HAZARD_CONFIG[hazardType];
    onSubmit({
      title,
      type: hazardType,
      severity: aiReport?.severity || config.defaultSeverity,
      latitude: capturedData.telemetry.latitude,
      longitude: capturedData.telemetry.longitude,
      altitude: capturedData.telemetry.altitude,
      heading: capturedData.telemetry.heading,
      description,
      imageUrl: capturedData.imageDataUrl,
      mediaType: capturedData.mediaType,
      aiConfidence: aiReport?.confidenceScore || 0.95,
      aiSummary: aiReport?.summary,
      surfaceQuality: aiReport?.surfaceQuality || 'PAVED',
      passableVehicles: aiReport?.passableVehicles || []
    });
  };

  return (
    <div className="hazard-review-container">
      <div className="review-header">
        <button className="btn-icon" onClick={onBack}>
          <ArrowLeft size={20} />
        </button>
        <h2>Confirm Location Update & AI Verification</h2>
      </div>

      <div className="review-grid">
        {/* Left Column: Captured Media with Geotag HUD */}
        <div className="media-preview-card">
          <img src={capturedData.imageDataUrl} alt="Geotag proof" className="proof-img" />
          <div className="geo-metadata-pill">
            <span>📍 {capturedData.telemetry.latitude.toFixed(6)}°N, {capturedData.telemetry.longitude.toFixed(6)}°E</span>
            <span>🧭 {capturedData.telemetry.heading ? `${capturedData.telemetry.heading}°` : '085° (East)'}</span>
          </div>
        </div>

        {/* Right Column: AI Analysis & Submission Form */}
        <form onSubmit={handleSubmit} className="form-content">
          {/* AI Inspection Banner */}
          <div className="ai-verification-card">
            <div className="ai-title">
              <Sparkles className="sparkle-icon" size={18} />
              <span>AI Real-Time Road & Vehicle Inspector</span>
            </div>
            {isVerifyingAi ? (
              <div className="ai-loading">
                <div className="spinner"></div>
                <span>Inspecting road surface, structural integrity, flyover context & vehicle clearance...</span>
              </div>
            ) : (
              <div className="ai-result">
                <div className="ai-badge">
                  <ShieldCheck size={16} />
                  <span>AI VERIFIED ({(aiReport.confidenceScore * 100).toFixed(0)}% Confidence)</span>
                </div>
                <p className="ai-desc">{aiReport.summary}</p>

                {/* Vehicle Suitability Breakdown */}
                <div className="ai-vehicle-breakdown">
                  <label>Vehicle Passability Matrix:</label>
                  <div className="vehicle-tag-row">
                    {Object.values(VEHICLE_TYPES).map((v) => {
                      const isAllowed = aiReport.passableVehicles?.includes(v.id);
                      return (
                        <span
                          key={v.id}
                          className={`v-suitability-tag ${isAllowed ? 'allowed' : 'restricted'}`}
                        >
                          {v.icon} {v.label}: {isAllowed ? '✅ Passable' : '⛔ Avoid'}
                        </span>
                      );
                    })}
                  </div>
                </div>

                <div className="anti-spoof-tag">
                  🛡️ Anti-Spoofing: Hardware GPS + Timestamp Verified Authentic
                </div>
              </div>
            )}
          </div>

          <div className="form-group">
            <label>Hazard / Road Update Category</label>
            <select
              value={hazardType}
              onChange={(e) => {
                setHazardType(e.target.value);
                setTitle(HAZARD_CONFIG[e.target.value].label);
              }}
              className="custom-select"
            >
              {Object.entries(HAZARD_CONFIG).map(([key, item]) => (
                <option key={key} value={key}>
                  {item.icon} {item.label}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Report Title</label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="custom-input"
              required
            />
          </div>

          <div className="form-group">
            <label>Detailed Note for Approaching Drivers & Navigation Graph</label>
            <textarea
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="custom-textarea"
              placeholder="Describe road blockage, bumpy potholes, flyover ramp status, or detour clearance..."
            />
          </div>

          <button type="submit" className="btn-submit-update">
            <Send size={18} />
            <span>Publish Geotag Update to Global Map</span>
          </button>
        </form>
      </div>
    </div>
  );
};
