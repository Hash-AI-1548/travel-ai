import React, { useEffect, useRef, useState } from 'react';
import { HAZARD_CONFIG } from '../config/constants.js';
import { DynamicRoutingService } from '../services/dynamicRoutingService.js';
import { Layers, Crosshair, MapPin } from 'lucide-react';

const TILE_LAYERS = {
  SATELLITE: {
    name: '🛰️ Satellite Imagery (Esri World)',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
    labelsUrl: 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}'
  },
  DARK: {
    name: '🌙 CartoDB Dark (Night Mode)',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
  },
  OSM: {
    name: '🗺️ OpenStreetMap (Standard)',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  },
  TOPO: {
    name: '⛰️ OpenTopoMap (Terrain)',
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attribution: 'Map data: &copy; OpenStreetMap, SRTM | Map style: &copy; OpenTopoMap'
  }
};

export function LiveLeafletMap({
  hazards,
  selectedHazard,
  onSelectHazard,
  userLocation,
  activeRouteType,
  selectedVehicle = 'CAR_SEDAN',
  onRouteCalculated
}) {
  const mapContainerRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersLayerRef = useRef(null);
  const routesLayerRef = useRef(null);
  const tileLayerRef = useRef(null);
  const labelsLayerRef = useRef(null);
  const [currentTileKey, setCurrentTileKey] = useState('SATELLITE');
  const [destinationCoords, setDestinationCoords] = useState([12.9820, 77.6150]);

  const defaultCenter = userLocation
    ? [userLocation.latitude, userLocation.longitude]
    : [12.9752, 77.5998];

  const startCoords = [12.9680, 77.5850];

  const getLeaflet = () => {
    return typeof window !== 'undefined' ? window.L : null;
  };

  // Initialize Leaflet Map
  useEffect(() => {
    const L = getLeaflet();
    if (!L || !mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: defaultCenter,
      zoom: 14,
      zoomControl: false,
      attributionControl: true
    });

    const activeTile = TILE_LAYERS[currentTileKey];
    const tileLayer = L.tileLayer(activeTile.url, {
      maxZoom: 19,
      attribution: activeTile.attribution
    }).addTo(map);

    tileLayerRef.current = tileLayer;

    if (activeTile.labelsUrl) {
      const labelsLayer = L.tileLayer(activeTile.labelsUrl, { maxZoom: 19 }).addTo(map);
      labelsLayerRef.current = labelsLayer;
    }

    const markersLayer = L.layerGroup().addTo(map);
    const routesLayer = L.layerGroup().addTo(map);

    markersLayerRef.current = markersLayer;
    routesLayerRef.current = routesLayer;
    mapInstanceRef.current = map;

    map.on('click', (e) => {
      setDestinationCoords([e.latlng.lat, e.latlng.lng]);
    });

    setTimeout(() => {
      map.invalidateSize();
    }, 250);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Tile Layer
  useEffect(() => {
    const L = getLeaflet();
    if (!L || !mapInstanceRef.current || !tileLayerRef.current) return;
    const activeTile = TILE_LAYERS[currentTileKey];

    mapInstanceRef.current.removeLayer(tileLayerRef.current);
    if (labelsLayerRef.current) {
      mapInstanceRef.current.removeLayer(labelsLayerRef.current);
      labelsLayerRef.current = null;
    }

    tileLayerRef.current = L.tileLayer(activeTile.url, {
      maxZoom: 19,
      attribution: activeTile.attribution
    }).addTo(mapInstanceRef.current);

    if (activeTile.labelsUrl) {
      labelsLayerRef.current = L.tileLayer(activeTile.labelsUrl, { maxZoom: 19 }).addTo(
        mapInstanceRef.current
      );
    }
  }, [currentTileKey]);

  // Update Hazard Markers and Popups
  useEffect(() => {
    const L = getLeaflet();
    if (!L || !mapInstanceRef.current || !markersLayerRef.current) return;
    const markersLayer = markersLayerRef.current;
    markersLayer.clearLayers();

    // 1. User Live GPS Location Marker
    if (userLocation) {
      const userIcon = L.divIcon({
        className: 'leaflet-user-gps-marker',
        html: `
          <div class="user-pulse-marker">
            <div class="user-pulse-dot"></div>
            <div class="user-pulse-ring"></div>
          </div>
        `,
        iconSize: [24, 24],
        iconAnchor: [12, 12]
      });

      L.marker([userLocation.latitude, userLocation.longitude], { icon: userIcon })
        .bindPopup('<b>📍 Your Live Location</b><br/>GPS Accuracy: ±' + Math.round(userLocation.accuracyMeters || 5) + 'm')
        .addTo(markersLayer);
    }

    // 2. Origin & Destination Markers
    const originIcon = L.divIcon({
      className: 'leaflet-route-endpoint-marker',
      html: `<div class="endpoint-marker origin">🟢 START</div>`,
      iconSize: [60, 24],
      iconAnchor: [30, 24]
    });
    L.marker(startCoords, { icon: originIcon }).addTo(markersLayer);

    const destIcon = L.divIcon({
      className: 'leaflet-route-endpoint-marker',
      html: `<div class="endpoint-marker destination">🏁 DEST</div>`,
      iconSize: [60, 24],
      iconAnchor: [30, 24]
    });
    L.marker(destinationCoords, { icon: destIcon })
      .bindPopup('<b>🏁 Destination Point</b><br/>(Click anywhere on map to reposition)')
      .addTo(markersLayer);

    // 3. Crowdsourced Hazard Markers
    hazards.forEach((hazard) => {
      const config = HAZARD_CONFIG[hazard.type] || HAZARD_CONFIG.BROKEN_BRIDGE;
      const isSelected = selectedHazard && selectedHazard.id === hazard.id;

      const customIcon = L.divIcon({
        className: 'leaflet-custom-hazard-marker',
        html: `
          <div class="hazard-pin-bubble ${hazard.severity.toLowerCase()} ${isSelected ? 'selected' : ''}" style="border-color: ${config.color};">
            <span class="hazard-emoji">${config.icon}</span>
          </div>
        `,
        iconSize: [36, 36],
        iconAnchor: [18, 36],
        popupAnchor: [0, -36]
      });

      const popupContent = document.createElement('div');
      popupContent.className = 'leaflet-hazard-popup-card';
      popupContent.innerHTML = `
        <div class="popup-header" style="border-left: 4px solid ${config.color}">
          <h4>${config.icon} ${hazard.title}</h4>
          <span class="badge ${hazard.severity.toLowerCase()}">${hazard.severity}</span>
        </div>
        <p class="popup-desc">${hazard.description}</p>
        <div class="popup-meta">
          <span>🛡️ AI Conf: ${((hazard.aiConfidence || 0.95) * 100).toFixed(0)}%</span>
          <span>👍 ${hazard.upvotes} Upvotes</span>
        </div>
        <button class="popup-btn-inspect">View Ground Truth Proof</button>
      `;

      popupContent.querySelector('.popup-btn-inspect').onclick = () => {
        if (onSelectHazard) onSelectHazard(hazard);
      };

      const marker = L.marker([hazard.latitude, hazard.longitude], { icon: customIcon })
        .bindPopup(popupContent)
        .addTo(markersLayer);

      marker.on('click', () => {
        if (onSelectHazard) onSelectHazard(hazard);
      });
    });
  }, [hazards, selectedHazard, userLocation, destinationCoords]);

  // Real-World Road Snapped Dynamic Routing
  useEffect(() => {
    const L = getLeaflet();
    if (!L || !mapInstanceRef.current || !routesLayerRef.current) return;
    const routesLayer = routesLayerRef.current;
    routesLayer.clearLayers();

    let isMounted = true;

    async function computeAndRenderRoutes() {
      const routeData = await DynamicRoutingService.computeVehicleRoutes({
        start: startCoords,
        destination: destinationCoords,
        vehicleType: selectedVehicle,
        activeHazards: hazards
      });

      if (!isMounted || !mapInstanceRef.current) return;

      if (onRouteCalculated) {
        onRouteCalculated(routeData);
      }

      const isSmallVehicle = selectedVehicle === 'BICYCLE' || selectedVehicle === 'MOTORCYCLE';

      if (activeRouteType === 'BLOCKED') {
        // 1. Red Blocked Naive Path
        L.polyline(routeData.naiveBlockedRoute.points, {
          color: '#ef4444',
          weight: 6,
          opacity: 0.85,
          dashArray: '10, 10'
        }).addTo(routesLayer);

        const brokenBridge = hazards.find((h) => h.type === 'BROKEN_BRIDGE') || hazards[0];
        if (brokenBridge) {
          L.circle([brokenBridge.latitude, brokenBridge.longitude], {
            radius: 120,
            color: '#ef4444',
            fillColor: '#ef4444',
            fillOpacity: 0.35,
            weight: 2
          }).addTo(routesLayer);
        }
      } else if (isSmallVehicle) {
        // 2. Cyan Glowing Small Vehicle Shortcut (Cycle / Bike Narrow Alley & Footbridge Route)
        L.polyline(routeData.smallVehicleRoute.points, {
          color: '#06b6d4',
          weight: 6,
          opacity: 0.95,
          lineCap: 'round'
        }).addTo(routesLayer);

        const shortcutPin = L.divIcon({
          className: 'leaflet-bypass-pin',
          html: `<div class="bypass-badge cycle">🚲 NARROW ALLEY & FOOTBRIDGE SHORTCUT (-${routeData.smallVehicleRoute.timeSavedMins} MINS)</div>`,
          iconSize: [230, 24],
          iconAnchor: [115, 12]
        });
        L.marker(routeData.smallVehicleRoute.points[3], { icon: shortcutPin }).addTo(routesLayer);
      } else {
        // 3. Recommended Smooth Expressway / Flyover Route (Green Glowing Line)
        L.polyline(routeData.primaryRoute.points, {
          color: '#22c55e',
          weight: 6,
          opacity: 0.95,
          lineCap: 'round'
        }).addTo(routesLayer);

        const flyoverWaypoint = routeData.primaryRoute.points[Math.floor(routeData.primaryRoute.points.length / 2)];
        const flyoverIcon = L.divIcon({
          className: 'leaflet-bypass-pin',
          html: `<div class="bypass-badge flyover">▲ ELEVATED HIGHWAY FLYOVER</div>`,
          iconSize: [180, 24],
          iconAnchor: [90, 12]
        });
        L.marker(flyoverWaypoint, { icon: flyoverIcon }).addTo(routesLayer);
      }
    }

    computeAndRenderRoutes();

    return () => {
      isMounted = false;
    };
  }, [activeRouteType, hazards, selectedVehicle, destinationCoords]);

  const handleCenterOnUser = () => {
    const L = getLeaflet();
    if (!L || !mapInstanceRef.current) return;
    const center = userLocation
      ? [userLocation.latitude, userLocation.longitude]
      : [12.9752, 77.5998];
    mapInstanceRef.current.flyTo(center, 15, { duration: 1.2 });
  };

  return (
    <div className="leaflet-map-wrapper">
      <div ref={mapContainerRef} className="leaflet-map-container" />

      {/* Floating Map Controls */}
      <div className="leaflet-floating-toolbar">
        <div className="tile-selector-group">
          <Layers size={14} color="#38bdf8" />
          <select
            value={currentTileKey}
            onChange={(e) => setCurrentTileKey(e.target.value)}
            className="leaflet-tile-select"
            title="Switch Map Mode (Satellite, Dark, OSM, Terrain)"
          >
            {Object.entries(TILE_LAYERS).map(([key, item]) => (
              <option key={key} value={key}>
                {item.name}
              </option>
            ))}
          </select>
        </div>

        <button
          className="leaflet-control-btn"
          onClick={handleCenterOnUser}
          title="Recenter on GPS Location"
        >
          <Crosshair size={16} />
        </button>
      </div>

      <div className="map-interaction-hint">
        <MapPin size={12} color="#38bdf8" />
        <span>Click anywhere on the map to set a new Destination</span>
      </div>
    </div>
  );
}
