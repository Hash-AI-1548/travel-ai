import React from 'react';
import { ArrowUpRight, ArrowDownRight, AlertTriangle, ShieldCheck, Layers, Compass } from 'lucide-react';

export const FlyoverGuidanceCard = ({ guidance, activeRouteId }) => {
  if (!guidance) return null;

  const isTakeFlyover = guidance.action === 'TAKE_FLYOVER';
  const isDoNotEnter = guidance.action === 'DO_NOT_ENTER';

  return (
    <div className={`flyover-guidance-card ${isTakeFlyover ? 'take-flyover' : 'service-road'}`}>
      <div className="flyover-header">
        <div className="flyover-badge">
          <Layers size={15} />
          <span>FLYOVER / ELEVATED SPLIT GUIDANCE</span>
        </div>
        <span className="clearance-tag">Clearance: {guidance.clearanceMeters || '4.5'}m</span>
      </div>

      <div className="flyover-visual-split">
        {/* Flyover Upper Level Path */}
        <div className={`split-tier upper ${isTakeFlyover ? 'selected-tier' : ''}`}>
          <div className="tier-icon">
            <ArrowUpRight size={20} />
          </div>
          <div className="tier-info">
            <h5>▲ ELEVATED EXPRESSWAY FLYOVER</h5>
            <p>Right 2 Lanes • Smooth Highway • Bypasses ground floods & bottlenecks</p>
          </div>
          {isTakeFlyover && <span className="active-pill">RECOMMENDED ROUTE</span>}
        </div>

        {/* Divider / Height clearance pillar */}
        <div className="split-divider">
          <div className="pillar"></div>
          <span>RAMP SPLIT IN 250M</span>
          <div className="pillar"></div>
        </div>

        {/* Lower Service Road Path */}
        <div className={`split-tier lower ${!isTakeFlyover && !isDoNotEnter ? 'selected-tier' : ''}`}>
          <div className="tier-icon">
            <ArrowDownRight size={20} />
          </div>
          <div className="tier-info">
            <h5>▼ GROUND SERVICE ROAD / UNDERPASS</h5>
            <p>Left Lane • Local Access • Caution: Lower speed & pedestrian crossing</p>
          </div>
          {!isTakeFlyover && !isDoNotEnter && <span className="active-pill bumpy">SHORTCUT ACTIVE</span>}
        </div>
      </div>

      <div className="flyover-instruction-bar">
        {isTakeFlyover ? (
          <div className="instruction-msg success">
            <ShieldCheck size={18} />
            <span><b>Keep Right:</b> Take the elevated flyover ramp to safely pass over the damaged river bridge.</span>
          </div>
        ) : (
          <div className="instruction-msg warning">
            <AlertTriangle size={18} />
            <span><b>Stay on Ground Level:</b> Taking lower ground connection for the unpaved shortcut.</span>
          </div>
        )}
      </div>
    </div>
  );
};
