/**
 * Core Type Definitions & Enums for Location Update & Intelligent Navigation Module
 */

export const HAZARD_TYPES = {
  BROKEN_BRIDGE: 'BROKEN_BRIDGE',
  ROAD_COLLAPSE: 'ROAD_COLLAPSE',
  FLOODING: 'FLOODING',
  LANDSLIDE_OBSTRUCTION: 'LANDSLIDE_OBSTRUCTION',
  TEMPORARY_BLOCKADE: 'TEMPORARY_BLOCKADE',
  NEW_ROAD_OPENED: 'NEW_ROAD_OPENED',
  ROAD_SURFACE_DAMAGED: 'ROAD_SURFACE_DAMAGED',
  NARROW_PASSAGE: 'NARROW_PASSAGE',
  LOW_CLEARANCE_BARRIER: 'LOW_CLEARANCE_BARRIER',
  FLYOVER_RAMP_CLOSED: 'FLYOVER_RAMP_CLOSED'
};

export const SEVERITY_LEVELS = {
  IMPASSABLE: 'IMPASSABLE',
  HIGH_RISK: 'HIGH_RISK',
  SLOWDOWN: 'SLOWDOWN',
  INFORMATIONAL: 'INFORMATIONAL'
};

export const VEHICLE_TYPES = {
  CAR_SEDAN: {
    id: 'CAR_SEDAN',
    label: 'Car / Sedan',
    icon: '🚗',
    osrmProfile: 'driving',
    minRoadWidthMeters: 2.2,
    maxHeightMeters: 1.8,
    speedMultiplier: 1.0,
    canUseAlleys: false
  },
  SUV_4X4: {
    id: 'SUV_4X4',
    label: 'SUV / 4x4',
    icon: '🚙',
    osrmProfile: 'driving',
    minRoadWidthMeters: 2.4,
    maxHeightMeters: 2.2,
    speedMultiplier: 1.05,
    canUseAlleys: false
  },
  HEAVY_TRUCK: {
    id: 'HEAVY_TRUCK',
    label: 'Heavy Truck / Bus',
    icon: '🚛',
    osrmProfile: 'driving',
    minRoadWidthMeters: 3.5,
    maxHeightMeters: 4.2,
    speedMultiplier: 0.75,
    canUseAlleys: false
  },
  MOTORCYCLE: {
    id: 'MOTORCYCLE',
    label: 'Bike / Scooter',
    icon: '🏍️',
    osrmProfile: 'bike',
    minRoadWidthMeters: 1.2,
    maxHeightMeters: 1.5,
    speedMultiplier: 1.3,
    canUseAlleys: true
  },
  BICYCLE: {
    id: 'BICYCLE',
    label: 'Cycle / Bicycle',
    icon: '🚲',
    osrmProfile: 'bike',
    minRoadWidthMeters: 0.8,
    maxHeightMeters: 1.2,
    speedMultiplier: 0.85,
    canUseAlleys: true
  }
};

export const FLYOVER_ACTIONS = {
  TAKE_FLYOVER: 'TAKE_FLYOVER',
  TAKE_SERVICE_ROAD: 'TAKE_SERVICE_ROAD',
  UNDERPASS: 'UNDERPASS',
  AT_GRADE: 'AT_GRADE'
};

export const CAPTURE_MODES = {
  PHOTO: 'PHOTO',
  UPLOAD: 'UPLOAD',
  PANORAMA: 'PANORAMA',
  VIDEO: 'VIDEO'
};

export const VERIFICATION_STATUS = {
  AI_VERIFIED: 'AI_VERIFIED',
  COMMUNITY_VERIFIED: 'COMMUNITY_VERIFIED',
  PENDING_REVIEW: 'PENDING_REVIEW',
  REJECTED: 'REJECTED'
};
