import React, { useState } from 'react';
import { MapPin, Navigation, Compass, AlertTriangle, ShieldCheck } from 'lucide-react';
import { LocationUpdateTab } from './modules/location_update/src/index.js';
import './modules/location_update/src/styles/locationUpdate.css';

export default function App() {
  const [activeTab, setActiveTab] = useState('LOCATION_UPDATE');

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', backgroundColor: '#090d16' }}>
      {/* Top App Header */}
      <header style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: '14px 28px',
        backgroundColor: '#0f172a',
        borderBottom: '1px solid #1e293b'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Compass size={28} color="#38bdf8" />
          <div>
            <h2 style={{ margin: 0, fontSize: '18px', color: '#f8fafc' }}>TRAVEL-AI NAVIGATOR</h2>
            <span style={{ fontSize: '11px', color: '#94a3b8' }}>Autonomous Rerouting & Ground-Truth Intelligence</span>
          </div>
        </div>

        {/* Top Navigation Tabs */}
        <nav style={{ display: 'flex', gap: '8px' }}>
          <button
            onClick={() => setActiveTab('PLANNER')}
            style={{
              padding: '8px 16px',
              borderRadius: '8px',
              border: '1px solid #334155',
              backgroundColor: activeTab === 'PLANNER' ? '#38bdf8' : '#1e293b',
              color: activeTab === 'PLANNER' ? '#0f172a' : '#94a3b8',
              fontWeight: 600,
              cursor: 'pointer'
            }}
          >
            🧭 Trip Planner
          </button>
          <button
            onClick={() => setActiveTab('NAVIGATION')}
            style={{
              padding: '8px 16px',
              borderRadius: '8px',
              border: '1px solid #334155',
              backgroundColor: activeTab === 'NAVIGATION' ? '#38bdf8' : '#1e293b',
              color: activeTab === 'NAVIGATION' ? '#0f172a' : '#94a3b8',
              fontWeight: 600,
              cursor: 'pointer'
            }}
          >
            🚗 Live Navigation
          </button>
          <button
            onClick={() => setActiveTab('LOCATION_UPDATE')}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              padding: '8px 16px',
              borderRadius: '8px',
              border: '1px solid #0284c7',
              background: activeTab === 'LOCATION_UPDATE'
                ? 'linear-gradient(135deg, #0284c7, #2563eb)'
                : '#1e293b',
              color: '#ffffff',
              fontWeight: 600,
              cursor: 'pointer',
              boxShadow: activeTab === 'LOCATION_UPDATE' ? '0 0 12px rgba(56, 189, 248, 0.4)' : 'none'
            }}
          >
            <AlertTriangle size={15} color="#f59e0b" />
            📍 LOCATION UPDATE
          </button>
        </nav>
      </header>

      {/* Main Tab Body */}
      <div style={{ flex: 1, padding: '20px', maxWidth: '1300px', margin: '0 auto', width: '100%', boxSizing: 'border-box' }}>
        {activeTab === 'PLANNER' && (
          <div style={{
            padding: '40px',
            background: '#111827',
            borderRadius: '12px',
            textAlign: 'center',
            border: '1px solid #1f2937'
          }}>
            <h3>AI Trip Planner</h3>
            <p style={{ color: '#94a3b8' }}>Dynamic itinerary generator with road obstacle safety checks.</p>
          </div>
        )}

        {activeTab === 'NAVIGATION' && (
          <div style={{
            padding: '40px',
            background: '#111827',
            borderRadius: '12px',
            textAlign: 'center',
            border: '1px solid #1f2937'
          }}>
            <h3>Turn-by-Turn GPS Navigation</h3>
            <p style={{ color: '#94a3b8' }}>Real-time guidance with instant ground-truth road closure notifications.</p>
          </div>
        )}

        {activeTab === 'LOCATION_UPDATE' && (
          <LocationUpdateTab />
        )}
      </div>
    </div>
  );
}
